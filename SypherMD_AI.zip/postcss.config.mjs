const config = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#1e40af", // Blue-800
      },
    },
  },
  plugins: ["@tailwindcss/postcss"],
};
export default config;
