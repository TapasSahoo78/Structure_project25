"use client"
import type { FC, ReactNode } from "react";
import { ThemeProvider } from "@mui/material"
import theme from "../utils/theme"

export const Styledroot: FC<{ children: ReactNode }> = ({ children }) => (
      <ThemeProvider theme={theme}>{children}</ThemeProvider>
);