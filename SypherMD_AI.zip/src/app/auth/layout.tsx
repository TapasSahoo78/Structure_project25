
"use client"
// import { useRouter } from "next/navigation";
import "../../styles/auth.css";
import "../../styles/globals.css"
// import { useEffect } from "react";

export default function PublicLayout({ children }: { children: React.ReactNode }) {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 ">
            <main className="flex-grow w-full    ">{children}</main>
        </div>
    );
}



// "use client";

// import { Provider } from "react-redux";
// import { store } from "@/redux/store";
// import { Styledroot } from "../Styledroot";
// import Box from '@mui/material/Box';

// import "../globals.css";


// export default function PublicLayout({
//   children,
// }: Readonly<{
//   children: React.ReactNode;
// }>) {
//   return (
//     <html lang="en">
//       <body>
//         <Provider store={store}>
//             <Styledroot>
//             <Box className=" flex-grow w-full h-100  p-6" sx={{ display: 'flex',justifyContent:'center', backgroundColor:"#e4dfdfff", height:"100vh" }}>
           
//                 {/* <main className="flex-grow w-full h-100 max-w-4xl p-6"> */}
//                     {children}
//                     {/* </main> */}
               
//           </Box>
//             </Styledroot>
//         </Provider>
//       </body>
//     </html>
//   );
// }
