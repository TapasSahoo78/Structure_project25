'use client';
import * as React from 'react';
import { useDispatch } from 'react-redux';
// import { loginRequest } from '@/redux/slices/authSlice';

import { IMAGE } from '../../../utils/ThemeImage';
import Box from '@mui/material/Box';
import Image from 'next/image';
// import { Card } from '@mui/material';
import IconButton from '@mui/material/IconButton';
// import Input from '@mui/material/Input';
// import FilledInput from '@mui/material/FilledInput';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
// import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
// import { alpha, styled } from '@mui/material/styles';
// import { green } from '@mui/material/colors';
// import Switch from '@mui/material/Switch';
// import Button from '@mui/material/Button';
import Link from 'next/link';
import Grid from '@mui/material/Grid';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';

import "../../../styles/auth.css"
import "./register.css"


import PrimaryButton from '../../../components/shared/PrimaryButton';

export default function RegisterPage() {
  // const dispatch = useDispatch();

  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  // const handleMouseDownPassword = (event) => {
  //   event.preventDefault();
  // };


  // const GreenSwitch = styled(Switch)(({ theme }) => ({
  //   '& .MuiSwitch-switchBase.Mui-checked': {
  //     color: green[600],
  //     '&:hover': {
  //       backgroundColor: alpha(green[600], theme.palette.action.hoverOpacity),
  //     },
  //   },
  //   '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
  //     backgroundColor: green[600],
  //   },
  // }));


  // const handleLogin = () => {
  //   dispatch(loginRequest({ username: 'Admin', password: '1234' }));
  // };

  return (
    // <div className="bg-white shadow-md rounded p-6 max-w-sm mx-auto">
    //   <h2 className="text-xl font-bold mb-4">Login</h2>
    //   <button
    //     className="bg-blue-600 text-white px-4 py-2 rounded"
    //     onClick={handleLogin}
    //   >
    //     Login as Admin
    //   </button>
    // </div>

    <Box className="authBg" sx={{ display: 'flex', flexDirection: "column" }}>
      <Link href="#" className='logo'>
        <Image src={IMAGE.AuthLogo} alt="" />
      </Link>

      <div className="authContent registerContent">
        <div className="authlogo">

          <div className='authPage'>
            <h1>Create new account</h1>
            <h6>Please fill all the details</h6>
            <Grid container spacing={2}>
              <Grid size={6}>
                <TextField className='w-full textFieldInput'
                  id="outlined-multiline-flexible"
                  label="First Name"
                  multiline
                  maxRows={4}
                />
              </Grid>
              <Grid size={6}>
                <TextField className='w-full textFieldInput'
                  id="outlined-multiline-flexible"
                  label="Last Name"
                  multiline
                  maxRows={4}
                />
              </Grid>
              <Grid size={6}>
                <TextField className='w-full textFieldInput'
                  id="outlined-multiline-flexible"
                  label="Email ID"
                  multiline
                  maxRows={4}
                />
              </Grid>
              <Grid size={6}>
                <FormControl className='w-full textFieldInput' sx={{ m: 0, width: '100%' }} variant="outlined">
                  <InputLabel htmlFor="outlined-adornment-password">
                    Create password

                  </InputLabel>
                  <OutlinedInput
                    id="outlined-adornment-password"
                    type={showPassword ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment className='eyeIcon' position="end">
                        <IconButton
                          aria-label={
                            showPassword
                              ? 'hide the password'
                              : 'display the password'
                          }
                          onClick={handleClickShowPassword}
                          edge="end"
                        >
                          {showPassword ? (
                            <VisibilityOffOutlinedIcon />
                          ) : (
                            <VisibilityOutlinedIcon />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="Create password"
                  />
                </FormControl>
              </Grid>
              <Grid size={12} >
                <div className='loginFooter'>



                  <FormControlLabel className='termCondition'
                    value="female"
                    control={<Radio />}
                    label={
                      <div className='labelAgreed' >
                        I agreed {" "}
                        <Link href="#" target="_blank">
                          terms and conditions
                        </Link>
                      </div>
                    }
                  />
                  <PrimaryButton buttonName="Sign In" ></PrimaryButton>

                  <Link href="/">Forgot Password? </Link>
                </div>
              </Grid>
            </Grid>
          </div>

        </div>
        <div className="authFooter">
          <p>Already have an account? <Link href="/auth/login">SIGN IN</Link></p>
          <div className="privacy">

            <Link style={{ border: "unset" }} href="#"> Terms and conditions</Link>

          </div>
        </div>
      </div>
    </Box>

  );
}
