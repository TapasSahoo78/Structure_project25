'use client';

import { Provider } from 'react-redux';
import { store } from '@/redux/store';
// import { Styledroot } from './Styledroot';
import '../styles/globals.css';
// import { ThemeProvider } from '@mui/material';
// import theme from '../utils/theme';
import '../utils/theme';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <Provider store={store}>
          {/* <ThemeProvider theme={theme}> */}
          {children}
          {/* </ThemeProvider> */}
        </Provider>
      </body>
    </html>
  );
}
