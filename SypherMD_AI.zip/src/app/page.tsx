import '../styles/page.css';
import LoginPage from './auth/login/page';

export default function HomePage() {
  return (
    <LoginPage/>
  );
}
