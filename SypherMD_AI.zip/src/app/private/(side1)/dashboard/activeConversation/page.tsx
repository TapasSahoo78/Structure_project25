"use client"

import { useState, useMemo, useCallback } from "react"
import { Minimize2, Pause, Square } from "lucide-react"

interface ConversationMessage {
  id: number
  text: string
  speaker: "doctor" | "patient"
}

interface ActiveConversationProps {
  onEndConversation: () => void
}

export default function ActiveConversation({ onEndConversation }: ActiveConversationProps) {
  const [isRecording, setIsRecording] = useState(true)
  const [currentTime] = useState("10:56") // Consider using useRef for mutable values that don't trigger re-renders

  // Memoized sample conversation data to prevent recreation on every render
  const messages: ConversationMessage[] = useMemo(() => [
    { id: 1, text: "Good Morning, doctor. May I come in?", speaker: "patient" },
    { id: 2, text: "Good Morning, doctor. May I come in?", speaker: "patient" },
    { id: 3, text: "Good Morning. How are you? You do look quite pale this morning.", speaker: "doctor" },
    { id: 4, text: "Good Morning. How are you? You do look quite pale this morning.", speaker: "doctor" },
    {
      id: 5,
      text: "Yes, doctor. I've not been feeling well for the past few days. I've been having a stomach ache for a few days and feeling a bit dizzy since yesterday.",
      speaker: "patient",
    },
    {
      id: 6,
      text: "Yes, doctor. I've not been feeling well for the past few days. I've been having a stomach ache for a few days and feeling a bit dizzy since yesterday.",
      speaker: "patient",
    },
    { id: 7, text: "Good Morning. How are you? You do look quite pale this morning.", speaker: "doctor" },
  ], [])

  // Use useCallback to memoize functions and prevent unnecessary re-renders
  const toggleRecording = useCallback(() => {
    setIsRecording(prev => !prev)
  }, [])

  const stopRecording = useCallback(() => {
    setIsRecording(false)
    onEndConversation()
  }, [onEndConversation])

  // Memoized waveform bars for better performance
  const waveformBars = useMemo(() =>
    Array.from({ length: 60 }).map((_, i) => (
      <div
        key={i}
        className={`w-1 bg-white rounded-full transition-all duration-150 ${isRecording && i < 30 ? "animate-pulse" : ""
          }`}
        style={{
          height: `${Math.random() * 40 + 10}px`,
          opacity: isRecording && i < 30 ? 1 : 0.6,
        }}
      />
    )), [isRecording]
  )

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
      <div className="w-full max-w-4xl bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        {/* Header */}
        <header className="flex items-center justify-between p-6 border-b border-gray-200 bg-white/95">
          <h2 className="text-slate-700 text-xl font-semibold">Current conversation</h2>
          <button
            onClick={onEndConversation}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-lg hover:bg-gray-100"
            aria-label="Minimize conversation"
          >
            <Minimize2 className="w-5 h-5" />
          </button>
        </header>

        {/* Conversation Messages */}
        <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
          {messages.map((message) => (
            <div key={message.id} className="flex items-start gap-3 group">
              <div
                className={`w-1 h-full min-h-[20px] rounded-full flex-shrink-0 ${message.speaker === "doctor" ? "bg-green-500" : "bg-blue-500"
                  }`}
                aria-hidden="true"
              />
              <p className="text-gray-700 leading-relaxed flex-1 text-sm md:text-base">
                {message.text}
              </p>
            </div>
          ))}
        </div>

        {/* Audio Controls */}
        <div className="p-6 border-t border-gray-200 bg-gray-50/50">
          <div className="bg-slate-600 rounded-lg p-4 flex items-center gap-4 shadow-md">
            {/* Waveform Visualization */}
            <div className="flex-1 flex items-center gap-1 h-12 justify-center">
              {waveformBars}
            </div>

            {/* Timer */}
            <div className="text-white font-mono text-lg min-w-[60px] text-center font-medium">
              {currentTime}
            </div>

            {/* Control Buttons */}
            <div className="flex gap-3">
              <button
                onClick={toggleRecording}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${isRecording
                    ? "bg-green-500 hover:bg-green-600 shadow-md"
                    : "bg-gray-500 hover:bg-gray-600 shadow-sm"
                  } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500`}
                aria-label={isRecording ? "Pause recording" : "Resume recording"}
              >
                <Pause className="w-6 h-6 text-white" />
              </button>

              <button
                onClick={stopRecording}
                className="w-12 h-12 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center transition-all duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                aria-label="Stop recording and end conversation"
              >
                <Square className="w-6 h-6 text-white fill-current" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}