"use client"

import { useState } from "react"
import { Mic, Send } from "lucide-react"

interface ConversationStarterProps {
  onStartConversation: () => void
}

export default function ConversationStarter({ onStartConversation }: ConversationStarterProps) {
  const [message, setMessage] = useState("")

  return (
    <>
      <style jsx>{`
        .circle-pulse {
          animation: circlePulse 2s cubic-bezier(0, 0, 0.2, 1) infinite;
        }
        
        .circle-pulse-delay-1 {
          animation: circlePulse 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          animation-delay: 0.5s;
        }
        
        .circle-pulse-delay-2 {
          animation: circlePulse 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          animation-delay: 1s;
        }
        
        .circle-pulse-delay-3 {
          animation: circlePulse 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          animation-delay: 1.5s;
        }
        
        .center-dot-pulse {
          animation: centerDotPulse 2s ease-in-out infinite;
        }
        
        @keyframes circlePulse {
          0% {
            transform: scale(0.8);
            opacity: 1;
          }
          50% {
            transform: scale(1.2);
            opacity: 0.3;
          }
          100% {
            transform: scale(1.4);
            opacity: 0;
          }
        }
        
        @keyframes centerDotPulse {
          0%, 100% {
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
          }
          50% {
            transform: translate(-50%, -50%) scale(1.2);
            opacity: 0.8;
          }
        }
      `}</style>

      <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
        <div className="w-full max-w-2xl bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-gray-500 text-lg mb-2">Hello, Indranil</h1>
            <h2 className="text-slate-800 text-2xl font-medium">Please start conversation & transcribing</h2>
          </div>

          <div className="flex justify-center mb-12">
            <div className="relative w-64 h-64">
              <div className="absolute inset-0 rounded-full border-2 border-blue-200 circle-pulse"></div>
              <div className="absolute inset-4 rounded-full border-2 border-cyan-300 circle-pulse-delay-1"></div>
              <div className="absolute inset-8 rounded-full border-2 border-blue-400 circle-pulse-delay-2"></div>
              <div className="absolute inset-12 rounded-full border-2 border-cyan-500 circle-pulse-delay-3"></div>

              <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full center-dot-pulse"></div>
            </div>
          </div>

          <div className="flex justify-center mb-12">
            <button
              onClick={onStartConversation}
              className="bg-slate-700 hover:bg-slate-800 text-white px-12 py-4 rounded-xl flex items-center gap-3 text-lg font-medium transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <Mic className="w-6 h-6" />
              Start Conversation
            </button>
          </div>

          {/* Input Field */}
          <div className="relative">
            <input
              type="text"
              placeholder="Ask here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-4 pr-20 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex gap-2">
              <button className="p-2 text-gray-400 hover:text-blue-500 transition-colors rounded-lg hover:bg-blue-50">
                <Send className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-400 hover:text-blue-500 transition-colors rounded-lg hover:bg-blue-50">
                <Mic className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
