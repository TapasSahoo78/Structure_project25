'use client';
import * as React from 'react';
// import { useDispatch } from 'react-redux';
// import { loginRequest } from '@/redux/slices/authSlice';

// import { IMAGE } from '@/utils/ThemeImage';
// import Box from '@mui/material/Box';
// import Image from 'next/image';
// import { Card } from '@mui/material';
// import IconButton from '@mui/material/IconButton';
// import Input from '@mui/material/Input';
// import FilledInput from '@mui/material/FilledInput';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import InputLabel from '@mui/material/InputLabel';
// import InputAdornment from '@mui/material/InputAdornment';
// import FormHelperText from '@mui/material/FormHelperText';
// import FormControl from '@mui/material/FormControl';
// import TextField from '@mui/material/TextField';

// import { alpha, styled } from '@mui/material/styles';
// import { green } from '@mui/material/colors';
// import Switch from '@mui/material/Switch';
// import Button from '@mui/material/Button';
// import Link from 'next/link';
// import Grid from '@mui/material/Grid';
// import PrimaryButton from '@/components/shared/PrimaryButton';



import ConversationStarter from './conversiationStarter/page';
import ActiveConversation from './activeConversation/page';


export default function dashbaord() {

   const [isConversationActive, setIsConversationActive] = React.useState(false)

  const handleStartConversation = () => {
    setIsConversationActive(true)
  }

  const handleEndConversation = () => {
    setIsConversationActive(false)
  }
  return (
    <div className="space-y-8">
      {!isConversationActive ? (
        <ConversationStarter onStartConversation={handleStartConversation} />
      ) : (
        <ActiveConversation onEndConversation={handleEndConversation} />
      )}

    
    </div>
  )
}
