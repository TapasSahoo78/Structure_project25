'use client';

import { Provider } from 'react-redux';
import { store } from '@/redux/store';
import '../../../styles/globals.css';
import Grid from '@mui/material/Grid';

import '@/utils/theme';
import SidebarDashbaord from '@/components/partials/SidebarDashboard';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <Provider store={store}>
          {/* <ThemeProvider theme={theme}> */}
         <Grid className="dashboardLayout" container spacing={2}>
          <Grid size={4}>
            <SidebarDashbaord/>
          </Grid>
          <Grid size={8}>
             {children}
          </Grid>

          </Grid>
         
          {/* </ThemeProvider> */}
     
        </Provider>
      </body>
    </html>
  );
}
