'use client';

import { Provider } from 'react-redux';
import { store } from '@/redux/store';
import '../../../styles/globals.css';
// import { ThemeProvider } from '@mui/material';
import '@/utils/theme';
import Sidebar from '@/components/partials/Sidebar';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <Provider store={store}>
          {/* <ThemeProvider theme={theme}> */}
          <Sidebar />
          {children}
          {/* </ThemeProvider> */}
        </Provider>
      </body>
    </html>
  );
}
