"use client";
import * as React from 'react';
import { useDispatch } from 'react-redux';
import { loginRequest } from '@/redux/slices/authSlice';

// import { IMAGE } from '../../../../utils/ThemeImage';
// import Box from '@mui/material/Box';
// import Image from 'next/image';
// import { Card } from '@mui/material';
// import IconButton from '@mui/material/IconButton';
// import Input from '@mui/material/Input';
// import FilledInput from '@mui/material/FilledInput';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import InputLabel from '@mui/material/InputLabel';
// import InputAdornment from '@mui/material/InputAdornment';
// import FormHelperText from '@mui/material/FormHelperText';
// import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';

import { alpha, styled } from '@mui/material/styles';
import { green } from '@mui/material/colors';
import Switch from '@mui/material/Switch';
// import Button from '@mui/material/Button';
// import Link from 'next/link';
import Grid from '@mui/material/Grid';
import PrimaryButton from '@/components/shared/PrimaryButton';




export default function profile() {

  const dispatch = useDispatch();

  // const [showPassword, setShowPassword] = React.useState(false);

  // const handleClickShowPassword = () => setShowPassword((show) => !show);

  const GreenSwitch = styled(Switch)(({ theme }) => ({
    '& .MuiSwitch-switchBase.Mui-checked': {
      color: green[600],
      '&:hover': {
        backgroundColor: alpha(green[600], theme.palette.action.hoverOpacity),
      },
    },
    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
      backgroundColor: green[600],
    },
  }));

  // const handleLogin = () => {
  //   dispatch(loginRequest({ username: 'Admin', password: '1234' }));
  // };

  return (
    <div className="dashboard-page" style={{ width: "100%" }}>
      <div className="authContent card bg-white">
        <div className="FormBoxHeight">
          <div className="authlogo">
            <div className='authPage '>
              <h6>Please share the following details</h6>


              <Grid container spacing={2}>
                <Grid size={6}>
                  <TextField className='w-full textFieldInput'
                    id="outlined-multiline-flexible"
                    label="NPI"
                    multiline
                    maxRows={4}
                  />
                </Grid>
                <Grid size={6}>
                  <TextField className='w-full textFieldInput'
                    id="outlined-multiline-flexible"
                    label="License"
                    multiline
                    maxRows={4}
                  />
                </Grid>

                <Grid size={6}>
                  <TextField className='w-full textFieldInput'
                    id="outlined-multiline-flexible"
                    label="State"
                    multiline
                    maxRows={4}
                  />
                </Grid>
                <Grid size={6}>
                  <TextField className='w-full textFieldInput'
                    id="outlined-multiline-flexible"
                    label="DEA"
                    multiline
                    maxRows={4}
                  />
                </Grid>

                <Grid size={12}>
                  <TextField className='w-full textFieldInput'
                    id="outlined-multiline-flexible"
                    label="Practice name"
                    multiline
                    maxRows={4}
                  />
                </Grid>

                <Grid size={12}>
                  <TextField
                    fullWidth
                    id="practice-name"
                    label="Practice name"
                    multiline
                    rows={4} // This helps control initial height
                    inputProps={{
                      style: {
                        minHeight: '20px', // Ensures minimum height
                        padding: '10px',    // Optional: adjust padding
                      },
                    }}
                    variant="outlined"
                    className="textFieldInput"
                  />
                </Grid>

              </Grid>

            </div>
          </div>
          <div className='loginFooter'>
            <PrimaryButton buttonName="Save & Continue" ></PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}