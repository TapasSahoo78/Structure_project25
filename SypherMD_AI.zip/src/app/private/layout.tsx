'use client';

import { useSelector } from 'react-redux';
import { RootState } from '@/redux/store';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import Navbar from '@/components/partials/Navbar';
import '../../styles/private.css';

export default function PrivateLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated } = useSelector((state: RootState) => state.auth);
  const router = useRouter();

  // useEffect(() => {
  //   if (!isAuthenticated) {
  //     router.push('/public/login');
  //   }
  // }, [isAuthenticated, router]);

  // if (!isAuthenticated) {
  //   return null; // or loading spinner
  // }
  return (
    <div className="dashbordMain">
      <Navbar />
      <div
        className="dashbordInner"
        style={{ padding: '116px 20px 20px 20px' }}
      >
        <div className="dashbaordRighSide">{children}</div>
      </div>
    </div>
  );
}
