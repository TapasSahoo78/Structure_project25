export default function Footer() {
    return (
        <footer className="w-full p-4 bg-gray-200 text-center">
            &copy; 2025 My Page Footer
        </footer>
    );
}