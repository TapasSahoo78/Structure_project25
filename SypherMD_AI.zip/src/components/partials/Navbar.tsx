"use client";

import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import Image from 'next/image';
import Link from 'next/link';
import { IMAGE } from '@/utils/ThemeImage';
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';

// Types
interface Props {
  window?: () => Window;
}

// Nav item structure
const navItems = [
  {
    type: 'link',
    label: 'FAQ',
   icon: (
      <Image
        src={IMAGE.support} 
        alt="FAQ"
        // width={20}
        // height={20}
      />
    ),
  },
  {
    type: 'link',
    label: 'Support',
    icon: (
        <Image
          src={IMAGE.question} 
          alt="FAQ"
          // width={20}
          // height={20}
        />
      ),
  },
];

const profileOptions = ['Profile', 'Logout'];

const drawerWidth = 240;

export default function Navbar(props: Props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const isMenuOpen = Boolean(anchorEl);

  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };

  const handleProfileClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleOptionClick = (option: string) => {
    console.log(option);
    handleMenuClose();
  };

  // Drawer (Mobile) Content
  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 2 }}>
        MUI
      </Typography>
      <Divider />
      <List>
        {navItems.map((item) => (
          <ListItem key={item.label} disablePadding>
            <ListItemButton sx={{ justifyContent: 'center' }}>
              <ListItemIcon sx={{ justifyContent: 'center' }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItemButton>
          </ListItem>
        ))}
        <ListItem disablePadding>
          <ListItemButton
            sx={{ justifyContent: 'center' }}
            onClick={handleProfileClick}
          >
            <ListItemIcon>
              <Avatar
                alt="User Name"
                src="/path/to/avatar.jpg" // Replace with dynamic image
                sx={{ width: 32, height: 32 }}
              />
            </ListItemIcon>
            <ListItemText primary="Indranil Sen" />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );

  // For mobile drawer container
  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar component="nav" className="appBarTop" sx={{ backgroundColor: '#fff', color: '#000' }}>
        <Toolbar className="appBarTopContet" sx={{ display: 'flex', justifyContent: 'space-between' }}>
          {/* Mobile Menu Button */}
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon sx={{ color: '#000' }} />
          </IconButton>

          {/* Logo (visible on desktop) */}
          <Box
            className="sideBarLogo"
            sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
          >
            <Link href="#" className="logo">
              <Image src={IMAGE.NavLogo} alt="Logo" width={180} height={40} />
            </Link>
          </Box>

          {/* Nav Items + Profile Dropdown (Desktop) */}
          <Box sx={{ display: { xs: 'none', sm: 'flex' }, alignItems: 'center', gap: 2 }}>
            {navItems.map((item) => (
              <Button key={item.label} sx={{ color: '#000', textTransform: 'none' }}>
                <Box sx={{ mr: 0.5 }}>{item.icon}</Box>
                {item.label}
              </Button>
            ))}

            {/* Profile Dropdown */}
            <Button
              sx={{ color: '#000', textTransform: 'none', gap: 1 }}
              onClick={handleProfileClick}
            >
              <Avatar
                alt="Indranil Sen "
                src="/path/to/avatar.jpg" // Replace with dynamic user image
                sx={{ width: 32, height: 32, backgroundColor: '#2D495B' }}
              />
              <Typography variant="body2">Indranil Sen <span><ExpandMoreOutlinedIcon /></span></Typography>
            </Button>

            {/* Dropdown Menu */}
            <Menu
              anchorEl={anchorEl}
              open={isMenuOpen}
              onClose={handleMenuClose}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
            >
              {profileOptions.map((option) => (
                <MenuItem key={option} onClick={() => handleOptionClick(option)}>
                  {option}
                </MenuItem>
              ))}
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <nav>
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
      </nav>

      {/* Optional: Main content placeholder */}
      {/* <Box component="main" sx={{ p: 3 }}>
        <Toolbar />
        <Typography paragraph>Content goes here.</Typography>
      </Box> */}
    </Box>
  );
}