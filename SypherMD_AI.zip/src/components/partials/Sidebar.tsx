import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import "./layout.css"
import Image from 'next/image';
import { IMAGE } from '@/utils/ThemeImage';


export default function Sidebar() {
  return (
    <div className="sidebar" >
        <h4 className='sidebarHeader'>Hello, Indranil</h4>
        <ul className="SidebarList" >
          <li><KeyboardDoubleArrowRightIcon/> Say hello to Freed, the AI-powered scribe transforming the way you document clinical notes. Personalization starts now— just share a few details.</li>
          <li><KeyboardDoubleArrowRightIcon/>Start your conversation and stop conversation when you want and get your SOAP.</li>
          <li><KeyboardDoubleArrowRightIcon/>Remove your unwanted SOAP any time.</li>
        </ul>

        <div className="sidebarFooter">
          
             <Image
                    src={IMAGE.frequency} 
                    alt="FAQ"
                  />
        </div>

    </div>
  );
}