"use client"

import { useState, useEffect } from "react"
import { Trash2, Edit3 } from "lucide-react"

interface SOAPItem {
  id: string
  title: string
  date: string
  time: string
  type: "tile" | "transcription" | "soap"
  children?: SOAPItem[]
}

const mockData: SOAPItem[] = [
  {
    id: "1",
    title: "Tile #1",
    date: "22 June, 2025",
    time: "11:30 AM - 11:55 A.M",
    type: "tile",
    children: [
      {
        id: "1-1",
        title: "Transcription",
        date: "22 June, 2025",
        time: "11:30 AM - 11:55 A.M",
        type: "transcription",
      },
      {
        id: "1-2",
        title: "SOAP",
        date: "22 June, 2025",
        time: "11:30 AM - 11:55 A.M",
        type: "soap",
      },
    ],
  },
  {
    id: "2",
    title: "Tile #2",
    date: "22 June, 2025",
    time: "11:30 AM - 11:55 A.M",
    type: "tile",
  },
]

export default function SidebarDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [mySOAPChecked, setMySOAPChecked] = useState(false)
  const [items, setItems] = useState<SOAPItem[]>(mockData)
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set())

  useEffect(() => {
    const allItemIds = getAllItemIds(items)
    const allChecked = allItemIds.length > 0 && allItemIds.every((id) => checkedItems.has(id))
    setMySOAPChecked(allChecked)
  }, [checkedItems, items])

  const getAllItemIds = (items: SOAPItem[]): string[] => {
    const ids: string[] = []
    items.forEach((item) => {
      ids.push(item.id)
      if (item.children) {
        ids.push(...getAllItemIds(item.children))
      }
    })
    return ids
  }

  const handleMasterCheckboxChange = (checked: boolean) => {
    if (checked) {
      const allIds = getAllItemIds(items)
      setCheckedItems(new Set(allIds))
    } else {
      setCheckedItems(new Set())
    }
    setMySOAPChecked(checked)
  }

  const handleItemCheckboxChange = (itemId: string, checked: boolean) => {
    const newCheckedItems = new Set(checkedItems)
    if (checked) {
      newCheckedItems.add(itemId)
    } else {
      newCheckedItems.delete(itemId)
    }
    setCheckedItems(newCheckedItems)
  }

  const handleDelete = (id: string) => {
    const deleteItem = (items: SOAPItem[]): SOAPItem[] => {
      return items.filter((item) => {
        if (item.id === id) {
          return false
        }
        if (item.children) {
          item.children = deleteItem(item.children)
        }
        return true
      })
    }
    setItems(deleteItem(items))
    const newCheckedItems = new Set(checkedItems)
    newCheckedItems.delete(id)
    setCheckedItems(newCheckedItems)
  }

  const renderSOAPItem = (item: SOAPItem, isChild = false) => {
    const hasChildren = item.children && item.children.length > 0

    return (
      <div key={item.id} className={isChild ? "mb-2" : "mb-4"}>
        <div
          className={`
            ${isChild ? "bg-blue-50 border border-blue-200 ml-4" : "listBgTop"} 
            rounded-lg p-4
          `}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center flex-1">
              <input
                type="checkbox"
                checked={checkedItems.has(item.id)}
                onChange={(e) => handleItemCheckboxChange(item.id, e.target.checked)}
                className="mr-3 w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
              <div className="flex items-center flex-1">
                <div>
                  <h3 className="transcriptHead flex items-center ">
                    <Edit3 className="mr-3 w-4 h-4 text-gray-500" /> {item.title}
                  </h3>
                  <p className="itemText">
                    {item.date} | {item.time}
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => handleDelete(item.id)}
              className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {hasChildren && <div className="mt-2">{item.children?.map((child) => renderSOAPItem(child, true))}</div>}
      </div>
    )
  }

  const filteredItems = items.filter(
    (item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.children?.some((child) => child.title.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  return (
    <div className="dashbaordSidebar max-w-4xl mx-auto py-8 px-4">
      <div className="DashbaordSidebarListing mb-3">
        <input
          type="text"
          placeholder="Search SOAP"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none mb-4"
        />

        <div className="LitingTopList flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={mySOAPChecked}
            onChange={(e) => handleMasterCheckboxChange(e.target.checked)}
            className="inputCheckbox"
          />
          <h2 className=" transcription">My Transcriptions</h2>
        </div>
      </div>

      <div>{filteredItems.map((item) => renderSOAPItem(item))}</div>
    </div>
  )
}
