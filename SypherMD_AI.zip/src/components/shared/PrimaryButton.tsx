import { FC, useState } from 'react';

import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

interface ButtonType{
    buttonName: string | undefined;
}

const PrimaryButton: FC<ButtonType> = ({buttonName }) => {
    return(
        <>
        <Button className='themeButton'     > {buttonName} </Button>
       </>
    )
}

export default PrimaryButton;