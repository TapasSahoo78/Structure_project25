import { takeLatest, put, delay } from "redux-saga/effects";
import { loginRequest, loginSuccess } from "../slices/authSlice";

function* handleLogin(action: ReturnType<typeof loginRequest>) {
  yield delay(1000); // Simulate API call
  yield put(loginSuccess({ name: action.payload.username }));
}

export default function* authSaga() {
  yield takeLatest(loginRequest.type, handleLogin);
}
