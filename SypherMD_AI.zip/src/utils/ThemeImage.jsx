import AuthLogo from '../assets/images/AuthLogo.png';
import AuthBg from '../assets/images/authbg.png';
import NavLogo from '../assets/images/navLogo.png';
import support from '../assets/images/suppot.png';
import question from '../assets/images/question.png';
import frequency from '../assets/images/frequency.png';
import circle from '../assets/images/circle.png';








export const IMAGE = {
    AuthLogo,
    AuthBg,
    NavLogo,
    support,
    question,
    frequency,
    circle,

};