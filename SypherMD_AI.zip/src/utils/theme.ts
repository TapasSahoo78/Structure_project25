"use client";
import { createTheme } from "@mui/material/styles";
import { Noto_Sans } from "next/font/google";
import { Poppins } from "next/font/google";

const notoSans = Noto_Sans({
  weight: ["100", "400", "700", "800", "900"],
  subsets: ["latin"],
  display: "swap",
});

const poppins = Poppins({
  weight: ["100", "400", "700", "800", "900"],
  subsets: ["latin"],
  display: "swap",
});

const theme = createTheme({
  typography: {
    fontFamily: `${poppins.style.fontFamily}, ${notoSans.style.fontFamily}, sans-serif`,
  },
});

export default theme;
