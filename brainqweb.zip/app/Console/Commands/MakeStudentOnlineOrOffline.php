<?php

namespace App\Console\Commands;

use App\Models\User\User;
use Illuminate\Console\Command;

class MakeStudentOnlineOrOffline extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:make-student-online-or-offline';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle(): void
    {
        $students = User::whereHas('roles', function ($query) {
            $query = $query->where('slug', 'student');
        })->where('is_online', false)->update(['is_online' => true]);
    }
}
