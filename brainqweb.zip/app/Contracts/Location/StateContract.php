<?php

namespace App\Contracts\Location;

/**
 * Interface StateContract
 * @package App\Contracts
 */
interface StateContract
{
    public function getStates(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false);
}
