<?php

namespace App\Contracts\Site;

interface BoardContract
{
    public function listBoards($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start=null,$inRandomOrder = false);

    public function createBoard(array $attributes);

    public function updateBoard(array $attributes,int $id);
}
