<?php

namespace App\Contracts\Site;

interface ChapterContract
{
    public function listChapters($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start=null,$inRandomOrder = false);

    public function createChapter(array $attributes);

    public function updateChapter(array $attributes,int $id);
}
