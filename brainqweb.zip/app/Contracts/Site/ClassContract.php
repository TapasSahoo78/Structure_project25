<?php

namespace App\Contracts\Site;

interface ClassContract
{
    public function listClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start=null,$inRandomOrder = false);

    public function createClass(array $attributes);

    public function updateClass(array $attributes,int $id);

    public function deleteClass(int $id);
    public function findClass(int $id);
}
