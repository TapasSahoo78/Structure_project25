<?php

namespace App\Contracts\Site;

/**
 * Interface PageContract
 * @package App\Contracts
 */
interface FaqContract
{
    /**
     * @param string $order
     * @param string $sort
     * @param array $columns
     * @return mixed
     */
    public function listFaqs(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $inRandomOrder = false);
}
