<?php

namespace App\Contracts\Site;

interface LiveContract
{
    public function listLiveClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start=null,$inRandomOrder = false);
}
