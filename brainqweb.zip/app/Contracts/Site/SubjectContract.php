<?php

namespace App\Contracts\Site;

interface SubjectContract
{
    public function listSubjects($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start=null,$inRandomOrder = false);

    public function createSubject(array $attributes);

    public function updateSubject(array $attributes,int $id);

    public function deleteSubject(int $id);
}
