<?php

namespace App\Contracts\User;

interface GraphContract
{
}
