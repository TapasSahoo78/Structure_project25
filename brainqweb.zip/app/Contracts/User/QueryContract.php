<?php

namespace App\Contracts\User;

interface QueryContract
{
    // public function listQuery($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false);

    // public function createQuery(array $attributes);

    // public function updateQuery(array $attributes,int $id);

    // public function deleteQuery(int $id);
}
