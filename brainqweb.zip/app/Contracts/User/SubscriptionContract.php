<?php

namespace App\Contracts\User;

interface SubscriptionContract
{
}
