<?php

namespace App\Contracts\User;

interface UserContract
{
    public function findUserByRole(array $filterConditions,string $role,string $orderBy = 'id', string $sortBy = 'asc',$limit= null,$offset=null,$inRandomOrder=false, $search= null);

    public function createUserInStep(array $attributes,string $step,$id=null);
}
