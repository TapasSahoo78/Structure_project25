<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\Site\BannerService;
use App\Http\Controllers\BaseController;

class BannerController extends BaseController
{

    protected $bannerService;

    public function __construct(BannerService $bannerService) {
        $this->bannerService = $bannerService;
    }


    public function viewBanners() {
        $this->setPageTitle('All Banners');
        return view('admin.banner.index');
    }

    public function addBanner(Request $request) {
        $this->setPageTitle('Add Banner');

           $request->validate([
                "order" => 'required|numeric|unique:banners,order,NULL,id,deleted_at,NULL',
                "banner_image" => 'required|file|mimes:jpg,png,gif,jpeg',
            ]);
            DB::beginTransaction();
            try{
                $isBannerCreated= $this->bannerService->createOrUpdateBanner($request->except('_token'));
                if($isBannerCreated){
                    DB::commit();
                    return $this->responseJson(true,200,'Banner created successfully');
                }
            }catch(\Exception $e){
                DB::rollback();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something went wrong','error',true);
            }

    }

    public function editBanner(Request $request, $uuid){
        $this->setPageTitle('Edit Banner');
        $bannerId= uuidtoid($uuid,'banners');
        $bannerData= $this->bannerService->findBannerById($bannerId);
            $request->validate([
                "order" => 'required|numeric|unique:banners,order,'.$bannerData->id.',id,deleted_at,NULL',
                "banner_image" => 'sometimes|file|mimes:jpg,png,gif,jpeg',
            ]);
            DB::beginTransaction();
            try{
                $isBannerUpdated= $this->bannerService->createOrUpdateBanner($request->except('_token'),$bannerId);
                if($isBannerUpdated){
                    DB::commit();
                    return $this->responseJson(true,200,'Banner updated successfully');
                }
            }catch(\Exception $e){
                DB::rollback();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something went wrong','error',true);
            }

    }


    public function deleteBanner($id){
        $bannerId =uuidtoid($id,'banners');
        DB::beginTransaction();
        try{
            $isBannerDeleted= $this->bannerService->deleteBanner($bannerId);
            if($isBannerDeleted){
                DB::commit();
                return $this->responseJson(true,200,'Banner deleted successfully');
            }
        }catch(\Exception $e){
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false,500,'Something went wrong');
        }
    }
}
