<?php

namespace App\Http\Controllers\Admin\Manage;

use App\Http\Controllers\BaseController;
use App\Services\Site\BoardService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BoardController extends BaseController
{

    protected $boardService;

    public function __construct(BoardService $boardService)
    {
        $this->boardService = $boardService;
    }
    public function index(Request $request)
    {
        $this->setPageTitle('Boards');
        return view('admin.board.index');
    }

    public function add(Request $request)
    {
        $request->validate([
            'name' => 'required|string|min:6',
            'initial_name' => 'required|string|min:2',
            'state' => 'required|string|exists:states,name',
        ]);
        DB::beginTransaction();
        try {
            $isBoardCreated = $this->boardService->createOrUpdateBoard($request->except('_token'));
            if ($isBoardCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Board created successfully', route('admin.manage.board.list'));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(true, 200, 'Board created successfully', route('admin.manage.board.list'));
        }
    }
    public function edit(Request $request, $uuid)
    {
        if ($request->post()) {
            $request->validate([
                'name' => 'required|string|min:6',
                'initial_name' => 'required|string|min:2',
                'state' => 'required|string|exists:states,name',
            ]);
            DB::beginTransaction();
            try {
                $id = uuidtoid($uuid, 'boards');
                $isBoardUpdated = $this->boardService->createOrUpdateBoard($request->except('_board'), $id);
                if ($isBoardUpdated) {
                    DB::commit();
                    return $this->responseJson(true,200,'Board updated successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseJson(false,500,'Something went wrong');
            }

        }
    }
}
