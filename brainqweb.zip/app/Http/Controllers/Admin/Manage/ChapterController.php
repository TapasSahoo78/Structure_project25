<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use App\Rules\YoutubeurlRule;
use Illuminate\Support\Facades\DB;
use App\Services\Site\ChapterService;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\VideoResource;
use App\Models\Site\Chapter;

class ChapterController extends BaseController
{
    protected $chapterService;

    public function __construct(ChapterService $chapterService)
    {
        $this->chapterService = $chapterService;
    }

    public function index(Request $request)
    {
        $name = slugtoname($request->slug, 'subjects');
        $this->setPageTitle('Chapters of ' . $name);
        return view('admin.chapter.index');
    }

    public function getNotes(Request $request)
    {
        $this->setPageTitle('Notes');
        $chapter = $this->chapterService->findChapter(uuidtoid($request->uuid, 'chapters'));
        $notes = $chapter->notes;
        return view('admin.chapter.notes.index', compact('notes'));
    }

    public function addNotes(Request $request)
    {
        $request->validate([
            //'note_uuid' => 'required',
            'question' => 'required|string|min:3',
            'answer' => 'required|string|min:3'
        ]);
        DB::beginTransaction();
        try {
            if (isset($request->note_uuid) && !empty($request->note_uuid)) {
                $isNoteCreated = $this->chapterService->createOrUpdateNote($request->except('_token'), $request->uuid);
            } else {
                $isNoteCreated = $this->chapterService->createOrUpdateNote($request->except('_token'));
            }
            info($isNoteCreated);
            if ($isNoteCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Note added successfully', route('admin.manage.subject.chapter.notes', $request->uuid));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', '');
        }
    }

    public function add(Request $request)
    {

        $request->validate([
            // 'name' => 'required|unique:chapters,name|string|min:2',
            'name' => 'required|string|min:2',
            'number' => 'required|numeric|',
            'description' => 'required|string|min:3',
            'subject' => 'required|string|exists:subjects,slug',
            'chapter_image' => 'sometimes|file|mimes:jpg,png',
            'banner_image' => 'file|sometimes|mimes:png,jpg'
        ]);
        DB::beginTransaction();
        try {
            $subjectId = slugtoid($request->subject, 'subjects');
            $boardChapter = Chapter::where([
                'name' => $request->name,
                'subject_id' => $subjectId
            ])->exists();

            if ($boardChapter) {
                return $this->responseJson(false, 500, 'This Chapter already exists!', route('admin.manage.subject.list'));
            }

            $request->merge(['subject_id' => slugtoid($request->subject, 'subjects')]);
            $isChapterCreated = $this->chapterService->createOrUpdateChapter($request->except('_token'));
            if ($isChapterCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Chapter created successfully', route('admin.manage.subject.chapter.list', $request->subject));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', '');
        }
    }

    public function edit(Request $request)
    {
        $request->validate([
            'name' => 'required|string|min:2',
            'number' => 'required|numeric',
            'description' => 'required|string|min:3',
            'subject' => 'required|string|exists:subjects,slug',
            'chapter_image' => 'sometimes|file|mimes:jpg,png',
            'banner_image' => 'file|sometimes|mimes:png,jpg'
        ]);
        DB::beginTransaction();
        try {
            $id = uuidtoid($request->uuid, 'chapters');
            $isChapterUpdated = $this->chapterService->createOrUpdateChapter($request->except('_token'), $id);
            if ($isChapterUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Chapter updated successfully', route('admin.manage.subject.chapter.list', $request->subject));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', '');
        }
    }

    public function listVideos(Request $request)
    {
        return view('admin.chapter.videos.list');
    }

    public function addVideo(Request $request)
    {
        $request->validate([
            'url' => ['required', 'url', new YoutubeurlRule],
            'chapter' => 'required|exists:chapters,uuid',
            'video_name' => 'required|string'
        ]);
        $request->merge(['code' => getVideoCode($request->url)]);
        DB::beginTransaction();
        try {
            $request->merge(['name' => $request->video_name, 'chapter_id' => uuidtoid($request->chapter, 'chapters')]);
            $isVideoCreated = $this->chapterService->createOrUpdateChapterVideo($request->except('_token'));
            if ($isVideoCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Video created successfully', route('admin.manage.subject.chapter.list', $request->chapter));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', '');
        }
    }

    public function editVideo(Request $request, $uuid)
    {
        $request->validate([
            'url' => ['required', 'url', new YoutubeurlRule],
            'video_name' => 'required|string',
        ]);
        $id = uuidtoid($uuid, 'videos');

        $request->merge(['code' => getVideoCode($request->url)]);
        DB::beginTransaction();
        try {
            $request->merge(['name' => $request->video_name]);
            $isVideoUpdated = $this->chapterService->createOrUpdateChapterVideo($request->except('_token'), $id);
            if ($isVideoUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Video updated successfully', route('admin.manage.subject.chapter.list', $request->chapter));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', '');
        }
    }

    public function getTest(Request $request)
    {
        $this->setPageTitle(ucwords($request->type) . ' Set');
        $chapterId = uuidtoid($request->uuid, 'chapters');
        $test = $this->chapterService->findTest($chapterId, $request->type);
        if (!$test) {
            DB::beginTransaction();
            try {
                $isTestCreated = $this->chapterService->createChapterTest($chapterId, $request->type);
                if ($isTestCreated) {
                    $test = $isTestCreated;
                    DB::commit();
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error', true);
            }
        }

        return view('admin.chapter.tests.' . $request->type, compact('test'));
    }
    public function addQuestion(Request $request)
    {
        $request->validate([
            'chapter' => 'required|exists:chapters,uuid',
            'test' => 'required|exists:tests,uuid',
            'question' => 'required|string',
            'answer' => 'required|array',
            'answer.*' => 'required|string',
            'is_right' => 'required'
        ]);
        DB::beginTransaction();
        try {
            $request->merge(['chapter_id' => uuidtoid($request->chapter, 'chapters'), 'test_id' => uuidtoid($request->test, 'tests')]);
            $isQuestionCreated = $this->chapterService->createQuestionAnswer($request->except('_token'), 'tests');
            if ($isQuestionCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Question added successfully', '');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseRedirectBack('Something went wrong', 'error', true);
        }
    }

    public function testAddUpdateTime(Request $request)
    {
        $request->validate([
            'total_duration' => 'required|numeric|min:1'
        ]);
        DB::beginTransaction();
        try {
            $request->merge(['test_id' => uuidtoid($request->uuid, 'tests')]);
            $isTimeUpdated = $this->chapterService->updateTimeInTest($request->except('_token'));
            if ($isTimeUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Time Updated successfully', '');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseRedirectBack('Something went wrong', 'error', true);
        }
    }

}
