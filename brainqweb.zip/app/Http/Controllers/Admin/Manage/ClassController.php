<?php

namespace App\Http\Controllers\Admin\Manage;

use App\Http\Controllers\BaseController;
use App\Services\Site\BoardService;
use App\Services\Site\ClassService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClassController extends BaseController
{
    protected $classService, $boardService;

    public function __construct(ClassService $classService, BoardService $boardService)
    {
        $this->classService = $classService;
        $this->boardService = $boardService;
    }
    public function index(Request $request)
    {
        $boards = $this->boardService->listBoards(['is_active' => true], 'id', 'desc');
        $this->setPageTitle('Classes');
        // dd($boards);
        return view('admin.class.index', compact('boards'));
    }

    public function add(Request $request)
    {
        $request->validate([
            'name' => 'required|string|min:2',
            'roman' => 'required|string',
            'board' => 'required|exists:boards,uuid',
            'medium' => 'required|exists:mediums,uuid',
            'class_image' => 'sometimes|file|mimes:jpg,png'
        ]);
        DB::beginTransaction();
        try {
            $isCLassCreated = $this->classService->createOrUpdateClass($request->except('_token'));
            if ($isCLassCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Class created successfully', route('admin.manage.class.list'));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', route('admin.manage.class.list'));
        }
    }

    public function edit(Request $request, $uuid)
    {

        if ($request->post()) {
            $request->validate([
                'name' => 'required|string|min:2',
                'roman' => 'required|string',
                'board' => 'required|exists:boards,uuid',
                'medium' => 'required|exists:mediums,uuid',
            ]);
            DB::beginTransaction();
            try {
                $id = uuidtoid($uuid, 'site_classes');
                $isClassUpdated = $this->classService->createOrUpdateClass($request->except('_token'), $id);
                if ($isClassUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Class updated successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }

}
