<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Services\Site\CouponService;
use App\Http\Controllers\BaseController;
use App\Services\User\SubscriptionService;


class CouponController extends BaseController
{

    protected $couponService,$subscriptionService;

    public function __construct(CouponService $couponService,SubscriptionService $subscriptionService)
    {
        $this->couponService = $couponService;
        $this->subscriptionService= $subscriptionService;
    }


    public function index()
    {
        $this->setPageTitle('All Coupons');
        $coupons = $this->couponService->listCoupons([]);
        $plans= $this->subscriptionService->listPlans('id','desc');
        return view('admin.coupon.index', compact('coupons','plans'));
    }


    public function add(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'code' => 'required|string|min:2',
            'started_at' => 'required',
            'ended_at' => 'required|',
            'type' => 'required|in:flat,%',
            'discount' => 'required',
            'usage_of_coupon' => 'required',
            'usage_per_user' => 'required'
        ]);
        DB::beginTransaction();
        try {
            $isCouponCreated = $this->couponService->createOrUpdateCoupon($request->except('_token'));
            if ($isCouponCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Coupon Created Successfully', route('admin.coupons.list'));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', route('admin.coupons.list'));
        }
    }

    public function edit(Request $request, $uuid)
    {
        if ($request->post()) {
            $request->validate([
                // 'name' => 'required|string|min:2',
                // 'roman' => 'required|string',
                // 'board' => 'required|exists:boards,uuid',
                // 'medium' => 'required|exists:mediums,uuid',
            ]);
            DB::beginTransaction();
            try {
                $id = uuidtoid($uuid, 'coupons');
                $isCouponUpdated = $this->couponService->createOrUpdateCoupon($request->except('_token'), $id);
                if ($isCouponUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Coupon updated successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }

    public function attachPlans(Request $request, $uuid){
        $request->validate([
            'plans'=>'sometimes|array',
            'plans.*'=> 'string|exists:packages,uuid'
        ]);
        $id= uuidtoid($uuid,'coupons');


        DB::beginTransaction();
        try {
            $isPlansAttachedOrDetached= $this->couponService->attachOrDetachPlans($request->only('plans'),$id);
            if($isPlansAttachedOrDetached){
                DB::commit();
                return $this->responseJson(true,200,'Plans are attached or detached successfully');
            }
        } catch (\Throwable $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something went wrong');
        }
    }



}
