<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use App\Rules\YoutubeurlRule;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Services\Site\ClassService;
use App\Http\Controllers\BaseController;
use App\Models\Site\LiveClass;
use App\Services\Site\BoardService;
use App\Services\Site\ChapterService;
use App\Services\Site\LiveService;
use Illuminate\Support\Carbon;

class LiveClassController extends BaseController
{

    public function __construct(protected UserService $userService, protected ClassService $classService, protected LiveService $liveService, protected ChapterService $chapterService, protected BoardService $boardService)
    {
        $this->userService = $userService;
        $this->classService = $classService;
        $this->liveService = $liveService;
        $this->chapterService = $chapterService;
        $this->boardService = $boardService;
    }
    public function index(Request $request)
    {
        $this->setPageTitle('All Live Classes');
        LiveClass::where('will_end_at', '<', Carbon::now())->update([
            'is_active' => false
        ]);
        $liveClasses = $this->liveService->listClasses([], 'id', 'desc');
        $boards = $this->boardService->listBoards(['is_active' => true], 'id', 'asc');
        $classes = $this->classService->listClasses(['is_active' => true], 'id', 'asc');
        $teachers = $this->userService->findUserByRole(['is_active' => true], 'teacher', 'id', 'asc');
        return view('admin.liveclass.index', compact('liveClasses', 'classes', 'teachers', 'boards'));
    }

    public function liveClassEnrollmentList($uuid)
    {
        $enrollment = LiveClass::where('uuid', $uuid)->with('enrolledUsers')->first();
        return view('admin.liveclass.enrollment', compact('enrollment'));
    }

    public function add(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'link_type' => 'required|in:youtube,meeting',
            'url' => ['required_if:link_type,youtube', 'url', new YoutubeurlRule],
            'meeting_url' => ['required_if:link_type,meeting', 'url'],
            'user' => 'required|exists:users,uuid',
            'board' => 'required|exists:boards,uuid',
            'class' => 'required|exists:site_classes,id',
            'subject' => 'required|exists:subjects,id',
            'will_live_at' => 'required|date_format:Y-m-d H:i|after_or_equal:today',
            'will_end_at' => 'required|date_format:Y-m-d H:i|after_or_equal:will_live_at'
        ]);

        DB::beginTransaction();
        try {
            if ($request->has('meeting_url')) {
                $request->url = $request->meeting_url;
            }
            $request->merge(['user_id' => uuidtoid($request->user, 'users'), 'board_id' => uuidtoid($request->board, 'boards'), 'site_class_id' => $request->class, 'subject_id' => $request->subject]);
            $isLiveClassCreated = $this->liveService->createOrUpdateLiveClass($request->except('_token'));
            if ($isLiveClassCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Live class added successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong');
        }
    }

    public function edit(Request $request, $uuid)
    {
        $request->validate([
            'name' => 'required|string',
            'url' => ['required', 'url', new YoutubeurlRule],
            'user' => 'required|exists:users,uuid',
            'board' => 'required|exists:boards,uuid',
            'class' => 'required|exists:site_classes,id',
            'subject' => 'required|exists:subjects,id',
            'will_live_at' => 'required|date_format:Y-m-d H:i|after_or_equal:today',
            'will_end_at' => 'required|date_format:Y-m-d H:i|after_or_equal:will_live_at'
        ]);

        DB::beginTransaction();
        try {
            $id = uuidtoid($uuid, 'live_classes');
            $request->merge(['user_id' => uuidtoid($request->user, 'users'), 'board_id' => uuidtoid($request->board, 'boards'), 'site_class_id' => $request->class, 'subject_id' => $request->subject]);
            $isLiveClassCreated = $this->liveService->createOrUpdateLiveClass($request->except('_token', 'user', 'board', 'class', 'subject'), $id);
            if ($isLiveClassCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Live class updated successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong');
        }
    }

    public function listExams(Request $request)
    {
        $this->setPageTitle('All scheduled exams');
        $scheduledExams = $this->liveService->listExams([], 'scheduled_at', 'desc');
        $boards = $this->boardService->listBoards(['is_active' => true], 'id', 'asc');
        return view('admin.liveclass.exams', compact('scheduledExams', 'boards'));
    }

    public function addExam(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'board' => 'required|exists:boards,uuid',
            'class' => 'required|exists:site_classes,id',
            'subject' => 'required|exists:subjects,id',
            'total_time' => 'required|numeric|min:1|max:240|gt:0',
            'total_marks' => 'required|numeric|min:1|max:100|gt:0',
            'scheduled_at' => 'required|date_format:Y-m-d H:i'
        ]);

        DB::beginTransaction();
        try {
            $request->merge(['board_id' => uuidtoid($request->board, 'boards'), 'site_class_id' => $request->class, 'subject_id' => $request->subject]);
            $isScheduledExamCreated = $this->liveService->createOrUpdateScheduledExam($request->except('_token'));
            if ($isScheduledExamCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Exam created successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong');
        }


    }

    public function editExam(Request $request, $uuid)
    {
        $request->validate([
            'name' => 'required|string',
            'board' => 'required|exists:boards,uuid',
            'class' => 'required|exists:site_classes,id',
            'subject' => 'required|exists:subjects,id',
            'total_time' => 'required|numeric|min:1|max:240|gt:0',
            'total_marks' => 'required|numeric|min:1|max:100|gt:0',
            'scheduled_at' => 'required|date_format:Y-m-d H:i'
        ]);
        DB::beginTransaction();
        try {
            $id = uuidtoid($uuid, 'exams');
            $request->merge(['board_id' => uuidtoid($request->board, 'boards'), 'site_class_id' => $request->class, 'subject_id' => $request->subject]);
            $isScheduledExamCreated = $this->liveService->createOrUpdateScheduledExam($request->except('_token'), $id);
            if ($isScheduledExamCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Exam updated successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong');
        }
    }

    public function examQuestions(Request $request, $uuid)
    {
        $exam = $this->liveService->findScheduledExam(uuidtoid($uuid, 'exams'));
        $this->setPageTitle('Questions for ' . $exam->name);
        return view('admin.liveclass.exam-questions', compact('exam'));
    }

    public function examAddQuestions(Request $request, $uuid)
    {
        $request->validate([
            'chapter' => 'required|exists:chapters,uuid',
            'marks' => 'required|numeric|min:1',
            'question' => 'required|string',
            'answer' => 'required|array',
            'answer.*' => 'required|string',
            'is_right' => 'required'
        ], [
            'chapter.required' => 'Chapter is required for this exam. Please first add any chapter.'
        ]);
        DB::beginTransaction();
        try {
            $request->merge(['chapter_id' => uuidtoid($request->chapter, 'chapters'), 'exam_id' => uuidtoid($uuid, 'exams')]);
            $isQuestionCreated = $this->chapterService->createQuestionAnswer($request->except('_token'), 'exams');
            if ($isQuestionCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Question added successfully', '');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseRedirectBack('Something went wrong', 'error', true);
        }
    }
}
