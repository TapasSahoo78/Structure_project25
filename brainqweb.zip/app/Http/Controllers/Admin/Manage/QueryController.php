<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\User\QueryService;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BaseController;
use App\Models\User\Query;
use App\Notifications\SendPushNotification;
use Webpatser\Uuid\Uuid;

class QueryController extends BaseController
{

    protected $queryService;

    public function __construct(QueryService $queryService)
    {
        $this->queryService = $queryService;
    }

    public function index()
    {
        $this->setPageTitle('All Queries');
        $queries = $this->queryService->listQuery([]);
        return view('admin.queries.index', compact('queries'));
    }
    public function edit(Request $request, $uuid)
    {
        if ($request->post()) {
            $request->validate([
                'answer' => 'required|string|min:3'
            ]);
            DB::beginTransaction();
            try {
                $id = uuidtoid($uuid, 'queries');
                $query = Query::where('id', $id)->with('student')->first();
                $request->merge(['replied_at' => now()]);
                $isQueryUpdated = $this->queryService->updateQuery($request->except('_token'), $id);
                if ($isQueryUpdated) {
                    DB::commit();
                    $fcmTokens = $query?->student?->pluck('device_token')->toArray();
                    $notify = auth()->user()->notify(new SendPushNotification('Query Message', $request->answer, $fcmTokens, 'all', $isQueryUpdated));
                    // if ($notify) {
                    $query?->student?->notifications()->create([
                        'id' => (string) Uuid::generate(4),
                        'type' => 'Query',
                        'notifiable_type' => get_class($query->student),
                        'notifiable_id' => $query->student->id,
                        'data' => ['title' => 'Query', 'message' => $request->answer]
                    ]);
                    // }
                    return $this->responseJson(true, 200, 'Query updated successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }
}
