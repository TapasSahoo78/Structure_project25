<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use App\Models\Setting\Setting;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class SettingController extends BaseController
{
    public function general(Request $request){
        $this->setPageTitle('Site Settings');
        return view('admin.setting.general');
    }

    public function edit(Request $request){
        $request->validate([
            "facebook_url"=> 'sometimes|nullable|url|regex:/^http(s)?:\/\/(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/',
            "twitter_url"=> 'sometimes|nullable|url|regex:/^http(s)?:\/\/(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/',
            "instagram_url"=> 'sometimes|nullable|url|regex:/^http(s)?:\/\/(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/',
            "whatsapp"=> "numeric|min:1000000000|max:9999999999|nullable"
        ]);
        // dd($request->all());
        $data = $request->except('_token', '_method');
            DB::beginTransaction();
            try {
                foreach ($data as $key => $value) {
                    if ($key == 'robot_txt') {
                        \File::put(public_path('robots.txt'), strip_tags($value));
                    }
                    Setting::updateOrCreate(['key' => $key], [
                        'value' => $value
                    ]);
                }
                DB::commit();
                return $this->responseRedirectBack('Settings Updated successfully','success');
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something went wrong','error');
            }
    }
}
