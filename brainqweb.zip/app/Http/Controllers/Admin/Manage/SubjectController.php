<?php

namespace App\Http\Controllers\Admin\Manage;

use App\Http\Controllers\BaseController;
use App\Models\Site\Subject;
use App\Services\Site\BoardService;
use App\Services\Site\SubjectService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubjectController extends BaseController
{

    protected $subjectService, $boardService;

    public function __construct(SubjectService $subjectService, BoardService $boardService)
    {
        $this->boardService = $boardService;
        $this->subjectService = $subjectService;
    }
    public function index(Request $request)
    {
        $this->setPageTitle('Subjects');
        $boards = $this->boardService->listBoards(['is_active' => true], 'id', 'desc');
        return view('admin.subject.index', compact('boards'));
    }

    public function add(Request $request)
    {
        $request->validate([
            // 'name' => 'required|string|min:6|unique:subjects,name',
            'name' => 'required|string|min:6',
            'board' => 'required|exists:boards,uuid',
            'class' => 'required|exists:site_classes,id',
            'subject_image' => 'required|file|sometimes|mimes:png,jpg,svg',
            'banner_image' => 'file|sometimes|mimes:png,jpg,svg'
        ]);
        DB::beginTransaction();
        try {
            $subjectId = Subject::where('name', $request->name)->first('id');
            if (isset($subjectId) && !empty($subjectId)) {
                $boardId = uuidtoid($request->board, "boards");
                $boardSubject = DB::table('boards_subjects')->where([
                    'board_id' => $boardId,
                    'subject_id' => $subjectId->id
                ])->exists();

                if ($boardSubject) {
                    return $this->responseJson(false, 200, 'This Subject already exists!', route('admin.manage.subject.list'));
                }
            }

            $isSubjectCreated = $this->subjectService->createOrUpdateSubject($request->except('_token'));
            if ($isSubjectCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Subject created successfully', route('admin.manage.subject.list'));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', route('admin.manage.subject.list'));
        }
    }
    public function edit(Request $request, $uuid)
    {
        if ($request->post()) {
            $request->validate([
                'name' => 'required|string|min:6',
                'board' => 'required|exists:boards,uuid',
                'class' => 'required|exists:site_classes,id',
                'subject_image' => 'required|file|sometimes|mimes:png,jpg,svg',
                'banner_image' => 'file|sometimes|mimes:png,jpg,svg'
            ]);
            if (!$request->has('is_top')) {
                $request->merge(['is_top' => false]);
            }
            DB::beginTransaction();
            try {
                $id = uuidtoid($uuid, 'subjects');
                $isSubjectUpdated = $this->subjectService->createOrUpdateSubject($request->except('_token'), $id);
                if ($isSubjectUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Subject updated successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }
}
