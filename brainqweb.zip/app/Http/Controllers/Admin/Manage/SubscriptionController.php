<?php

namespace App\Http\Controllers\Admin\Manage;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Services\User\SubscriptionService;
use Illuminate\Support\Carbon;

class SubscriptionController extends BaseController
{

    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService){
        $this->subscriptionService= $subscriptionService;
    }


    public function index(Request $request){
        $this->setPageTitle('Subscription Palns');
        $plans= $this->subscriptionService->listPlans('id','desc');
        return view('admin.subscription.index',compact('plans'));
    }

    public function add(Request $request){
        $request->validate([
            'name'=> 'required|unique:packages,name',
            'package_type'=>'required|string',
            'price'=> 'numeric|required_if:package_type,paid',
            'interval'=> 'required|string|in:month,year',
            'description'=> 'required|string',
            'duration'=> 'required',
            'is_most_popular'=> 'required|in:1,0'
        ]);
        DB::beginTransaction();
        try {
            $isPlanCreated= $this->subscriptionService->createOrUpdatePlan($request->except('_token'));
            if($isPlanCreated){
                DB::commit();
                return $this->responseJson(true,200,'Plan Created successfully',route('admin.subscription.list'));
            }

        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', route('admin.subscription.list'));
        }

    }
    public function edit(Request $request,$uuid){
        $id= uuidtoid($uuid,'packages');
        $request->validate([
            'name'=> 'required|unique:packages,name,'.$id,
            'package_type'=>'required|string',
            'price'=> 'numeric|required_if:package_type,paid',
            'interval'=> 'required|string|in:month,year',
            'description'=> 'required|string',
            'duration'=> 'required',
            'is_most_popular'=> 'required|in:1,0'
        ]);
        DB::beginTransaction();
        try {
            $isPlanUpdated= $this->subscriptionService->createOrUpdatePlan($request->except('_token'),$id);
            if($isPlanUpdated){
                DB::commit();
                return $this->responseJson(true,200,'Plan Updated successfully',route('admin.subscription.list'));
            }

        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . '--' . $e->getFile() . '--' . $e->getLine());
            return $this->responseJson(false, 500, 'Something Went Wrong', route('admin.subscription.list'));
        }

    }
}
