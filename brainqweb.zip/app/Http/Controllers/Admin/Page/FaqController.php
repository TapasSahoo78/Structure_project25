<?php

namespace App\Http\Controllers\Admin\Page;

use App\Http\Controllers\BaseController;
use App\Services\Site\FaqService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FaqController extends BaseController
{

    protected $faqService;

    public function __construct(FaqService $faqService)
    {
        $this->faqService = $faqService;
    }

    public function index()
    {
        $this->setPageTitle('All Faqs');
        $filterConditions = [];
        $faqs = $this->faqService->listFaqs($filterConditions, 'id', 'asc');
        return view('admin.faq.index', compact('faqs'));
    }

    public function add(Request $request)
    {
        $request->validate([
            'question' => 'required|string|unique:faqs,question',
            "answer" => 'required'
        ]);
        DB::beginTransaction();
        try {
            $isFaqCreated = $this->faqService->createOrUpdateFaq($request->except('_token'));
            if ($isFaqCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Faq created successfully');
            }
        } catch (\Exception $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'Something went wrong');
        }
    }

    public function edit(Request $request, $uuid)
    {
        $faqId = uuidtoid($uuid, 'faqs');
        $faqData = $this->faqService->findFaqById($faqId);
        $request->validate([
            'question' => 'required|string|unique:faqs,question,' . $faqId,
            "answer" => 'required',
        ]);
        DB::beginTransaction();
        try {
            $isFaqUpdated = $this->faqService->createOrUpdateFaq($request->except('_token'), $faqId);
            if ($isFaqUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Faq updated successfully');
            }
        } catch (\Exception $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'Something went wrong');
        }
    }

    public function deleteFaq($id)
    {
        $bannerId = uuidtoid($id, 'banners');
        DB::beginTransaction();
        try {
            $isBannerDeleted = $this->bannerService->deleteBanner($bannerId);
            if ($isBannerDeleted) {
                DB::commit();
                return $this->responseJson(true, 200, 'Banner deleted successfully');
            }
        } catch (\Exception $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'Something went wrong');
        }
    }

}
