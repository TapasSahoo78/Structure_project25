<?php

namespace App\Http\Controllers\Admin\Page;

use Exception;
use Illuminate\Http\Request;
use App\Services\Cms\PageService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class PageController extends BaseController
{
    protected $pageService;
    public function __construct(PageService $pageService){
        $this->pageService= $pageService;
    }
    public function index(Request $request){
        $this->setPageTitle('All Pages');
        $pages= $this->pageService->findPages([],'id','desc');
        return view('admin.page.index',compact('pages'));
    }

    public function add(Request $request){
        $this->setPageTitle('Add page');
        if($request->post()){
            $request->validate([
                'name' => 'required|string|min:3|unique:pages,name',
                'title' => 'required|string|min:3|unique:pages,title',
                'description' => 'required',
            ]);
            DB::beginTransaction();
            try {
                $isPageCreated= $this->pageService->createPage($request->except('_token'));
                if($isPageCreated){
                    DB::commit();
                    return $this->responseRedirect('admin.cms.page.list','Page Created successfully','success');
                }
            } catch (Exception $e) {
                DB::rollBack();

                return $this->responseRedirectBack('Something went wrong','error',true);
            }
        }
        return view('admin.page.add');
    }
    public function edit(Request $request){
        $this->setPageTitle('Edit page');
        $id= uuidtoid($request->uuid,'pages');
        $page= $this->pageService->findPage($id);
        if($request->post()){
            // dd($request->all());
            $request->validate([
                'name' => 'required|string|min:3|unique:pages,name,'.$id,
                'title' => 'required|string|min:3|unique:pages,title,'.$id,
                'description' => 'required',
            ]);
            DB::beginTransaction();
            try {
                $isPageCreated= $this->pageService->createPage($request->except('_token'));
                if($isPageCreated){
                    DB::commit();
                    return $this->responseRedirect('admin.cms.page.list','Page Created successfully','success');
                }
            } catch (Exception $e) {
                DB::rollBack();

                return $this->responseRedirectBack('Something went wrong','error',true);
            }
        }
        return view('admin.page.add',compact('page'));
    }
}
