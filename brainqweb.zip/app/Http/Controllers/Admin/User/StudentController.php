<?php

namespace App\Http\Controllers\Admin\User;

use App\Http\Controllers\BaseController;
use App\Services\User\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends BaseController
{

    protected $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    public function index(Request $request)
    {
        $this->setPageTitle('Students');
        return view('admin.user.student.index');
    }

    public function add(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'first_name' => 'required|string|min:4',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number',
                'board' => 'required',
                'school_name' => 'required',
                'pincode' => 'required|numeric|min:100000|max:999999',
                'classes' => 'required',
                'state' => 'required|exists:states,slug',
                'medium' => 'required|exists:mediums,uuid',
                'city' => 'required|exists:cities,id',
                'role' => 'required|string|in:student',
                'user_image' => 'sometimes|file|mimes:jpg,png,svg,jpeg',
            ]);
            $request->merge(['password' => bcrypt($request->mobile_number)]);
            DB::beginTransaction();
            try {
                $isStudentCreated = $this->userService->createUser($request->except('_token'));
                if ($isStudentCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Student Created Successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }

    }
    public function edit(Request $request, $uuid)
    {
        $id = uuidtoid($uuid, 'users');
        if ($request->post()) {
            $request->validate([
                'first_name' => 'required|string|min:4',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number,' . $id,
                'board' => 'required|exists:boards,uuid',
                'classes' => 'required|exists:site_classes,id',
                'school_name' => 'required',
                'state' => 'required|exists:states,slug',
                'pincode' => 'required|numeric|min:100000|max:999999',
                'medium' => 'required|exists:mediums,uuid',
                'city' => 'required|exists:cities,id',
                'user_image' => 'file|sometimes|mimes:png,jpg',
            ]);
            DB::beginTransaction();
            try {
                $isStudentEdited = $this->userService->updateUser($request->except('_token'), $id);
                if ($isStudentEdited) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Student Updated Successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }
}
