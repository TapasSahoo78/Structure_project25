<?php

namespace App\Http\Controllers\Admin\User;

use Illuminate\Http\Request;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Services\Site\ClassService;

class TeacherController extends BaseController
{
    protected $userService,$classService;

    public function __construct(UserService $userService,ClassService $classService)
    {
        $this->userService = $userService;
        $this->classService = $classService;
    }

    public function index(Request $request){
        $this->setPageTitle('Teachers');
        return view('admin.user.teacher.index');
    }

    public function add(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'first_name' => 'required|string|min:4',
                'email' => 'required|email|unique:users,email',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number',
                'board' => 'required|exists:boards,uuid',
                'state' => 'required|exists:states,name',
                'qualification' => 'required|string|min:2',
                'designation' => 'required|string|min:2',
                'address' => 'required|string|min:2',
                'teacher_password' => 'required|string|min:6',
                'role'=> 'required|string|in:teacher',
                'user_image'=> 'sometimes|file|mimes:jpg,png,svg,jpeg',
                'teacher_cv'=> 'sometimes|file|mimes:jpg,png,jpeg,pdf,docx,doc'
            ]);
            $request->merge(['password'=>bcrypt($request->teacher_password),'email_verified_at'=>now()]);
            DB::beginTransaction();
            try {
                $isTeacherCreated = $this->userService->createUser($request->except('_token'));
                if ($isTeacherCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Teacher Created Successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }

    }
    public function edit(Request $request, $uuid)
    {
        $id = uuidtoid($uuid, 'users');
        if ($request->post()) {
            $request->validate([
                'first_name' => 'required|string|min:4',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number,'. $id,
                'board' => 'required|exists:boards,uuid',
                'state' => 'required|exists:states,name',
                'qualification' => 'required|string|min:2',
                'designation' => 'required|string|min:2',
                'address' => 'required|string|min:2',
                'user_image' => 'file|sometimes|mimes:png,jpg,svg',
                'teacher_cv'=> 'sometimes|file|mimes:jpg,png,jpeg,pdf,docx,doc'
            ]);
            DB::beginTransaction();
            try {
                $isStudentEdited = $this->userService->updateUser($request->except('_token'), $id);
                if ($isStudentEdited) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Teacher Updated Successfully');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, 'Something went wrong');
            }

        }
    }

    public function addClassSubject(Request $request, $uuid){
        $request->validate([
            'class'=>'required|array',
            'class.*'=> 'required|string',
            'subjects'=>'required|array',
            'subjects.*.*'=> 'required'
        ]);
        // dd($request->all());
        DB::beginTransaction();
        try {
            $id= uuidtoid($uuid,'users');
            $isTeacherClassSubjectCreated = $this->classService->createTeacherClassSubject($request->except('_token'),$id);
            if($isTeacherClassSubjectCreated){
                DB::commit();
                return $this->responseJson(true, 200, 'Teacher Subject Class attached successfully');
            }
        } catch (\exception $e) {
            DB::rollBack();
        }
    }
}
