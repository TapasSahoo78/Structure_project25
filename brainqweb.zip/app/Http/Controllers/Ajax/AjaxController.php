<?php

namespace App\Http\Controllers\Ajax;

use Illuminate\Http\Request;
use App\Models\Setting\Setting;
use App\Services\Cms\PageService;
use App\Services\Site\LiveService;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Services\Site\BoardService;
use App\Services\Site\ClassService;
use App\Services\User\QueryService;
use App\Http\Resources\UserResource;
use App\Services\Site\BannerService;
use App\Services\Site\CouponService;
use Illuminate\Support\Facades\File;
use App\Http\Resources\BoardResource;
use App\Http\Resources\ClassResource;
use App\Services\Site\ChapterService;
use App\Services\Site\SubjectService;
use App\Http\Resources\CouponResource;
use App\Http\Resources\ChapterResource;
use App\Http\Resources\SubjectResource;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\ExamResource;
use App\Http\Resources\Api\PlanResource;
use App\Http\Resources\Api\QueryResource;
use App\Http\Resources\Api\VideoResource;
use App\Http\Resources\Api\BannerResource;
use App\Services\User\SubscriptionService;
use App\Http\Resources\Api\LiveClassResource;
use App\Services\Site\FaqService;

class AjaxController extends BaseController
{

    protected $boardService, $subjectService, $userService, $classService, $chapterService, $subscriptionService, $couponService, $pageService, $queryService, $bannerService, $liveService, $faqService;

    public function __construct(BoardService $boardService, SubjectService $subjectService, UserService $userService, ClassService $classService, ChapterService $chapterService, SubscriptionService $subscriptionService, CouponService $couponService, PageService $pageService, QueryService $queryService, BannerService $bannerService, LiveService $liveService, FaqService $faqService)
    {
        $this->boardService = $boardService;
        $this->couponService = $couponService;
        $this->subjectService = $subjectService;
        $this->userService = $userService;
        $this->classService = $classService;
        $this->chapterService = $chapterService;
        $this->subscriptionService = $subscriptionService;
        $this->pageService = $pageService;
        $this->queryService = $queryService;
        $this->bannerService = $bannerService;
        $this->liveService = $liveService;
        $this->faqService = $faqService;
    }
    public function getBoards(Request $request)
    {
        if ($request->ajax()) {
            $start = ($request->page - 1) * 8;
            $listBoards = $this->boardService->listBoards([], 'id', 'desc', 8, $start);
            if ($listBoards->isNotEmpty()) {
                $data = view('components.board.board')->with(['listBoards' => $listBoards])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }
    public function getBanners(Request $request)
    {
        if ($request->ajax()) {
            $start = ($request->page - 1) * 10;
            $banners = $this->bannerService->listBanners([], 'id', 'desc', 10, $start);
            if ($banners->isNotEmpty()) {
                $data = view('components.banner.banner')->with(['banners' => $banners])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }

    public function getBanner(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'banners');
            $isBanner = $this->bannerService->findBannerById($id);
            if ($isBanner) {
                return $this->responseJson(true, 200, 'Banner found successfully', new BannerResource($isBanner));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }
    public function getBoard(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'boards');
            $isBoard = $this->boardService->findBoard($id);
            if ($isBoard) {
                return $this->responseJson(true, 200, 'Board found successfully', new BoardResource($isBoard));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }

    public function getChapters(Request $request)
    {
        if ($request->ajax()) {
            $id = slugtoid($request->slug, 'subjects');
            $start = ($request->page - 1) * 8;
            $chapters = $this->chapterService->listChapters(['subject_id' => $id], 'id', 'desc', 8, $start);
            if ($chapters->isNotEmpty()) {
                $data = view('components.chapter.chapter')->with(['chapters' => $chapters])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }

    public function getChapter(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'chapters');
            $isChapter = $this->chapterService->findChapter($id);
            if ($isChapter) {
                return $this->responseJson(true, 200, 'Chapter found successfully', new ChapterResource($isChapter));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }
    public function getClasses(Request $request)
    {
        if ($request->ajax()) {
            $start = ($request->page - 1) * 8;
            if ($request->uuid && $request->uuid != 'undefined') {
                $board = $this->boardService->findBoard(uuidtoid($request->uuid, 'boards'));
                $classes = $board->classes()->orderBy('id', 'desc')->offset($start)->paginate(8);
            } else {
                $classes = $this->classService->listclasses([], 'id', 'desc', 8, $start);
            }

            // dd($classes);
            if ($classes->isNotEmpty()) {
                $data = view('components.class.class')->with(['classes' => $classes])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }

    public function getClass(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'site_classes');
            $isClass = $this->classService->findClass($id);
            if ($isClass) {
                return $this->responseJson(true, 200, 'Class found successfully', new ClassResource($isClass));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }
    public function getLiveClass(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'live_classes');
            $isClass = $this->liveService->findLiveClass($id);
            if ($isClass) {
                return $this->responseJson(true, 200, 'Live class found successfully', new LiveClassResource($isClass));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }
    public function getScheduleExam(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'exams');
            $isExam = $this->liveService->findScheduledExam($id);
            if ($isExam) {
                return $this->responseJson(true, 200, 'Scheduled Exam found successfully', new ExamResource($isExam));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }

    public function getSubjects(Request $request)
    {
        if ($request->ajax()) {
            // dump($request->class);
            $start = ($request->page - 1) * 8;
            if ($request->class && $request->class != 'undefined') {
                $class = $this->classService->findClass($request->class);
                // dd($class);
                $subjects = $class?->subjects()?->orderBy('id','desc')->offset($start)->paginate(8);
            } else {
                $subjects = $this->subjectService->listSubjects([], 'id', 'desc', 8, $start);
            }

            if ($subjects->isNotEmpty()) {
                $data = view('components.subject.subject')->with(['subjects' => $subjects])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }
    public function getSubjectsByClass(Request $request)
    {
        if ($request->ajax()) {
            $class = $this->classService->findClass($request->class_id);
            return $this->responseJson(true, 200, 'Subjects Data found', $class?->subjects);
        }
        abort(405);
    }

    public function getSubject(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'subjects');
            $isSubject = $this->subjectService->findSubject($id);
            if ($isSubject) {
                return $this->responseJson(true, 200, 'Board found successfully', new SubjectResource($isSubject));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }

    /**
     *  find GetCoupon uuid
     */
    public function getCoupon(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'coupons');
            $isCoupon = $this->couponService->findCoupon($id);
            if ($isCoupon) {
                return $this->responseJson(true, 200, 'Coupon found successfully', new CouponResource($isCoupon));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }
    public function getQuery(Request $request)
    {
        // dd(uuidtoid($request->uuid, 'queries'));
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'queries');
            $isQuery = $this->queryService->findQuery($id);
            if ($isQuery) {
                return $this->responseJson(true, 200, 'Query found successfully', new QueryResource($isQuery));
            }
            return $this->responseJson(false, 200, 'No data found');
        }
        abort(405);
    }

    public function getUsers(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                if ($request->is_active != 'all') {
                    $filterCondition = [
                        'is_active' => $request->is_active,
                    ];
                } else {
                    $filterCondition = [];
                }
                $status = $request->is_active;
                $totalData = $this->userService->getTotalUsers($role, $status);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (empty($request->search)) {
                    $users = $this->userService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false);
                } else {
                    $search = $request->search;
                    $users = $this->userService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->userService->getTotalUsers($role, $status, $search);
                }

                // if (isset($request->board) && !empty($request->board)) {
                //     $boardId = uuidtoid($request->board, 'boards');
                //     $users->whereHas('boards', function ($q) use ($boardId) {
                //         $q->where('board_id', $boardId);
                //     });
                // }
                // if (isset($request->classes) && !empty($request->classes)) {
                //     $classId = $request->classes;
                //     $users->whereHas('classes', function ($q) use ($classId) {
                //         $q->where('class_id', $classId);
                //     });
                // }

                if (!empty($users)) {
                    foreach ($users as $user) {
                        $randomIds = $user->app_id;

                        $status = $user->is_active == true ? 'checked' : '';
                        $index++;
                        $nestedData['sr'] = '<p>' . $index . '</p>';
                        $nestedData['id'] = $user->app_id;

                        $nestedData['name'] = '<div class="student"><div class="studentimg"><img src="' . $user->profile_picture . '" alt="Profile Picture"></div><p><a class="viewUser" data-uuid="' . $user->uuid . '" data-action="view" href="javascript:void(0)">' . $user->full_name . '</a></p></div>';
                        $nestedData['teacher_name'] = '<div class="student"><div class="studentimg"><img src="' . $user->profile_picture . '" alt="Profile Picture"></div><p><a class="viewUser" data-uuid="' . $user->uuid . '" data-action="view" href="javascript:void(0)">' . $user->full_name . '(' . $user->profile->designation . ')</a></p><br><p>Qualification:- ' . $user->profile->qualification . '</p></div>';
                        $nestedData['contact'] = '<div class="student">' . ($user->email ? '<p><a href="mailto:' . $user->email . '"><i class="fa fa-envelope" aria-hidden="true"></i>' . $user->email . '</a></p><p class="ml-3 mr-3">I</p>' : '') . '<p class="numbertext"><i class="fa fa-mobile" aria-hidden="true"></i>' . $user->mobile_number . '</p>' . ($role == 'teacher' ? '<p class="ml-3 mr-3">I</p><p class="numbertext"><i class="fa fa-book" aria-hidden="true"></i>' . $user->profile?->address . '</p>' : '') . '</div>';
                        $nestedData['board'] = $user->boards?->first()?->initial_name != '' ? $user->boards?->first()?->initial_name : $user->boards?->first()?->name;
                        $nestedData['class'] = $user->classes?->first()?->name . ' (' . $user->classes?->first()?->roman . ')';

                        $nestedData['state'] = $user->profile?->state;
                        $nestedData['is_active'] = $user->is_active;
                        $pointer = !$user->is_active ? "pe-none" : "";
                        $nestedData['status'] = '<div class="custom-control custom-switch inTable"><input type="checkbox" class="custom-control-input changeStatus" id="switch' . $user->uuid . '" name="is_active"' . $status . ' data-uuid="' . $user->uuid . '" data-table="users" data-message="deactive" ><label class="custom-control-label" for="switch' . $user->uuid . '"  ></label></div>';

                        $nestedData['action'] = '
                        <div class="board-right dot-right ' . $pointer . '">
                            <div class="dropdown">
                                <button class="btn bg-transparent dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                <a class="dropdown-item viewUser" data-action="view" href="javascript:void(0)" data-uuid="' . $user->uuid . '"><i class="fa mr-1" aria-hidden="true"><img src="' . asset('assets/img/edit.png') . '" alt="View image"></i>View</a>

                                    <a class="dropdown-item editUser" data-action="edit" href="javascript:void(0)" data-uuid="' . $user->uuid . '"><i class="fa mr-1" aria-hidden="true"><img src="' . asset('assets/img/edit.png') . '" alt="Edit image"></i>Edit</a>';
                        if ($role == 'teacher' && $user->my_cv) {
                            $nestedData['action'] .= '
                            <a class="dropdown-item" href="' . $user->my_cv . '" target="_blank"><i class="fa fa-book mr-1" aria-hidden="true"></i>View-Cv</a>';
                        }
                        if ($role == 'teacher') {
                            $nestedData['action'] .= '
                            <a class="dropdown-item addSubjectClass text-wrap" data-uuid="' . $user->uuid . '" href="javascript:void(0)" ><i class="fa fa-book mr-1" aria-hidden="true"></i>Add subject-class</a>';
                        }
                        if ($role == 'teacher') {
                            $nestedData['action'] .= '
                            <a class="dropdown-item editClassSubject text-wrap" data-uuid="' . $user->uuid . '" href="javascript:void(0)" ><i class="fa fa-book mr-1" aria-hidden="true"></i>View subject-class</a>';
                        }


                        $nestedData['action'] .= '
                                    <a class="dropdown-item deleteData" href="javascript:void(0)" data-uuid="' . $user->uuid . '" data-table="users"><i class="fa mr-1" aria-hidden="true"><img src="' . asset('assets/img/delete.png') . '" alt="delete image"></i>Delete</a>
                                </div>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    // "recordsTotal" => (int) $totalData,
                    "recordsTotal" => (int) $totalFiltered,
                    "recordsFiltered" => (int) $totalData,
                    // "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getUser(Request $request, $uuid)
    {
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'users');
            $filterConditions = [
                'id' => $id,
                'is_blocked' => false,
                'is_approve' => true
            ];
            $user = $this->userService->findOne($filterConditions);
            return $this->responseJson(true, 200, 'Data Found', new UserResource($user));
        }
        abort(405);
    }
    public function getUserClassSubject(Request $request, $uuid)
    {
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'users');
            $count = $request->count ?? 0;
            $filterConditions = [
                'id' => $id,
                'is_blocked' => false,
                'is_approve' => true
            ];
            $user = $this->userService->findOne($filterConditions);
            if ($user) {
                $classes = $user->boards->first()->classes;
                $data = view('components.dropdown.class')->with(['classes' => $classes, 'count' => $count])->render();
            }
            return $this->responseJson(true, 200, 'Data Found', $data);
        }
        abort(405);
    }

    public function editUserClassSubject(Request $request, $uuid)
    {
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'users');
            $filterConditions = [
                'id' => $id,
                'is_blocked' => false,
                'is_approve' => true
            ];
            $user = $this->userService->findOne($filterConditions);
            if ($user) {
                $userClasses = $user->teacherSubjectClass->groupBy('site_class_id');
                if ($userClasses->isEmpty())
                    return $this->responseJson(true, 200, 'No Data Found', []);
                $classes = $user->boards->first()->classes;
                $data = view('components.dropdown.subject-class-all')->with(['classes' => $classes, 'userClasses' => $user->teacherSubjectClass->groupBy('site_class_id')])->render();
            }
            return $this->responseJson(true, 200, 'Data Found', $data);
        }
        abort(405);
    }

    public function getPlan(Request $request, $uuid)
    {
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'packages');
            $user = $this->subscriptionService->find($id);
            return $this->responseJson(true, 200, 'Data Found', new PlanResource($user));
        }
        abort(405);
    }

    public function getVideos(Request $request)
    {
        if ($request->ajax()) {
            $start = ($request->page - 1) * 8;
            $id = uuidtoid($request->uuid, 'chapters');
            $videos = $this->chapterService->listVideos(['chapter_id' => $id], 'id', 'desc', 8, $start);
            if ($videos->isNotEmpty()) {
                $data = view('components.video.video')->with(['videos' => $videos])->render();
                return $this->responseJson(true, 200, 'Data Found Successfully', $data);
            }
            return $this->responseJson(false, 200, 'No more data', []);
        }
        abort(405);
    }

    public function getVideo(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'videos');
            $user = $this->chapterService->findVideo($id);
            return $this->responseJson(true, 200, 'Data Found', new VideoResource($user));
        }
        abort(405);
    }
    public function setStatus(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            $data = $request->value;
            $id = uuidtoid($request->uuid, $table);
            switch ($table) {
                case 'users':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->userService->updateUser($request->only('is_active'), $id);
                    $message = 'User Status updated';
                    break;
                case 'banners':
                    $data = $this->bannerService->updateBanner($request->only('is_active'), $id);
                    $message = 'Banner Status updated';
                    break;
                case 'boards':
                    $data = $this->boardService->updateBoard($request->only('is_active'), $id);
                    $message = 'Board Status updated';
                    break;
                case 'subjects':
                    $data = $this->subjectService->updateSubject($request->only('is_active'), $id);
                    $message = 'Subject Status updated';
                    break;
                case 'site_classes':
                    $data = $this->classService->updateClass($request->only('is_active'), $id);
                    $message = 'Class status updated';
                    break;
                case 'chapters':
                    $data = $this->chapterService->createOrUpdateChapter($request->only('is_active'), $id);
                    $message = 'Chapter status updated';
                    break;
                case 'packages':
                    $data = $this->subscriptionService->updatePackage($request->only('is_active'), $id);
                    $message = 'Chapter status updated';
                    break;
                case 'coupons':
                    $data = $this->couponService->updateCoupon($request->only('is_active'), $id);
                    $message = 'Coupon status updated';
                    break;
                case 'videos':
                    $data = $this->chapterService->updateVideo($request->only('is_active'), $id);
                    $message = 'Video status updated';
                    break;
                case 'pages':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->pageService->updatePage($request->only('is_active'), $id);
                    $message = 'Page status updated';
                    break;
                case 'live_classes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->liveService->updateLiveClass($request->only('is_active'), $id);
                    $message = 'Live Class status updated';
                    break;
                case 'exams':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->liveService->updateScheduledExam($request->only('is_active'), $id);
                    $message = 'Exam status updated';
                    break;
                case 'faqs':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->faqService->updateFaqStatus($request->only('is_active'), $id);
                    $message = 'Faq status updated';
                    break;
                default:
                    return $this->responseJson(false, 200, 'Something Wrong Happened');
            }

            if ($data) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 200, 'Something Wrong Happened');
            }
        }
        abort(405);
    }

    /* public function updateSettings(Request $request)
    {
        if ($request->ajax()) {
            $data = $request->except('_token', '_method');
            DB::beginTransaction();
            try {
                foreach ($data as $key => $value) {
                    if ($key == 'robot_txt') {
                        File::put(public_path('robots.txt'), strip_tags($value));
                    }
                    Setting::updateOrCreate(['key' => $key], [
                        'value' => $value
                    ]);
                }
                DB::commit();
                return $this->responseJson(true, 200, 'Settings updated successfully');
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, $e->getCode(), 'Something went wrong');
            }
        } else {
            abort(405);
        }
    } */


    public function detachQuestion(Request $request)
    {
        if ($request->ajax()) {
            $questionId = uuidtoid($request->uuid, 'questions');
            $examId = uuidtoid($request->exam, 'exams');
            $exam = $this->liveService->findScheduledExam($examId);
            if ($exam) {
                $exam->questions()->detach($questionId);
                return $this->responseJson(true, 200, 'Question Removed successfully', []);
            }
            return $this->responseJson(false, 500, 'Something went wrong', []);
        } else {
            abort(405);
        }
    }
    public function deleteData(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            switch ($table) {
                case 'users':
                    // $id = uuidtoid($request->uuid, $table);
                    $data = $this->userService->deleteUser($request->except('find'));
                    $message = 'User Deleted';
                    break;
                case 'banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->bannerService->deleteBanner($id);
                    $message = 'Banner Deleted';
                    break;
                case 'boards':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->boardService->deleteBoard($id);
                    $message = 'Board Deleted';
                    break;
                case 'site_classes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->classService->deleteClass($id);
                    $message = 'Class Deleted';
                    break;
                case 'subjects':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->subjectService->deleteSubject($id);
                    $message = 'Subject Deleted';
                    break;
                case 'chapters':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->chapterService->deleteChapter($id);
                    $message = 'Class Deleted';
                    break;
                case 'notes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->chapterService->deleteNote($id);
                    $message = 'Class Deleted';
                    break;
                case 'packages':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->subscriptionService->deletePackage($id);
                    $message = 'Plan Deleted';
                    break;
                case 'coupons':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->couponService->deleteCoupon($id);
                    $message = 'Plan Deleted';
                    break;
                case 'pages':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->pageService->deletePage($id);
                    $message = 'Page Deleted';
                    break;
                case 'videos':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->chapterService->deleteVideo($id);
                    $message = 'Plan Deleted';
                    break;
                case 'questions':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->chapterService->deleteQuestion($id);
                    $message = 'Plan Deleted';
                    break;
                case 'live_classes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->liveService->deleteLiveClass($id);
                    $message = 'Live Class deleted';
                    break;
                case 'exams':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->liveService->deleteSchedledExam($id);
                    $message = 'Live Class deleted';
                    break;
                case 'faqs':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->faqService->deleteFaq($id);
                    $message = 'Faq deleted';
                    break;
                case 'queries':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->queryService->deleteQuery($id);
                    $message = 'Query deleted';
                    break;
            }
            if (isset($data)) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        } else {
            abort(405);
        }

    }

    public function getRemainingMarks(Request $request, $uuid)
    {
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'exams');
            $exam = $this->liveService->findScheduledExam($id);
            if ($exam) {
                $data = [
                    'marks' => $exam->total_marks,
                    'remaining' => ($exam->total_marks) - ($exam->questions->sum('marks')),
                ];
                return $this->responseJson(true, 200, 'marks found', $data);
            }
        } else {
            abort(405);
        }
    }
}
