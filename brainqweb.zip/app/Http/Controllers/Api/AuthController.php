<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use OpenApi\Attributes\Info;
use Illuminate\Support\Carbon;
use OpenApi\Attributes\License;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use OpenApi\Attributes\Attachable;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\UserResource;
use App\Models\User\User;
use Illuminate\Support\Facades\Validator;
use Laravel\Passport\Token;

#[Info(
    version: '1.0.0',
    title: 'My API',
    attachables: [new Attachable()]
)]
#[License(name: 'MIT')]
class AuthController extends BaseController
{

    protected $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    /**
     * @OA\post(
     *      path="/login",
     *      tags={"Student Login"},
     *      operationId="agentLogin",
     *      summary="Login Student",
     *      description="Login Student information",
     *      @OA\Parameter(
     *          name="mobile_number",
     *          description="Mobile Number",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="password",
     *          description="password",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=400,
     *          description="Bad Request"
     *      ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *      @OA\Response(
     *          response=405,
     *          description="Method not allowed"
     *      )
     * )
     */


    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'required|numeric',
            'password' => 'required',
            /* 'device_id' => 'required',
            'device_type' => 'required|in:android,ios', */
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), "");
        }
        /* need to be checked in production */
        /* $baseUrl = 'localhost:8000'."/oauth/token";
        $response= Http::asForm()->post($baseUrl, [
        'username' => $request->mobile_number,
        'password' => $request->password,
        'client_id' => config('passport.password_grant_client.id'),
        'client_secret' => config('passport.password_grant_client.secret'),
        'grant_type' => 'password',
        'scope' => '*',
        ]);
        dd($response->getBody()); */
        if (empty(checkUserWithRole($request->mobile_number))) {
            return $this->responseJson(false, 200, 'Credential are not allowed!', "");
        }
        if (!auth()->attempt($request->only(['mobile_number', 'password']))) {
            return $this->responseJson(false, 200, 'Incorrect Details. Please try again', []);
        }
        if (!auth()->user()->hasRole('student')) {
            auth()->logout();
            return $this->responseJson(false, 200, 'Sorry you are not a student', []);
        }
        if (!auth()->user()->is_approve) {
            auth()->logout();
            return $this->responseJson(false, 200, 'Please wait for your account approval', []);
        }
        if (!auth()->user()->is_active) {
            auth()->logout();
            return $this->responseJson(false, 200, 'Your account has been deactivated. Please contact admin', []);
        }
        if (auth()->user()->is_blocked) {
            auth()->logout();
            return $this->responseJson(false, 200, 'Your account has been blocked. Please contact admin', []);
        }

        $user = auth()->user();
        if (isset($user->id) && !empty($user->id)) {
            Token::where('user_id', $user->id)->update(['revoked' => 1]);
        }
        return $this->responseJson(true, 200, 'User Details Found', new UserResource($user));
    }

    public function generateToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'refresh_token' => 'required',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        $baseUrl = url('/');
        $response = Http::post("{$baseUrl}/oauth/token", [
            'refresh_token' => $request->refresh_token,
            'client_id' => config('passport.password_grant_client.id'),
            'client_secret' => config('passport.password_grant_client.secret'),
            'grant_type' => 'refresh_token',
        ]);
        if ($response->ok()) {
            return $this->responseJson(true, 200, 'New token Generated', $response);
        }
        return $this->responseJson(false, 500, 'Token generation failed', []);
    }
    public function registerInStep(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'step' => 'required|string|in:first,second,third,fourth,fifth',
            'uuid' => 'required_unless:step,first|exists:users,uuid',
            // 'device_id' => 'required_if:step,first|string',
            'first_name' => 'required_if:step,first|string',
            'mobile_number' => 'required_if:step,first|numeric',
            // 'mobile_number' => 'required_if:step,first|numeric|unique:users,mobile_number',
            'otp' => 'required_if:step,second|numeric',
            'state' => 'required_if:step,third|exists:states,id',
            'city' => 'required_if:step,third|exists:cities,id',
            'pincode' => 'required_if:step,third|numeric',
            'school_name' => 'required_if:step,fourth|string',
            'class' => 'required_if:step,fourth|exists:site_classes,uuid',
            'board' => 'required_if:step,fourth|exists:boards,uuid',
            'medium' => 'required_if:step,fourth|exists:mediums,uuid',
            'password' => 'required_if:step,fifth|min:6|confirmed',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        DB::beginTransaction();
        try {
            // Check if the account is deleted
            $deletedUser = User::withTrashed()
                ->where('mobile_number', $request->mobile_number)
                ->first();

            if ($deletedUser && $deletedUser->trashed()) {
                return $this->responseJson(false, 400, ['This account has already been deleted.Please contact with BrainQ Admin!'], []);
            }
            $checkUser = User::where(['mobile_number' => $request->mobile_number, 'is_approve' => true])->exists();
            if (isset($checkUser) && !empty($checkUser)) {
                return $this->responseJson(false, 400, ['This mobile number is alreday exists!'], []);
            }
            switch ($request->step) {
                case 'first':
                    $destination = $request->mobile_number;
                    $genOTp = rand(1000, 9999);
                    $content = "Don't Share: $genOTp is your BrainQ verification OTP. For any assistance visit https://brainq.co.in Team BrainQ";
                    $result = sendSms($destination, $content);
                    $request->merge(['password' => bcrypt($request->mobile_number), 'verification_code' => $genOTp, 'is_approve' => 0, 'registration_ip' => $request->ip()]);
                    $isDataProcessed = $this->userService->createUserInSteps($request->only(['first_name', 'mobile_number', 'password', 'is_approve', 'is_active', 'verification_code', 'registration_ip'/* ,'device_token' */]), $request->step);
                    $message = $isDataProcessed ? 'User data added successfully' : 'User data added failed!';
                    break;
                case 'second':
                    if (empty($request->otp)) {
                        return $this->responseJson(false, 400, 'Please enter OTP!', []);
                    }
                    $id = uuidtoid($request->uuid, 'users');
                    $isDataProcessed = $this->userService->checkOtp($request->otp, $id);
                    $isDataProcessed ? User::where('id', $id)->update(['is_active' => 1]) : '';
                    $message = $isDataProcessed ? 'Otp verified successfully' : 'OTP verification failed!';
                    break;
                case 'third':
                    $id = uuidtoid($request->uuid, 'users');
                    $isDataProcessed = $this->userService->createUserInSteps($request->only(['state', 'city', 'pincode']), $request->step, $id);
                    $message = $isDataProcessed ? 'Location data added successfully' : 'Location added failed!';

                    break;
                case 'fourth':
                    $id = uuidtoid($request->uuid, 'users');
                    $isDataProcessed = $this->userService->createUserInSteps($request->only(['school_name', 'board', 'class', 'medium']), $request->step, $id);
                    $message = $isDataProcessed ? 'Location data added successfully' : 'Location added failed!';
                    break;
                case 'fifth':
                    $id = uuidtoid($request->uuid, 'users');
                    $isDataProcessed = $this->userService->createUserInSteps($request->only(['password']), $request->step, $id);
                    $message = $isDataProcessed ? 'Password Set Successfully' : 'Password set failed!';
                    break;
                default:
                    return $this->responseJson(false, 400, 'Bad Request', []);
                    break;
            }
            if ($isDataProcessed) {
                DB::commit();
                return $this->responseJson(true, 200, $message, new UserResource($isDataProcessed));
            } else {
                return $this->responseJson(false, 200, $message ?? 'Failed!', []);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }

    public function changeState(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'state' => 'required|in:foreground,background'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        DB::beginTransaction();
        try {
            switch ($request->state) {
                case 'foreground':
                    $updateData = [
                        'is_online' => true,
                        'last_login_at' => Carbon::now()
                    ];
                    break;
                case 'background':
                    $updateData = [
                        'is_online' => false,
                        'last_logout_at' => Carbon::now()
                    ];
                    break;
            }

            if ($updateData) {
                $isUserUpdated = auth()->user()->update($updateData);
                if ($isUserUpdated) {
                    DB::commit();
                    $message = $request->state == 'foreground' ? 'User Logged in Successfully' : "User Logged out successfully";
                    $data = $request->state == 'foreground' ? (new UserResource(auth()->user())) : [];
                    return $this->responseJson(true, 200, $message, $data);
                }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }

    public function logout(Request $request)
    {
        $user = $request->user()->token();
        if ($user->revoke()) {
            return $this->responseJson(true, 200, 'User logged out successfully', []);
        }
        return $this->responseJson(false, 400, 'Something went wrong', []);
    }

    public function getForgetOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'numeric|digits:10|exists:users,mobile_number'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        $mobileNumber = $request->mobile_number;
        if (empty(checkUserWithRole($mobileNumber))) {
            return $this->responseJson(false, 200, 'Credential are not allowed!', "");
        }
        $user = $this->userService->findOne(['mobile_number' => $mobileNumber, 'is_active' => 1]);
        if (!empty($user)) {
            $destination = $request->mobile_number;
            $genOTp = rand(1000, 9999);
            $content = "Don't Share: $genOTp is your BrainQ verification OTP. For any assistance visit https://brainq.co.in Team BrainQ";
            $result = sendSms($destination, $content);
            return $this->responseJson(true, 200, 'User Details found', ['otp' => $genOTp]);
        }
        return $this->responseJson(false, 400, 'User not found', []);
    }

    public function resetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'numeric|digits:10|exists:users,mobile_number',
            'is_otp_verified' => 'required|boolean|in:1',
            'password' => 'required|min:8|string|confirmed'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        DB::beginTransaction();
        try {
            $user = $this->userService->findOne(['mobile_number' => $request->mobile_number, 'is_active' => 1]);
            $userPasswordUpdate = $this->userService->basicUpdate(['password' => bcrypt($request->password)], $user->id);
            if ($userPasswordUpdate) {
                DB::commit();
                return $this->responseJson(true, 200, 'Password reset successfully', []);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }

    public function changePassword(Request $request)
    {
        $user = auth()->user();
        $validator = Validator::make($request->all(), [
            'current_password' => [
                'required',
                function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                }
            ],
            'new_password' => 'required|string|min:6'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        DB::beginTransaction();
        try {
            $password = bcrypt($request->new_password);
            $isUserPasswordUpdated = auth()->user()->update([
                'password' => $password
            ]);
            if ($isUserPasswordUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Password Changed Successfully', new UserResource(auth()->user()));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }
}
