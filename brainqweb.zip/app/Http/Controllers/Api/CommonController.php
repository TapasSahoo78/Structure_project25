<?php

namespace App\Http\Controllers\Api;

use App\Models\Cms\Page;
use App\Models\Site\Test;
use App\Models\Site\Coupon;
use App\Models\Site\Medium;
use App\Models\Site\Package;
use App\Models\Site\Subject;
use Illuminate\Http\Request;
use App\Services\Site\BoardService;
use App\Services\Site\BannerService;
use App\Services\Location\StateService;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\PageResource;
use App\Http\Resources\Api\PlanResource;
use App\Http\Resources\Api\TestResource;
use App\Http\Resources\Api\BoardResource;
use App\Http\Resources\Api\StateResource;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\BannerResource;
use App\Http\Resources\Api\CouponResource;
use App\Http\Resources\Api\GradeResource;
use App\Http\Resources\Api\MediumResource;
use App\Http\Resources\Api\SubjectResource;
use App\Models\Site\Grade;

class CommonController extends BaseController
{
    protected $stateService, $boardService, $bannerService;

    public function __construct(StateService $stateService, BoardService $boardService, BannerService $bannerService)
    {
        $this->stateService = $stateService;
        $this->boardService = $boardService;
        $this->bannerService = $bannerService;
    }
    public function getLocations(Request $request)
    {
        $states = $this->stateService->getStates(['status' => true], 'name', 'asc');

        return $this->responseJson(true, 200, 'States Data Found', StateResource::collection($states));
    }
    public function getBanners(Request $request)
    {
        $filterConditions = ['is_active' => true];
        if ($request->has('state')) {
            $filterConditions = [
                'state' => $request->state
            ];
        }
        $banners = $this->bannerService->listBanners($filterConditions, 'order', 'asc');
        return $this->responseJson(true, 200, 'Banners Data Found', BannerResource::collection($banners));
    }
    public function getBoards(Request $request)
    {
        $filterConditions = ['is_active' => true];
        if ($request->has('state')) {
            $filterConditions = [
                'state' => $request->state
            ];
        }
        $boards = $this->boardService->listBoards($filterConditions, 'name', 'asc');
        return $this->responseJson(true, 200, 'Boards Data Found', BoardResource::collection($boards));
    }
    public function getMediums(Request $request)
    {
        $mediums = Medium::whereIn('name', ['bengali', 'english'])->get();
        return $this->responseJson(true, 200, 'Mediums Data Found', MediumResource::collection($mediums));
    }
    public function getSubjects(Request $request)
    {
        $subjects = Subject::where('is_active', true)->get();
        return $this->responseJson(true, 200, 'Subjects Data Found', SubjectResource::collection($subjects));
    }

    public function getPlans(Request $request)
    {
        $packages = Package::where('is_active', true)->get();
        return $this->responseJson(true, 200, 'Plans Data Found', PlanResource::collection($packages));
    }
    public function getCoupons(Request $request)
    {
        $coupons = Coupon::get();
        return $this->responseJson(true, 200, 'Coupons Data Found', CouponResource::collection($coupons));
    }
    public function getpage(Request $request, $slug)
    {
        if ($slug == 'faq') {
            return $this->responseJson(true, 200, 'Faq Data Found', array('link' => route('frontend.faqs')));
        }

        if ($slug == 'terms-condition') {
            return $this->responseJson(true, 200, 'Page Data Found', array('link' => route('terms.conditions')));
        }

        $page = Page::where('slug', $slug)?->first();
        if ($page) {
            return $this->responseJson(true, 200, 'Page Data Found', new PageResource($page));
        }
        return $this->responseJson(false, 404, 'No Page found', []);
    }
    public function getTests(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'required|in:practise,test',
            'subject_uuid' => 'required|string|exists:subjects,uuid',
            'chapter_uuid' => 'required|string|exists:chapters,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        $filterConditions = [
            'is_active' => true,
            'subject_id' => uuidtoid($request->subject_uuid, 'subjects')
        ];

        $type = $request->type;
        $tests = Test::whereHas('type', function ($query) use ($type) {
            $query = $query->where('type', $type);
        });

        // if ($request->has('chapter_uuid')) {
        $chapterId = uuidtoid($request->chapter_uuid, 'chapters');
        $tests = $tests->whereHas('chapters', function ($query) use ($chapterId) {
            $query = $query->where('id', $chapterId);
        });
        // }
        $tests = $tests->where($filterConditions)->get();
        if ($tests->isNotEmpty() && $tests->first()->questions->isNotEmpty()) {
            // return $this->responseJson(true, 200, 'Tests Data Found', new TestResource($tests->first()));
            return $this->responseJson(true, 200, 'Tests Data Found', TestResource::collection($tests));
        }
        return $this->responseJson(false, 404, 'No ' . $type . ' set found', []);
    }

    public function getGrades(Request $request)
    {
        $grades = Grade::all();
        return $this->responseJson(true, 200, 'Grades Found', GradeResource::collection($grades));
    }
}
