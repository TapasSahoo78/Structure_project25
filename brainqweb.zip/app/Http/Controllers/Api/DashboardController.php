<?php

namespace App\Http\Controllers\Api;

use App\Models\Site\Exam;
use Illuminate\Http\Request;
use App\Models\Site\LiveClass;
use Illuminate\Support\Carbon;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Services\User\QueryService;
use App\Notifications\AllNotification;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\ExamResource;
use App\Http\Resources\Api\ExamResultResource;
use App\Http\Resources\Api\UserResource;
use App\Http\Resources\Api\GraphResource;
use App\Http\Resources\Api\QueryResource;
use Illuminate\Support\Facades\Validator;
use App\Services\User\SubscriptionService;
use App\Http\Resources\Api\SubjectResource;
use App\Http\Resources\Api\LiveClassResource;
use App\Http\Resources\Api\NotificationResource;
use App\Models\ExamResultHistory;
use App\Models\ExamScore;
use App\Models\User\Query;
use Illuminate\Support\Facades\Auth;

class DashboardController extends BaseController
{
    protected $userService, $subscriptionService, $queryService;

    public function __construct(UserService $userService, SubscriptionService $subscriptionService, QueryService $queryService)
    {
        $this->userService = $userService;
        $this->subscriptionService = $subscriptionService;
        $this->queryService = $queryService;
    }
    public function getSubjects(Request $request)
    {
        $user = auth()->user();
        $boardSubjects = $user->classes?->first()->subjects->where('is_active', true);
        return $this->responseJson(true, 200, 'Subjects found according to the class', SubjectResource::collection($boardSubjects));
    }
    public function getProfile(Request $request)
    {
        return $this->responseJson(true, 200, 'Profile Data Found successfully', new UserResource(auth()->user()));
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|min:3',
            'profile_image' => 'sometimes|file|image|mimes:png,jpg,jpeg',
            'email' => 'sometimes|nullable|email|unique:users,email,' . $user->id,
            'username' => 'sometimes|nullable|unique:users,username,' . $user->id,
            'gender' => 'sometimes|nullable|string|in:male,female,other',
            'blood_group' => 'sometimes|nullable|string|in:A+,A-,B+,B-,AB+,AB-,O+,O-',
            'school_name' => 'sometimes|nullable|string|min:3',
            'state' => 'sometimes|nullable|string|exists:states,id',
            'city' => 'sometimes|nullable|string|exists:cities,id',
            'pincode' => 'sometimes|nullable|numeric|min:100000|max:999999',
            'board' => 'sometimes|exists:boards,uuid',
            'class' => 'sometimes|exists:site_classes,uuid',
            'medium' => 'sometimes|exists:mediums,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        DB::beginTransaction();
        try {
            $isUserUpdated = $this->userService->updateStudentUser($request->except('_token'), $user->id);
            if ($isUserUpdated) {
                DB::commit();
                // $data = ['type' => 'profileUpdated', 'title' => 'Student Profile'];
                // $user->notify(new AllNotification($data));
                return $this->responseJson(true, 200, 'Profile Updated successfully', new UserResource($isUserUpdated));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function subscription(Request $request)
    {
        $user = auth()->user();
        $validator = Validator::make($request->all(), [
            'package_uuid' => 'required|string|exists:packages,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        DB::beginTransaction();
        try {
            $isSubscriptionCreated = $this->subscriptionService->addSubscription($request->only('package_uuid'), auth()->user()->id);
            if ($isSubscriptionCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'User subscribed successfully', new UserResource($isSubscriptionCreated));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function addQuery(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'query' => 'required|string'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), "");
        }
        DB::beginTransaction();
        try {
            $request->merge(['user_id' => auth()->user()->id]);
            $isQueryCreated = $this->queryService->createOrupdateQuery($request->except('_token'));
            if ($isQueryCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Query added successfully', new QueryResource($isQueryCreated));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function getQueries(Request $request)
    {
        $queries = Query::where('user_id', Auth::id())->latest()->get();
        return $this->responseJson(true, 200, 'Student Queries found', QueryResource::collection($queries));
    }

    public function addScreenTime(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'required|string|in:in,out',
            'screen' => 'required|string',
            'subject_uuid' => 'required|exists:subjects,uuid',
            'chapter_uuid' => 'required|exists:chapters,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        DB::beginTransaction();
        try {
            $filterConditions = [
                'screen_name' => $request->screen,
                'subject_id' => uuidtoid($request->subject_uuid, 'subjects'),
                'chapter_id' => uuidtoid($request->chapter_uuid, 'chapters')
            ];
            $isGraphExist = auth()->user()->graphs()->where($filterConditions)->whereDate('created_at', '=', now()->format('Y-m-d'))->whereNull('out_time')->first();
            if ($request->type == 'in') {
                $data = [
                    'in_time' => now()
                ];
            } else {
                $data = [
                    'out_time' => now()
                ];
            }
            if ($isGraphExist) {
                $isGraphUpdatedOrCreated = $isGraphExist->update($data);
            } else {
                $data = array_merge($data, [
                    'screen_name' => $request->screen,
                    'subject_id' => uuidtoid($request->subject_uuid, 'subjects'),
                    'chapter_id' => uuidtoid($request->chapter_uuid, 'chapters'),
                ]);
                $isGraphUpdatedOrCreated = auth()->user()->graphs()->create($data);
            }
            if ($isGraphUpdatedOrCreated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Screen time stored successfully', []);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }

    public function getScreenGraph(Request $request)
    {
        $date = date('Y-m-d');
        $validator = Validator::make($request->all(), [
            'from_date' => 'required|date|date_format:Y-m-d|before_or_equal:' . $date,
            'to_date' => 'required|date|date_format:Y-m-d|before_or_equal:' . $date . '|after_or_equal:from_date'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        $graphs = auth()->user()->graphs()->whereBetween('created_at', [Carbon::parse($request->from_date)->format('Y-m-d 00:00:00'), Carbon::parse($request->to_date)->format('Y-m-d 23:59:59')])->get()?->groupBy('subject.name');
        if ($graphs->isNotEmpty()) {
            foreach ($graphs as $key => $graph) {
                $data[$key] = GraphResource::collection($graph);
            }
            return $this->responseJson(true, 200, 'Grpah Data Found', $data);
        } else {
            return $this->responseJson(true, 200, 'No data found', []);
        }

    }


    public function getLiveclasses(Request $request)
    {
        $userSubjects = auth()->user()->classes()->first()?->subjects()?->pluck('id')?->toArray();
        $userClass = auth()->user()->classes()->first()?->id;
        if ($userClass && !is_null($userSubjects)) {
            //dd(Carbon::now('Asia/Kolkata'));
            if (isset($request->will_end_at) && !empty($request->will_end_at)) {
                $today = $request->will_end_at;
                // ->where('will_live_at', '>=', now()->toDateString())
                // $liveClasses = LiveClass::whereIn('subject_id', $userSubjects)->where('site_class_id', $userClass)->where('is_finished', false)->where('will_live_at', '>=', now())->where('will_end_at', '<=', $today)->get();
                $liveClasses = LiveClass::whereIn('subject_id', $userSubjects)
                    ->where('is_active', true)
                    ->where('site_class_id', $userClass)
                    ->where('is_finished', false)
                    ->where('will_live_at', '>=', Carbon::now('Asia/Kolkata'))
                    ->where('will_end_at', '<=', Carbon::now('Asia/Kolkata'))
                    ->get();
                if ($liveClasses->isNotEmpty())
                    return $this->responseJson(true, 200, 'Live Class data found', LiveClassResource::collection($liveClasses));
            }
            $liveClasses = LiveClass::whereIn('subject_id', $userSubjects)
                ->where('is_active', true)
                ->where('site_class_id', $userClass)
                ->where('is_finished', false)
                ->where('will_live_at', '>', Carbon::now('Asia/Kolkata')->toDateString())
                ->get();
            if ($liveClasses->isNotEmpty())
                return $this->responseJson(true, 200, 'Live Class data found', LiveClassResource::collection($liveClasses));
        }
        return $this->responseJson(false, 200, 'No Live Class found', []);

    }

    public function makeEnrollmentInLiveClass(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'live_class_uuid' => 'required|exists:live_classes,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        DB::beginTransaction();
        try {
            $liveClassId = uuidtoid($request->live_class_uuid, 'live_classes');
            // $liveClassAttached = auth()->user()->enrolledClasses()->sync([$liveClassId]);
            auth()->user()->enrolledClasses()->attach($liveClassId);
            DB::commit();
            return $this->responseJson(true, 200, 'You have enrolled successfully', LiveClassResource::collection(auth()->user()->enrolledClasses));
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }

    }

    public function getExams(Request $request)
    {
        $userClassId = auth()->user()?->classes->first()?->id;

        // $isExamsFound = Exam::where(['site_class_id' => $userClassId, 'is_active' => true])->where('scheduled_at', '>=', Carbon::now('Asia/Kolkata'))->get();
        $currentTime = Carbon::now('Asia/Kolkata');
        $isExamsFound = Exam::where(['site_class_id' => $userClassId, 'is_active' => true])
            // ->where('scheduled_at', '>=', $currentTime)
            ->whereRaw('DATE_ADD(scheduled_at, INTERVAL total_time MINUTE) >= ?', [$currentTime])
            ->get();

        if ($isExamsFound->isNotEmpty()) {
            return $this->responseJson(true, 200, 'Exams data found', ExamResource::collection($isExamsFound));
        }

        return $this->responseJson(false, 200, 'No exams found');
    }

    public function notifications()
    {
        $allNotifications = auth()->user()->notifications()->get();

        $notifications = auth()->user()->unreadNotifications;
        return $this->responseJson(true, 200, 'Notifications found successfully', [
            NotificationResource::collection($notifications),
            NotificationResource::collection($allNotifications)
        ]);
    }
    public function readNotifications(Request $request)
    {
        if ($request->has('id')) {
            auth()->user()->unreadNotifications->where('id', $request->id)->markAsRead();
        } else {
            auth()->user()->unreadNotifications->markAsRead();
        }
        $notifications = auth()->user()->notifications()->get();
        return $this->responseJson(true, 200, 'Notifications found succesfully', NotificationResource::collection($notifications));
    }
    public function delteNotification(Request $request)
    {
        $isNotificationDeleted = auth()->user()->notifications()->where('id', $request->id)->delete();
        $message = $isNotificationDeleted ? 'Notification deleted successfully' : 'Notification delete unscessfull';
        $notifications = auth()->user()->notifications()->get();
        return $this->responseJson(true, 200, $message, NotificationResource::collection($notifications));
    }

    public function storeExamScore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_id' => 'required',
            'score' => 'required',
            'total_score' => 'required',
            'user_ans' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        DB::beginTransaction();
        try {
            $liveExamId = uuidtoid($request->exam_id, 'exams');
            $userId = Auth::id();

            $examScores = collect($request->user_ans)->map(function ($answer) use ($liveExamId, $userId) {
                return [
                    'exam_id' => $liveExamId,
                    'user_id' => $userId,
                    'question_id' => uuidtoid($answer['question_id'], 'questions'),
                    'answer_id' => $answer['answer_id'] ? uuidtoid($answer['answer_id'], 'answers') : NULL,
                    'created_at' => Carbon::now()
                ];
            })->toArray();

            ExamResultHistory::insert($examScores);

            $examScore = ExamScore::create([
                'exam_id' => $liveExamId,
                'user_id' => Auth::id(),
                'score' => $request->score,
                'total_score' => $request->total_score
            ]);
            if (isset($examScore) && !empty($examScore)) {
                DB::commit();
                return $this->responseJson(true, 200, 'Exam has been completed', $examScore);
            } else {
                return $this->responseJson(true, 200, 'Exam failed', (object) []);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }

    }

    public function getExamHistory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_id' => 'required|exists:exams,uuid'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->all(), []);
        }
        try {
            $examResult = ExamResultHistory::with(['exam', 'user', 'question', 'answer'])->where([
                'exam_id' => uuidtoid($request->exam_id, 'exams'),
                'user_id' => Auth::id()
            ])->get();
            return $this->responseJson(true, 200, 'Get exam result succesfully', ExamResultResource::collection($examResult));
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), []);
        }
    }
}
