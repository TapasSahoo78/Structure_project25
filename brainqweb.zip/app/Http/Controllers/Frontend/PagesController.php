<?php

namespace App\Http\Controllers\Frontend;

use App\Models\Cms\Page;
use Illuminate\Http\Request;
use App\Services\Site\FaqService;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BaseController;

class PagesController extends BaseController
{

    public function __construct(protected FaqService $faqService){
        $this->faqService= $faqService;
    }
    public function anyPages(Request $request,$slug){
        $page= Page::where(['slug'=>$slug,'is_active'=>true])->first();
        if($page){
            $this->setPageTitle($page->title);
            return view('frontend.page.any-pages',compact('page'));
        }
        $this->showErrorPage(404);
    }

    public function listFaq(Request $request){
        $this->setPageTitle('Faqs');
        $faqs= $this->faqService->listFaqs(['is_active'=>true],'id','asc');
        return view('frontend.page.faqs',compact('faqs'));
    }
}
