<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\BaseController;
use Illuminate\Http\Request;

class DashboardController extends BaseController
{
    public function index(Request $request){
        return view('student.dashboard.index');
    }
}
