<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\BaseController;

class TeacherController extends BaseController
{
    public function index(Request $request){
        $this->setPageTitle('Dashboard');
        return view('teacher.dashboard.index');
    }

    public function profile(Request $request){
        $this->setPageTitle('My Profile');
        if($request->post()){
            $request->validate([
                'username'=> 'required|string|unique:users,username,'.auth()->user()->id,
                'first_name'=> 'required|string',
                'last_name'=> 'sometimes|string',
                'mobile_number'=> 'required|numeric|unique:users,mobile_number,'.auth()->user()->id,
                'gender'=> 'sometimes|string|in:male,female,other',
                'birthday'=> 'sometimes|nullable|date|date_format:Y-m-d|before:-18 years',
                'designation'=> 'sometimes|nullable|string',
                'qualification'=> 'sometimes|nullable|string',
                'address'=> 'sometimes|nullable|string',
            ]);
            // dd($request->all());
            Db::beginTransaction();
            try {
                $isUserUpdated= auth()->user()->update($request->except('_token'));
                if($isUserUpdated){
                    $isUserProfileUpdated= auth()->user()->profile()->update($request->only(['gender','birthday','designation','qualification','address']));
                    if($isUserProfileUpdated){
                        DB::commit();
                        return $this->responseRedirectBack('User Profile updated successfully','success');
                    }
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong','error');
            }
        }
        return view('teacher.dashboard.profile');
    }

    public function changePassword(Request $request){
        if ($request->post()) {
            $user = auth()->user();
            $request->validate([
                'current_password' => ['required', function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                }],
                'password' => 'required|string|min:6|confirmed'
            ]);

            DB::beginTransaction();
            try {
                $password = bcrypt($request->password);
                $isUserPasswordUpdated = $user->update([
                    'password' => $password
                ]);
                if ($isUserPasswordUpdated) {
                    DB::commit();
                    return $this->responseRedirectBack('Password Changed Successfully','success');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong','error');
            }
        }
        $this->setPageTitle('Change Password');
        return view('teacher.dashboard.change-password');
    }
}
