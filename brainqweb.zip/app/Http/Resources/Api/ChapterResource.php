<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ChapterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid'=> $this->uuid,
            'name' => $this->name,
            'number' => $this->number,
            'description' => $this->description,
            'videos'=> VideoResource::collection($this->videos),
            'notes'=> NoteResource::collection($this->notes),
            'display_picture' => $this->display_picture,
            'banner_picture' => $this->banner_picture
        ];
    }
}
