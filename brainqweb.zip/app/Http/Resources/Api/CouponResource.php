<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CouponResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid'=> $this->uuid,
            'code'=> $this->code,
            'type'=> $this->type,
            'discount'=> $this->discount,
            'usage_per_user'=> $this->usage_per_user,
            'usage_of_coupon'=> $this->usage_of_coupon,
            'started_at'=> $this->started_at,
            'ended_at'=> $this->ended_at,
            'is_expired'=> $this->is_expired,
            'is_active'=> $this->is_active,
        ];
    }
}
