<?php

namespace App\Http\Resources\Api;

use App\Models\ExamScore;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class ExamResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $isAttend = ExamScore::where([
            'exam_id' => $this?->id,
            'user_id' => Auth::id()
        ])->first();
        return [
            'uuid' => $this->uuid,
            'name' => $this->name,
            'board_uuid' => $this->board->uuid,
            'class_id' => $this->site_class_id,
            'subject_id' => $this->subject->id,
            'class' => new ClassResource($this->class),
            'subject' => new SubjectResource($this->subject),
            'questions' => QuestionResource::collection($this->questions),
            'scheduled_at' => Carbon::parse($this->scheduled_at)->format('Y-m-d H:i'),
            'total_marks' => $this->total_marks,
            'total_time' => $this->total_time,

            'is_attended' => $isAttend ? true : false
        ];
    }
}
