<?php

namespace App\Http\Resources\Api;

use App\Models\Site\Answer;
use Illuminate\Http\Resources\Json\JsonResource;

class ExamResultResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $userAns = Answer::select('answer')->where(['question_id' => $this?->question_id, 'is_right' => 1])->first();
        return [
            'id' => $this?->uuid,
            'question' => $this?->question?->question,
            'question_ans' => $this?->question?->answers,
            'user_answer' => $this?->answer?->answer,
            'ans_status' => $userAns?->answer == $this?->answer?->answer ? true : false
        ];
    }
}
