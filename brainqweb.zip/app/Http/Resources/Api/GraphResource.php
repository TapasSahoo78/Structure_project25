<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class GraphResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        return [
            'uuid'=> $this->uuid,
            'screen_name'=> $this->screen_name,
            'in_time'=> $this->in_time,
            'out_time'=> $this->out_time,
            'total_duration'=> $this->total_duration
        ];
    }
}
