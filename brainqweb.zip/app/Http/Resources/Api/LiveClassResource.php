<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class LiveClassResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $enrolledClass= auth()?->user()->enrolledclasses()?->pluck('id')->toArray() ?? [];
        return [
            'uuid'=> $this->uuid,
            'user'=> $this->teacher->uuid,
            'board_uuid'=> $this->board->uuid,
            'class_id'=> $this->site_class_id,
            'subject_id'=> $this->subject->id,
            'link_type'=> $this->link_type,
            'teacher' =>new UserResource($this->teacher),
            'class_details' =>new ClassResource($this->class),
            'subject_details'=> new SubjectResource($this->subject),
            'url'=> $this->url,
            'code'=> getVideoCode($this->url),
            'name'=> $this->name,
            'description'=> $this->description,
            'will_live_at'=> Carbon::parse($this->will_live_at)->format('Y-m-d H:i'),
            'will_end_at'=> Carbon::parse($this->will_end_at)->format('Y-m-d H:i'),
            'is_started' => (bool) $this->is_started,
            'is_finished' => (bool) $this->is_finished,
            'is_active' => (bool) $this->is_active,
            'is_enrolled' => (bool) in_array($this->id,$enrolledClass)
        ];
    }
}
