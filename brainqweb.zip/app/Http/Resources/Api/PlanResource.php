<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PlanResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "name" => $this->name,
            "uuid" => $this->uuid,
            "package_type" => $this->package_type,
            "description" => $this->description,
            "price" => $this->price?->price,
            "duration" => $this->price?->duration . ' ' . $this->price->interval,
            "is_most_popular" => (bool) $this->is_most_popular,
            "is_active" => (bool) $this->is_active,
            "coupons"=> CouponResource::collection($this->coupons),
            "b_duration"=>$this->price?->duration,
            "b_interval"=> $this->price?->interval
        ];
    }
}
