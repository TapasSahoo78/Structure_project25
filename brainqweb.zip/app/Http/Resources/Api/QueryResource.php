<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class QueryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid'=> $this->uuid,
            'query'=> $this->query,
            'answer'=> $this->answer,
            'status'=> $this->status== 0 ? 'pending' : ($this->status== 1 ? 'resolved' : 'in progress'),
            'replied_at'=> $this->replied_at,
            'created_at'=> $this->created_at,

        ];
    }
}
