<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use App\Http\Resources\Api\ChapterResource;
use Illuminate\Http\Resources\Json\JsonResource;

class SubjectResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid' => $this->uuid,
            'name' => $this->name,
            'display_picture' => $this->display_picture,
            'banner_picture' => $this->banner_picture,
            'local_language' => $this->local_language,
            'is_top' => (bool) $this->is_top,
            'chapters' => ChapterResource::collection($this->chapters->where('is_active', true))
        ];
    }
}
