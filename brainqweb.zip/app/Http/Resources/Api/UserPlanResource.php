<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserPlanResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "name" => $this->packageable?->name,
            "uuid" => $this->packageable?->uuid,
            "package_type"=> $this->packageable?->package_type,
            "description"=> $this->packageable?->description,
            "price"=> $this->packageable?->price?->price,
            "start_date"=> $this->start_date,
            "end_date"=> $this->end_date,
            "duration"=> $this->packageable?->price?->duration.' '. $this->packageable?->price->interval,
            "is_most_popular"=> (bool) $this->is_most_popular,
            "is_active"=> (bool) $this->packageable?->is_active,
        ];
    }
}
