<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $dataArray = [
            'uuid' => $this->uuid,
            'mobile_number' => $this->mobile_number,
            'name' => $this->first_name,
            'app_id' => (integer) $this->app_id,
            'username' => $this->username,
            'otp' => $this->verification_code,
            'profile_picture' => $this->profile_picture,
            'school_name' => $this->profile?->school_name,
            'blood_group' => $this->profile?->blood_group,
            'state' => $this->profile?->state,
            'city' => $this->profile?->city,
            'pincode' => $this->profile?->pincode,
            'board' => new BoardResource($this->boards?->first()),
            'class' => new ClassResource($this->classes?->first()),
            'medium' => new MediumResource($this->mediums?->first()),
            'is_active' => (bool) $this->is_active,
            'is_online' => (bool) $this->is_online,
            'is_approve' => (bool) $this->is_approve,
            'is_blocked' => (bool) $this->is_blocked,
            'is_subscribed' => (bool) $this->is_subscribed,
            "plan" => new UserPlanResource($this->current_plan),
            "created_at" => $this->created_at
        ];
        if (request()->step == 'fifth' || request()->step == 'fourth' || request()->route()->getName() == 'auth.login') {
            $tokenArray = ['access-token' => $this->createToken('access-token')->accessToken];
            $dataArray = array_merge($dataArray, $tokenArray);
        }
        return $dataArray;
    }
}
