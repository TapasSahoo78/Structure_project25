<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ChapterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'name' => $this->name,
            'number' => $this->number,
            'subject'=> $this->subject->name,
            'is_active'=> $this->is_active,
            'description'=> $this->description,
            'display_picture'=> $this->display_picture,
            'banner_picture' => $this->banner_picture
        ];
    }
}
