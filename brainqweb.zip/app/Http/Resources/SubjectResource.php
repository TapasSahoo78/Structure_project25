<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SubjectResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid' => $this->uuid,
            'name' => $this->name,
            'board' =>$this->boards?->first()?->initial_name,
            'board_uuid' =>$this->boards?->first()?->uuid,
            'class' => $this->classes?->first()?->name.'('.$this->classes?->first()?->roman.')',
            'class_id' => $this->classes?->first()?->id,
            'display_picture' => $this->display_picture,
            'is_top'=> (bool) $this->is_top,
            'banner_picture' => $this->banner_picture,
        ];
    }
}
