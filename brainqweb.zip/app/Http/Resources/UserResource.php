<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request): array
    {
        return [
            'uuid' => $this->uuid,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'full_name' => $this->full_name,
            'email' => $this->email,
            'designation' => $this->profile?->designation,
            'address' => $this->profile?->address,
            'school_name' => $this->profile?->school_name,
            'pincode' => $this->profile?->pincode,
            'state' => $this->profile?->state,
            'state_slug' => $this->profile?->state ? nametoslug($this->profile?->state ,'states') : '',
            'subjects' => $this->profile?->subjects,
            'qualification' => $this->profile?->qualification,
            'mobile_number' => $this->mobile_number ?? '',
            'board' =>$this->boards?->first()?->initial_name,
            'board_uuid' =>$this->boards?->first()?->uuid,
            'medium_uuid' =>$this->mediums?->first()?->uuid,
            'class' => $this->classes?->first()?->name.'('.$this->classes?->first()?->roman.')',
            'city_id' => !empty($this->profile?->city) ? slugtoid($this->profile?->city,'cities') : '' ,
            'class_id' => $this->classes?->first()?->id,
            'display_picture'=> $this->profile_picture
        ];
    }
}
