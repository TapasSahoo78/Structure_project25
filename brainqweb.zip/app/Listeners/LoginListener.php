<?php

namespace App\Listeners;


use App\Services\User\UserService;
use Illuminate\Auth\Events\Login;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class LoginListener
{

    protected $userService;
    /**
     * Create the event listener.
     */
    public function __construct(UserService $userService)
    {
        $this->userService= $userService;
    }

    /**
     * Handle the event.
     */
    public function handle(Login $event): void
    {
        auth()->user()->update([
            'is_online' => true,
            'last_login_at'=>date('Y-m-d H:i:s'),
            'last_login_ip' => request()->ip()
        ]);
    }
}
