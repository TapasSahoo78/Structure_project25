<?php

namespace App\Listeners;

use App\Models\User\User;
use App\Services\User\UserService;
use Illuminate\Auth\Events\Logout;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class LogoutListener
{

    protected $userService;
    /**
     * Create the event listener.
     */
    public function __construct(UserService $userService)
    {
        $this->userService= $userService;
    }

    /**
     * Handle the event.
     */
    public function handle(Logout $event): void
    {
        $this->userService->updateUser([
            'is_online' => false,
            'last_logout_at'=>date('Y-m-d H:i:s'),
        ],$event?->user?->id);
    }
}
