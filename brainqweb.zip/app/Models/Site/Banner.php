<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\SiteMedia\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Banner extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'uuid',
        'name',
        'is_active',
        'order',
    ];

    public function image(){
        return $this->morphOne(Media::class,'mediaable');
    }

    public function getDisplayImageAttribute(){
        return $this->bannerImage();
    }

    protected function bannerImage($type='original'){
        $file= $this->image?->file;
        if($file){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/' . $type . '/banner/' . $file))){
                    return asset('storage/images/' . $type . '/banner/' . $file);
                }
            }
        }
        return asset('assets/img/default-banner.png');
    }
}
