<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\SiteMedia\Media;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Board extends Model
{
    use HasFactory, Sluggable,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $model->state = ucwords(strtolower($model->state));
            preg_match_all('/\b\w/', $model->name, $matches);
            $model->initial_name = !empty($model->initial_name) ? $model->initial_name : strtoupper(implode('', $matches[0]));
        });
    }
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name',
            ],
        ];
    }

    protected $fillable = [
        'name',
        'uuid',
        'slug',
        'initial_name',
        'state',
        'address',
        'email',
        'website',
        'is_active'
    ];

    public function classes():BelongsToMany{
        return $this->belongsToMany(SiteClass::class,'boards_classes');
    }

    public function students() :BelongsToMany{
        return $this->belongsToMany(User::class,'students_boards');
    }

    public function subjects():BelongsToMany {
        return $this->belongsToMany(Subject::class,'boards_subjects');
    }

    public function liveClasses():HasMany{
        return $this->hasMany(LiveClass::class);
    }
    public function exams():HasMany{
        return $this->hasMany(Exam::class);
    }

    public function media():MorphOne{
        return $this->morphOne(Media::class,'mediaable');
    }

    public function getdisplayPictureAttribute(){
        $file= $this->media()?->value('file');
        if(!is_null($file)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/original/board/' . $file))){
                    return asset('storage/images/original/board/' . $file);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }

}
