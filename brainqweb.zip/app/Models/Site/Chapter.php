<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\SiteMedia\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Chapter extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'name',
        'subject_id',
        'description',
        'number',
        'is_active'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function subject():BelongsTo{
        return $this->belongsTo(Subject::class);
    }

    public function videos():HasMany{
        return $this->hasMany(Video::class);
    }
    public function notes():HasMany{
        return $this->hasMany(Note::class);
    }

    public function tests():BelongsToMany{
        return $this->belongsToMany(Test::class,'tests_chapters');
    }

    public function graphs():HasMany{
        return $this->hasMany(Graph::class);
    }

    public function media():MorphOne{
        return $this->morphOne(Media::class,'mediaable');
    }

    public function getdisplayPictureAttribute(){
        $file= $this->media()?->value('file');
        if(!is_null($file)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/original/chapter/' . $file))){
                    return asset('storage/images/original/chapter/' . $file);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }

    public function getbannerPictureAttribute(){
        $file= $this->media()?->where('media_type','banner')?->value('file');
        if(!is_null($file)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/original/banner/' . $file))){
                    return asset('storage/images/original/banner/' . $file);
                }
            }
        }
        return asset('assets/img/default-chapter-banner.png');
    }
}
