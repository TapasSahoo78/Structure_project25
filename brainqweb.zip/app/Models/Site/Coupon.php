<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Coupon extends Model
{
    use HasFactory, SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'uuid',
        'title',
        'code',
        'type',
        'discount',
        'usage_per_user',
        'usage_of_coupon',
        'started_at',
        'ended_at',
        'is_expired',
        'is_active'
    ];

    public function getDateDiffrenceAttribute()
    {
        $startDate = Carbon::parse($this->started_at);
        $endDate = Carbon::parse($this->ended_at);
        return $endDate->diffInDays($startDate);
    }


    public function packages():BelongsToMany{
        return $this->belongsToMany(Package::class,'coupons_packages');
    }

}
