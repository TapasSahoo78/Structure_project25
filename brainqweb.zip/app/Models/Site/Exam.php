<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Exam extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'uuid',
        'name',
        'code',
        'site_class_id',
        'board_id',
        'subject_id',
        'total_time',
        'total_marks',
        'is_active',
        'scheduled_at',
    ];


    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }


    public function subject():BelongsTo{
        return $this->belongsTo(Subject::class);
    }
    public function board():BelongsTo{
        return $this->belongsTo(Board::class);
    }

    public function class():BelongsTo{
        return $this->belongsTo(SiteClass::class,'site_class_id');
    }

    public function questions():BelongsToMany{
        return $this->belongsToMany(Question::class,'exams_questions');
    }


}
