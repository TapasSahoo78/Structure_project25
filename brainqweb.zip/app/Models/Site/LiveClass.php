<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class LiveClass extends Model
{
    use HasFactory, SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'name',
        'link_type',
        'description',
        'url',
        'user_id',
        'subject_id',
        'board_id',
        'site_class_id',
        'will_live_at',
        'will_end_at',
        'description',
        'is_started',
        'is_finished',
        'is_active'
    ];

    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class);
    }

    public function board(): BelongsTo
    {
        return $this->belongsTo(Board::class);
    }
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function class(): BelongsTo
    {
        return $this->belongsTo(SiteClass::class, 'site_class_id');
    }

    public function enrolledusers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'live_class_user');
    }
}
