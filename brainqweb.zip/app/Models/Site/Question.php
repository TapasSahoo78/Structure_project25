<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Question extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'uuid',
        'question',
        'chapter_id',
        'marks',
        'is_active'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function tests():BelongsToMany{
        return $this->belongsToMany(Test::class,'tests_questions');
    }
    public function exams():BelongsToMany{
        return $this->belongsToMany(Exam::class,'exams_questions');
    }

    public function chapter():BelongsTo{
        return $this->belongsTo(Chapter::class);
    }

    public function answers():HasMany{
        return $this->hasMany(Answer::class);
    }
}
