<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\SiteMedia\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class SiteClass extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'name',
        'roman',
        'is_active'

    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function media():MorphOne{
        return $this->morphOne(Media::class,'mediaable');
    }

    public function getdisplayPictureAttribute(){
        $file= $this->media()?->value('file');
        if(!is_null($file)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/original/class/' . $file))){
                    return asset('storage/images/original/class/' . $file);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }

    public function subjects():BelongsToMany{
        return $this->belongsToMany(Subject::class,'classes_subjects');
    }

    public function userSubjects():BelongsToMany{
        return $this->belongsToMany(Subject::class,'users_subjects_classes')->withPivot('user_id')->join('users','user_id','=','users.id');
    }

    public function boards():BelongsToMany{
        return $this->belongsToMany(Board::class,'boards_classes');
    }

    public function users() :BelongsToMany{
        return $this->belongsToMany(User::class,'students_classes');
    }
    public function mediums() :BelongsToMany{
        return $this->belongsToMany(Medium::class,'classes_mediums');
    }

    public function liveclasses():HasMany{
        return $this->hasMany(LiveClass::class);
    }
}
