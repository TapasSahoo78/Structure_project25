<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\SiteMedia\Media;
use App\Models\User\Graph;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Subject extends Model
{
    use HasFactory, Sluggable, SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    protected $fillable = [
        'name',
        'is_top',
        'is_active'
    ];

    public function classes(): BelongsToMany
    {
        return $this->belongsToMany(SiteClass::class, 'classes_subjects');
    }
    public function userClasses(): BelongsToMany
    {
        return $this->belongsToMany(SiteClass::class, 'users_subjects_classes')->withPivot('user_id')->join('users', 'user_id', '=', 'users.id');
    }

    public function boards(): BelongsToMany
    {
        return $this->belongsToMany(Board::class, 'boards_subjects');
    }

    public function chapters(): HasMany
    {
        return $this->hasMany(Chapter::class);
    }
    public function graphs(): HasMany
    {
        return $this->hasMany(Graph::class);
    }

    public function liveclasses(): HasMany
    {
        return $this->hasMany(LiveClass::class);
    }


    public function media(): MorphOne
    {
        return $this->morphOne(Media::class, 'mediaable');
    }

    public function getdisplayPictureAttribute()
    {
        // $file = $this->media()?->value('file');
        $file = $this->media()?->where('media_type', 'image')?->value('file');

        if (!is_null($file)) {
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if ($fileDisk == 'public') {
                if (file_exists(public_path('storage/images/original/subject/' . $file))) {
                    return asset('storage/images/original/subject/' . $file);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }
    public function getbannerPictureAttribute()
    {
        $file = $this->media()?->where('media_type', 'banner')?->value('file');
        if (!is_null($file)) {
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if ($fileDisk == 'public') {
                if (file_exists(public_path('storage/images/original/banner/' . $file))) {
                    return asset('storage/images/original/banner/' . $file);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }
}
