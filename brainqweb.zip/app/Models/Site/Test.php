<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Test extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'test_type_id',
        'name',
        'subject_id',
        'total_time',
        'is_active'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function type():BelongsTo{
        return $this->belongsTo(TestType::class,'test_type_id');
    }

    public function subject():BelongsTo{
        return $this->belongsTo(Subject::class);
    }

    public function chapters():BelongsToMany{
        return $this->belongsToMany(Chapter::class,'tests_chapters');
    }

    public function questions():BelongsToMany{
        return $this->belongsToMany(Question::class,'tests_questions');
    }
}
