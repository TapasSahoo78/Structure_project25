<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\SiteMedia\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Video extends Model
{
    use HasFactory,SoftDeletes;


    protected $fillable= [
        'uuid',
        'chapter_id',
        'name',
        'url',
        'code',
        'is_free',
        'is_active',
        'description',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
        self::created(function ($model) {
            $model->thumbnail = (string) Uuid::generate(4);
        });
    }

    public function chapter():BelongsTo{
        return $this->belongsTo(Chapter::class);
    }
    public function video():HasOne{
        return $this->hasOne(Video::class);
    }

    public function media():MorphOne{
        return $this->morphOne(Media::class,'mediaable');
    }

    public function getdisplayPictureAttribute(){
        return 'https://img.youtube.com/vi/'.$this->code.'/hqdefault.jpg';
    }
}
