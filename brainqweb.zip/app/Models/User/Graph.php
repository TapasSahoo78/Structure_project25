<?php

namespace App\Models\User;

use Webpatser\Uuid\Uuid;
use App\Models\Site\Chapter;
use App\Models\Site\Subject;
use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Graph extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'screen_name',
        'user_id',
        'subject_id',
        'chapter_id',
        'in_time',
        'out_time'
    ];

    public function user():BelongsTo{
        return $this->belongsTo(User::class);
    }
    public function chapter():BelongsTo{
        return $this->belongsTo(Chapter::class);
    }
    public function subject():BelongsTo{
        return $this->belongsTo(Subject::class);
    }

    public function gettotalDurationAttribute(){
        $inTime= Carbon::parse($this->in_time);
        if(!is_null($this->out_time)){
            $outTime= Carbon::parse($this->out_time);
            $diffrence= $outTime->floatDiffInSeconds($inTime);
        }
        return $diffrence ?? 0 ;

    }
}
