<?php

namespace App\Models\User;

use Webpatser\Uuid\Uuid;
use App\Models\Site\Board;
use App\Models\Site\Medium;
use App\Models\Site\Document;
use App\Models\Site\LiveClass;
use App\Models\Site\SiteClass;
use App\Models\SiteMedia\Media;
use Laravel\Passport\HasApiTokens;
use App\Models\Site\PackageValidity;
use App\Models\Site\UserSubjectClass;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Traits\HasRolesAndPermissions as TraitsHasRolesAndPermissions;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, TraitsHasRolesAndPermissions;

    public function findForPassport($username)
    {
        return $this->where('mobile_number', $username)->first();
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'uuid',
        'app_id',
        'email',
        'mobile_number',
        'password',
        'username',
        'verification_code',
        'email_verified_at',
        'mobile_number_verified_at',
        'is_online',
        'device_token',
        'is_active',
        'is_approve',
        'is_subscribed',
        'is_blocked',
        'last_login_at',
        'last_logout_at',
        'last_login_ip'
    ];

    /**
     * The attributes that will be created automatically at time of creation.
     *
     * @var array<int, string>
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $model->app_id = (integer) rand(1, 90000000);
        });
    }

    protected $appends = [
        'profile_picture'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'id',
        'password',
        'remember_token',
        'created_at',
        'updated_at',
        'deleted_at',
        'mobile_number_verified_at',
        'registration_ip',
        'last_login_ip',
        'last_logout_at',
        'last_login_at',
        'email_verified_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'two_factor_expires_at' => 'datetime',
    ];
    /* ORM relations start  */
    public function profile()
    {
        return $this->hasOne(Profile::class);
    }

    public function boards(): BelongsToMany
    {
        return $this->belongsToMany(Board::class, 'students_boards');
    }
    public function classes(): BelongsToMany
    {
        return $this->belongsToMany(SiteClass::class, 'students_classes');
    }

    public function mediums(): BelongsToMany
    {
        return $this->belongsToMany(Medium::class, 'users_mediums');
    }

    public function device(): HasMany
    {
        return $this->hasMany(Device::class);
    }

    public function liveclasses(): HasMany
    {
        return $this->hasMany(LiveClass::class);
    }

    public function enrolledclasses(): BelongsToMany
    {
        return $this->belongsToMany(LiveClass::class, 'live_class_user');
    }

    public function media(): HasMany
    {
        return $this->hasMany(Media::class, 'user_id', 'id');
    }

    public function plans(): HasMany
    {
        return $this->hasMany(PackageValidity::class);
    }

    public function queries(): HasMany
    {
        return $this->hasMany(Query::class);
    }
    public function graphs(): HasMany
    {
        return $this->hasMany(Graph::class);
    }

    public function getcurrentPlanAttribute()
    {
        return $this->plans()->where(['is_expired' => false])->where('start_date', '<=', date('Y-m-d'))->where('end_date', '>', date('Y-m-d'))->first();
    }


    public function teacherSubjectClass(): HasMany
    {
        return $this->hasMany(UserSubjectClass::class, 'user_id');
    }

    public function documents(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function getmyCvAttribute()
    {
        $cv = $this->documents()->where('document_type', 'cv')?->value('file');
        if (!is_null($cv)) {
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if ($fileDisk == 'public') {
                if (file_exists(public_path('storage/documents/cv/' . $cv))) {
                    return asset('storage/documents/cv/' . $cv);
                }
            }
        }
        return false;
    }



    /* ORM relations end  */

    public function generateUserName($userType, $name)
    {
        $number = mt_rand(100000, 999999);
        $username = $userType . substr($name, 3) . $number;
        if ($this->usernameexists($username)) {
            return $this->generateUsername($userType, $name);
        }
        return $username;
    }
    public function generateTwoFactorCode()
    {
        $this->timestamps = false;
        $this->two_factor_code = rand(10000, 99999);
        $this->two_factor_expires_at = now()->addMinutes(2);
        $this->save();
    }

    public function resetTwoFactorCode()
    {
        $this->timestamps = false;
        $this->two_factor_code = null;
        $this->two_factor_expires_at = null;
        $this->save();
    }

    /* scopes for query start */

    public function scopeActive($query, $type)
    {
        return $query->whereHas(
            'roles',
            function ($q) use ($type) {
                $q->where('slug', $type);
            }
        )->where('is_active', '1');
    }

    public function scopeInactive($query, $type)
    {
        return $query->whereHas(
            'roles',
            function ($q) use ($type) {
                $q->where('slug', $type);
            }
        )->where('is_active', '0');
    }

    public function scopeUsernameexists($query, $username)
    {
        return $query->where('username', $username)->exists();
    }

    /* scopes for query end */


    /* protected function firstName(): Attribute
    {
        return Attribute::make(
            get: fn (string $value) => ucfirst($value),
        );
    }
    protected function lastName(): Attribute
    {
        return Attribute::make(
            get: fn (string $value) => ucfirst($value),
        );
    } */

    public function profilePicture($type = 'original')
    {
        $profilePicture = $this->media()->where('is_profile_picture', 1)->value('file');
        if (!is_null($profilePicture)) {
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if ($fileDisk == 'public') {
                if (file_exists(public_path('storage/images/' . $type . '/user/' . $profilePicture))) {
                    return asset('storage/images/' . $type . '/user/' . $profilePicture);
                }
            }
        }
        return asset('assets/img/placeholder-no-image.png');
    }

    public function getFullNameAttribute()
    {
        return $this->first_name . (!is_null($this->last_name) ? ' ' . $this->last_name : '');
    }

    public function getProfilePictureAttribute()
    {
        return $this->profilePicture();
    }


}
