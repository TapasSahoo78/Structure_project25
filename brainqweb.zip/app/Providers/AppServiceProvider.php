<?php

namespace App\Providers;

use App\Models\Site\Board;
use App\Models\Site\Medium;
use App\Models\Site\State;
use Illuminate\Support\Collection;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\LengthAwarePaginator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Paginator::useBootstrap();
        if (!Collection::hasMacro('paginate')) {
            Collection::macro(
                'paginate',
                function ($perPage = 14, $page = null, $options = []) {
                    $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
                    return (
                        new LengthAwarePaginator(
                            $this->forPage($page, $perPage),
                            $this->count(),
                            $perPage,
                            $page,
                            $options
                        )
                    )->withPath('');
                }
            );
        }
        View::composer(['*'], function ($view) {
            $boards = Board::where('is_active', true)->get();
            $mediums = Medium::whereIn('name', ['bengali', 'english'])->get();
            $states = State::whereHas('country', function ($query) {
                $query = $query->where('name', 'India');
            })->get();
            $view->with(['boards' => $boards, 'mediums' => $mediums, 'states' => $states]);
        });
    }
}
