<?php

namespace App\Providers;


use Illuminate\Support\ServiceProvider;
use App\Contracts\Location\StateContract;
use App\Repositories\Location\StateRepository;
use App\Contracts\User\{GraphContract, UserContract,SubscriptionContract,QueryContract};
use App\Repositories\User\{GraphRepository, UserRepository,SubscriptionRepository,QueryRepository};
use App\Contracts\Site\{BoardContract,BannerContract,SubjectContract,ClassContract,ChapterContract,CouponContract, FaqContract, PageContract,LiveContract};

use App\Repositories\Site\{BoardRepository,BannerRepository,SubjectRepository,ClassRepository,ChapterRepository,CouponRepository, FaqRepository, PageRepository,LiveRepository};

class RepositoryServiceProvider extends ServiceProvider
{

    protected $repositories = [
        BoardContract::class => BoardRepository::class,
        BannerContract::class => BannerRepository::class,
        UserContract::class => UserRepository::class,
        SubjectContract::class => SubjectRepository::class,
        ClassContract::class => ClassRepository::class,
        ChapterContract::class => ChapterRepository::class,
        StateContract::class => StateRepository::class,
        SubscriptionContract::class => SubscriptionRepository::class,
        QueryContract::class => QueryRepository::class,
        CouponContract::class => CouponRepository::class,
        PageContract::class => PageRepository::class,
        GraphContract::class => GraphRepository::class,
        LiveContract::class => LiveRepository::class,
        FaqContract::class => FaqRepository::class
    ];
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        foreach ($this->repositories as $interface => $implementation) {
            $this->app->bind($interface, $implementation);
        }
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
