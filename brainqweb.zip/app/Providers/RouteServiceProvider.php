<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * Typically, users are redirected here after authentication.
     *
     * @var string
     */
    public const HOME = 'admin/dashboard';


    protected $namespace = 'App\Http\Controllers';
    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     */
    public function boot(): void
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::middleware('api')
                ->prefix('api')
                ->namespace($this->namespace . '\Api')
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });

        $this->mapAuthRoutes();
        $this->mapAdminRoutes();
        $this->mapAjaxRoutes();
        $this->mapTeacherRoutes();
        $this->mapStudentRoutes();
        $this->mapFrontendRoutes();
    }


     protected function mapAuthRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace)
             ->group(base_path('routes/auth.php'));
     }

     protected function mapAdminRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace)
             ->prefix('admin')
             ->group(base_path('routes/admin.php'));
     }

     protected function mapAjaxRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace . '\Ajax')
             ->prefix('ajax')
             ->group(base_path('routes/ajax.php'));
     }

     protected function mapTeacherRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace)
             ->prefix('teacher')
             ->group(base_path('routes/teacher.php'));
     }
     protected function mapFrontendRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace.'\Frontend')
             ->group(base_path('routes/frontend.php'));
     }
     protected function mapStudentRoutes()
     {
         Route::middleware('web')
             ->namespace($this->namespace.'\Student')
             ->prefix('student')
             ->group(base_path('routes/student.php'));
     }
    /**
     * Configure the rate limiters for the application.
     */
    protected function configureRateLimiting(): void
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });
    }
}
