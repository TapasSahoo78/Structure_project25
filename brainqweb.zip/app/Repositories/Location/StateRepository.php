<?php

namespace App\Repositories\Location;

use App\Models\Site\State;
use App\Repositories\BaseRepository;
use App\Contracts\Location\StateContract;

class StateRepository extends BaseRepository implements StateContract
{

    protected $model;

    /**
     * StateRepository constructor
     *
     * @param State $model
     */
    public function __construct(State $model)
    {
        parent::__construct($model);
        $this->model= $model;
    }

    public function getStates($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false){
        $model = $this->model;
        if (!is_null($filterConditions)) {
            $model = $model->where($filterConditions);
        }
        $model= $model->whereHas('country',function($query){
            $query= $query->where('slug','india')->orWhere('name','India');
        });
        $model = $model->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $model = $model->offset($start);
        }
        if($inRandomOrder){
            $model= $model->inRandomOrder();
        }
        if (!is_null($limit)) {
            return $model->paginate($limit);
        }
        return $model->get();
    }
}
