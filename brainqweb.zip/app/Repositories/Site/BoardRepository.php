<?php

namespace App\Repositories\Site;

use App\Contracts\Site\BoardContract;
use App\Models\Site\Board;
use App\Models\Site\SiteClass;
use App\Repositories\BaseRepository;
use App\Traits\UploadAble;

/**
 * Class BoardRepository
 *
 * @package \App\Repositories\Site
 */
class BoardRepository extends BaseRepository implements BoardContract
{
    use UploadAble;

    protected $model, $classModel;
    /**
     * BrandRepository constructor.
     * @param Board $model
     */
    public function __construct(Board $model, SiteClass $classModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->classModel = $classModel;
    }

    public function listBoards($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $boards = $this->model;
        if (!is_null($filterConditions)) {
            $boards = $boards->where($filterConditions);
        }
        $boards = $boards->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $boards = $boards->offset($start);
        }
        if (!is_null($limit)) {
            return $boards->paginate($limit);
        }
        return $boards->get();
    }

    public function createBoard(array $attributes)
    {
        $isBoardCreated = $this->create($attributes);
        if ($isBoardCreated) {
            // $classes = $this->classModel->all();
            // $isBoardCreated->classes()->attach($classes);
            if (isset($attributes['board_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['board_image']->getClientOriginalExtension();
                $isBoardRelatedMediaUploaded = $this->uploadOne($attributes['board_image'], config('constants.SITE_BOARD_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isBoardRelatedMediaUploaded) {
                    $isBoardCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isBoardCreated;
    }
    public function updateBoard(array $attributes, $id)
    {
        $isBoard = $this->find($id);
        $isBoardUpdated = $this->update($attributes, $id);
        if ($isBoardUpdated) {
            if (isset($attributes['board_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['board_image']->getClientOriginalExtension();
                $isBoardRelatedMediaUploaded = $this->uploadOne($attributes['board_image'], config('constants.SITE_BOARD_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isBoardRelatedMediaUploaded) {
                    $isBoard->media()->delete();
                    $isBoard->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isBoardUpdated;
    }

    public function deleteBoard($id)
    {
        $isBoardfound = $this->find($id);
        if ($isBoardfound) {
            $isMediaDeleted = $isBoardfound->media()->delete();
            return $this->delete($id);
        }
        return false;
    }

}
