<?php

namespace App\Repositories\Site;

use App\Models\Site\Exam;
use App\Models\Site\Note;
use App\Models\Site\Test;
use App\Models\Site\Board;
use App\Models\Site\Video;
use App\Traits\UploadAble;
use App\Models\Site\Chapter;
use App\Models\Site\Question;
use App\Models\Site\TestType;
use App\Repositories\BaseRepository;
use App\Contracts\Site\ChapterContract;

/**
 * Chapter BoardRepository
 *
 * @package \App\Repositories\Site
 */
class ChapterRepository extends BaseRepository implements ChapterContract
{
    use UploadAble;

    protected $model, $videoModel, $noteModel, $testModel, $testTypeModel, $questionModel, $examModel;
    /**
     * ChapterRepository constructor.
     * @param Chapter $model
     * @param Video $videoModel
     * @param Video $videoModel
     * @param Note $noteModel
     * @param Test $testModel
     * @param TestType $testTypeModel
     * @param Question $questionModel
     * @param Exam $examModel
     */
    public function __construct(Chapter $model, Video $videoModel, Note $noteModel, Test $testModel, TestType $testTypeModel, Question $questionModel, Exam $examModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->videoModel = $videoModel;
        $this->noteModel = $noteModel;
        $this->testModel = $testModel;
        $this->testTypeModel = $testTypeModel;
        $this->questionModel = $questionModel;
        $this->examModel = $examModel;
    }

    public function listChapters($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $chapters = $this->model;
        if (!is_null($filterConditions)) {
            $chapters = $chapters->where($filterConditions);
        }
        $chapters = $chapters->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $chapters = $chapters->offset($start);
        }
        if (!is_null($limit)) {
            return $chapters->paginate($limit);
        }
        return $chapters->get();
    }
    public function listVideos($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $videos = $this->videoModel;
        if (!is_null($filterConditions)) {
            $videos = $videos->where($filterConditions);
        }
        $videos = $videos->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $videos = $videos->offset($start);
        }
        if (!is_null($limit)) {
            return $videos->paginate($limit);
        }
        return $videos->get();
    }



    public function createChapter(array $attributes)
    {
        $isChapterCreated = $this->create($attributes);
        if ($isChapterCreated) {
            if (isset($attributes['chapter_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['chapter_image']->getClientOriginalExtension();
                $isChapterRelatedMediaUploaded = $this->uploadOne($attributes['chapter_image'], config('constants.SITE_CHAPTER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isChapterRelatedMediaUploaded) {
                    $isChapterCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
            if (isset($attributes['banner_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isChapterRelatedBannerMediaUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_BANNER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isChapterRelatedBannerMediaUploaded) {
                    $isChapterCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isChapterCreated;
    }
    public function updateChapter(array $attributes, $id)
    {
        $isChapter = $this->find($id);
        $isChapterUpdated = $this->update($attributes, $id);
        if ($isChapterUpdated) {
            if (isset($attributes['chapter_image'])) {
                $fileName = uniqid() . '.' . $attributes['chapter_image']->getClientOriginalExtension();
                $isChapterRelatedMediaUploaded = $this->uploadOne($attributes['chapter_image'], config('constants.SITE_CHAPTER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isChapterRelatedMediaUploaded) {
                    $isChapter->media()->delete();
                    $isChapter->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
            if (isset($attributes['banner_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isChapterRelatedBannerMediaUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_BANNER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isChapterRelatedBannerMediaUploaded) {
                    $isChapter->media()->where('media_type', 'banner')->delete();
                    $isChapter->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isChapterUpdated;
    }

    public function deleteChapter($id)
    {
        $isChapterfound = $this->find($id);
        if ($isChapterfound) {
            $isMediaDeleted = $isChapterfound->media()->delete();
            return $this->delete($id);
        }
        return false;
    }

    public function createChapterVideo($attributes)
    {
        $isVideoCreated = $this->videoModel->create($attributes);
        return $isVideoCreated;
    }


    public function createChapterNote($attributes)
    {
        $isChapter = $this->find(uuidtoid($attributes['uuid'], 'chapters'));
        if ($isChapter) {
            $isChapterRelatedNoteCreated = $isChapter->notes()->create([
                'question' => $attributes['question'],
                'answer' => $attributes['answer'],
                'is_active' => true
            ]);
            return $isChapterRelatedNoteCreated;
        }
        return false;
    }

    public function updateChapterNote($attributes, $id)
    {
        $isChapter = $this->find(uuidtoid($id, 'chapters'));
        if ($isChapter) {
            info($isChapter);
            $isChapterRelatedNoteCreated = $isChapter->notes()->where('id', $attributes['note_uuid'])->update([
                'question' => $attributes['question'],
                'answer' => $attributes['answer'],
                'is_active' => true
            ]);
            return $isChapterRelatedNoteCreated;
        }
        return false;
    }

    public function deleteChapterNote($id)
    {
        return $this->noteModel->find($id)->delete();
    }

    public function findVideo($id)
    {
        return $this->videoModel->find($id);
    }

    public function deleteVideo($id)
    {
        return $this->videoModel->find($id)->delete();
    }
    public function updateVideo($attributes, $id)
    {
        $attributes['is_free'] = isset($attributes['is_free']) ? 1 : 0;
        $video = $this->videoModel->find($id);
        $isVideoUpdated = $video->update($attributes);
        return $isVideoUpdated;
    }

    public function findChapterTest(int $id, string $type)
    {
        $test = $this->testModel;
        $test = $test->whereHas('chapters', function ($query) use ($id) {
            $query = $query->where('id', $id);
        });
        $test = $test->whereHas('type', function ($query) use ($type) {
            $query = $query->where('type', $type);
        });
        $test = $test->orderBy('id', 'desc');
        return $test->first();
    }

    public function addChapterTest(int $id, string $type)
    {
        $chapter = $this->find($id);
        $type = $this->testTypeModel->where('type', $type)->first();
        if ($chapter && $type) {
            $isTestCreated = $this->testModel->create([
                'name' => 'Test for ' . $chapter->name,
                'test_type_id' => $type->id,
                'subject_id' => $chapter->subject->id,
            ]);
            if ($isTestCreated) {
                $isTestCreated->chapters()->attach($chapter);
            }
            return $isTestCreated;
        }
        return false;
    }

    public function createQuestionAnswer(array $attributes, string $type = 'tests')
    {
        $chapter = $this->find($attributes['chapter_id']);
        if ($chapter) {
            $isQuestionCreated = $this->questionModel->create([
                'question' => $attributes['question'],
                'marks' => $attributes['marks'] ?? NULL,
                'chapter_id' => $attributes['chapter_id'] ?? NULL,
                'is_active' => true
            ]);
            if ($isQuestionCreated) {
                if ($type == 'tests') {
                    $test = $this->testModel->find($attributes['test_id']);
                    $isQuestionCreated->tests()->attach($test);
                } else {
                    $exam = $this->examModel->find($attributes['exam_id']);
                    $isQuestionCreated->exams()->attach($exam);
                }

                foreach ($attributes['answer'] as $key => $value) {
                    $isQuestionCreated->answers()->create([
                        'answer' => $value,
                        'is_right' => $key == $attributes['is_right'] ?? false
                    ]);
                }
            }
            return $isQuestionCreated;
        }
        return false;
    }

    public function deleteQuestion(int $id)
    {
        $question = $this->questionModel->find($id);
        if ($question) {
            $isAnswerDeleted = $question->answers()->delete();
            if ($isAnswerDeleted) {
                $question->tests()->detach();
                return $question->delete();
            }
        }
        return false;
    }

    public function updateTimeInTest(array $attributes)
    {
        $test = $this->testModel->find($attributes['test_id']);
        if ($test) {
            return $test->update(['total_time' => $attributes['total_duration']]);
        }
        return false;
    }

}
