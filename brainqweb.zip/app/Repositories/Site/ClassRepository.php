<?php

namespace App\Repositories\Site;

use App\Models\Site\Board;
use App\Traits\UploadAble;
use App\Models\Site\Medium;
use App\Models\Site\Subject;
use App\Models\Site\SiteClass;
use App\Repositories\BaseRepository;
use App\Contracts\Site\ClassContract;
use App\Models\User\User;

/**
 * Class BoardRepository
 *
 * @package \App\Repositories\Site
 */
class ClassRepository extends BaseRepository implements ClassContract
{
    use UploadAble;
    protected $model,$boardModel,$mediumModel,$subjectModel,$userModel;
    /**
     * BrandRepository constructor.
     * @param SiteClass $model
     */
    public function __construct(SiteClass $model,Board $boardModel,Medium $mediumModel,Subject $subjectModel,User $userModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->boardModel = $boardModel;
        $this->mediumModel = $mediumModel;
        $this->subjectModel = $subjectModel;
        $this->userModel = $userModel;
    }

    public function listClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $classes = $this->model;
        if (!is_null($filterConditions)) {
            $classes = $classes->where($filterConditions);
        }
        $classes = $classes->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $classes = $classes->offset($start);
        }
        if (!is_null($limit)) {
            return $classes->paginate($limit);
        }
        return $classes->get();
    }

    public function createClass(array $attributes)
    {
        $isClassCreated = $this->create($attributes);
        if ($isClassCreated) {
            if (isset($attributes['board']) || isset($attributes['medium'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $medium = $this->mediumModel->find(uuidtoid($attributes['medium'], 'mediums'));
                $isClassCreated->boards()->attach($board);
                $isClassCreated->mediums()->attach($medium);
            }
            if (isset($attributes['class_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['class_image']->getClientOriginalExtension();
                $isBoardRelatedMediaUploaded = $this->uploadOne($attributes['class_image'], config('constants.SITE_CLASS_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isBoardRelatedMediaUploaded) {
                    $isClassCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isClassCreated;
    }
    public function updateClass(array $attributes, $id)
    {
        $isClass = $this->find($id);
        $isClassUpdated = $this->update($attributes, $id);
        if ($isClassUpdated) {
            if (isset($attributes['board']) || isset($attributes['medium'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $medium = $this->boardModel->find(uuidtoid($attributes['medium'], 'mediums'));
                $isClass->boards()->detach();
                $isClass->mediums()->detach();
                $isClass->boards()->attach($board);
                $isClass->mediums()->attach($medium);
            }
            if (isset($attributes['class_image'])) {
                $fileName = $fileName = uniqid().'.'. $attributes['class_image']->getClientOriginalExtension();
                $isClassRelatedMediaUploaded = $this->uploadOne($attributes['class_image'], config('constants.SITE_CLASS_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isClassRelatedMediaUploaded) {
                    $isClass->media()->delete();
                    $isClass->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isClassUpdated;
    }

    public function deleteClass($id)
    {
        $isClassFound = $this->find($id);
        if ($isClassFound) {
            $isMediaDeleted = $isClassFound->media()->delete();
            return $this->delete($id);
        }
        return false;
    }

    public function createOrUpdateTeacherClassSubject(array $attributes, int $id)
    {
        if ($attributes['flag'] == 'edit') {
            $user = $this->userModel->find($id);
            $user->teacherSubjectClass()->delete();
        }
        foreach ($attributes['class'] as $key => $value) {
            $class = $this->find(uuidtoid($value, 'site_classes'));
            $subjects = $this->subjectModel->whereIn('id', $attributes['subjects'][$key])->get();
            $isSubjectAttachedWithClassAndUser = $class->userSubjects()->syncWithPivotValues($subjects, ['user_id' => $id]);
        }
        return true;
    }

    public function findClass($id){
        return $this->model->where('id',$id)->where('is_active',0)->first();
    }
}
