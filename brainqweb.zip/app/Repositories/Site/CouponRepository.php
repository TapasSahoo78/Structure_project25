<?php
namespace App\Repositories\Site;

use App\Models\Site\Coupon;
use App\Contracts\Site\CouponContract;
use App\Models\Site\Package;
use App\Repositories\BaseRepository;

/**
 * Class PageRepository
 *
 * @package \App\Repositories
 */
class CouponRepository extends BaseRepository implements CouponContract
{
    protected $model,$packageModel;
    /**
     * CouponRepository constructor
     *
     * @param Coupon $model
     * @param Package $packageModel
     */
    /**
     * CouponRepository constructor
     *
     *
     */
    public function __construct(Coupon $model,Package $packageModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->packageModel = $packageModel;

    }

    /**
     * List of all coupons
     *
     * @param string $order
     * @param string $sort
     * @param array $columns
     * @return mixed
     */
    public function listCoupons($filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false)
    {
        $coupons = $this->model->where($filterConditions);
        if (!is_null($limit)) {
            return $coupons->paginate($limit);
        }
        return $coupons->get();
    }

    /**
     * Find a coupon with id
     *
     * @param int $id
     */
    public function findCouponById(int $id)
    {
        return $this->find($id);
    }

    /**
     * Create a coupon
     *
     * @param array $attributes
     * @return Coupon|mixed
     */
    public function createCoupon($attributes)
    {
        $isCouponCreated = $this->create($attributes);
        return $isCouponCreated;
    }

    /**
     *  Update a coupon
     *
     * @param array $attributes
     * @param int $id
     * @return Coupon|mixed
     */
    public function updateCoupon($attributes, $id)
    {
        $coupon = $this->find($id);
        $isCouponUpdated = $coupon->update($attributes);
        return $isCouponUpdated;
    }

    /**
     * Delete a coupon
     *
     * @param int $id
     * @return bool|mixed
     */
    public function deleteCoupon($id)
    {
        return $this->delete($id);
    }

    /**
     * Update a coupon's status
     *
     * @param array $params
     * @param int $id
     * @return mixed
     */
    public function setCouponStatus($attributes, $id)
    {
        return $this->update($attributes, $id);
    }

    public function attachOrDetachPlans(array $attributes, int $id){
        $isCoupon= $this->find($id);
        if($isCoupon){
           $isCoupon->packages()->detach();
            if(!empty($attributes['plans'])){
                $plans= $this->packageModel->whereIn('uuid',$attributes['plans'])->get();
                if($plans->isnotEmpty()){
                    $isCoupon->packages()->attach($plans);
                }
            }
            return true;
        }
        return false;
    }
}
