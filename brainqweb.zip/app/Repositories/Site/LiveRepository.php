<?php

namespace App\Repositories\Site;


use App\Traits\UploadAble;
use App\Models\Site\LiveClass;
use App\Contracts\Site\LiveContract;
use App\Models\Site\Exam;
use App\Repositories\BaseRepository;

/**
 * Class BoardRepository
 *
 * @package \App\Repositories\Site
 */
class LiveRepository extends BaseRepository implements LiveContract
{
    use UploadAble;
    protected $model,$examModel;
    /**
     * BrandRepository constructor.
     * @param LiveClass $model
     */
    public function __construct(LiveClass $model,Exam $examModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->examModel = $examModel;
    }

    public function listLiveClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $classes = $this->model;
        if (!is_null($filterConditions)) {
            $classes = $classes->where($filterConditions);
        }
        $classes = $classes->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $classes = $classes->offset($start);
        }
        if (!is_null($limit)) {
            return $classes->paginate($limit);
        }
        return $classes->get();
    }
    public function listExams($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $classes = $this->examModel;
        if (!is_null($filterConditions)) {
            $classes = $classes->where($filterConditions);
        }
        $classes = $classes->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $classes = $classes->offset($start);
        }
        if (!is_null($limit)) {
            return $classes->paginate($limit);
        }
        return $classes->get();
    }


    public function findExam(int $id){
        return $this->examModel->find($id);
    }

    public function createExam(array $attributes){
        return $this->examModel->create($attributes);
    }
    public function updateExam(array $attributes, int $id){
        return $this->examModel->find($id)->update($attributes);
    }

    public function deleteExam(int $id){
        return $this->examModel->find($id)->delete();
    }
}
