<?php

namespace App\Repositories\Site;

use App\Models\Site\Board;
use App\Traits\UploadAble;
use App\Models\Site\Subject;
use App\Models\Site\SiteClass;
use App\Repositories\BaseRepository;
use App\Contracts\Site\SubjectContract;

/**
 * Class BoardRepository
 *
 * @package \App\Repositories\Site
 */
class SubjectRepository extends BaseRepository implements SubjectContract
{
    use UploadAble;
    protected $model, $boardModel, $classModel;
    /**
     * BrandRepository constructor.
     * @param Subject $model
     */
    public function __construct(Subject $model, Board $boardModel, SiteClass $classModel, )
    {
        parent::__construct($model);
        $this->model = $model;
        $this->boardModel = $boardModel;
        $this->classModel = $classModel;
    }

    public function listSubjects($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        $subjects = $this->model;
        if (!is_null($filterConditions)) {
            $subjects = $subjects->where($filterConditions);
        }
        $subjects = $subjects->orderBy($orderBy, $sortBy);
        if (!is_null($start)) {
            $subjects = $subjects->offset($start);
        }
        if (!is_null($limit)) {
            return $subjects->paginate($limit);
        }
        return $subjects->get();
    }

    public function createSubject(array $attributes)
    {
        $isSubjectCreated = $this->create($attributes);
        if ($isSubjectCreated) {
            if (isset($attributes['board']) || isset($attributes['class'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $class = $this->classModel->find($attributes['class']);
                $isSubjectCreated->boards()->attach($board);
                $isSubjectCreated->classes()->attach($class);
            }
            if (isset($attributes['subject_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['subject_image']->getClientOriginalExtension();
                $isSubjectRelatedMediaUploaded = $this->uploadOne($attributes['subject_image'], config('constants.SITE_SUBJECT_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isSubjectRelatedMediaUploaded) {
                    $isSubjectCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
            if (isset($attributes['banner_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isSubjectRelatedBannerMediaUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_BANNER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isSubjectRelatedBannerMediaUploaded) {
                    $isSubjectCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isSubjectCreated;
    }
    public function updateSubject(array $attributes, $id)
    {
        $isSubject = $this->find($id);
        $isSubjectUpdated = $this->update($attributes, $id);
        if ($isSubjectUpdated) {
            if (isset($attributes['board']) || isset($attributes['class'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $class = $this->classModel->find($attributes['class']);
                $isSubject->boards()->detach();
                $isSubject->classes()->detach();
                $isSubject->boards()->attach($board);
                $isSubject->classes()->attach($class);
            }
            if (isset($attributes['subject_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['subject_image']->getClientOriginalExtension();
                $isSubjectRelatedMediaUploaded = $this->uploadOne($attributes['subject_image'], config('constants.SITE_SUBJECT_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isSubjectRelatedMediaUploaded) {
                    $isSubject->media()->where('media_type', 'image')->forceDelete();
                    $isSubject->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
            if (isset($attributes['banner_image'])) {
                $fileName = $fileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isSubjectRelatedBannerMediaUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_BANNER_IMAGE_UPLOAD_PATH'), $fileName);
                if ($isSubjectRelatedBannerMediaUploaded) {
                    $isSubject->media()->where('media_type', 'banner')->forceDelete();
                    $isSubject->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $fileName,
                        'alt_text' => $attributes['alt_text'] ?? NULL,
                        'is_profile_picture' => false,
                    ]);
                }
            }
        }
        return $isSubjectUpdated;
    }

    public function deleteSubject($id)
    {
        $isSubjectFound = $this->find($id);
        if ($isSubjectFound) {
            $isMediaDeleted = $isSubjectFound->media()->delete();
            return $this->delete($id);
        }
        return false;
    }
}
