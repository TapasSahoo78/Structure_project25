<?php

namespace App\Repositories\User;


use App\Models\User\User;

use App\Models\User\Graph;
use App\Traits\UploadAble;
use App\Repositories\BaseRepository;
use App\Contracts\User\GraphContract;

/**
 * Class UserRepository
 *
 * @package \App\Repositories\User
 */
class GraphRepository extends BaseRepository implements GraphContract
{
    use UploadAble;
    protected $model;
    public function __construct(Graph $model)
    {
        parent::__construct($model);
        $this->model = $model;
    }






}
