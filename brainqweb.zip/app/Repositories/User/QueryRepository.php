<?php

namespace App\Repositories\User;


use App\Models\User\User;

use App\Traits\UploadAble;
use Illuminate\Support\Carbon;
use App\Repositories\BaseRepository;
use App\Contracts\User\QueryContract;
use App\Models\User\Query;

/**
 * Class UserRepository
 *
 * @package \App\Repositories\User
 */
class QueryRepository extends BaseRepository implements QueryContract
{
    use UploadAble;
    protected $model, $userModel;
    public function __construct(Query $model, User $userModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->userModel = $userModel;
    }

    /**
     * List of all coupons
     *
     * @param string $order
     * @param string $sort
     * @param array $columns
     * @return mixed
     */
    public function listQuery($filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false)
    {
        $query = $this->model->where($filterConditions);
        if (!is_null($limit)) {
            return $query->latest()->paginate($limit);
        }
        return $query->latest()->paginate($limit);
    }

    /**
     * Find a coupon with id
     *
     * @param int $id
     */
    // public function findCouponById(int $id)
    // {
    //     return $this->find($id);
    // }

    // /**
    //  * Create a coupon
    //  *
    //  * @param array $attributes
    //  * @return Coupon|mixed
    //  */
    // public function createCoupon($attributes)
    // {
    //     $isCouponCreated = $this->create($attributes);
    //     return $isCouponCreated;
    // }

    // /**
    //  *  Update a coupon
    //  *
    //  * @param array $attributes
    //  * @param int $id
    //  * @return Coupon|mixed
    //  */
    // public function updateCoupon($attributes, $id)
    // {
    //     $coupon = $this->find($id);
    //     $isCouponUpdated = $coupon->update($attributes);
    //     return $isCouponUpdated;
    // }

    // /**
    //  * Delete a coupon
    //  *
    //  * @param int $id
    //  * @return bool|mixed
    //  */
    // public function deleteCoupon($id)
    // {
    //     return $this->delete($id);
    // }

    // /**
    //  * Update a coupon's status
    //  *
    //  * @param array $params
    //  * @param int $id
    //  * @return mixed
    //  */
    // public function setCouponStatus($attributes, $id)
    // {
    //     return $this->update($attributes, $id);
    // }


}
