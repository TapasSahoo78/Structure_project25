<?php

namespace App\Repositories\User;

use App\Models\User\Role;
use App\Models\User\User;
use App\Mail\SendMailable;
use App\Models\Site\Board;
use App\Traits\UploadAble;
use App\Models\Site\SiteClass;
use App\Contracts\User\UserContract;
use App\Models\Site\Medium;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Mail;
use Illuminate\Database\Eloquent\Builder;

/**
 * Class UserRepository
 *
 * @package \App\Repositories\User
 */
class UserRepository extends BaseRepository implements UserContract
{
    use UploadAble;
    protected $model, $boardModel, $classModel, $roleModel, $mediumModel;
    public function __construct(User $model, Board $boardModel, SiteClass $classModel, Role $roleModel, Medium $mediumModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->roleModel = $roleModel;
        $this->boardModel = $boardModel;
        $this->classModel = $classModel;
        $this->mediumModel = $mediumModel;
    }

    public function findUserByRole(array $filterConditions, string $role, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model->whereHas('roles', function (Builder $query) use ($role) {
            $query->where('slug', $role);
        });
        if (!is_null($filterConditions)) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $model = $model->where(function ($model) use ($search) {
                $model->where('first_name', 'LIKE', "%{$search}%")
                    ->orWhere('last_name', 'LIKE', "%{$search}%")
                    ->orWhere('app_id', 'LIKE', "%{$search}%")
                    ->orWhere('email', 'LIKE', "%{$search}%")
                    ->orWhere('mobile_number', 'LIKE', "%{$search}%");
            });
        }

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }

        if (!is_null($limit)) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function createUser(array $attributes)
    {
        $isUserCreated = $this->create($attributes);
        if ($isUserCreated) {
            $city = isset($attributes['city']) ? customfind($attributes['city'], 'cities') : '';
            $state = $attributes['role'] == 'teacher' ? $attributes['state'] : slugtoname($attributes['state'], 'states');
            $isUserCreated->profile()->create([
                'gender' => $attributes['gender'] ?? '',
                'state' => $state,
                'designation' => $attributes['designation'] ?? '',
                'qualification' => $attributes['qualification'] ?? '',
                'address' => $attributes['address'] ?? '',
                'city' => !empty($city) ? $city->name : '',
                'school_name' => $attributes['school_name'] ?? '',
                'pincode' => $attributes['pincode'] ?? null,
            ]);
            $role = $this->roleModel->where('slug', $attributes['role'])->get();
            if (isset($attributes['board'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $isUserCreated->roles()->attach($role);
                $isUserCreated->boards()->attach($board);
                if (isset($attributes['classes'])) {
                    $class = $this->classModel->find($attributes['classes']);
                    $isUserCreated->classes()->attach($class);
                }
                if (isset($attributes['medium'])) {
                    $medium = $this->mediumModel->find(uuidtoid($attributes['medium'], 'mediums'));
                    $isUserCreated->mediums()->attach($medium);
                }

            }

            if (isset($attributes['user_image'])) {
                $fileName = uniqid() . '.' . $attributes['user_image']->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($attributes['user_image'], config('constants.SITE_USER_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $isFileRelatedMediaCreated = $isUserCreated->media()->create([
                        'mediaable_type' => get_class($isUserCreated),
                        'mediaable_id' => $isUserCreated->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'is_profile_picture' => true,
                    ]);
                }
            }
            if (isset($attributes['teacher_cv']) && !empty($attributes['teacher_cv'])) {
                $fileName = uniqid() . '.' . $attributes['teacher_cv']->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($attributes['teacher_cv'], config('constants.SITE_CV_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $isFileRelatedDocumentCreated = $isUserCreated->documents()->create([
                        'title' => ($attributes['first_name'] ?? 'Teacher') . '-cv',
                        'document_type' => 'cv',
                        'file' => $fileName,
                        'is_active' => true,
                    ]);
                }
            }

            if ($attributes['role'] == 'teacher') {
                $smtpHost = config('mail.mailers.smtp.host');
                $smtpPort = config('mail.mailers.smtp.port');
                $smtpUsername = config('mail.mailers.smtp.username');
                $smtpPassword = config('mail.mailers.smtp.password');

                info($smtpHost);
                info($smtpPort);
                info($smtpUsername);
                info($smtpPassword);

                if (!empty($smtpHost) && !empty($smtpPort) && !empty($smtpUsername) && !empty($smtpPassword)) {
                    $mailData = [
                        'to' => $attributes['email'],
                        'from' => 'no-reply@elearn.com',
                        'mail_type' => 'teacher-information',
                        'line' => 'Welcome To brainQ E-learning portal',
                        'content' => 'Your have been registered as a teacher in our portal.Please change your password once you login into our portal',
                        'subject' => 'Credentials for Login',
                        'password' => $attributes['teacher_password'],
                        'greetings' => 'Hello Sir/Madam',
                        'link' => route('login')
                    ];
                    Mail::send(new SendMailable($mailData));
                }
            }
        }
        return $isUserCreated;
    }
    public function updateUser(array $attributes, int $id = null)
    {
        $isUser = $this->find($id);
        $isUserUpdated = $isUser?->update($attributes);
        if ($isUserUpdated) {
            $state = '';
            $city = isset($attributes['city']) ? customfind($attributes['city'], 'cities') : '';
            if (isset($attributes['state'])) {
                $state = $attributes['role'] == 'teacher' ? $attributes['state'] : slugtoname($attributes['state'], 'states');
            }

            $isUser?->profile()->update([
                'gender' => $attributes['gender'] ?? '',
                'state' => $state ?? '',
                'city' => !empty($city) ? $city->name : '',
                'designation' => $attributes['designation'] ?? '',
                'qualification' => $attributes['qualification'] ?? '',
                'subjects' => $attributes['subjects'] ?? '',
                'school_name' => $attributes['school_name'] ?? '',
                'pincode' => $attributes['pincode'] ?? null,
                'address' => $attributes['address'] ?? '',
            ]);
            if (isset($attributes['board'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $isUser->boards()->detach();
                $isUser->boards()->attach($board);

                if (isset($attributes['classes'])) {
                    $class = $this->classModel->find($attributes['classes']);
                    $isUser->classes()->detach();
                    $isUser->classes()->attach($class);
                }
                if (isset($attributes['medium'])) {
                    $medium = $this->mediumModel->find(uuidtoid($attributes['medium'], 'mediums'));
                    $isUser->mediums()->detach();
                    $isUser->mediums()->attach($medium);
                }
            }
            if (isset($attributes['user_image'])) {
                $fileName = uniqid() . '.' . $attributes['user_image']->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($attributes['user_image'], config('constants.SITE_USER_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $isUser->media()->delete();
                    $isFileRelatedMediaCreated = $isUser->media()->create([
                        'mediaable_type' => get_class($isUser),
                        'mediaable_id' => $isUser->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'is_profile_picture' => true,
                    ]);
                }
            }
            if (isset($attributes['teacher_cv'])) {
                $fileName = uniqid() . '.' . $attributes['teacher_cv']->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($attributes['teacher_cv'], config('constants.SITE_CV_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $documentDelete = $isUser->documents()->delete();
                    $isFileRelatedDocumentCreated = $isUser->documents()->create([
                        'title' => ($attributes['first_name'] ?? 'Teacher') . '-cv',
                        'document_type' => 'cv',
                        'file' => $fileName,
                        'is_active' => true,
                    ]);
                }
            }
        }
        return $isUserUpdated;
    }


    public function createUserInStep(array $attributes, string $step, $id = null)
    {
        switch ($step) {
            case 'first':
                // $isUser = $this->create($attributes);
                $cehckUserr = User::where('mobile_number', $attributes['mobile_number'])->first();
                if (!empty($cehckUserr) && !$cehckUserr->is_active) {
                    $attributes['is_active'] = false;
                }
                $isUser = User::updateOrCreate(['mobile_number' => $attributes['mobile_number']], $attributes);
                if ($isUser) {
                    $isProfile = $isUser->profile()->create([
                        'gender' => $attributes['gender'] ?? ''
                    ]);
                }
                break;
            case 'second':
                $isUser = $this->find($id);
                if ($isUser) {
                    $isProfile = $isUser->profile()->update([
                        'gender' => $attributes['gender'] ?? ''
                    ]);
                }
                break;
            case 'third':
                $isUser = $this->find($id);
                $state = isset($attributes['state']) ? customfind($attributes['state'], 'states') : '';
                $city = isset($attributes['city']) ? customfind($attributes['city'], 'cities') : '';
                if ($isUser) {
                    $isProfile = $isUser->profile()->update([
                        'state' => !empty($state) ? $state->name : '',
                        'city' => !empty($city) ? $city->name : '',
                        'pincode' => $attributes['pincode'] ?? '',
                    ]);
                }
                break;
            case 'fourth':
                $isUser = $this->find($id);
                if ($isUser) {
                    $isProfileUpdated = $isUser->profile()->update([
                        'school_name' => $attributes['school_name'] ?? '',
                    ]);
                    if (isset($attributes['board'])) {
                        $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                        $isUser->boards()->attach($board);
                        if (isset($attributes['class'])) {
                            $class = $this->classModel->find(uuidtoid($attributes['class'], 'site_classes'));
                            $isUser->classes()->attach($class);
                        }
                        if (isset($attributes['medium'])) {
                            $medium = $this->mediumModel->find(uuidtoid($attributes['medium'], 'mediums'));
                            $isUser->mediums()->attach($medium);
                        }
                    }
                }
                break;
            case 'fifth':
                $isUser = $this->find($id);
                if ($isUser) {
                    $studentRole = $this->roleModel->where('slug', 'student')->get();
                    $isUser->roles()->attach($studentRole);
                    $attributes['password'] = bcrypt($attributes['password']);
                    $attributes['is_approve'] = true;
                    $attributes['is_active'] = true;
                    $attributes['is_online'] = true;
                    $isUserUpdated = $isUser->update($attributes);
                }
                break;

            default:
                return false;
                break;
        }
        return $isUser;
    }

    public function updateStudent(array $attributes, int $id)
    {
        $isUser = $this->find($id);
        $isUserUpdated = $isUser->update($attributes);

        if ($isUserUpdated) {
            $state = isset($attributes['state']) ? customfind($attributes['state'], 'states') : '';
            $city = isset($attributes['city']) ? customfind($attributes['city'], 'cities') : '';
            $isUser->profile()->update([
                'gender' => $attributes['gender'] ?? '',
                'state' => $state->name ?? '',
                'city' => $city->name ?? '',
                'subjects' => $attributes['subjects'] ?? '',
                'school_name' => $attributes['school_name'] ?? '',
                'pincode' => $attributes['pincode'] ?? null,
                'address' => $attributes['address'] ?? '',
                'blood_group' => $attributes['blood_group'] ?? NUll,
            ]);
            // dd($attributes);

            if (isset($attributes['board'])) {
                $board = $this->boardModel->find(uuidtoid($attributes['board'], 'boards'));
                $isUser->boards()->detach();
                $isUser->boards()->attach($board);

                if (isset($attributes['class'])) {
                    $class = $this->classModel->find(uuidtoid($attributes['class'], 'site_classes'));
                    $isUser->classes()->detach();
                    $isUser->classes()->attach($class);
                }
                if (isset($attributes['medium'])) {
                    $medium = $this->mediumModel->find(uuidtoid($attributes['medium'], 'mediums'));
                    $isUser->mediums()->detach();
                    $isUser->mediums()->attach($medium);
                }
            }
            if (isset($attributes['profile_image'])) {
                $fileName = uniqid() . '.' . $attributes['profile_image']->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($attributes['profile_image'], config('constants.SITE_USER_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $isUser->media()->delete();
                    $isFileRelatedMediaCreated = $isUser->media()->create([
                        'mediaable_type' => get_class($isUser),
                        'mediaable_id' => $isUser->id,
                        'media_type' => 'image',
                        'file' => $fileName,
                        'is_profile_picture' => true,
                    ]);
                }
            }
            return $isUser;
        }
        return false;
    }

    public function otpVerify($otp, $id)
    {
        $isUser = $this->findOneBy(['id' => $id, 'verification_code' => $otp]);
        if ($isUser) {
            $this->update(['mobile_number_verified_at' => now()], $id);
        }
        return $isUser;
    }
}
