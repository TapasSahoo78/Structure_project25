<?php

namespace App\Services\Cms;

use App\Contracts\Site\PageContract;

class PageService
{
    /**
     * @var PageContract
     */
    protected $pageRepository;

    /**
     * CityService constructor
     */
    public function __construct(PageContract $pageRepository)
    {
        $this->pageRepository = $pageRepository;
    }

    public function findPages(array $filterConditions,string $orderBy="id",string $sortBy="desc"){
        return $this->pageRepository->listPages($filterConditions,$orderBy,$sortBy);
    }

    public function findPage(int $id){
        return $this->pageRepository->find($id);
    }

    public function createPage(array $attributes){
        return $this->pageRepository->create($attributes);
    }
    public function updatePage(array $attributes, int $id){
        return $this->pageRepository->update($attributes,$id);
    }
    public function deletePage(int $id){
        return $this->pageRepository->delete($id);
    }
}
