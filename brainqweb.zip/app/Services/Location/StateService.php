<?php

namespace App\Services\Location;

use App\Contracts\Location\StateContract;

class StateService
{
    /**
     * @var StateContract
     */
    protected $stateRepository;

    /**
     * StateService constructor
     */
    public function __construct(StateContract $stateRepository)
    {
        $this->stateRepository = $stateRepository;
    }

    public function findState(int $id){
        return $this->stateRepository->find($id);
    }

    public function getStates($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false){
        return $this->stateRepository->getStates($filterConditions, $orderBy, $sortBy, $limit, $start,$inRandomOrder);
    }
}
