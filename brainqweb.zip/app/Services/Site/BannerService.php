<?php

namespace App\Services\Site;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\Site\BannerContract;

class BannerService
{
    /**
     * @var BannerContract
     */
    protected $bannerRepository;

	/**
     * UserService constructor
     */
    public function __construct(BannerContract $bannerRepository){
        $this->bannerRepository= $bannerRepository;
    }

    public function listBanners(array $filterConditions,string $orderBy='id',$sortBy='asc',$limit= null,$start=null,$inRandomOrder= false){
        return $this->bannerRepository->findBanners($filterConditions,$orderBy,$sortBy,$limit,$start,$inRandomOrder);
    }

    public function findBannerById(int $id){
        return $this->bannerRepository->find($id);
    }

    public function createOrUpdateBanner(array $attributes, $id=null){
        if(is_null($id)){
            return $this->bannerRepository->createBanner($attributes);
        }else{
            return $this->bannerRepository->updateBanner($attributes,$id);
        }
    }

    public function updateBanner($attributes,$id){
        return $this->bannerRepository->update($attributes,$id);
    }

    public function deleteBanner($id){
        return $this->bannerRepository->deleteBanner($id);
    }
}
