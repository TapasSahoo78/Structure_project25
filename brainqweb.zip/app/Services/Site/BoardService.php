<?php

namespace App\Services\Site;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\Site\BoardContract;

class BoardService
{
    /**
     * @var BannerContract
     */
    protected $boardRepository;

	/**
     * UserService constructor
     */
    public function __construct(BoardContract $boardRepository){
        $this->boardRepository= $boardRepository;
    }

    public function listBoards($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false){
        return $this->boardRepository->listBoards($filterConditions,$orderBy,$sortBy,$limit,$start,$inRandomOrder);
    }

    public function findBoard(int $id){
        return $this->boardRepository->find($id);
    }

    public function createOrUpdateBoard(array $attributes,$id=null)
    {
        if(!is_null($id)){
            return $this->boardRepository->updateBoard($attributes,$id);
        }
        return $this->boardRepository->createBoard($attributes);
    }

    public function updateBoard($attributes,$id){
        return $this->boardRepository->update($attributes,$id);
    }

    public function deleteBoard($id){
        return $this->boardRepository->deleteBoard($id);
    }
}
