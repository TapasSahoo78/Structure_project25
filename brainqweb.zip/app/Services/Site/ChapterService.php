<?php

namespace App\Services\Site;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\Site\ChapterContract;

class ChapterService
{
    /**
     * @var ChapterContract
     */
    protected $chapterRepository;

    /**
     * UserService constructor
     */
    public function __construct(ChapterContract $chapterRepository)
    {
        $this->chapterRepository = $chapterRepository;
    }

    public function listChapters($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        return $this->chapterRepository->listChapters($filterConditions, $orderBy, $sortBy, $limit, $start, $inRandomOrder);
    }

    public function findChapter(int $id)
    {
        return $this->chapterRepository->find($id);
    }

    public function createOrUpdateChapter(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->chapterRepository->updateChapter($attributes, $id);
        }
        return $this->chapterRepository->createChapter($attributes);
    }

    public function updateChapter($attributes, $id)
    {
        return $this->chapterRepository->update($attributes, $id);
    }

    public function deleteChapter($id)
    {
        return $this->chapterRepository->deleteChapter($id);
    }
    public function deleteNote($id)
    {
        return $this->chapterRepository->deleteChapterNote($id);
    }


    public function createOrUpdateChapterVideo(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->chapterRepository->updateVideo($attributes, $id);
        }
        return $this->chapterRepository->createChapterVideo($attributes);
    }

    public function createOrUpdateNote(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->chapterRepository->updateChapterNote($attributes, $id);
        }
        return $this->chapterRepository->createChapterNote($attributes);
    }

    public function listVideos($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        return $this->chapterRepository->listVideos($filterConditions, $orderBy, $sortBy, $limit, $start, $inRandomOrder);
    }

    public function findVideo(int $id){
        return $this->chapterRepository->findVideo($id);
    }

    public function deleteVideo($id)
    {
        return $this->chapterRepository->deleteVideo($id);
    }

    public function updateVideo($attributes, $id)
    {
        return $this->chapterRepository->updateVideo($attributes, $id);
    }

    public function findTest(int $id,string $type){
        return $this->chapterRepository->findChapterTest($id,$type);
    }
    public function createChapterTest(int $id,string $type){
        return $this->chapterRepository->addChapterTest($id,$type);
    }

    public function createQuestionAnswer(array $attributes,string $type){
        return $this->chapterRepository->createQuestionAnswer($attributes,$type);
    }
    public function deleteQuestion(int $id){
        return $this->chapterRepository->deleteQuestion($id);
    }

    public function updateTimeInTest(array $attributes){
        return $this->chapterRepository->updateTimeInTest($attributes);
    }
}
