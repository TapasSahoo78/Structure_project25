<?php

namespace App\Services\Site;

use App\Contracts\Site\ClassContract;

class ClassService
{
    /**
     * @var ClassContract
     */
    protected $classRepository;

    /**
     * SubjectService constructor
     */
    public function __construct(ClassContract $classRepository){
        $this->classRepository= $classRepository;
    }

    public function listClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false){
        return $this->classRepository->listClasses($filterConditions,$orderBy,$sortBy,$limit,$start,$inRandomOrder);
    }

    public function findClass(int $id){
        // return $this->classRepository->findClass( $id);
        return $this->classRepository->find($id);
    }

    public function createOrUpdateClass(array $attributes,$id=null)
    {
        if(!is_null($id)){
            return $this->classRepository->updateClass($attributes,$id);
        }
        return $this->classRepository->createClass($attributes);
    }

    public function updateClass($attributes,$id){
        return $this->classRepository->update($attributes,$id);
    }

    public function deleteClass($id){
        return $this->classRepository->deleteClass($id);
    }

    public function createTeacherClassSubject(array $attributes, int $id){
        return $this->classRepository->createOrUpdateTeacherClassSubject($attributes,$id);
    }


}
