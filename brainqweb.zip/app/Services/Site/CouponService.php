<?php

namespace App\Services\Site;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\Site\CouponContract;

class CouponService
{
    /**
     * @var CouponContract
     */
    protected $couponRepository;

    /**
     * UserService constructor
     */
    public function __construct(CouponContract $couponRepository)
    {
        $this->couponRepository = $couponRepository;
    }

    public function listCoupons($filterConditions, $orderBy = 'id', $sortBy = 'asc')
    {
        return $this->couponRepository->listCoupons($filterConditions, $orderBy, $sortBy);
    }


    public function findCoupon(int $id){
        return $this->couponRepository->find($id);
    }

    public function createOrUpdateCoupon(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->couponRepository->update($attributes, $id);
        }
        return $this->couponRepository->create($attributes);
    }

    public function updateCoupon($attributes, $id)
    {
        return $this->couponRepository->update($attributes, $id);
    }

    public function deleteCoupon($id)
    {
        return $this->couponRepository->delete($id);
    }

    public function attachOrDetachPlans(array $attributes,int $id){
        return $this->couponRepository->attachOrDetachPlans($attributes,$id);
    }


}
