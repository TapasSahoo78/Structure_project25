<?php

namespace App\Services\Site;

use App\Contracts\Site\FaqContract;

class FaqService
{
    /**
     * @var FaqContract
     */
    protected $faqRepository;

    /**
     * FaqService constructor
     */
    public function __construct(FaqContract $faqRepository)
    {
        $this->faqRepository = $faqRepository;
    }
    public function listFaqs(array $filterConditions, string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        return $this->faqRepository->listFaqs($filterConditions, $orderBy, $sortBy, $limit, $inRandomOrder);
    }

    public function findFaqById($id)
    {
        return $this->faqRepository->find($id);
    }

    public function createOrUpdateFaq(array $attributes, $id = null)
    {
        if (is_null($id)) {
            return $this->faqRepository->create($attributes);
        } else {
            return $this->faqRepository->update($attributes, $id);
        }
    }
    public function updateFaqStatus($attributes, $id)
    {
        return $this->faqRepository->update($attributes, $id);
    }

    public function deleteFaq(int $id){
        return $this->faqRepository->delete($id);
    }
}
