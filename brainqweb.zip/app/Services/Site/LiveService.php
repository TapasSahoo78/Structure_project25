<?php

namespace App\Services\Site;

use App\Contracts\Site\LiveContract;
use App\Models\Site\LiveClass;

class LiveService
{
    /**
     * @var LiveContract
     */
    protected $liveRepository;

    /**
     * SubjectService constructor
     */
    public function __construct(LiveContract $liveRepository)
    {
        $this->liveRepository = $liveRepository;
    }

    public function listClasses($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        return $this->liveRepository->listLiveClasses($filterConditions, $orderBy, $sortBy, $limit, $start, $inRandomOrder);
    }
    public function listExams($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start = null, $inRandomOrder = false)
    {
        return $this->liveRepository->listExams($filterConditions, $orderBy, $sortBy, $limit, $start, $inRandomOrder);
    }

    public function findLiveClass(int $id)
    {
        // $details = LiveClass::where('id', $id)->first();
        return $this->liveRepository->find($id);
    }
    public function findScheduledExam(int $id)
    {
        return $this->liveRepository->findExam($id);
    }

    public function createOrUpdateScheduledExam(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->liveRepository->updateExam($attributes, $id);
        }
        return $this->liveRepository->createExam($attributes);
    }
    public function updateScheduledExam(array $attributes, int $id)
    {
        return $this->liveRepository->updateExam($attributes, $id);
    }

    public function createOrUpdateLiveClass(array $attributes, $id = null)
    {
        // if (!is_null($id)) {
        //     return $this->liveRepository->update($attributes, $id);
        // }
        // return $this->liveRepository->create($attributes);
        $meassage = false;
        $check = LiveClass::where('id', $id)->first();
        // return $this->liveRepository->update($attributes,$id);
        if (isset($check) && !empty($check)) {
            $update = LiveClass::where('id', $id)->update($attributes);
            $meassage = true;
        } else {
            $update = LiveClass::create($attributes);
            $meassage = false;
        }
        return $update;
    }

    public function updateLiveClass($attributes, $id)
    {
        $update = LiveClass::where('id', $id)->update($attributes);
        // return $this->liveRepository->update($attributes,$id);
        if (isset($update) && !empty($update)) {
            return true;
        } else {
            return false;
        }
    }

    public function deleteLiveClass($id)
    {
        return $this->liveRepository->delete($id);
    }
    public function deleteSchedledExam($id)
    {
        return $this->liveRepository->deleteExam($id);
    }


}
