<?php

namespace App\Services\Site;

use App\Contracts\Site\SubjectContract;

class SubjectService
{
    /**
     * @var SubjectContract
     */
    protected $subjectRepository;

    /**
     * SubjectService constructor
     */
    public function __construct(SubjectContract $subjectRepository){
        $this->subjectRepository= $subjectRepository;
    }

    public function listSubjects($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $start= null,$inRandomOrder = false){
        return $this->subjectRepository->listSubjects($filterConditions,$orderBy,$sortBy,$limit,$start,$inRandomOrder);
    }

    public function findSubject(int $id){
        return $this->subjectRepository->find($id);
    }

    public function createOrUpdateSubject(array $attributes,$id=null)
    {
        if(!is_null($id)){
            return $this->subjectRepository->updateSubject($attributes,$id);
        }
        return $this->subjectRepository->createSubject($attributes);
    }

    public function updateSubject($attributes,$id){
        return $this->subjectRepository->update($attributes,$id);
    }

    public function deleteSubject($id){
        return $this->subjectRepository->deleteSubject($id);
    }


}
