<?php

namespace App\Services\User;

use App\Contracts\User\QueryContract;
use App\Models\User\Query;

class QueryService
{
    protected $queryRepository;

    public function __construct(QueryContract $queryRepository)
    {
        $this->queryRepository = $queryRepository;
    }


    public function listPlans(string $orderBy = 'id', string $sortBy = 'asc')
    {
        return $this->queryRepository->all('*', $orderBy, $sortBy);
    }
    public function find(int $id)
    {
        return $this->queryRepository->find($id);
    }

    public function createOrupdateQuery(array $attributes, $id = null)
    {
        if (!is_null($id)) {
            return $this->queryRepository->update($attributes, $id);
        }
        return $this->queryRepository->create($attributes);
    }

    public function listQuery($filterConditions, $orderBy = 'id', $sortBy = 'desc', $limit = 3)
    {
        return $this->queryRepository->listQuery($filterConditions, $orderBy, $sortBy, $limit);
    }

    public function findQuery(int $id)
    {
        return $this->queryRepository->find($id);
    }

    public function updateQuery($attributes, $id)
    {
        return $this->queryRepository->update($attributes, $id);
    }

    public function deleteQuery($id)
    {
        $delete = Query::where('id', $id)->delete();
        return $delete;
    }
}
