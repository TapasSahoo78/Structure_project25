<?php

namespace App\Services\User;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\User\SubscriptionContract;

class SubscriptionService
{
    protected $subscriptionRepository;

    public function __construct(SubscriptionContract $subscriptionRepository)
    {
        $this->subscriptionRepository = $subscriptionRepository;
    }


    public function listPlans(string $orderBy = 'id', string $sortBy = 'asc'){
        return $this->subscriptionRepository->all('*',$orderBy,$sortBy);
    }
    public function find(int $id){
        return $this->subscriptionRepository->find($id);
    }

    public function createOrupdatePlan(array $attributes,$id=null){
        if(!is_null($id)){
            return $this->subscriptionRepository->updatePlan($attributes,$id);
        }
        return $this->subscriptionRepository->createPlan($attributes);
    }

    public function addSubscription(array $attributes,int $id){
        return $this->subscriptionRepository->makeSubscription($attributes,$id);
    }

    public function updatePackage(array $attributes,int $id){
        return $this->subscriptionRepository->update($attributes,$id);
    }

    public function deletePackage(int $id){
        return $this->subscriptionRepository->delete($id);
    }


}
