<?php

namespace App\Services\User;

use Str;
use Illuminate\Support\Carbon;
use App\Contracts\User\UserContract;

class UserService
{
    protected $userRepository;

    public function __construct(UserContract $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function getTotalUsers(string $role, $status, string $search = null)
    {
        if ($status != 'all') {
            if (!is_null($search)) {
                return $this->userRepository->findUserByRole(['is_active' => $status], $role, 'id', 'asc', '', '', false, $search)->count();
            }
            return $this->userRepository->findUserByRole(['is_active' => $status], $role)->count();
        }
        if (!is_null($search)) {
            return $this->userRepository->findUserByRole([], $role, 'id', 'asc', '', '', false, $search)->count();
        }
        return $this->userRepository->findUserByRole([], $role)->count();
    }

    public function findUserByRole(array $filterConditions, string $role, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        return $this->userRepository->findUserByRole($filterConditions, $role, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }

    public function findOne(array $filterConditions)
    {
        return $this->userRepository->findOneByOrFail($filterConditions);
    }

    public function createUser(array $attributes)
    {
        return $this->userRepository->createUser($attributes);
    }
    public function updateUser(array $attributes, int $id = null)
    {
        return $this->userRepository->updateUser($attributes, $id);
    }
    public function updateStudentUser(array $attributes, int $id)
    {
        return $this->userRepository->updateStudent($attributes, $id);
    }

    public function deleteUser($attributes)
    {
        $id = uuidtoid($attributes['uuid'], 'users');
        return $this->userRepository->delete($id);
    }

    public function createUserInSteps(array $attributes, string $step, $id = null)
    {
        return $this->userRepository->createUserInStep($attributes, $step, $id);
    }

    public function checkOtp(string $otp, int $id)
    {
        return $this->userRepository->otpVerify($otp, $id);
    }

    public function basicUpdate(array $attributes, int $id)
    {
        return $this->userRepository->update($attributes, $id);
    }
}
