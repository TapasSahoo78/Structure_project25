<?php

namespace App\View\Components\modal;

use App\Services\Site\BoardService;
use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class addclass extends Component
{
    protected $boardService;
    /**
     * Create a new component instance.
     */
    public function __construct(public $boards,BoardService $boardService)
    {
        $this->boardService= $boardService;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        $boards= $this->boardService->listBoards(['is_active'=>true]);
        return view('components.modals.add-class',compact($boards));
    }
}
