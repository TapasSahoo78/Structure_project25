<?php

return [
    'secret' => env('RECAPTCHA_SECRET'),
    'sitekey' => env('RECAPTCHA_SITEKEY'),
    'host_server' => env('RECAPTCHA_HOST'),
    'score' => 0.5,
];
