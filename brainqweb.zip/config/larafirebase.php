<?php

return [

    'authentication_key' => 'AAAApvD5zBo:APA91bFR_a_LUsCnGWaalS3J-dGLAXMU2qq3T2rj5fJxZlClNdDDyGbxzd3UKZRDGG5fTeNWmjhZUFyhZlQ6Gh5gy2MIai_mDJoFah0R7Te81e7GJWVsPZ5pfkD05lIO_axfTKzQMbyj'

];
