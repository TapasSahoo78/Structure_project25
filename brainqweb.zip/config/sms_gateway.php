<?php

return [
    'apiKey' => 'QlJBSU5ROjJIRm52Q3dv',
    'apiUrl' => 'https://vas.themultimedia.in/domestic/sendsms/jsonapi.php',
    'source' => 'BRAINQ',
    'entityId' => '1701173070651942342',
    'tempId' => '1707173754995755330',
];
