<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid');
            $table->string('title', 100)->nullable();
            $table->string('code', 100)->comment('Coupon Code')->nullable();
            $table->enum('type', ['%', 'flat'])->nullable();
            $table->decimal('discount', 12,2)->nullable();
            $table->bigInteger('usage_per_user')->nullable();
            $table->bigInteger('usage_of_coupon')->nullable();
            $table->date('started_at')->nullable();
            $table->date('ended_at')->nullable();
            $table->boolean('is_expired')->default(false)->comment('0 for not expired,1 for expired');
            $table->tinyInteger('is_active')->default('1')->comment('0:Inactive,1:Active')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coupons');
    }
};
