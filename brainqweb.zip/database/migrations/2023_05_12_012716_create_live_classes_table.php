<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('live_classes', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->nullable();
            $table->foreignId('user_id')->references('id')->on('users')->cascadeOnDelete()->comment('Teacher Id who will present in the class');
            $table->foreignId('site_class_id')->references('id')->on('site_classes')->cascadeOnDelete();
            $table->foreignId('subject_id')->references('id')->on('subjects')->cascadeOnDelete();
            $table->string('name', 100)->nullable();
            $table->string('url', 100)->nullable();
            $table->longText('description')->nullable();
            $table->timestamp('will_live_at')->nullable();
            $table->timestamp('will_end_at')->nullable();
            $table->boolean('is_started')->nullable()->default(false);
            $table->boolean('is_finished')->nullable()->default(false);
            $table->boolean('is_active')->nullable()->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('live_classes');
    }
};
