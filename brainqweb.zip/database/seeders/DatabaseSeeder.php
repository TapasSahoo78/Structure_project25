<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use Illuminate\Database\Seeder;
use Database\Seeders\Cms\PageSeeder;
use Database\Seeders\Site\ExamSeeder;
use Database\Seeders\Site\TestSeeder;
use Database\Seeders\Site\GradeSeeder;
use Database\Seeders\Site\QuestionSeeder;
use Database\Seeders\User\{RoleSeeder,PermissionSeeder,UserSeeder};
use Database\Seeders\Site\{BoardSeeder,CountriesSeeder,StatesSeeder,ClassSeeder,SubjectSeeder,MappingSeeder,MediumSeeder, PackageSeeder,CouponSeeder, TestTypeSeeder};

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        /* $this->call(BoardSeeder::class);
        $this->call(ClassSeeder::class);
        $this->call(SubjectSeeder::class);
        $this->call(PermissionSeeder::class);
        $this->call(RoleSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(MediumSeeder::class);
        $this->call(MappingSeeder::class);
        $this->call(CountriesSeeder::class);
        $this->call(StatesSeeder::class);
        $this->call(PackageSeeder::class);
        $this->call(CouponSeeder::class);
        $this->call(PageSeeder::class); */
        // $this->call(TestSeeder::class);
        // $this->call(ExamSeeder::class);
        $this->call(GradeSeeder::class);

    }
}
