<?php

namespace Database\Seeders\Site;

use App\Models\Site\Board;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class BoardSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/boards.json');
        $data  = json_decode($json);
        foreach ($data->boards as $key => $value) {
            Board::create((array)$value);
        }
    }
}
