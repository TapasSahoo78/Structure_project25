<?php

namespace Database\Seeders\Site;


use App\Models\Site\SiteClass;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class ClassSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/classes.json');
        $data  = json_decode($json);
        foreach ($data->classes as $key => $value) {
            SiteClass::create((array)$value);
        }
    }
}
