<?php

namespace Database\Seeders\Site;

use App\Models\Site\Coupon;
use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CouponSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/coupons.json');
        $data  = json_decode($json);
        foreach ($data->coupons as $key => $value) {
            $value->started_at = Carbon::now()->format('Y-m-d');
            $value->ended_at = Carbon::parse($value->started_at)->addDays(20)->format('Y-m-d');
            Coupon::create((array)$value);
        }
    }
}
