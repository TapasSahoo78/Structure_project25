<?php

namespace Database\Seeders\Site;

use App\Models\Site\Exam;
use App\Models\Site\Question;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ExamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $isExamCreated= Exam::create([
            'name'=> 'Computer Exam',
            'site_class_id'=> 4,
            'subject_id'=> 70,
            'total_time'=> 60,
            'is_active'=>true,
            'scheduled_at'=> now()
        ]);
        if($isExamCreated){
            // logger($isExamCreated->getRelation('questions'));
            $question= Question::all();
            $isExamCreated->questions()->attach($question);
        }
    }
}
