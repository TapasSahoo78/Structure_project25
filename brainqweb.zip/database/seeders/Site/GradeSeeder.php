<?php

namespace Database\Seeders\Site;

use App\Models\Site\Grade;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class GradeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/grades.json');
        $data  = json_decode($json);
        foreach ($data->grades as $key => $value) {
            Grade::create((array)$value);
        }
    }
}
