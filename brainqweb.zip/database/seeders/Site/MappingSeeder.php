<?php

namespace Database\Seeders\Site;

use App\Models\User\Role;
use App\Models\User\User;
use App\Models\Site\Board;
use App\Models\Site\Medium;
use App\Models\Site\Subject;
use App\Models\Site\SiteClass;
use App\Models\User\Permission;
use Illuminate\Database\Seeder;

class MappingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $SuperAdminUser = User::find(1);
        $teacherUser = User::find(2);


        $isAdminRole = Role::where('slug', 'super-admin')->first();
        $teacherRole = Role::where('slug', 'teacher')->first();

        $permissions = Permission::get();
        $subjects = Subject::all();
        foreach($subjects as $subject){
            $board = Board::where('state','WEST BENGAL')->inRandomOrder()->first();
            $class = SiteClass::inRandomOrder()->first();
            $subject->classes()->attach($class);
            $subject->boards()->attach($board);
        }
        /* Assign permission to the role */
        $isAdminRole->permissions()->attach($permissions);

        /* Assign role and permission to the user */
        $SuperAdminUser->roles()->attach($isAdminRole);
        $teacherUser->roles()->attach($teacherRole);
        $SuperAdminUser->permissions()->attach($permissions);


        /* Assign classes to the board */
        $boards = Board::all();
        $classes = SiteClass::all();
        foreach ($boards as $board) {
            $board->classes()->attach($classes);
        }
        $mediums= Medium::all();
        foreach ($mediums as $medium) {
            $medium->boards()->attach($boards);
        }
        /* Not For Production */
        if(env('APP_ENV')!='production'){
            $studentRole = Role::where('slug', 'student')->first();
            $studentUsers = User::whereNotIn('id', [1, 2])->get();
            $studentRole->users()->attach($studentUsers);
            foreach ($studentUsers as $student) {
                $randomBoard = Board::where('state', 'WEST BENGAL')->inRandomOrder()->first();
                $class = SiteClass::inRandomOrder()->first();
                $student->boards()->attach($randomBoard);
                $student->classes()->attach($class);
            }
        }

    }
}
