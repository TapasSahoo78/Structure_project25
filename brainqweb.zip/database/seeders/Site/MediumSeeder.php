<?php

namespace Database\Seeders\Site;

use App\Models\Site\Medium;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MediumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/mediums.json');
        $data  = json_decode($json);
        foreach ($data->mediums as $key => $value) {
            Medium::create((array)$value);
        }
    }
}
