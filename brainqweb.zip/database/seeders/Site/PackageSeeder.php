<?php

namespace Database\Seeders\Site;

use App\Models\Site\Package;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PackageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/packages.json');
        $data  = json_decode($json);
        foreach ($data->packages as $key => $value) {
            $isPackageCreated=Package::create([
                'name'=>$value->name,
                'package_type' => $value->package_type,
                'is_most_popular' => $value->is_most_popular,
                'description' => $value->description
            ]);
            if($isPackageCreated){
                $isPackageCreated->price()->create([
                    'price' => $value->price->price,
                    'duration' => $value->price->duration,
                    'interval' => $value->price->interval
                ]);
            }
        }
    }
}
