<?php

namespace Database\Seeders\Site;

use App\Models\Site\Question;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class QuestionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Question::create([
            'question'=> 'What is a question?',
            'chapter_id' => 1,
            'marks' => 3
        ]);
    }
}
