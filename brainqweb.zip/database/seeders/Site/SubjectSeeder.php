<?php

namespace Database\Seeders\Site;

use App\Models\Site\Subject;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SubjectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path().'/data/subjects.json');
        $data  = json_decode($json);
        foreach ($data->subjects as $key => $value) {
            Subject::create((array)$value);
        }
    }
}
