<?php

namespace Database\Seeders\Site;

use App\Models\Site\Test;
use App\Models\Site\Question;
use App\Models\Site\TestType;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class TestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $typeArray= ['practise','test'];
        foreach ($typeArray as $value) {
            TestType::create([
                'type'=> $value,
                'is_active' =>true
            ]);
        }


        $firstQuestion=Question::create([
            'question'=>'What is Verb?',
            'chapter_id'=>4,
            'marks' => 1.00,
            'is_active'=> true
        ]);
        $secondQuestion=Question::create([
            'question'=>'What is Noun?',
            'chapter_id'=>4,
            'marks' => 1.00,
            'is_active'=> true
        ]);
        $isTestCreated= Test::create([
            'name'=> 'Grammar Test',
            'test_type_id'=> 1,
            'subject_id'=> 4,
            'total_time'=> 60,
            'is_active' => true
        ]);
        $isTestCreated->questions()->attach(Question::all());
        $firstQuestion->answers()->create([
            'answer'=> 'a word used to describe an action, state, or occurrence',
            'is_right' => true,
        ],
        [
            'answer'=> 'a word not in the list',
            'is_right' => false,
        ]);
        $secondQuestion->answers()->create([
            'answer'=> 'a word (other than a pronoun) used to identify any of a class of people, places, or things',
            'is_right' => true,
        ],
        [
            'answer'=> 'NOA',
            'is_right' => false,
        ]);

    }
}
