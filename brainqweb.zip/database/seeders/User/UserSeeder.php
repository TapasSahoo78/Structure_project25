<?php

namespace Database\Seeders\User;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User\Role;
use App\Models\User\User;
use Faker\Factory as Faker;
use Illuminate\Http\Request;
use App\Models\User\Permission;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(Request $request): void
    {
        $faker = Faker::create();
        $adminUser = new User();
        $adminUser->uuid = $faker->uuid;
        $adminUser->first_name = 'Super';
        $adminUser->last_name = 'Admin';
        $adminUser->username = 'superadmin';
        $adminUser->email = 'super.admin@elearning.com';
        $adminUser->mobile_number = 9191244321;
        $adminUser->email_verified_at = $faker->dateTime();
        $adminUser->mobile_number_verified_at = $faker->dateTime();
        $adminUser->password = bcrypt('secret');
        $adminUser->registration_ip = $request->getClientIp();
        $adminUser->is_active = 1;
        if($adminUser->save()){
            $adminUser->profile()->create([
                'uuid'=>$faker->uuid,
                'birthday'=>'1993-05-27',
                'gender'=> 'male',
            ]);
        }

        $teacherUser= new User();
        $teacherUser->uuid = $faker->uuid;
        $teacherUser->first_name = 'e-learn';
        $teacherUser->last_name = 'Teacher';
        $teacherUser->username = 'teacher';
        $teacherUser->email = 'teacher@elearning.com';
        $teacherUser->mobile_number = 9191254321;
        $teacherUser->email_verified_at = $faker->dateTime();
        $teacherUser->mobile_number_verified_at = $faker->dateTime();
        $teacherUser->password = bcrypt('secret');
        $teacherUser->registration_ip = $request->getClientIp();
        $teacherUser->is_active = 1;
        if($teacherUser->save()){
            $teacherUser->profile()->create([
                'uuid'=>$faker->uuid,
                'birthday'=>'1993-05-27',
                'gender'=> 'male',
                'designation'=> 'Senior Teacher',
                'qualification'=> 'M.A,B.Ed',
                'subjects'=> 'Bengali,English',
            ]);
        }
        if(env('APP_ENV')!='production'){
            for ($i=0; $i <= 15 ; $i++) {
                $studentUser= new User();
                $studentUser->uuid = $faker->uuid;
                $studentUser->first_name = fake()->name();
                $studentUser->username = fake()->username();
                $studentUser->mobile_number = $faker->numerify('##########');
                $studentUser->mobile_number_verified_at = $faker->dateTime();
                $studentUser->password = bcrypt('secret');
                $studentUser->registration_ip = $request->getClientIp();
                $studentUser->is_active = 1;
                if($studentUser->save()){
                    $studentUser->profile()->create([
                        'uuid'=>$faker->uuid,
                        'birthday'=>'1993-05-27',
                        'gender'=> 'male',
                        'state'=> 'west-bengal',
                        'city'=> 'kolkata',
                    ]);
                }
            }
        }
    }
}
