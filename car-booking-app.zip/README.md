<h1 align="center">Car Booking App</h1>

<p align="center">
<p>mkdir car-booking-app</p>
<p>cd car-booking-app</p>
<p>npm init -y</p>
<p>npm install express mongoose socket.io bcryptjs jsonwebtoken cors dotenv</p>
<p>npm install -D nodemon</p>
<p># Additional for serving frontend</p>
<p>npm install serve-static</p>
</p>

<p align="center">
1. Project Setup (Same as Before)
   
2.  Models (With Comments)
models/User.js:
models/Car.js:
models/Booking.js:

3. Middleware (New: Auth with Comments)
   middleware/auth.js:

4. Routes (With Comments)
   routes/auth.js:
   routes/bookings.js (Updated with auth):

5. Server (Updated with Socket.IO Auth, Frontend Serving, Comments)
   server.js:

Seed Data Script (Optional: Run once to add sample cars/drivers. Create seed.js):

6. Frontend Code (New: Vanilla JS with Comments)
Create a public folder in your project root. Inside, add index.html (single file for simplicity).
public/index.html:

</p>

<br>

## :dart: About

Describe your project

## :sparkles: Features

:heavy_check_mark: Feature 1;\
:heavy_check_mark: Feature 2;\
:heavy_check_mark: Feature 3;

## :rocket: Technologies

The following tools were used in this project:

- [Expo](https://expo.io/)
- [Node.js](https://nodejs.org/en/)
- [React](https://pt-br.reactjs.org/)
- [React Native](https://reactnative.dev/)
- [TypeScript](https://www.typescriptlang.org/)

## :white_check_mark: Requirements

Before starting :checkered_flag:, you need to have [Git](https://git-scm.com) and [Node](https://nodejs.org/en/) installed.

## :checkered_flag: Starting

```bash
# Clone this project
$ git clone https://github.com/{{YOUR_GITHUB_USERNAME}}/car-booking-app

# Access
$ cd car-booking-app

# Install dependencies
$ yarn

# Run the project
$ yarn start

# The server will initialize in the <http://localhost:3000>
```

## :memo: License

This project is under license from MIT. For more details, see the [LICENSE](LICENSE) file.

Made with :heart: by <a href="https://github.com/{{YOUR_GITHUB_USERNAME}}" target="_blank">{{YOUR_NAME}}</a>

&#xa0;

<a href="#top">Back to top</a>
