// Run: node seed.js (after starting MongoDB)
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../models/User");
const Car = require("../models/Car");

mongoose.connect(process.env.MONGO_URI);

async function seed() {
  // Create sample driver
  const driver = new User({
    name: "Driver Dave",
    email: "driver@example.com",
    password: "pass123", // Will be hashed
    role: "driver",
  });
  await driver.save();

  // Create sample car
  const car = new Car({
    make: "Toyota",
    model: "Camry",
    year: 2020,
    licensePlate: "ABC123",
    driverId: driver._id,
    available: true,
    currentLocation: { lat: 37.7749, lng: -122.4194 },
  });
  await car.save();

  console.log("Seeded data!");
  process.exit();
}

seed();
