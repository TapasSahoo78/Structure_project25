// Import JWT for token verification
const jwt = require("jsonwebtoken");

// Middleware function to verify JWT token and attach user to req
module.exports = (req, res, next) => {
  // Extract token from Authorization header (Bearer <token>)
  const token = req.header("Authorization")?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "No token provided" }); // Unauthorized if no token

  try {
    // Verify token against secret
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach decoded payload (userId, role) to req
    next(); // Proceed to route handler
  } catch (err) {
    res.status(401).json({ error: "Invalid token" }); // Bad token
  }
};
