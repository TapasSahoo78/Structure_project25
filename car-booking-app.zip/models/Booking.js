// Import MongoDB schema
const mongoose = require("mongoose");

// Define Booking schema for trip details
const bookingSchema = new mongoose.Schema(
  {
    passengerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    }, // Who booked
    carId: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true }, // Which car
    pickup: {
      // Pickup location details
      address: String, // Human-readable address
      lat: Number, // Latitude
      lng: Number, // Longitude
    },
    dropoff: {
      // Dropoff location
      address: String,
      lat: Number,
      lng: Number,
    },
    status: {
      type: String,
      enum: ["pending", "accepted", "in-progress", "completed"],
      default: "pending",
    }, // Booking lifecycle
    fare: { type: Number, required: true }, // Estimated cost
  },
  { timestamps: true }
);

// Export the model
module.exports = mongoose.model("Booking", bookingSchema);
