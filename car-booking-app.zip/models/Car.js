// Import MongoDB schema module
const mongoose = require('mongoose');

// Define Car schema for vehicle details
const carSchema = new mongoose.Schema({
  make: { type: String, required: true }, // Car manufacturer (e.g., 'Toyota')
  model: { type: String, required: true }, // Car model (e.g., 'Camry')
  year: { type: Number, required: true }, // Manufacturing year
  licensePlate: { type: String, required: true, unique: true }, // Unique plate number
  driverId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // Reference to driver user
  available: { type: Boolean, default: true }, // Is the car free for booking?
  currentLocation: { // Real-time location (updated via Socket.IO)
    lat: Number, // Latitude
    lng: Number  // Longitude
  }
}, { timestamps: true }); // Auto timestamps

// Export the model
module.exports = mongoose.model('Car', carSchema);