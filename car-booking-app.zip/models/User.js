// Import required modules for MongoDB schema and password hashing
const mongoose = require("mongoose"); // ODM for MongoDB
const bcrypt = require("bcryptjs"); // Library for secure password hashing

// Define the User schema with fields for passengers and drivers
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // User's full name
    email: { type: String, required: true, unique: true }, // Unique email for login
    password: { type: String, required: true }, // Hashed password
    role: { type: String, enum: ["passenger", "driver"], required: true }, // Role: 'passenger' or 'driver'
    location: {
      // Optional current location (for drivers)
      lat: Number, // Latitude
      lng: Number, // Longitude
    },
  },
  { timestamps: true }
); // Auto-add createdAt and updatedAt fields

// Middleware: Hash password before saving (only if modified)
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next(); // Skip if password unchanged
  this.password = await bcrypt.hash(this.password, 10); // Hash with salt rounds=10
  next();
});

// Method to compare plain password with hashed one
userSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.password); // Returns true if match
};

// Export the model for use in routes
module.exports = mongoose.model("User", userSchema);
