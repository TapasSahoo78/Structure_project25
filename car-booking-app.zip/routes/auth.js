// Import Express router and dependencies
const express = require("express");
const jwt = require("jsonwebtoken"); // For generating tokens
const User = require("../models/User"); // User model
const router = express.Router(); // Create router instance

// POST /api/auth/register - Register new user
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body; // Destructure input
    // Validate role (basic check)
    if (!["passenger", "driver"].includes(role)) {
      return res.status(400).json({ error: "Invalid role" });
    }
    // Create new user instance
    const user = new User({ name, email, password, role });
    await user.save(); // Save to DB (triggers hash)
    // Generate JWT token with userId and role
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET
    );
    // Respond with token and user info (exclude password)
    res.status(201).json({
      token,
      user: { id: user._id, name, email, role },
    });
  } catch (err) {
    // Handle duplicate email or other errors
    if (err.code === 11000) {
      return res.status(400).json({ error: "Email already exists" });
    }
    res.status(400).json({ error: err.message });
  }
});

// POST /api/auth/login - Login existing user
router.post("/login", async (req, res) => {
  try {
    const { email, password, role } = req.body; // Destructure input
    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" }); // No user
    }
    // Check password match
    if (!(await user.comparePassword(password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    // Generate token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET
    );
    // Respond
    res.json({
      token,
      user: { id: user._id, name: user.name, email, role },
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router; // Export router
