// Imports
const express = require("express");
const Booking = require("../models/Booking"); // Booking model
const Car = require("../models/Car"); // Car model
const auth = require("../middleware/auth"); // Auth middleware
const router = express.Router();

// GET /api/bookings/cars - List available cars (protected)
router.get("/cars", auth, async (req, res) => {
  try {
    // Fetch available cars, populate driver name and location
    const cars = await Car.find({ available: true }).populate(
      "driverId",
      "name location"
    );
    res.json(cars); // Send as JSON
  } catch (err) {
    res.status(500).json({ error: err.message }); // Server error
  }
});

// POST /api/bookings - Create new booking (passenger only, protected)
router.post("/", auth, async (req, res) => {
  try {
    // Role check
    if (req.user.role !== "passenger") {
      return res.status(403).json({ error: "Only passengers can book" });
    }
    const { carId, pickup, dropoff, fare } = req.body; // Destructure
    // Find and check car availability
    const car = await Car.findById(carId);
    console.log(car);

    if (!car || !car.available) {
      return res.status(400).json({ error: "Car not available" });
    }
    // Create booking
    const booking = new Booking({
      passengerId: req.user.userId,
      carId,
      pickup,
      dropoff,
      fare,
    });
    await booking.save(); // Save to DB
    // Update car status
    car.available = false;
    await car.save();
    // Emit Socket.IO event to notify driver (room based on driver ID)
    req.io
      .to(`driver-${car.driverId}`)
      .emit("new-booking", { bookingId: booking._id });
    res.status(201).json(booking); // Respond with booking
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/bookings/:id/accept - Accept booking (driver only, protected)
router.patch("/:id/accept", auth, async (req, res) => {
  try {
    // Role check
    if (req.user.role !== "driver") {
      return res.status(403).json({ error: "Only drivers can accept" });
    }
    // Find booking and populate car
    const booking = await Booking.findById(req.params.id).populate("carId");
    if (!booking) {
      return res.status(404).json({ error: "Booking not found" });
    }
    // Ownership check
    if (booking.carId.driverId.toString() !== req.user.userId) {
      return res.status(403).json({ error: "Not your booking" });
    }
    // Update status
    booking.status = "accepted";
    await booking.save();
    // Notify passenger via Socket.IO (room based on passenger ID)
    req.io
      .to(`passenger-${booking.passengerId}`)
      .emit("booking-accepted", { bookingId: booking._id });
    res.json(booking);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/bookings/:id - Get booking details (protected, owner only)
router.get("/:id", auth, async (req, res) => {
  try {
    // Find and populate
    const booking = await Booking.findById(req.params.id).populate(
      "passengerId carId"
    );
    if (!booking) {
      return res.status(404).json({ error: "Booking not found" });
    }
    // Access check: passenger or driver
    const isPassenger = booking.passengerId._id.toString() === req.user.userId;
    const isDriver = booking.carId.driverId.toString() === req.user.userId;
    if (!isPassenger && !isDriver) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    res.json(booking);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
