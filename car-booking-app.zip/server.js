// Load environment variables
require("dotenv").config();
// Import core modules
const express = require("express"); // Web framework
const mongoose = require("mongoose"); // MongoDB ODM
const cors = require("cors"); // CORS middleware
const http = require("http"); // HTTP server
const socketIo = require("socket.io"); // Real-time WebSockets
const jwt = require("jsonwebtoken"); // For Socket auth
const path = require("path"); // File paths
const serveStatic = require("serve-static"); // Serve static files
// Import routes
const authRoutes = require("./routes/auth");
const bookingRoutes = require("./routes/bookings");

// Create Express app and HTTP server
const app = express();
const server = http.createServer(app);
// Initialize Socket.IO with CORS
const io = socketIo(server, {
  cors: { origin: "*" }, // Allow all origins (dev only; restrict in prod)
});

// Middleware stack
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON bodies

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected successfully")) // Success log
  .catch((err) => console.error("MongoDB connection error:", err)); // Error log

// API Routes (prefix /api)
app.use("/api/auth", authRoutes);
app.use("/api/bookings", bookingRoutes);

// Attach io to req for use in routes (after routes? No, before)
app.use((req, res, next) => {
  req.io = io; // Make Socket.IO available in route handlers
  next();
});

// Serve frontend static files (HTML/JS/CSS) from public folder
app.use(serveStatic(path.join(__dirname, "public"))); // Serve /public as static

// Socket.IO Authentication Middleware
io.use((socket, next) => {
  // Extract token from handshake auth
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error("No token provided"));
  try {
    // Verify and attach userId
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    socket.userId = decoded.userId; // Attach to socket
    socket.role = decoded.role; // Attach role
    next(); // Proceed
  } catch (err) {
    next(new Error("Authentication error")); // Reject
  }
});

// Socket.IO Connection Handler
io.on("connection", (socket) => {
  console.log("User connected:", socket.id); // Log connection

  // Event: Join booking room as driver
  socket.on("join-booking", (bookingId) => {
    socket.join(bookingId); // Join room for real-time
    console.log(`Driver ${socket.userId} joined booking room: ${bookingId}`);
  });

  // Event: Join to track booking as passenger
  socket.on("track-booking", (bookingId) => {
    socket.join(bookingId); // Join room
    console.log(`Passenger ${socket.userId} tracking booking: ${bookingId}`);
  });

  // Event: Driver sends location update
  socket.on("location-update", async ({ bookingId, location }) => {
    try {
      // Import models inside handler (avoid circular deps)
      const Booking = require("./models/Booking");
      const Car = require("./models/Car");
      // Find booking to verify ownership
      const booking = await Booking.findById(bookingId).populate("carId");
      if (!booking || booking.carId.driverId.toString() !== socket.userId) {
        return socket.emit("error", { message: "Unauthorized update" });
      }
      // Update car location in DB
      await Car.findOneAndUpdate(
        { _id: booking.carId._id },
        { currentLocation: location },
        { new: true }
      );
      // Broadcast to room (passengers/drivers in booking)
      io.to(bookingId).emit("driver-location", {
        location,
        timestamp: new Date().toISOString(),
      });
      console.log(`Location updated for booking ${bookingId}:`, location);
    } catch (err) {
      console.error("Location update error:", err);
    }
  });

  // Disconnect handler
  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`); // Log startup
});
