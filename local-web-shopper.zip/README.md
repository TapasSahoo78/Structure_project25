# 🛒 Local Web Shopper

> **GitHub Repo**: [SouthMagnolia/local-web-shopper](https://github.com/SouthMagnolia/local-web-shopper)

---

## ⚙️ Stack

- **Backend**: Laravel 12 (PHP 8.4)
- **Frontend**: React 19
- **Database**: MySQL/MariaDB

---

## 🧭 Getting Started

### 1. Clone the Repository

```bash
git clone https://github.com/SouthMagnolia/local-web-shopper.git
cd local-web-shopper
```

### 2. Install PHP Dependencies

```bash 
composer install
```

### 3. Set Up Environment Variables
```bash
cp .env.example .env
php artisan key:generate
```

Then edit your .env file with the appropriate values. 

The following are common fields which will require an update on initial setup:

```bash
# Database
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=database_name
DB_USERNAME=username
DB_PASSWORD=password

# Mailer 
MAIL_MAILER=log
MAIL_SCHEME=null
MAIL_HOST=127.0.0.1
MAIL_PORT=2525
MAIL_USERNAME=null
MAIL_PASSWORD=null
MAIL_FROM_ADDRESS="hello@example.com"
MAIL_FROM_NAME="${APP_NAME}"

# Stripe
STRIPE_KEY="STRIPE_KEY"
STRIPE_SECRET="STRIPE_SECRET"
STRIPE_WEBHOOK_SECRET="STRIPE_WEBHOOK_SECRET"

# Google Maps
MAPS_API_KEY="MAPS_API_KEY"
```
### 4. Install Node Dependencies
```bash
npm install
```
### 5. Run Migrations

```bash
php artisan migrate
```
### 6. Run Development Servers

```bash
php artisan serve
npm run dev
```

## 📁 Project Structure
```bash
├── app/                     # Laravel backend
├── resources/
│   └── js/                  # React 19 frontend
├── routes/
│   ├── web.php              # Web routes
│   └── api.php              # API routes
├── database/
│   └── migrations/          # DB migrations
├── public/
├── .env                     # Environment configuration
└── vite.config.js           # Vite config
```

## 🔨 Build for Production

```bash
npm run build
php artisan config:cache
php artisan route:cache
```
---

### ⚙️ Stripe Webhooks Configuration

The webhook enpdoint is at `/api/stripe/webhook`.

Set up the following Stripe webhook events to properly sync customer, subscription, and billing data:

#### 🧑‍💼 Customer Events

* `customer.deleted` – Triggered when a customer is deleted.
* `customer.updated` – Triggered when any property of a customer changes.
* `customer.subscription.deleted` – Triggered when a customer’s subscription ends.
* `customer.subscription.paused` – Triggered when a subscription enters `status=paused`. Does **not** trigger when payment collection is paused.
* `customer.subscription.resumed` – Triggered when a paused subscription is resumed (`status=paused` is cleared). Does **not** trigger when only payment collection is resumed.
* `customer.subscription.updated` – Triggered when a subscription changes (e.g., plan switch, status change from trial to active).

#### 🧾 Invoice Events

* `invoice.created` – Triggered when a new invoice is created.
* `invoice.paid` – Triggered when an invoice payment attempt succeeds or is marked as paid manually.
* `invoice.payment_failed` – Triggered when a payment attempt fails (e.g., card declined or missing payment method).
* `invoice.payment_succeeded` – Triggered when a payment attempt succeeds.
* `invoice.updated` – Triggered when any invoice detail changes (e.g., amount).
* `invoice.voided` – Triggered when an invoice is voided.

#### 🛍️ Product Events

* `product.deleted` – Triggered when a product is deleted.
* `product.updated` – Triggered when a product is updated.

---

### 🗺️ Google Maps API Configuration

Ensure your Google Maps API key has the following permissions enabled:

* **Maps JavaScript API**
* **Places API**
* **Places API (New)**
* **Geocoding API**

You can enable these in the [Google Cloud Console](https://console.cloud.google.com/apis/library) under your project.

---

## 👥 Contributors

Maintained by SouthMagnolia