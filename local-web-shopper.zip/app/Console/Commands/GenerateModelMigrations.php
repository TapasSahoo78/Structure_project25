<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use ReflectionClass;

class GenerateModelMigrations extends Command
{
    protected $signature = 'make:model-migrations {model? : The model name}';
    protected $description = 'Generate migration files for all models or a specific model';

    public function handle()
    {
        $modelName = $this->argument('model');

        if ($modelName) {
            $this->generateMigrationForModel($modelName);
        } else {
            $this->generateMigrationsForAllModels();
        }

        $this->info('Migration generation completed.');
    }

    private function generateMigrationsForAllModels()
    {
        $modelsDirectory = app_path('Models');
        $modelFiles = File::files($modelsDirectory);

        foreach ($modelFiles as $file) {
            $this->generateMigrationForModel($file->getBasename('.php'));
        }
    }

    private function generateMigrationForModel($modelName)
    {
        $fullyQualifiedClassName = "App\\Models\\{$modelName}";
        
        if (!class_exists($fullyQualifiedClassName)) {
            $this->error("Model {$modelName} not found.");
            return;
        }

        $model = new $fullyQualifiedClassName();
        $tableName = $model->getTable();
        $migrationName = date('Y_m_d_His') . '_create_' . $tableName . '_table.php';
        $migrationPath = database_path("migrations/{$migrationName}");
        
        $fields = $this->getFieldsFromDocBlock($fullyQualifiedClassName);
        $migrationContent = $this->generateMigrationContent($modelName, $tableName, $fields);
        
        File::put($migrationPath, $migrationContent);
        
        $this->info("Created migration for {$modelName}: {$migrationName}");
        
        sleep(1); // Ensure unique timestamp for next migration
    }

    private function getFieldsFromDocBlock($className)
    {
        $reflect = new ReflectionClass($className);
        $docComment = $reflect->getDocComment();
        
        $fields = [];
        if (preg_match_all('/@property\s+([\\\\\w]+)\s+\$(\w+)/', $docComment, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $fields[$match[2]] = $this->mapDocTypeToSchemaType($match[1]);
            }
        }
        
        return $fields;
    }

    private function mapDocTypeToSchemaType($docType)
    {
        $typeMap = [
            'int' => 'integer',
            'integer' => 'integer',
            'bigint' => 'bigInteger',
            'float' => 'float',
            'double' => 'double',
            'decimal' => 'decimal',
            'string' => 'string',
            'text' => 'text',
            'bool' => 'boolean',
            'boolean' => 'boolean',
            'date' => 'date',
            'datetime' => 'dateTime',
            'timestamp' => 'timestamp',
            '\Carbon\Carbon' => 'timestamp',
        ];

        // Handle enum types
        if (Str::contains($docType, 'Enum')) {
            return "enum('" . Str::afterLast($docType, '\\') . "')";
        }

        return $typeMap[$docType] ?? 'string'; // Default to string if type is not recognized
    }

    private function generateMigrationContent($modelName, $tableName, $fields)
    {
        $schemaFields = collect($fields)->map(function ($type, $field) {
            if (Str::startsWith($type, 'enum')) {
                // For enum fields, we need to fetch the possible values
                $enumClass = "App\\Enums\\" . Str::between($type, "'", "'");
                $enumValues = implode("', '", array_column($enumClass::cases(), 'name'));
                return "            \$table->enum('{$field}', ['{$enumValues}']);";
            }
            return "            \$table->{$type}('{$field}');";
        })->implode("\n");
        
        return <<<EOT
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('{$tableName}', function (Blueprint \$table) {
            \$table->id();
{$schemaFields}
            \$table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('{$tableName}');
    }
};
EOT;
    }
}