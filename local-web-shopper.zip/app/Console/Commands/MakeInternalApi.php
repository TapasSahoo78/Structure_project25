<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Str;
use Illuminate\Filesystem\Filesystem;

class MakeInternalApi extends Command
{
    protected $signature = 'make:internal-api {model}';

    protected $description = 'Generate internal API scaffold for a given model (controller, resource, requests, route snippet)';

    public function handle()
    {
        $model = Str::studly($this->argument('model'));
        $modelPath = app_path("Models/{$model}.php");

        if (!file_exists($modelPath)) {
            $this->error("Model file not found at: {$modelPath}");
            return;
        }

        $docblock = file_get_contents($modelPath);
        preg_match_all('/@property\s+([^\s]+)\s+\$(\w+)/', $docblock, $matches);
        $fields = array_combine($matches[2], $matches[1]);

        $controller = "Internal/{$model}Controller";
        $resource = "{$model}Resource";
        $requests = [
            'Index' => "{$model}IndexRequest",
            'Show' => "{$model}ShowRequest",
            'Store' => "{$model}StoreRequest",
            'Update' => "{$model}UpdateRequest",
            'Destroy' => "{$model}DestroyRequest",
        ];
        $lowerPlural = Str::kebab(Str::pluralStudly($model));

        Artisan::call("make:controller {$controller} --api");
        Artisan::call("make:resource {$resource}");

        foreach ($requests as $requestName) {
            Artisan::call("make:request {$requestName}");
        }

        $controllerPath = app_path("Http/Controllers/Internal/{$model}Controller.php");
        $resourcePath = app_path("Http/Resources/{$model}Resource.php");

        $fs = new Filesystem();

        $fs->put($controllerPath, $this->controllerTemplate($model, $fields, $requests));
        $fs->put($resourcePath, $this->resourceTemplate($model, $fields));

        foreach ($requests as $operation => $requestName) {
            $requestPath = app_path("Http/Requests/{$requestName}.php");
            $fs->put($requestPath, $this->requestTemplate($model, $fields, $operation));
        }

        $this->info("✅ Scaffolding complete for model: {$model}");

        $this->line("\n📌 Add the following to your routes/api.php inside your internal group:");
        $this->line("use App\\Http\\Controllers\\Internal\\{$model}Controller;");
        $this->line("Route::apiResource('{$lowerPlural}', {$model}Controller::class);");
    }

    protected function controllerTemplate($model, $fields, $requests)
    {
        $filters = collect($fields)
            ->filter(fn($type, $name) => $name !== 'id' && $name !== 'created_at' && $name !== 'updated_at')
            ->map(fn($type, $name) => "        if (\$request->filled('{$name}')) {\n            \$query->where('{$name}', \$request->{$name});\n        }")
            ->implode("\n\n");

        $useStatements = collect($requests)
            ->map(fn($request) => "use App\\Http\\Requests\\{$request};")
            ->implode("\n");

        return <<<PHP
<?php

namespace App\Http\Controllers\Internal;

use App\Models\\{$model};
use App\Http\Controllers\Controller;
use App\Http\Resources\\{$model}Resource;
{$useStatements}
use Illuminate\Http\Request;

class {$model}Controller extends Controller
{
    public function index({$requests['Index']} \$request)
    {
        \$query = {$model}::query();

{$filters}

        return {$model}Resource::collection(\$query->paginate(20));
    }

    public function store({$requests['Store']} \$request)
    {
        \$item = {$model}::create(\$request->validated());
        return new {$model}Resource(\$item);
    }

    public function show({$requests['Show']} \$request, {$model} \$item)
    {
        return new {$model}Resource(\$item);
    }

    public function update({$requests['Update']} \$request, {$model} \$item)
    {
        \$item->update(\$request->validated());
        return new {$model}Resource(\$item);
    }

    public function destroy({$requests['Destroy']} \$request, {$model} \$item)
    {
        \$item->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
}
PHP;
    }

    protected function resourceTemplate($model, $fields)
    {
        $body = collect($fields)
            ->map(fn($_, $name) => "            '{$name}' => \$this->{$name},")
            ->implode("\n");

        return <<<PHP
<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class {$model}Resource extends JsonResource
{
    public function toArray(\$request)
    {
        return [
{$body}
        ];
    }
}
PHP;
    }

    protected function requestTemplate($model, $fields, $operation)
    {
        $rules = $this->getRules($fields, $operation);

        return <<<PHP
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class {$model}{$operation}Request extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
{$rules}
        ];
    }
}
PHP;
    }

    protected function getRules($fields, $operation)
    {
        switch ($operation) {
            case 'Index':
            case 'Show':
            case 'Destroy':
                return ''; // No rules for these operations
            case 'Store':
                return collect($fields)
                    ->filter(fn($type, $name) => !in_array($name, ['id', 'created_at', 'updated_at']))
                    ->map(fn($type, $name) => "            '{$name}' => 'required|string|max:255',")
                    ->implode("\n");
            case 'Update':
                return collect($fields)
                    ->filter(fn($type, $name) => !in_array($name, ['id', 'created_at', 'updated_at']))
                    ->map(fn($type, $name) => "            '{$name}' => 'sometimes|required|string|max:255',")
                    ->implode("\n");
            default:
                return '';
        }
    }
}