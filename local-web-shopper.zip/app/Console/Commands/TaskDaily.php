<?php

namespace App\Console\Commands;

use App\Models\Ad;
use Illuminate\Console\Command;

class TaskDaily extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'task:daily';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Daily Tasks that Run at 2am.';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // info("Task daily cron jobs is running");
        Ad::dailyAdCheck();
        return 0;
    }
}
