<?php

namespace App\Enums;

enum AdFailureType: string
{
    case INVOICE_CREATE = 'INVOICE_CREATE';
    case INVOICE_PAY = 'INVOICE_PAY';
    case SUB_CREATE = 'SUB_CREATE';
    case SUB_CANCEL = 'SUB_CANCEL';
    case PAYMENT_FAILED = 'PAYMENT_FAILED';

    /**
     * @return string
     */
    public function getHumanDesc(): string
    {
        return match ($this) {
            self::INVOICE_CREATE => "Failed creating invoice",
            self::INVOICE_PAY    => "Failed paying invoice",
            self::SUB_CREATE     => "Failed creating subscription",
            self::SUB_CANCEL     => "Failed canceling subscription",
            self::PAYMENT_FAILED => "Payment failed"
        };
    }
}
