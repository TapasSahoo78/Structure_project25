<?php

namespace App\Enums;

enum AdStatus: string
{
    case DRAFT = 'DRAFT';
    case SCHEDULED = 'SCHEDULED';
    case LIVE = 'LIVE';
    case PAUSED = 'PAUSED';
    case ENDED = 'ENDED';
    case FAILED = 'FAILED';
    case SUSPENDED = 'SUSPENDED';
    case ARCHIVED = 'ARCHIVED';

    public function getHuman(): string
    {
        return match ($this) {
            self::DRAFT => "Draft",
            self::SCHEDULED => "Scheduled",
            self::LIVE => "Live",
            self::PAUSED => "Paused",
            self::ENDED => "Ended",
            self::FAILED => "Failed",
            self::SUSPENDED => "Suspended",
            self::ARCHIVED => "Archived"
        };
    }

    public function getColor(): string
    {
        return match ($this) {
            self::DRAFT => "secondary",
            self::SCHEDULED => "primary",
            self::LIVE => "success",
            self::PAUSED => "warning",
            self::ENDED => "secondary",
            self::FAILED => "danger",
            self::SUSPENDED => "danger",
            self::ARCHIVED => "dark"
        };
    }

    public function getDescription(): string
    {
        return match ($this) {
            self::DRAFT => "Ad is being created or edited and is not yet ready for publication.",
            self::SCHEDULED => "Ad is set to go live at a future date.",
            self::LIVE => "Ad is currently active and visible to the target audience.",
            self::PAUSED => "Ad was live but has been temporarily paused.",
            self::ENDED => "Ad has reached its end date and is no longer active.",
            self::FAILED => "Ad encountered an error during publication or while live.",
            self::SUSPENDED => "Ad has been removed or suspended due to policy violations or other issues.",
            self::ARCHIVED => "Ad is no longer active and has been moved to long-term storage."
        };
    }

    public function isEditable(): bool
    {
        return in_array($this, [
            self::DRAFT,
            self::PAUSED,
            self::SCHEDULED
        ]);
    }

    public function canBePublished(): bool
    {
        return in_array($this, [
            self::DRAFT,
            self::PAUSED,
            self::SCHEDULED
        ]);
    }

    public function canBeScheduled(): bool
    {
        return in_array($this, [
            self::DRAFT,
            self::SCHEDULED,
            self::FAILED
        ]);
    }

    public function canBeReinstated(): bool
    {
        return in_array($this, [
            self::PAUSED,
            self::SUSPENDED
        ]);
    }
}
