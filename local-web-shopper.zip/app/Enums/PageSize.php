<?php

namespace App\Enums;

enum PageSize: string
{
    case QUARTER = 'QUARTER';
    case HALF = 'HALF';
    case FULL = 'FULL';
    case BANNER = 'BANNER';

    public function getHuman(): string
    {
        return match ($this)
        {
            self::QUARTER => "1/4 Page",
            self::HALF    => "1/2 Page",
            self::FULL    => "Full Page",
            self::BANNER  => "Banner"
        };
    }

    static public function getSelectable(): array
    {
        return array_combine(
            array_column(self::cases(), 'value'),
            array_map(fn($case) => $case->getHuman(), self::cases())
        );
    }
}