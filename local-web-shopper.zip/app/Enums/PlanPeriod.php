<?php

namespace App\Enums;

enum PlanPeriod: string
{
    case DAILY = 'DAILY';
    case MONTHLY = 'MONTHLY';
    case QUARTERLY = 'QUARTERLY';
    case BIANNUALLY = 'BIANNUALLY';
    case ANNUALLY = 'ANNUALLY';

    public function getHuman(): string
    {
        return match ($this)
        {
             self::DAILY    => "Daily",
            self::MONTHLY    => "Monthly",
            self::QUARTERLY  => "Quarterly",
            self::BIANNUALLY => "Biannually",
            self::ANNUALLY   => "Annually"
        };
    }

    static public function getSelectable(): array
    {
        return array_combine(
            array_column(self::cases(), 'value'),
            array_map(fn($case) => $case->getHuman(), self::cases())
        );
    }

    public function getStripeValue(): string
    {
        return match ($this)
        {
              self::DAILY                                   => "day",
            self::MONTHLY, self::QUARTERLY, self::BIANNUALLY => "month",
            self::ANNUALLY                                   => "year"
        };
    }

    public function getIntervalCount(): int
    {
        return match ($this)
        {
            self::DAILY, self::MONTHLY, self::ANNUALLY => 1,
            self::QUARTERLY               => 3,
            self::BIANNUALLY              => 6
        };
    }
}
