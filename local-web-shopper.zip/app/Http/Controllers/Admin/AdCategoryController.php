<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdCategory;
use App\Http\Requests\AdCategoryStoreRequest;
use App\Http\Requests\AdCategoryUpdateRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AdCategoryController extends Controller
{
    public function index()
    {
        $adCategories = AdCategory::all();
        return Inertia::render('admin/ad-categories/index', ['adCategories' => $adCategories]);
    }

    public function create()
    {
        return Inertia::render('admin/ad-categories/create');
    }

    public function store(AdCategoryStoreRequest $request)
    {
        $adCategory = AdCategory::create($request->validated());
        return redirect()->route('admin.ad-categories.index')->with('success', 'Plan created successfully.');
    }

    // public function show(AdCategory $adCategory)
    // {
    //     return Inertia::render('admin/ad-categories/show', ['adCategory' => $adCategory]);
    // }

    // public function edit(AdCategory $adCategory)
    // {
    //     return Inertia::render('admin/ad-categories/edit', ['adCategory' => $adCategory]);
    // }

    public function update(AdCategoryUpdateRequest $request, AdCategory $adCategory)
    {
        $adCategory->update($request->validated());
        return redirect()->route('admin.ad-categories.index')->with('success', 'Plan updated successfully.');
    }

    public function destroy(AdCategory $adCategory)
    {
        $adCategory->delete();
        return redirect()->route('admin.ad-categories.index')->with('success', 'Plan deleted successfully.');
    }
}