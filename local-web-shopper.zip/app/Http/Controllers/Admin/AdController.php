<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Http\Requests\AdStoreRequest;
use App\Http\Requests\AdUpdateRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AdController extends Controller
{
    public function index()
    {
        return Inertia::render('admin/advertisements/index');
    }

    // public function create()
    // {
    //     return Inertia::render('admin/advertisements/create');
    // }

    public function store(AdStoreRequest $request)
    {
        $ad = Ad::create($request->validated());
        return redirect()->route('admin.ads.index')->with('success', 'Ad created successfully.');
    }

    // public function show(Ad $ad)
    // {
    //     return Inertia::render('admin/advertisements/show', ['ad' => $ad]);
    // }

    // public function edit(Ad $ad)
    // {
    //     return Inertia::render('admin/advertisements/edit', ['ad' => $ad]);
    // }

    public function update(AdUpdateRequest $request, Ad $ad)
    {
        $ad->update($request->validated());
        return redirect()->route('admin.ads.index')->with('success', 'Ad updated successfully.');
    }

    public function destroy(Ad $ad)
    {
        $ad->delete();
        return redirect()->route('admin.ads.index')->with('success', 'Ad deleted successfully.');
    }
}