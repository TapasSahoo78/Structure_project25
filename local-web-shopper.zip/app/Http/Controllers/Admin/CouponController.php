<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Http\Requests\CouponStoreRequest;
use App\Http\Requests\CouponUpdateRequest;
use App\Models\Coupon;
use App\Services\CouponService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Stripe\Exception\ApiErrorException;

class CouponController extends Controller
{
    protected $couponService;

    public function __construct(CouponService $couponService)
    {
        $this->couponService = $couponService;
    }

    public function index()
    {
        $coupons = Coupon::all();
        return Inertia::render('admin/coupons/index', ['coupons' => $coupons]);
    }

    public function create()
    {
        return Inertia::render('admin/coupons/create');
    }

    public function store(CouponStoreRequest $request)
    {
        try {
            $coupon = $this->couponService->createCoupon($request->validated());
            return redirect()->route('admin.coupons.index')->with('success', 'Coupon created successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to create Coupon: ' . $e->getMessage()]);
        }
    }

    // public function show(Plan $plan)
    // {
    //     return Inertia::render('admin/plans/show', ['plan' => $plan]);
    // }

    // public function edit(Plan $plan)
    // {
    //     return Inertia::render('admin/plans/edit', ['plan' => $plan]);
    // }

    public function update(CouponUpdateRequest $request, Coupon $coupon)
    {
        try {
            $this->couponService->updateCoupon($coupon, $request->validated());
            return redirect()->route('admin.coupons.index')->with('success', 'Coupon updated successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to update Coupon: ' . $e->getMessage()]);
        }
    }

    public function destroy(Coupon $coupon)
    {
        try {
            $this->couponService->archiveCoupon($coupon);
            return redirect()->route('admin.coupons.index')->with('success', 'Coupon archived and deleted successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to archive Coupon: ' . $e->getMessage()]);
        }
    }
}
