<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Http\Requests\InvoiceStoreRequest;
use App\Http\Requests\InvoiceUpdateRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;

class InvoiceController extends Controller
{
    public function index()
    {
        $invoice = Invoice::all();
        return Inertia::render('admin/invoices/index', ['invoice' => $invoice]);
    }

    public function create()
    {
        return Inertia::render('admin/invoices/create');
    }

    public function store(InvoiceStoreRequest $request)
    {
        $invoice = Invoice::create($request->validated());
        return redirect()->route('admin.invoices.index')->with('success', 'Invoice created successfully.');
    }

    // public function show(Invoice $invoice)
    // {
    //     return Inertia::render('admin/invoices/show', ['invoice' => $invoice]);
    // }

    // public function edit(Invoice $invoice)
    // {
    //     return Inertia::render('admin/invoices/edit', ['invoice' => $invoice]);
    // }

    public function update(InvoiceUpdateRequest $request, Invoice $invoice)
    {
        $invoice->update($request->validated());
        return redirect()->route('admin.invoices.index')->with('success', 'Invoice updated successfully.');
    }

    public function destroy(Invoice $invoice)
    {
        $invoice->delete();
        return redirect()->route('admin.invoices.index')->with('success', 'Invoice deleted successfully.');
    }
}