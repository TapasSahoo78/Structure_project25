<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Http\Requests\PlanStoreRequest;
use App\Http\Requests\PlanUpdateRequest;
use App\Services\PlanService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Stripe\Exception\ApiErrorException;

class PlanController extends Controller
{
    protected $planService;

    public function __construct(PlanService $planService)
    {
        $this->planService = $planService;
    }

    public function index()
    {
        $plans = Plan::all();
        return Inertia::render('admin/plans/index', ['plans' => $plans]);
    }

    public function create()
    {
        return Inertia::render('admin/plans/create');
    }

    public function store(PlanStoreRequest $request)
    {
        try {
            $plan = $this->planService->createPlan($request->validated());
            return redirect()->route('admin.plans.index')->with('success', 'Plan created successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to create Plan: ' . $e->getMessage()]);
        }
    }
    // public function show(Plan $plan)
    // {
    //     return Inertia::render('admin/plans/show', ['plan' => $plan]);
    // }

    // public function edit(Plan $plan)
    // {
    //     return Inertia::render('admin/plans/edit', ['plan' => $plan]);
    // }

    public function update(PlanUpdateRequest $request, Plan $plan)
    {
        try {
            $this->planService->updatePlan($plan, $request->validated());
            return redirect()->route('admin.plans.index')->with('success', 'Plan updated successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to update Plan: ' . $e->getMessage()]);
        }
    }

    public function destroy(Plan $plan)
    {
        try {
            $this->planService->archivePlan($plan);
            return redirect()->route('admin.plans.index')->with('success', 'Plan archived and deleted successfully.');
        } catch (ApiErrorException $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to archive Plan: ' . $e->getMessage()]);
        }
    }
}
