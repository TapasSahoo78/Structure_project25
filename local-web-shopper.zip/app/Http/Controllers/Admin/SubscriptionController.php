<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Inertia\Inertia;

class SubscriptionController extends Controller
{
    public function index()
    {
        $subscriptions = auth()->user()->subscriptions;
        return Inertia::render('admin/subscriptions/index', ['subscriptions' => $subscriptions]);
    }

    public function create()
    {
        return Inertia::render('admin/subscriptions/create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'duration' => 'required|integer|min:1',
            // Add other validation rules as needed
        ]);

        auth()->user()->subscriptions()->create($validated);

        return redirect()->route('admin.subscriptions.index')->with('success', 'Subscription created successfully.');
    }

    public function show(Subscription $subscription)
    {
        $this->authorize('view', $subscription);
        return Inertia::render('admin/subscriptions/show', ['subscription' => $subscription]);
    }

    public function edit(Subscription $subscription)
    {
        $this->authorize('update', $subscription);
        return Inertia::render('admin/subscriptions/edit', ['subscription' => $subscription]);
    }

    public function update(Request $request, Subscription $subscription)
    {
        $this->authorize('update', $subscription);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'duration' => 'required|integer|min:1',
            // Add other validation rules as needed
        ]);

        $subscription->update($validated);

        return redirect()->route('admin.subscriptions.index')->with('success', 'Subscription updated successfully.');
    }

    public function destroy(Subscription $subscription)
    {
        $this->authorize('delete', $subscription);

        $subscription->delete();

        return redirect()->route('admin.subscriptions.index')->with('success', 'Subscription deleted successfully.');
    }
}