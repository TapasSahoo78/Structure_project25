<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Http\Requests\AdminUserStoreRequest;
use App\Http\Requests\AdminUserUpdateRequest;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;
use \Illuminate\Support\Str;

class UserController extends Controller
{
    public function index()
    {
        $user = User::all();
        return Inertia::render('admin/users/index', ['user' => $user]);
    }

    public function create()
    {
        return Inertia::render('admin/users/create');
    }

    public function store(AdminUserStoreRequest $request)
    {
        $validatedData = $request->validated();
        $validatedData['is_admin'] = true;
        $validatedData['name'] = $validatedData['fname'] . $validatedData['lname'];
        $password = Str::random(12);
        $validatedData['password'] = Hash::make($password);
        $user = User::create($validatedData);

        return redirect()->route('admin.users.index')->with('success', 'User created successfully.');
    }

    // public function show(User $user)
    // {
    //     return Inertia::render('admin/users/show', ['user' => $user]);
    // }

    // public function edit(User $user)
    // {
    //     return Inertia::render('admin/users/edit', ['user' => $user]);
    // }

    public function update(AdminUserUpdateRequest $request, User $user)
    {
        $validatedData = $request->validated();
        $user->update($validatedData);
        return redirect()->route('admin.users.index')->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('admin.users.index')->with('success', 'User deleted successfully.');
    }
}
