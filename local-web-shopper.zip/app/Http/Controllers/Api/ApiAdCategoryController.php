<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AdCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ApiAdCategoryController extends Controller
{

    /**
     *
     * @return JsonResponse
     */
    public function getCategories(): JsonResponse
    {
        $cats = AdCategory::all();
        // $cats = AdCategory::has('ads')->get();
        return response()->json(['data' => $cats], 200);
    }
}
