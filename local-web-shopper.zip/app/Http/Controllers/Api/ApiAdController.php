<?php

namespace App\Http\Controllers\Api;

use App\Enums\AdStatus;
use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\AdHistory;
use App\Models\Plan;
use App\Models\Subscription;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ApiAdController extends Controller
{
    public function getAdsOld189(Request $request): JsonResponse
    {
        // $request->validate([
        //     'latitude'    => 'required',
        //     'longitude'   => 'required',
        //     'category_id' => 'nullable|integer',
        //     'sort_by'     => 'nullable|in:distance,created_at,start_date,end_date',
        //     'sort_order'  => 'nullable|in:asc,desc',
        //     'page'        => 'nullable|integer|min:1',
        //     'per_page'    => 'nullable|integer|min:1|max:100',
        // ]);

        $lat = $request->latitude;
        $long = $request->longitude;
        $category_id = $request->category_id;
        $sort_by = $request->sort_by ?? 'distance';
        $sort_order = $request->sort_order ?? 'asc';
        $status = AdStatus::LIVE;
        $page = $request->page ?? 1;
        $per_page = $request->per_page ?? 20;

        $ads = Ad::selectRaw("ads.id, ads.business_id, ads.subscription_id, ads.category_id,
                              ads.title, ads.description, ads.start_date,
                          ads.end_date, ads.status, ads.created_at, ads.updated_at,
                          addresses.id as address_id, addresses.formatted_address,
                          addresses.latitude, addresses.longitude,
                         ( 3956 * acos( cos( radians(?) ) *
                               cos( radians( addresses.latitude ) )
                               * cos( radians( addresses.longitude ) - radians(?)
                               ) + sin( radians(?) ) *
                               sin( radians( addresses.latitude ) ) )
                             ) AS distance", [$lat, $long, $lat])
            ->join('addresses', 'ads.address_id', '=', 'addresses.id')
            ->where('ads.subscription_id', '>', 0)
            ->when($category_id, function ($q, $category_id) {
                $q->where('ads.category_id', $category_id);
            })
            ->where('ads.status', $status)
            ->with([
                // 'file:id,real',
                'file',
                'category:id,name',
                'plan'
            ]);

        if ($sort_by === 'distance') {
            $ads->orderBy('distance', $sort_order);
        } else {
            $ads->orderBy("ads.$sort_by", $sort_order)
                ->orderBy('distance', 'asc');
        }

        $ads = $ads->get();
        $filtered_ads = $ads->filter(function ($ad) {
            return $ad->distance <= $ad?->plan?->radius;
        })->map(function ($ad) {
            $ad->address = $ad->formatted_address;
            unset($ad->address_id, $ad->formatted_address);
            return $ad;
        })->values();
        $total = $filtered_ads->count();
        $ads_page = $filtered_ads->slice(($page - 1) * $per_page, $per_page);

        return response()->json([
            'data' => $ads_page,
            'current_page' => $page,
            'per_page' => $per_page,
            'total' => $total,
        ], 200);
    }

    public function getAds(Request $request): JsonResponse
    {
        $request->validate([
            'latitude'    => 'required',
            'longitude'   => 'required',
            'category_id' => 'nullable|integer',
            'sort_by'     => 'nullable|in:distance,created_at,start_date,end_date',
            'sort_order'  => 'nullable|in:asc,desc',
            'page'        => 'nullable|integer|min:1',
            'per_page'    => 'nullable|integer|min:1|max:100',
        ]);

        $lat        = $request->latitude;
        $long       = $request->longitude;
        // $lat        = 33.5802563;
        // $long       = -85.0822049;
        $categoryId = $request->category_id;
        $sort_by    = $request->sort_by ?? 'distance';
        $sort_order = $request->sort_order ?? 'asc';
        $status     = AdStatus::LIVE;
        $page       = $request->page ?? 1;
        $per_page   = $request->per_page ?? 20;

        $today = now()->startOfDay();

        // Base query
        $ads = Ad::selectRaw("
            ads.id, ads.business_id, ads.subscription_id, ads.category_id,
            ads.title, ads.description, ads.start_date, ads.end_date,
            ads.status, ads.created_at, ads.updated_at,
            addresses.id as address_id, addresses.formatted_address,
            addresses.latitude, addresses.longitude,
            (3956 * acos(
                cos(radians(?)) *
                cos(radians(addresses.latitude)) *
                cos(radians(addresses.longitude) - radians(?)) +
                sin(radians(?)) *
                sin(radians(addresses.latitude))
            )) AS distance
        ", [$lat, $long, $lat])
            ->join('addresses', 'ads.address_id', '=', 'addresses.id')
            ->where('ads.subscription_id', '>', 0)
            ->when($categoryId, function ($q, $categoryId) {
                $q->where('ads.category_id', $categoryId);
            })
            ->where('ads.status', $status)
            ->with(['file', 'category:id,name', 'plan']);

        if ($sort_by === 'distance') {
            $ads->orderBy('distance', $sort_order);
        } else {
            $ads->orderBy("ads.$sort_by", $sort_order)
                ->orderBy('distance', 'asc');
        }

        $ads = $ads->get();

        // Filter within plan radius
        $ads = $ads->filter(function ($ad) {
            return $ad->distance <= $ad?->plan?->radius;
        })->map(function ($ad) {
            $ad->address = $ad->formatted_address;
            unset($ad->address_id, $ad->formatted_address);
            return $ad;
        })->values();

        // Group ads by subscription
        $subscriptions = $ads->groupBy('subscription_id');

        $finalAds = collect();

        foreach ($subscriptions as $subscriptionId => $subAds) {
            // Check expiry
            $subscription = Subscription::find($subscriptionId);
            // Skip expired subscriptions
            if ($subscription && $subscription->ends_at && $today->gt(Carbon::parse($subscription->ends_at))) {
                continue;
            }

            // Sort ads by start_date (consistent order)
            $subAds = $subAds->sortBy('start_date')->values();

            // Get today’s ad from history if exists
            $historyToday = AdHistory::where('subscription_id', $subscriptionId)
                ->whereDate('date', $today)
                ->first();

            if ($historyToday) {
                // Already picked today → fetch ad
                $ad = $subAds->firstWhere('id', $historyToday->ad_id);
                if ($ad) {
                    $finalAds->push($ad);
                    continue;
                }
            }

            // No ad picked today → decide rotation
            $yesterdayHistory = AdHistory::where('subscription_id', $subscriptionId)
                ->whereDate('date', $today->copy()->subDay())
                ->first();

            // Filter only valid ads (not expired)
            $validAds = $subAds->filter(function ($ad) use ($today) {
                // If no end_date → auto-renew forever
                if (empty($ad->end_date)) {
                    return true;
                }
                // If end_date >= today → still active
                return Carbon::parse($ad->end_date)->endOfDay()->gte($today);
            })->values(); // reset indexes

            if ($validAds->isEmpty()) {
                // No valid ads, skip this subscription
                continue;
            }

            if ($validAds->count() === 1) {
                // Only one valid ad → repeat daily
                $adToShow = $validAds->first();
            } else {
                if (!$yesterdayHistory) {
                    // First ad if no history
                    $adToShow = $validAds->first();
                } else {
                    // Rotate to next ad after yesterday
                    $lastIndex = $validAds->search(fn($a) => $a->id === $yesterdayHistory->ad_id);

                    if ($lastIndex === false) {
                        // Yesterday’s ad expired → reset to first valid
                        $adToShow = $validAds->first();
                    } else {
                        $nextIndex = ($lastIndex + 1) % $validAds->count();
                        $adToShow  = $validAds[$nextIndex];
                    }
                }
            }

            // Save today’s pick in DB (avoid duplicate)
            AdHistory::firstOrCreate([
                'subscription_id' => $subscriptionId,
                'ad_id'           => $adToShow->id,
                'date'            => $today->toDateString(),
            ]);

            $finalAds->push($adToShow);
        }

        // Pagination
        $total    = $finalAds->count();
        $ads_page = $finalAds->slice(($page - 1) * $per_page, $per_page)->values();

        return response()->json([
            'data'         => $ads_page,
            'current_page' => $page,
            'per_page'     => $per_page,
            'total'        => $total,
        ], 200);
    }

    public function show(Ad $ad): JsonResponse
    {
        $ad->increment('view_count');

        $user = auth()->user();
        $isFavorite = $user ? $user->favorites()->where('ad_id', $ad->id)->exists() : false;

        $adData = $ad->load('file', 'category:id,name', 'address:id,formatted_address,latitude,longitude')->toArray();
        $adData['isFavorite'] = $isFavorite;

        return response()->json(['data' => $adData], 200);
    }

    public function getDevAds(Request $request): JsonResponse
    {
        $request->validate([
            'latitude'    => 'required',
            'longitude'   => 'required',
            'category_id' => 'nullable|integer',
            'sort_by'     => 'nullable|in:distance,created_at,start_date,end_date',
            'sort_order'  => 'nullable|in:asc,desc',
            'page'        => 'nullable|integer|min:1',
            'per_page'    => 'nullable|integer|min:1|max:100',
        ]);

        $lat = $request->latitude;
        $long = $request->longitude;
        $category_id = $request->category_id;
        $sort_by = $request->sort_by ?? 'distance';
        $sort_order = $request->sort_order ?? 'asc';
        $status = AdStatus::LIVE;
        $page = $request->page ?? 1;
        $per_page = $request->per_page ?? 20;

        $ads = Ad::selectRaw("ads.id, ads.business_id, ads.subscription_id, ads.category_id,
                          ads.title, ads.description, ads.start_date,
                          ads.end_date, ads.status, ads.created_at, ads.updated_at,
                          addresses.id as address_id, addresses.formatted_address,
                          addresses.latitude, addresses.longitude,
                         ( 3956 * acos( cos( radians(?) ) *
                           cos( radians( addresses.latitude ) )
                           * cos( radians( addresses.longitude ) - radians(?)
                           ) + sin( radians(?) ) *
                           sin( radians( addresses.latitude ) ) )
                         ) AS distance", [$lat, $long, $lat])
            ->join('addresses', 'ads.address_id', '=', 'addresses.id')
            ->where('ads.subscription_id', '>', 0)
            ->when($category_id, function ($q, $category_id) {
                $q->where('ads.category_id', $category_id);
            })
            ->with([
                'file',
                'category:id,name',
                'plan'
            ]);

        if ($sort_by === 'distance') {
            $ads->orderBy('distance', $sort_order);
        } else {
            $ads->orderBy("ads.$sort_by", $sort_order)
                ->orderBy('distance', 'asc');
        }

        $ads = $ads->get()->map(function ($ad) {
            $ad->address = $ad->formatted_address;
            unset($ad->address_id, $ad->formatted_address);
            return $ad;
        });

        $total = $ads->count();
        $ads_page = $ads->slice(($page - 1) * $per_page, $per_page);

        return response()->json([
            'data' => $ads_page,
            'current_page' => $page,
            'per_page' => $per_page,
            'total' => $total,
        ], 200);
    }
}
