<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AdFavorite;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class ApiAdFavoriteController extends Controller
{
    /**
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        $onlyIds = $request->boolean('only_ids', false);

        $favorites = auth()->user()->favorites;

        if ($onlyIds) {
            $favorites = $favorites->pluck('id');
        }

        return response()->json(['data' => $favorites], 200);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'ad_id' => 'required|exists:ads,id',
        ]);

        $userId = auth()->user()->id;
        $adId = $request->ad_id;

        $favorite = AdFavorite::where('user_id', $userId)->where('ad_id', $adId)->first();

        if ($favorite) {
            $favorite->delete();
            return response()->json(['message' => 'Ad favorite removed successfully'], 200);
        } else {
            $favorite = AdFavorite::create(['user_id' => $userId, 'ad_id' => $adId]);
            return response()->json(['data' => $favorite, 'message' => 'Ad favorite created successfully'], 201);
        }
    }

    /**
     * @param int $id
     * @return JsonResponse
     */
    public function destroy(int $id): JsonResponse
    {
        $favorite = AdFavorite::findOrFail($id);

        if(auth()->user()->id !== $favorite->user_id)
        {
            return response()->json(['message' => 'Cannot delete Ad favorite'], 401);
        }

        $favorite->delete();
        return response()->json(['message' => 'Ad favorite deleted successfully'], 200);
    }

}
