<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Str;

class ApiAuthController extends Controller
{
    /**
     * Store a User
     * @param Request $request
     * @return JsonResponse
     */
    public function register(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email'    => 'required|email|max:250|unique:users',
            'password' => 'required|min:8',
            'device_name'     => 'required'
        ]);

        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password)
        ]);

        $user->logAction('user_registered');

        $token = $user->createToken($request->device_name)->plainTextToken;
        return response()->json(['token' => $token], 200);
    }

    /**
     * @throws ValidationException
     */
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
            'device_name'     => 'required'
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        $token = $user->createToken($request->device_name)->plainTextToken;
        $user->logAction('user_login', ['timestamp' => now()]);

        return response()->json(['token' => $token], 200);
    }

    /**
     * @param Request $request
     * @return Response
     */
    public function logout(Request $request): Response
    {
        if ($request->user()) {
            $request->user()->currentAccessToken()->delete();
            $request->user()->logAction('user_logout', ['timestamp' => now()]);
        }
        return response()->noContent();
    }

    /**
     * Update password
     */
    public function updatePassword(Request $request): JsonResponse
    {
        $request->validate([
            'currentPassword' => 'required_with:newPassword',
            'newPassword'     => 'required_with:currentPassword|different:currentPassword|min:8',
        ]);

        $user = $request->user();

        if ($request->has('currentPassword') && $request->has('newPassword')) {
            if (!Hash::check($request->currentPassword, $user->password)) {
                return response()->json(['error' => 'Current password is incorrect'], 422);
            }

            $user->update([
                'password' => Hash::make($request->newPassword)
            ]);

            $user->currentAccessToken()->delete();

            $user->logAction('user_password_update', ['timestamp' => now()]);

            return response()->json(['message' => 'Password updated successfully. You must reauthenticate to continue.'], 200);
        }

        return response()->json();
    }

    /**
     * Handle user request for password reset
     * @param Request $request
     * @return JsonResponse
     */
    public function sendPasswordReset(Request $request): JsonResponse
    {
        $request->validate([
            'email'    => 'required|email',
        ]);

        $email = $request->only('email');
        $user = User::where('email', $email)->first();

        $status = Password::sendResetLink($email);

        if ($status === Password::RESET_LINK_SENT) {
            if ($user) {
                $user->logAction('user_password_reset_requested', ['timestamp' => now()]);
            }

            return response()->json([
                'message' => __($status)
            ], 200);
        } else {
            return response()->json([
                'message' => __($status),
                'errors' => ['email' => __($status)]
            ], 400);
        }
    }

    /**
     * Handle resetting password
     * @param Request $request
     * @return JsonResponse
     */
    public function resetPassword(Request $request): JsonResponse
    {
        $request->validate([
            'email'    => 'required|email',
            'token'    => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function (User $user, string $password) {
                $user->forceFill([
                    'password' => Hash::make($password)
                ])->setRememberToken(Str::random(60));

                $user->save();

                $user->logAction('user_password_reset', ['timestamp' => now()]);

                event(new PasswordReset($user));
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            return response()->json([
                'message' => __($status),
                'data' => ['reset' => true]
            ], 200);
        } else {
            return response()->json([
                'message' => __($status),
                'errors' => ['email' => [__($status)]]
            ], 422);
        }
    }

    public function buttonVisibility(Request $request)
    {
        return response()->json(['data' => []], 200);
    }
}
