<?php

namespace App\Http\Controllers\Api;

use App\Enums\AdStatus;
use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\AdHistory;
use App\Models\Coupon;
use App\Models\Plan;
use App\Models\PromoCode;
use App\Models\Subscription;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class ApiCouponController extends Controller
{
    // public function validate(Request $request)
    // {
    //     $request->validate([
    //         'code' => 'required|string|min:2',
    //         'plan_id' => 'sometimes|exists:plans,id', // Optional: Validate against specific plan
    //     ]);

    //     $coupon = PromoCode::where('code', $request->code)
    //         ->where('is_active', true)
    //         ->first();
    //     $plan = Plan::where('id', $request->plan_id)
    //         ->first();

    //     if (!$plan) {
    //         throw ValidationException::withMessages([
    //             'code' => 'Please select a plan before proceeding.',
    //         ]);
    //     }

    //     if (!$coupon) {
    //         throw ValidationException::withMessages([
    //             'code' => 'Invalid or inactive promo code.',
    //         ]);
    //     }

    //     // Optional: Check if coupon applies to plan (e.g., via metadata or relations)
    //     // if ($request->plan_id && !$coupon->appliesToPlan($request->plan_id)) {
    //     //     throw ValidationException::withMessages(['code' => 'Coupon not valid for this plan.']);
    //     // }

    //     return response()->json([
    //         'valid' => true,
    //         'code' => $coupon->code,
    //         'discount_type' => $coupon->discount_type,
    //         'discount_value' => $coupon->discount_value,
    //         'duration' => $coupon->duration,
    //         'plan_price' => $plan->price,
    //         // Calculate preview discount if needed
    //         'preview_discount' => $this->calculateDiscount($coupon, $plan->price ?? 0),
    //     ]);
    // }

    public function validate(Request $request)
    {
        // Validate input
        $validated = $request->validate([
            'code' => 'required|string|min:2',
            'plan_id' => 'nullable|exists:plans,id', // Changed to nullable to allow optional plan_id
        ]);

        // Retrieve promo code
        $promoCode = PromoCode::where('code', $validated['code'])
            ->where('is_active', true)
            ->first();

        if (!$promoCode) {
            throw ValidationException::withMessages([
                'code' => 'The promo code is invalid or inactive.',
            ]);
        }
        $coupon = Coupon::where('stripe_coupon_id', $promoCode->coupon_id)->first();
        // Initialize plan and price
        $plan = null;
        $planPrice = 0;

        if ($validated['plan_id']) {
            $plan = Plan::find($validated['plan_id']);
            if (!$plan) {
                throw ValidationException::withMessages([
                    'plan_id' => 'The selected plan does not exist.',
                ]);
            }
            $planPrice = $plan->price;
        }

        // Optional: Validate promo code against Stripe
        if (config('services.stripe.secret')) {
            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            try {
                $stripePromoCode = \Stripe\PromotionCode::retrieve($promoCode->stripe_promo_code_id);
                if (!$stripePromoCode->active || $stripePromoCode->code !== $promoCode->code) {
                    $promoCode->update([
                        'expires_at' => Carbon::createFromTimestamp($stripePromoCode->expires_at)->setTimezone('UTC'),
                        'is_active' => false
                    ]);
                    throw ValidationException::withMessages([
                        'code' => 'The promo code is invalid or inactive in Stripe.',
                    ]);
                }
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during promo code validation', [
                    'promo_code_id' => $promoCode->id,
                    'code' => $promoCode->code,
                    'error' => $e->getMessage(),
                ]);
                throw ValidationException::withMessages([
                    'code' => 'Unable to validate promo code. Please try again later.',
                ]);
            }
        }

        // Optional: Check if coupon applies to the plan (uncomment and implement if needed)
        // if ($plan && !$coupon->appliesToPlan($plan->id)) {
        //     throw ValidationException::withMessages([
        //         'code' => 'This promo code is not valid for the selected plan.',
        //     ]);
        // }

        // Calculate discount (ensure calculateDiscount method is implemented)
        $previewDiscount = $this->calculateDiscount($coupon, $planPrice);

        return response()->json([
            'valid' => true,
            'code' => $promoCode->code,
            'discount_type' => $coupon->discount_type,
            'discount_value' => $coupon->discount_value,
            'duration' => $coupon->duration,
            'plan_price' => $planPrice,
            'preview_discount' => $previewDiscount,
        ], 200);
    }

    private function calculateDiscount($coupon, $planPrice)
    {
        if ($coupon->discount_type === 'percent') {
            return $planPrice * ($coupon->discount_value / 100);
        }
        return $coupon->discount_value;
    }
}
