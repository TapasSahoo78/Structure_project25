<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Laravel\Cashier\Exceptions\IncompletePayment;
use Illuminate\Support\Facades\DB;
use App\Enums\AdStatus;

class ApiProfileController extends Controller
{
    /**
     * View Profile
     * @param Request $request
     * @return mixed
     */
    public function show(Request $request): JsonResponse
    {
        $user = $request->user()->only(['name', 'email']);

        return response()->json(['data' => $user], 200);
    }

    /**
     * Update Profile
     * @param Request $request
     * @return mixed
     */
    public function update(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                'max:250',
                Rule::unique('users')->ignore(auth()->user()->id),
            ],
        ]);

        $user = $request->user();

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
        ]);

        return response()->json(['message' => 'Profile updated successfully'], 200);
    }

    /**
     * Delete user account
     * @param Request $request
     * @return JsonResponse
     */
    public function destroy(Request $request): JsonResponse
    {
        $user = $request->user();
        try {
            DB::beginTransaction();

            // Cancel all user subscriptions in Stripe
            $user?->business?->subscriptions?->each(function ($subscription) {
                if ($subscription->stripe_status !== 'canceled') {
                    try {
                        $subscription->cancelNow();
                    } catch (IncompletePayment $exception) {
                        // Handle incomplete payment exception if needed
                    }
                }
            });

            // Update LIVE ads to Canceled status
            $user?->business?->ads()
                ->where('status', AdStatus::LIVE)
                ->orWhere('status', AdStatus::SCHEDULED)
                ->update(['status' => AdStatus::CANCELED]);


            // Delete all user's tokens
            $user->tokens()->delete();

            // Delete the user
            $user->delete();

            // Log out the user
            Auth::guard('web')->logout();

            DB::commit();

            return response()->json(['message' => 'User account and associated data deleted successfully'], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'An error occurred while deleting the account', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Display logged history/actions of a user
     */
    public function history()
    {
        $logs = auth()->user()->logs;
        return response()->json(['data' => $logs], 200);
    }
}
