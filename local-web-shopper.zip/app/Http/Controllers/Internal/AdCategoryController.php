<?php

namespace App\Http\Controllers\Internal;

use App\Models\AdCategory;
use App\Http\Controllers\Controller;
use App\Http\Resources\AdCategoryResource;
use App\Http\Requests\AdCategoryIndexRequest;
use App\Http\Requests\AdCategoryShowRequest;
use App\Http\Requests\AdCategoryStoreRequest;
use App\Http\Requests\AdCategoryUpdateRequest;
use App\Http\Requests\AdCategoryDestroyRequest;

class AdCategoryController extends Controller
{
    public function index(AdCategoryIndexRequest $request)
    {
        $query = AdCategory::query();

        if ($request->filled('name')) {
            $query->where('name', $request->name);
        }

        return AdCategoryResource::collection($query->paginate(20));
    }

    public function store(AdCategoryStoreRequest $request)
    {
        $adCategory = AdCategory::create($request->validated());
        return new AdCategoryResource($adCategory);
    }

    public function show(AdCategoryShowRequest $request, AdCategory $adCategory)
    {
        return new AdCategoryResource($adCategory);
    }

    public function update(AdCategoryUpdateRequest $request, AdCategory $adCategory)
    {
        $adCategory->update($request->validated());
        return new AdCategoryResource($adCategory);
    }

    public function destroy(AdCategoryDestroyRequest $request, AdCategory $adCategory)
    {
        $adCategory->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
}