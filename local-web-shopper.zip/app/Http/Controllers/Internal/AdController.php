<?php

namespace App\Http\Controllers\Internal;

use App\Models\Ad;
use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Http\Requests\AdIndexRequest;
use App\Http\Requests\AdShowRequest;
use App\Http\Requests\AdStoreRequest;
use App\Http\Requests\AdUpdateRequest;
use App\Http\Requests\AdDestroyRequest;
use App\Http\Requests\AdNearbyRequest;
use App\Enums\AdStatus;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use App\Services\AdService;

class AdController extends Controller
{
    protected $adService;

    public function __construct(AdService $adService)
    {
        $this->adService = $adService;
    }

    public function index(AdIndexRequest $request): AnonymousResourceCollection
    {
        $query = Ad::with(['plan', 'file', 'address', 'subscription']);
        $user = Auth::user();
        if ($user->isAdmin()) {
            if ($request->filled('business_id')) {
                $query->where('business_id', $request->business_id);
            }
        } else {
            $query->where('business_id', $user->business_id);
        }
        $request->merge(['title' => $request->name]);
        $this->applyFilters($query, $request);
        return AdResource::collection($query->paginate($request->per_page ?? 20));
    }

    private function applyFilters($query, $request)
    {
        $filters = [
            'title' => 'where',
            'status' => 'where',
            'category_id' => 'where',
            'business_id' => 'where',
            'creator_id' => 'where',
            'subscription_id' => 'where',
            'view_count' => 'where',
            'suspended_by' => 'where',
        ];

        foreach ($filters as $field => $method) {
            if ($request->filled($field)) {
                $query->$method($field, $request->$field);
            }
        }

        $dateFields = ['start_date', 'end_date', 'suspended_on'];
        foreach ($dateFields as $dateField) {
            if ($request->filled($dateField . '_from')) {
                $query->where($dateField, '>=', $request->{$dateField . '_from'});
            }
            if ($request->filled($dateField . '_to')) {
                $query->where($dateField, '<=', $request->{$dateField . '_to'});
            }
        }

        if ($request->filled('suspended_reason')) {
            $query->where('suspended_reason', 'like', '%' . $request->suspended_reason . '%');
        }
    }

    public function store(AdStoreRequest $request): AdResource
    {
        $ad = Ad::create($request->validated());
        return new AdResource($ad);
    }

    public function show(/*AdShowRequest $request,*/Ad $ad): AdResource
    {
        return new AdResource($ad->load(['plan', 'file', 'address']));
    }

    public function update(AdUpdateRequest $request, Ad $ad): AdResource
    {
        $ad->update($request->validated());
        return new AdResource($ad->load(['plan', 'file', 'address']));
    }

    public function destroy(AdDestroyRequest $request, Ad $ad): JsonResponse
    {
        $deleted = $this->adService->deleteAd($ad);

        if ($deleted) {
            return response()->json(['message' => 'Deleted successfully'], 200);
        } else {
            return response()->json(['message' => 'Failed to delete'], 500);
        }
    }

    public function nearby(AdNearbyRequest $request): AnonymousResourceCollection
    {
        $lat = $request->latitude;
        $long = $request->longitude;
        $category_id = $request->category_id;
        $sort_by = $request->sort_by ?? 'distance';
        $sort_order = $request->sort_order ?? 'asc';
        $status = AdStatus::LIVE;
        $per_page = $request->per_page ?? 20;

        $ads = $this->getBaseNearbyQuery($lat, $long, $category_id, $status)
            ->with([
                'file',
                'category:id,name',
                'plan',
                'address'
            ]);

        $this->applySorting($ads, $sort_by, $sort_order);

        // Fetch more results than needed to allow for filtering
        $fetched_ads = $ads->paginate($per_page * 3);

        // Filter ads based on plan radius
        $filtered_ads = $fetched_ads->filter(function ($ad) {
            return $ad->distance <= $ad->plan->radius;
        })->values();

        // Manual pagination
        $page = $request->input('page', 1);
        $sliced_ads = $filtered_ads->slice(($page - 1) * $per_page, $per_page);

        $paginator = new \Illuminate\Pagination\LengthAwarePaginator(
            $sliced_ads,
            $filtered_ads->count(),
            $per_page,
            $page,
            ['path' => $request->url(), 'query' => $request->query()]
        );

        return AdResource::collection($paginator);
    }

    public function nearbyDev(AdNearbyRequest $request): AnonymousResourceCollection
    {
        $lat = $request->latitude;
        $long = $request->longitude;
        $category_id = $request->category_id;
        $sort_by = $request->sort_by ?? 'distance';
        $sort_order = $request->sort_order ?? 'asc';

        $ads = $this->getBaseNearbyQuery($lat, $long, $category_id)
            ->with([
                'business',
                'file:id,real,path', // Changed from 'file:id,real' to just 'file'
                'category:id,name',
                'plan',
                'address'
            ]);

        $this->applySorting($ads, $sort_by, $sort_order);

        return AdResource::collection($ads->paginate($request->per_page ?? 20));
    }

    private function getBaseNearbyQuery($lat, $long, $category_id, $status = null)
    {
        return Ad::with('file')
            ->join('addresses', 'ads.address_id', '=', 'addresses.id')
            ->leftJoin('ad_images', function ($join) {
                $join->on('ads.id', '=', 'ad_images.ad_id')
                    ->where('ad_images.is_primary', true);
            })
            ->leftJoin('files', 'ad_images.file_id', '=', 'files.id')
            ->select('ads.*', 'addresses.latitude', 'addresses.longitude', 'files.id as file_id', 'files.path as file_path')
            ->selectRaw("( 3956 * acos( cos( radians(?) ) *
                       cos( radians( addresses.latitude ) )
                       * cos( radians( addresses.longitude ) - radians(?)
                           ) + sin( radians(?) ) *
                       sin( radians( addresses.latitude ) ) )
                         ) AS distance", [$lat, $long, $lat])
            ->where('ads.subscription_id', '>', 0)
            ->when($category_id, function ($q, $category_id) {
                $q->where('ads.category_id', $category_id);
            })
            ->when($status, function ($q, $status) {
                $q->where('ads.status', $status);
            });
    }

    private function applySorting($query, $sort_by, $sort_order)
    {
        if ($sort_by === 'distance') {
            $query->orderBy('distance', $sort_order);
        } else {
            $query->orderBy("ads.$sort_by", $sort_order)
                ->orderBy('distance', 'asc');
        }
    }
}
