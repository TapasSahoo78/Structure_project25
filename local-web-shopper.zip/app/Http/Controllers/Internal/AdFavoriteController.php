<?php

namespace App\Http\Controllers\Internal;

use App\Models\AdFavorite;
use App\Http\Controllers\Controller;
use App\Http\Resources\AdFavoriteResource;
use App\Http\Requests\AdFavoriteIndexRequest;
use App\Http\Requests\AdFavoriteShowRequest;
use App\Http\Requests\AdFavoriteStoreRequest;
use App\Http\Requests\AdFavoriteUpdateRequest;
use App\Http\Requests\AdFavoriteDestroyRequest;
use Illuminate\Http\Request;

class AdFavoriteController extends Controller
{
    public function index(AdFavoriteIndexRequest $request)
    {
        $query = AdFavorite::query();

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('ad_id')) {
            $query->where('ad_id', $request->ad_id);
        }

        return AdFavoriteResource::collection($query->paginate(20));
    }

    public function store(AdFavoriteStoreRequest $request)
    {
        $adFavorite = AdFavorite::create($request->validated());
        return new AdFavoriteResource($adFavorite);
    }

    public function show(AdFavoriteShowRequest $request, AdFavorite $adFavorite)
    {
        return new AdFavoriteResource($adFavorite);
    }

    public function update(AdFavoriteUpdateRequest $request, AdFavorite $adFavorite)
    {
        $adFavorite->update($request->validated());
        return new AdFavoriteResource($adFavorite);
    }

    public function destroy(AdFavoriteDestroyRequest $request, AdFavorite $adFavorite)
    {
        $adFavorite->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
}