<?php

namespace App\Http\Controllers\Internal;

use App\Http\Controllers\Controller;
use App\Models\Business;
use App\Http\Requests\BusinessIndexRequest;
use App\Http\Requests\BusinessStoreRequest;
use App\Http\Requests\BusinessShowRequest;
use App\Http\Requests\BusinessUpdateRequest;
use App\Http\Requests\BusinessDestroyRequest;
use App\Http\Requests\BusinessPaymentMethodShowRequest;
use App\Http\Requests\BusinessPaymentMethodUpdateRequest;
use App\Services\BusinessService;
use App\Http\Resources\BusinessResource;
use App\Http\Resources\BusinessPaymentMethodResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Stripe;
use Stripe\Invoice as StripeInvoice;

class BusinessController extends Controller
{
    protected BusinessService $businessService;

    public function __construct(BusinessService $businessService)
    {
        $this->businessService = $businessService;
    }

    public function index(\Illuminate\Http\Request $request)
    {
        $query = Business::with(['address', 'primaryUser']);

        if ($request->input('name')) {
            $query->where('name', $request->input('name'));
        }

        if ($request->input('phone')) {
            $query->where('phone', $request->input('phone'));
        }

        return BusinessResource::collection($query->paginate(20));
    }

    public function store(BusinessStoreRequest $request)
    {
        $business = Business::create($request->validated());
        return new BusinessResource($business);
    }

    public function show(BusinessShowRequest $request, Business $business)
    {
        $business->load('address');
        return new BusinessResource($business);
    }

    public function update(BusinessUpdateRequest $request, Business $business)
    {
        $updatedBusiness = $this->businessService->updateBusiness($business, $request->validated());
        return new BusinessResource($updatedBusiness);
    }

    public function destroy(BusinessDestroyRequest $request, Business $business)
    {
        $business->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function showPaymentMethod(BusinessPaymentMethodShowRequest $request, Business $business)
    {
        return new BusinessPaymentMethodResource($business);
    }

    public function updatePaymentMethod(BusinessPaymentMethodUpdateRequest $request, Business $business)
    {
        try {
            $paymentMethodId = $request->stripe_payment_method_id;
            $business1 = $this->businessService->updatePaymentMethod($business, $paymentMethodId);
            return new BusinessPaymentMethodResource($business);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    // public function detachPaymentMethod(Request $request)
    // {
    //     $request->validate([
    //         'payment_method_id' => 'required|string',
    //     ]);

    //     try {
    //         Stripe::setApiKey(config('services.stripe.secret'));

    //         // 1. Detach from Stripe
    //         $paymentMethod = StripeInvoice::retrieve($request->payment_method_id);
    //         $paymentMethod->detach();

    //         // 2. Remove from your DB
    //         // Business::where('stripe_payment_method_id', $request->payment_method_id)->delete();

    //         Business::where('stripe_payment_method_id', $request->payment_method_id)->update([
    //             'stripe_payment_method_id' => NULL,
    //             'pm_type' => NULL,
    //             'pm_last_four' => NULL,
    //             'pm_brand' => NULL,
    //             'pm_exp_month' => NULL,
    //             'pm_exp_year' => NULL,
    //             'pm_card_holder_name' => NULL
    //         ]);

    //         return response()->json([
    //             'success' => true,
    //             'payment_method' => $request->payment_method_id,
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'success' => false,
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    public function detachPaymentMethod(Request $request)
    {
        $request->validate([
            'payment_method_id' => 'required|string',
        ]);

        try {
            Stripe::setApiKey(config('services.stripe.secret'));

            // Retrieve and detach the payment method from Stripe
            $paymentMethod = \Stripe\PaymentMethod::retrieve($request->payment_method_id);

            $paymentMethod->detach();

            // Update the business record in your database
            Business::where('stripe_payment_method_id', $request->payment_method_id)->update([
                'stripe_payment_method_id' => NULL,
                'pm_type' => NULL,
                'pm_last_four' => NULL,
                'pm_brand' => NULL,
                'pm_exp_month' => NULL,
                'pm_exp_year' => NULL,
                'pm_card_holder_name' => NULL
            ]);

            return response()->json([
                'success' => true,
                'payment_method' => $request->payment_method_id,
            ]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            return response()->json([
                'success' => false,
                'error' => 'Stripe API error: ' . $e->getMessage(),
            ], 500);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'General error: ' . $e->getMessage(),
            ], 500);
        }
    }
}
