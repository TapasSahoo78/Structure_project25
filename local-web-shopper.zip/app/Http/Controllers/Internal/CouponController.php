<?php

namespace App\Http\Controllers\Internal;

use App\Models\Plan;
use App\Http\Controllers\Controller;
use App\Http\Requests\CouponIndexRequest;
use App\Http\Requests\CouponShowRequest;
use App\Http\Requests\CouponStoreRequest;
use App\Http\Requests\CouponUpdateRequest;
use App\Http\Requests\CouponDestroyRequest;
use App\Http\Resources\CouponResource;
use App\Models\Coupon;
use App\Services\CouponService;
use Illuminate\Http\Request;
use Stripe\Exception\ApiErrorException;

class CouponController extends Controller
{
    protected $couponService;

    public function __construct(CouponService $couponService)
    {
        $this->couponService = $couponService;
    }

    public function index(CouponIndexRequest $request)
    {
        $query = Coupon::query();

        $query->when($request->code, function ($q, $code) {
            $q->where('code', 'LIKE', "%{$code}%");
        });

        return CouponResource::collection($query->paginate(20));
    }

    public function store(CouponStoreRequest $request)
    {
        try {
            $plan = $this->couponService->createCoupon($request->validated());
            return new CouponResource($plan);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to create Plan: ' . $e->getMessage()], 500);
        }
    }

    public function show(CouponShowRequest $request, Coupon $coupon)
    {
        return new CouponResource($coupon);
    }

    public function update(CouponUpdateRequest $request, Coupon $coupon)
    {
        try {
            $updatedCoupon = $this->couponService->updateCoupon($coupon, $request->validated());
            return new CouponResource($updatedCoupon);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to update Plan: ' . $e->getMessage()], 500);
        }
    }

    public function destroy(CouponDestroyRequest $request, Coupon $coupon)
    {
        try {
            $this->couponService->archiveCoupon($coupon);
            return response()->json(['message' => 'Plan archived in Stripe and deleted from database successfully']);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to archive Plan: ' . $e->getMessage()], 500);
        }
    }
}
