<?php

namespace App\Http\Controllers\Internal;

use App\Models\File;
use App\Http\Controllers\Controller;
use App\Http\Resources\FileResource;
use App\Http\Requests\FileIndexRequest;
use App\Http\Requests\FileShowRequest;
use App\Http\Requests\FileStoreRequest;
use App\Http\Requests\FileUpdateRequest;
use App\Http\Requests\FileDestroyRequest;
use App\Services\FileService;
use Illuminate\Http\Request;

class FileController extends Controller
{
    protected $fileService;

    public function __construct(FileService $fileService)
    {
        $this->fileService = $fileService;
    }

    public function index(FileIndexRequest $request)
    {
        $query = File::query();

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('real')) {
            $query->where('real', $request->real);
        }

        if ($request->filled('filename')) {
            $query->where('filename', $request->filename);
        }

        if ($request->filled('mime_type')) {
            $query->where('mime_type', $request->mime_type);
        }

        if ($request->filled('path')) {
            $query->where('path', $request->path);
        }

        if ($request->filled('hash')) {
            $query->where('hash', $request->hash);
        }

        if ($request->filled('size')) {
            $query->where('size', $request->size);
        }

        return FileResource::collection($query->paginate(20));
    }

    public function store(FileStoreRequest $request)
    {
        $file = $this->fileService->uploadFile(
            $request->file('file'),
            auth()->user()->business_id,
            auth()->id()
        );
        return new FileResource($file);
    }

    public function show(FileShowRequest $request, File $file)
    {
        return new FileResource($file);
    }

    public function update(FileUpdateRequest $request, File $file)
    {
        $file->update($request->validated());
        return new FileResource($file);
    }

    public function destroy(FileDestroyRequest $request, File $file)
    {
        $deleted = $this->fileService->deleteFile($file);
        return response()->json(['message' => $deleted ? 'Deleted successfully' : 'File not found']);
    }
}
