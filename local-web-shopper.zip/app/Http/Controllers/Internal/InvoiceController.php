<?php

namespace App\Http\Controllers\Internal;

use App\Models\Invoice;
use App\Http\Controllers\Controller;
use App\Http\Resources\InvoiceResource;
use App\Http\Requests\InvoiceIndexRequest;
use App\Http\Requests\InvoiceShowRequest;
use App\Http\Requests\InvoiceUpdateRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Stripe\Stripe;
use Stripe\Invoice as StripeInvoice;
use Illuminate\Http\JsonResponse;

class InvoiceController extends Controller
{
    public function index(InvoiceIndexRequest $request): AnonymousResourceCollection
    {
        $query = Invoice::query();
        $user = Auth::user();

        if ($user->isAdmin()) {
            if ($request->filled('business_id')) {
                $query->where('business_id', $request->business_id);
            }
        } else {
            $query->where('business_id', $user->business_id);
        }

        $this->applyFilters($query, $request);

        return InvoiceResource::collection($query->paginate($request->per_page ?? 20));
    }

    private function applyFilters($query, $request)
    {
        $filters = [
            'user_id' => 'where',
            'status' => 'where',
            'due_on' => 'where',
            'sent_on' => 'where',
            'paid_on' => 'where',
            'stripe_invoice_id' => 'where',
            'suspension_sent' => 'where',
            'termination_sent' => 'where',
            'ad_id' => 'where',
            'total' => 'where',
            'subscription_id' => 'where',
        ];

        foreach ($filters as $field => $method) {
            if ($request->filled($field)) {
                $query->$method($field, $request->$field);
            }
        }
    }

    public function show(InvoiceShowRequest $request, Invoice $invoice): JsonResponse
    {
        Stripe::setApiKey(config('services.stripe.secret'));

        try {
            $stripeInvoice = StripeInvoice::retrieve($invoice->stripe_id);

            return response()->json([
                'id' => $stripeInvoice->id,
                'number' => $stripeInvoice->number,
                'status' => $stripeInvoice->status,
                'due_date' => $invoice->due_date,
                'amount_due' => $stripeInvoice->amount_due,
                'amount_paid' => $stripeInvoice->amount_paid,
                'amount_remaining' => $stripeInvoice->amount_remaining,
                'currency' => $stripeInvoice->currency,
                'customer_name' => $stripeInvoice->customer_name,
                'customer_email' => $stripeInvoice->customer_email,
                'lines' => array_map(function($line) {
                    return [
                        'description' => $line->description,
                        'amount' => $line->amount,
                        'quantity' => $line->quantity,
                    ];
                }, $stripeInvoice->lines->data),
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to retrieve invoice details'], 500);
        }
    }

    public function update(InvoiceUpdateRequest $request, Invoice $invoice)
    {
        $invoice->update($request->validated());
        return new InvoiceResource($invoice);
    }
}
