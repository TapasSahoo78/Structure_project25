<?php

namespace App\Http\Controllers\Internal;

use App\Models\Plan;
use App\Http\Controllers\Controller;
use App\Http\Resources\PlanResource;
use App\Http\Requests\PlanIndexRequest;
use App\Http\Requests\PlanShowRequest;
use App\Http\Requests\PlanStoreRequest;
use App\Http\Requests\PlanUpdateRequest;
use App\Http\Requests\PlanDestroyRequest;
use App\Services\PlanService;
use Illuminate\Http\Request;
use Stripe\Exception\ApiErrorException;

class PlanController extends Controller
{
    protected $planService;

    public function __construct(PlanService $planService)
    {
        $this->planService = $planService;
    }

    public function index(PlanIndexRequest $request)
    {
        $query = Plan::query();

        $query->when($request->name, function ($q, $name) {
            $q->where('name', 'LIKE', "%{$name}%");
        })
        ->when($request->description, function ($q, $description) {
            $q->where('description', 'LIKE', "%{$description}%");
        })
        ->when($request->price, function ($q, $price) {
            $q->where('price', $price);
        })
        ->when($request->stripe_product_id, function ($q, $stripeProductId) {
            $q->where('stripe_product_id', $stripeProductId);
        })
        ->when($request->stripe_price_id, function ($q, $stripePriceId) {
            $q->where('stripe_price_id', $stripePriceId);
        })
        ->when($request->size, function ($q, $size) {
            $q->where('size', $size);
        })
        ->when($request->radius, function ($q, $radius) {
            $q->where('radius', $radius);
        })
        ->when($request->period, function ($q, $period) {
            $q->where('period', $period);
        });

        return PlanResource::collection($query->paginate(20));
    }

    public function store(PlanStoreRequest $request)
    {
        try {
            $plan = $this->planService->createPlan($request->validated());
            return new PlanResource($plan);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to create Plan: ' . $e->getMessage()], 500);
        }
    }

    public function show(PlanShowRequest $request, Plan $plan)
    {
        return new PlanResource($plan);
    }

    public function update(PlanUpdateRequest $request, Plan $plan)
    {
        try {
            $updatedPlan = $this->planService->updatePlan($plan, $request->validated());
            return new PlanResource($updatedPlan);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to update Plan: ' . $e->getMessage()], 500);
        }
    }

    public function destroy(PlanDestroyRequest $request, Plan $plan)
    {
        try {
            $this->planService->archivePlan($plan);
            return response()->json(['message' => 'Plan archived in Stripe and deleted from database successfully']);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to archive Plan: ' . $e->getMessage()], 500);
        }
    }
}
