<?php

namespace App\Http\Controllers\Internal;

use App\Models\Plan;
use App\Http\Controllers\Controller;
use App\Http\Requests\PromoCodeIndexRequest;
use App\Http\Requests\PromoCodeShowRequest;
use App\Http\Requests\CouponStoreRequest;
use App\Http\Requests\PromoCodeUpdateRequest;
use App\Http\Requests\PromoCodeDestroyRequest;
use App\Http\Requests\PromoCodeStoreRequest;
use App\Http\Resources\PromoCodeResource;
use App\Models\Coupon;
use App\Models\PromoCode;
use App\Services\PromoCodeService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\ApiErrorException;

class PromoCodeController extends Controller
{
    protected $promoCodeService;

    public function __construct(PromoCodeService $promoCodeService)
    {
        $this->promoCodeService = $promoCodeService;
    }

    public function index(PromoCodeIndexRequest $request)
    {
        $query = PromoCode::query();

        $query->when($request->code, function ($q, $code) {
            $q->where('code', 'LIKE', "%{$code}%");
        });

        return PromoCodeResource::collection($query->paginate(20));
    }

    public function store(PromoCodeStoreRequest $request)
    {
        try {
            $plan = $this->promoCodeService->createPromoCode($request->validated());
            return new PromoCodeResource($plan);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to create Promo Code: ' . $e->getMessage(), 'message' => $e->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to create Promo Code: ', 'message' => $e->getMessage()], 500);
        }
    }

    public function show(PromoCodeShowRequest $request, PromoCode $promoCode)
    {
        return new PromoCodeResource($promoCode);
    }

    public function update(PromoCodeUpdateRequest $request, PromoCode $promoCode)
    {
        try {
            $updatedCoupon = $this->promoCodeService->updatePromoCode($promoCode, $request->validated());
            return new PromoCodeResource($updatedCoupon);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to update Promo Code: ' . $e->getMessage(), 'message' => $e->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to update Promo Code: ', 'message' => $e->getMessage()], 500);
        }
    }

    public function destroy(PromoCodeDestroyRequest $request, PromoCode $promoCode)
    {
        try {
            $this->promoCodeService->archivePromoCode($promoCode);
            return response()->json(['message' => 'Promo Code archived in Stripe and deleted from database successfully']);
        } catch (ApiErrorException $e) {
            return response()->json(['error' => 'Failed to archive Promo Code: ' . $e->getMessage(), 'message' => $e->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to archive Promo Code: ', 'message' => $e->getMessage()], 500);
        }
    }
}
