<?php

namespace App\Http\Controllers\Internal;

use App\Models\Plan;
use App\Models\Subscription;
use App\Http\Controllers\Controller;
use App\Http\Resources\SubscriptionResource;
use App\Http\Requests\SubscriptionIndexRequest;
use App\Http\Requests\SubscriptionShowRequest;
use App\Http\Requests\SubscriptionStoreRequest;
use App\Http\Requests\SubscriptionUpdateRequest;
use App\Http\Requests\SubscriptionDestroyRequest;
use Illuminate\Http\Request;
use App\Services\SubscriptionService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class SubscriptionController extends Controller
{
    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService)
    {
        $this->subscriptionService = $subscriptionService;
    }

    public function index(SubscriptionIndexRequest $request)
    {
        $query = Subscription::query()->with('plan')->has('plan')->where(function ($q) {
            $q->whereNull('ends_at')
                ->orWhere('ends_at', '>', Carbon::now());
        });
        $user = Auth::user();

        // allow admin to filter by business, else limit to auth user business_id
        if ($user->isAdmin()) {
            if ($request->filled('business_id')) {
                $query->where('business_id', $request->business_id);
            }
        } else {
            $query->where('business_id', $user->business_id);
        }

        $this->applyFilters($query, $request);
        return SubscriptionResource::collection($query->paginate(20));
    }

    private function applyFilters($query, $request)
    {
        $filters = [
            'name' => 'where',
            'stripe_status' => 'where',
            'ends_at' => 'where',
            'plan_id' => 'where',
        ];

        foreach ($filters as $field => $method) {
            if ($request->filled($field)) {
                $query->$method($field, $request->$field);
            }
        }

        if ($request->filled('period')) {
            $query->whereHas('plan', function ($q) use ($request) {
                $q->where('period', $request->period);
            });
        }

        if ($request->filled('size')) {
            $query->whereHas('plan', function ($q) use ($request) {
                $q->where('size', $request->size);
            });
        }
    }

    public function store(SubscriptionStoreRequest $request)
    {
        $plan = Plan::where('id', $request->plan_id)->firstOrFail();
        $subscription = $this->subscriptionService->createSubscription($request, $plan);

        return new SubscriptionResource($subscription->load('plan'));
    }

    public function show(SubscriptionShowRequest $request, Subscription $subscription)
    {
        return new SubscriptionResource($subscription->load('plan'));
    }

    public function update(SubscriptionUpdateRequest $request, Subscription $subscription)
    {
        $subscription->update($request->validated());
        return new SubscriptionResource($subscription->fresh()->load('plan'));
    }

    public function destroy(SubscriptionDestroyRequest $request, Subscription $subscription)
    {
        $this->subscriptionService->cancelSubscription($subscription);
        return response()->json(['message' => 'Subscription canceled successfully']);
    }
}
