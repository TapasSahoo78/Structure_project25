<?php

namespace App\Http\Controllers\Internal;

use App\Models\User;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Http\Requests\UserIndexRequest;
use App\Http\Requests\UserShowRequest;
use App\Http\Requests\UserStoreRequest;
use App\Http\Requests\UserUpdateRequest;
use App\Http\Requests\UserDestroyRequest;
use Illuminate\Http\Request;
use Stripe\StripeClient;
use App\Http\Requests\UserPaymentMethodUpdateRequest;
use App\Models\Subscription;
use Illuminate\Support\Carbon;

class UserController extends Controller
{
    public function index(UserIndexRequest $request)
    {
        $query = User::with('business');

        if ($request->filled('name')) {
            $query->where('name', $request->name);
        }

        if ($request->filled('email')) {
            $query->where('email', $request->email);
        }

        if ($request->filled('email_verified_at')) {
            $query->where('email_verified_at', $request->email_verified_at);
        }

        if ($request->filled('password')) {
            $query->where('password', $request->password);
        }

        if ($request->filled('remember_token')) {
            $query->where('remember_token', $request->remember_token);
        }

        if ($request->filled('phone')) {
            $query->where('phone', $request->phone);
        }

        if ($request->filled('address')) {
            $query->where('address', $request->address);
        }

        if ($request->is_admin == "true") {
            $query->where('is_admin', 1);
        } elseif ($request->is_admin == "false") {
            $query->where('is_admin', 0);
        }

        if ($request->filled('stripe_id')) {
            $query->where('stripe_id', $request->stripe_id);
        }

        if ($request->filled('pm_type')) {
            $query->where('pm_type', $request->pm_type);
        }

        if ($request->filled('pm_last_four')) {
            $query->where('pm_last_four', $request->pm_last_four);
        }

        if ($request->filled('trial_ends_at')) {
            $query->where('trial_ends_at', $request->trial_ends_at);
        }

        if ($request->filled('stripe_payment_method_id')) {
            $query->where('stripe_payment_method_id', $request->stripe_payment_method_id);
        }

        if ($request->filled('pm_brand')) {
            $query->where('pm_brand', $request->pm_brand);
        }

        if ($request->filled('longitude')) {
            $query->where('longitude', $request->longitude);
        }

        if ($request->filled('latitude')) {
            $query->where('latitude', $request->latitude);
        }
        return UserResource::collection($query->paginate(20));
    }

    public function store(UserStoreRequest $request)
    {
        $user = User::create($request->validated());
        return new UserResource($user->load('business'));
    }

    public function show(UserShowRequest $request, User $user)
    {
        return new UserResource($user->load('business'));
    }

    public function update(UserUpdateRequest $request, User $user)
    {
        // info($request->validated());
        // $user->update($request->validated());
        $user->update($request->only(['name', 'email', 'fname', 'lname', 'password', 'is_admin', 'login_code']));
        $user->business->update($request->only(['phone']));
        $user->business->address->update($request->only(['street_number', 'street_name', 'city', 'state', 'postal_code', 'country']));
        return new UserResource($user->fresh('business'));
    }

    public function destroy(UserDestroyRequest $request, User $user)
    {
        $user->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
}
