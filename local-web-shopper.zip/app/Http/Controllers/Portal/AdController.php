<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdStoreRequest;
use App\Http\Requests\AdUpdateRequest;
use App\Http\Resources\AdEditResource;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Ad;
use App\Services\AdService;
use App\Http\Resources\AdResource;
use Illuminate\Support\Facades\Log;

class AdController extends Controller
{
    protected $adService;

    public function __construct(AdService $adService)
    {
        $this->adService = $adService;
    }

    public function index()
    {
        return Inertia::render('portal/advertisements/index');
    }

    public function create()
    {
        return Inertia::render('portal/advertisements/create');
    }

    public function show(Ad $ad)
    {
        return Inertia::render('portal/advertisements/show', [
            'ad' => new AdResource($ad->load(['subscription', 'category', 'plan', 'file', 'address']))
        ]);
    }


    public function edit(Ad $ad)
    {

        return Inertia::render('portal/advertisements/edit', [
            'ad' => new AdEditResource($ad->load(['subscription', 'category', 'plan', 'file', 'address']))
        ]);
    }

    public function store(AdStoreRequest $request)
    {
        // $ad = $this->adService->createAd($request->validated());
        $ad = $this->adService->createAd($request->all());
        return Inertia::render('portal/advertisements/index');
    }

    public function update(AdUpdateRequest $request, Ad $ad)
    {
        // $updatedAd = $this->adService->updateAd($ad, $request->validated());
        $updatedAd = $this->adService->updateAd($ad, $request->all());
        return Inertia::render('portal/advertisements/index');
    }


    public function publish(Ad $ad)
    {
        try {
            $publishedAd = $this->adService->publishAd($ad);
            return redirect()->route('portal.ads.show', $publishedAd)->with('flash', [
                'message' => 'Ad published successfully',
                'type' => 'success'
            ]);
        } catch (\InvalidArgumentException $e) {
            Log::error('InvalidArgumentException in ' . get_class($this) . '::' . __METHOD__ . ' on line ' . __LINE__ . ': ' . $e->getMessage());
            return response()->json(['message' => $e->getMessage()], 400);
            // return redirect()->route('portal.ads.show', $publishedAd)->with('flash', [
            //     'message' => $e->getMessage(),
            //     'type' => 'error'
            // ]);
        } catch (\Exception $e) {
            Log::error('Error in ' . get_class($this) . '::' . __METHOD__ . ' on line ' . __LINE__ . ': ' . $e->getMessage());
            return response()->json(['message' => $e->getMessage()], 500);
            // return redirect()->route('portal.ads.show', $publishedAd)->with('flash', [
            //     'message' => $e->getMessage(),
            //     'type' => 'error'
            // ]);
        }
    }

    public function end(Ad $ad)
    {

        try {
            $endedAd = $this->adService->endAd($ad);
            return redirect()->route('portal.ads.show', $endedAd)->with('flash', [
                'message' => 'Ad ended successfully',
                'type' => 'success'
            ]);
        } catch (\Exception $e) {
            Log::error('Error in ' . get_class($this) . '::' . __METHOD__ . ' on line ' . __LINE__ . ': ' . $e->getMessage());
            return back()->with('flash', [
                'message' => $e->getMessage(),
                'type' => 'error'
            ]);
        }
    }
}
