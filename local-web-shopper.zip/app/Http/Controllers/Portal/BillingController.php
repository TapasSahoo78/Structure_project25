<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Inertia\Inertia;

class BillingController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        return Inertia::render('portal/billing/index', [
            'business' => $user->business
        ]);
    }

    public function invoices()
    {
        $user = auth()->user();
        $invoices = $user->invoices(); // Assuming you're using Laravel Cashier

        return Inertia::render('portal/billing/invoices', [
            'invoices' => $invoices,
        ]);
    }

    public function paymentMethods()
    {
        $user = auth()->user();
        $paymentMethods = $user->paymentMethods();

        return Inertia::render('portal/billing/payment-methods', [
            'paymentMethods' => $paymentMethods,
        ]);
    }

    public function addPaymentMethod(Request $request)
    {
        $user = auth()->user();
        $paymentMethodToken = $request->input('payment_method_token');

        // Add the payment method to the user's account
        $user->addPaymentMethod($paymentMethodToken);

        return redirect()->route('portal.billing.payment-methods')
            ->with('success', 'Payment method added successfully.');
    }

    public function removePaymentMethod($paymentMethodId)
    {
        $user = auth()->user();
        $paymentMethod = $user->findPaymentMethod($paymentMethodId);

        if ($paymentMethod) {
            $paymentMethod->delete();
        }

        return redirect()->route('portal.billing.payment-methods')
            ->with('success', 'Payment method removed successfully.');
    }

    public function setDefaultPaymentMethod(Request $request)
    {
        $user = auth()->user();
        $paymentMethodId = $request->input('payment_method_id');

        $user->updateDefaultPaymentMethod($paymentMethodId);

        return redirect()->route('portal.billing.payment-methods')
            ->with('success', 'Default payment method updated successfully.');
    }
}
