<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Inertia\Inertia;
use Illuminate\Validation\Rules;
use Inertia\Response;

class PasswordController extends Controller
{
    /**
     * Show the user's password settings page.
     */
    public function edit(): Response
    {
        return Inertia::render('portal/settings/password');
    }

    /**
     * Update the user's password.
     */
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'current_password' => ['required', 'current_password'],
            // 'password' => ['required', Password::defaults(), 'confirmed'],
            'password' => [
                'required',
                'string',
                'confirmed',
                Rules\Password::min(8)
                    ->mixedCase()
                    ->numbers()
                    ->symbols(),
            ],
        ], [
            'password.min' => 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol',
            'password.mixedCase' => 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol',
            'password.numbers' => 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol',
            'password.symbols' => 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol',
        ]);

        $request->user()->update([
            'password' => Hash::make($validated['password']),
        ]);

        return back();
    }
}
