<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
// use App\Http\Requests\Settings\ProfileUpdateRequest;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;
use App\Services\BusinessService;

use App\Http\Requests\ProfileUpdateRequest;
use App\Http\Requests\BusinessProfileUpdateRequest;

class ProfileController extends Controller
{
    protected $businessService;

    public function __construct(BusinessService $businessService)
    {
        $this->businessService = $businessService;
    }

    /**
     * Show the user's profile settings page.
     */
    public function edit(Request $request): Response
    {
        return Inertia::render('portal/settings/profile', [
            'mustVerifyEmail' => $request->user() instanceof MustVerifyEmail,
            'status' => $request->session()->get('status'),
        ]);
    }

    /**
     * Update the user's profile settings.
     */
    // public function update(ProfileUpdateRequest $request): RedirectResponse
    // {
    //     $request->user()->fill($request->validated());

    //     if ($request->user()->isDirty('email')) {
    //         $request->user()->email_verified_at = null;
    //     }

    //     $request->user()->save();

    //     return to_route('portal.profile.edit');
    // }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validate([
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
    public function editBusiness(Request $request): Response
    {
        return Inertia::render('portal/settings/business');
    }

        /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
{
    $validated = $request->validated();
    
    $validated['name'] = $validated['fname'] . ' ' . $validated['lname'];
    
    $request->user()->fill($validated);

    if ($request->user()->isDirty('email')) {
        $request->user()->email_verified_at = null;
    }

    $request->user()->save();

    return to_route('portal.profile')->with('status', 'profile-updated');
}

    /**
     * Update the user's business profile information.
     */
    public function updateBusiness(BusinessProfileUpdateRequest $request): RedirectResponse
    {
        $this->businessService->updateBusiness($request->user()->business, $request->validated());

        return to_route('portal.business')->with('status', 'business-profile-updated');
    }
}
