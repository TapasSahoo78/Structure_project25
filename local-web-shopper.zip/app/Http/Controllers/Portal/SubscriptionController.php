<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use Inertia\Inertia;
use App\Http\Requests\SubscriptionIndexRequest;
use App\Http\Requests\SubscriptionShowRequest;
use App\Http\Requests\SubscriptionStoreRequest;
use App\Http\Requests\SubscriptionUpdateRequest;
use App\Http\Requests\SubscriptionDestroyRequest;
use App\Services\SubscriptionService;
use Stripe\Exception\ApiErrorException;
use Laravel\Cashier\Exceptions\IncompletePayment;
use Stripe\Exception\CardException;
use Stripe\Exception\RateLimitException;
use Stripe\Exception\InvalidRequestException;
use Stripe\Exception\AuthenticationException;
use Stripe\Exception\PermissionException;
use Stripe\Exception\SignatureVerificationException;

class SubscriptionController extends Controller
{
    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService)
    {
        $this->subscriptionService = $subscriptionService;
    }

    public function index()
    {

        $subscription = Subscription::where('business_id', session('sub_id'))->latest()->first();

        if ($subscription) {
            $subscription->forceFill([
                'plan_id' => session('plan_id'),
                'name'       => session('pending_name') ?? NULL,
                'creator_id' => session('creator_id')
            ])->save();
        }

        session()->forget(['sub_id', 'creator_id', 'pending_name']);

        return Inertia::render('portal/subscriptions/index');
    }

    public function create()
    {
        return Inertia::render('portal/subscriptions/create');
    }

    // public function store(SubscriptionStoreRequest $request)
    // {
    //     // $plan = Plan::where('id', $request->plan_id)->firstOrFail();
    //     // $subscription = $this->subscriptionService->createSubscription($request, $plan);
    //     // return redirect()->route('portal.subscriptions.index')->with('success', 'Subscription created successfully.');
    // }

    public function store(SubscriptionStoreRequest $request)
    {
        try {
            $plan = Plan::where('id', $request->plan_id)->firstOrFail();
            $subscription = $this->subscriptionService->createSubscription($request, $plan);
            return redirect()->route('portal.subscriptions.index')->with('success', 'Subscription created successfully.');
        } catch (IncompletePayment $e) {
            // temporarily store plan_id and any data in session
            session([
                'sub_id' => auth()->user()->business->id,
                'plan_id' => $request->plan_id,
                'creator_id' => auth()->user()->id,
                'pending_name' => $request->name
            ]);
            return redirect()->route(
                'cashier.payment',
                [$e->payment->id, 'redirect' => route('portal.subscriptions.redirect')]
            );
        } catch (CardException $e) {
            return back()->withErrors(['error' => 'Card error: ' . $e->getMessage()]);
        } catch (RateLimitException $e) {
            return back()->withErrors(['error' => 'Too many requests: ' . $e->getMessage()]);
        } catch (InvalidRequestException $e) {
            return back()->withErrors(['error' => 'Invalid request: ' . $e->getMessage()]);
        } catch (AuthenticationException $e) {
            return back()->withErrors(['error' => 'Authentication failed: ' . $e->getMessage()]);
        } catch (PermissionException $e) {
            return back()->withErrors(['error' => 'Permission error: ' . $e->getMessage()]);
        } catch (SignatureVerificationException $e) {
            return back()->withErrors(['error' => 'Invalid signature: ' . $e->getMessage()]);
        } catch (ApiErrorException $e) {
            return back()->withErrors(['error' => 'Stripe API error: ' . $e->getMessage()]);
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Unexpected error: ' . $e->getMessage()]);
        }
    }

    public function show(SubscriptionShowRequest $subscription)
    {
        $this->authorize('view', $subscription);
        return Inertia::render('portal/subscriptions/show', ['subscription' => $subscription]);
    }

    public function edit(Subscription $subscription)
    {
        $this->authorize('update', $subscription);
        return Inertia::render('portal/subscriptions/edit', ['subscription' => $subscription]);
    }

    public function update(SubscriptionUpdateRequest $request, Subscription $subscription)
    {
        $this->authorize('update', $subscription);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'duration' => 'required|integer|min:1',
            // Add other validation rules as needed
        ]);

        $subscription->update($validated);

        return redirect()->route('portal.subscriptions.index')->with('success', 'Subscription updated successfully.');
    }

    public function destroy(SubscriptionDestroyRequest $subscription)
    {
        $this->authorize('delete', $subscription);

        $subscription->delete();

        return redirect()->route('portal.subscriptions.index')->with('success', 'Subscription deleted successfully.');
    }
}
