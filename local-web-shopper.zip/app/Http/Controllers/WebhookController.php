<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\Coupon;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Plan;
use App\Models\PromoCode;
use App\Models\Subscription;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Stripe\Event;
use Stripe\StripeClient;
use Stripe\Exception\SignatureVerificationException;
use Stripe\Webhook;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class WebhookController extends Controller
{
    protected StripeClient $stripe;

    public function __construct()
    {
        $this->stripe = new StripeClient(config('services.stripe.secret'));
    }

    public function handleWebhook(Request $request)
    {
        $payload = $request->getContent();
        $sig_header = $request->header('Stripe-Signature');
        $webhookSecret = config('services.stripe.webhook.secret');

        Log::info('Webhook received', [
            'payload' => $payload,
            'signature' => $sig_header,
            'webhook_secret' => substr($webhookSecret, 0, 5) . '...'
        ]);

        try {
            $event = Webhook::constructEvent(
                $payload,
                $sig_header,
                $webhookSecret
            );
        } catch (SignatureVerificationException $e) {
            Log::error('Signature verification failed', [
                'error' => $e->getMessage(),
                'sig_header' => $sig_header,
                'payload' => substr($payload, 0, 100) . '...'
            ]);
            return response()->json(['error' => 'Invalid signature: ' . $e->getMessage()], 400);
        } catch (\Exception $e) {
            Log::error('Webhook error', ['error' => $e->getMessage()]);
            return response()->json(['error' => 'Webhook error: ' . $e->getMessage()], 400);
        }

        Log::info('Webhook event constructed successfully', ['type' => $event->type]);

        try {
            switch ($event->type) {
                case 'customer.updated':
                case 'customer.deleted':
                    $this->handleCustomerEvent($event);
                    break;
                case 'invoice.created':
                case 'invoice.updated':
                case 'invoice.paid':
                case 'invoice.payment_failed':
                case 'invoice.payment_succeeded':
                case 'invoice.finalized':
                case 'invoice.marked_uncollectible':
                case 'invoice.voided':
                    $this->handleInvoiceEvent($event);
                    break;
                case 'product.updated':
                case 'product.deleted':
                    $this->handleProductEvent($event);
                    break;
                case 'customer.subscription.created':
                case 'customer.subscription.updated':
                case 'customer.subscription.deleted':
                    $this->handleSubscriptionEvent($event);
                    break;
                case 'coupon.created':
                case 'coupon.deleted':
                case 'coupon.updated':
                    $this->handleCouponEvent($event);
                    break;
                case 'promotion_code.created':
                case 'promotion_code.updated':
                    $this->handlePromoCodeEvent($event);
                    break;
                default:
                    Log::warning('Unhandled event type', ['type' => $event->type]);
                    return response()->json(['error' => 'Unhandled event type: ' . $event->type], 400);
            }
        } catch (\Exception $e) {
            Log::error('Error processing webhook', ['error' => $e->getMessage(), 'type' => $event->type]);
            return response()->json(['error' => 'Error processing webhook: ' . $e->getMessage()], 500);
        }

        return response()->json(['success' => true]);
    }

    private function handleCustomerEvent(Event $event)
    {
        $stripeCustomer = $event->data->object;

        $business = Business::where('stripe_id', $stripeCustomer->id)->first();

        if (!$business) {
            \Log::error("Business not found for Stripe customer ID: {$stripeCustomer->id}");
            return;
        }

        $business->update([
            'name' => $stripeCustomer->name,
            'phone' => $stripeCustomer->phone,
            'stripe_id' => $stripeCustomer->id,
        ]);

        if (isset($stripeCustomer->email)) {
            $primaryUser = $business->primaryUser;
            if ($primaryUser) {
                $primaryUser->update(['email' => $stripeCustomer->email]);
            }
        }

        if (isset($stripeCustomer->invoice_settings->default_payment_method)) {
            $paymentMethodId = $stripeCustomer->invoice_settings->default_payment_method;

            try {
                $stripe = new \Stripe\StripeClient(config('services.stripe.secret'));
                $paymentMethod = $stripe->paymentMethods->retrieve($paymentMethodId);

                $business->update([
                    'stripe_payment_method_id' => $paymentMethod->id,
                    'pm_type' => $paymentMethod->type,
                    'pm_last_four' => $paymentMethod->card->last4,
                    'pm_brand' => $paymentMethod->card->brand,
                    'pm_exp_month' => $paymentMethod->card->exp_month,
                    'pm_exp_year' => $paymentMethod->card->exp_year,
                    'pm_card_holder_name' => $paymentMethod->billing_details->name,
                ]);
            } catch (\Exception $e) {
                \Log::error("Error fetching payment method: " . $e->getMessage());
            }
        }

        if ($event->type === 'customer.deleted') {
            $business->update(['is_active' => false]);
        }
    }

    private function handleInvoiceEvent(Event $event)
    {
        $stripeInvoice = $event->data->object;

        info($stripeInvoice->due_date);

        // Find the business_id using the Stripe customer_id
        $business = Business::where('stripe_id', $stripeInvoice->customer)->first();

        if (!$business) {
            Log::error('Business not found for Stripe customer ID: ' . $stripeInvoice->customer);
            return;
        }

        $invoice = Invoice::updateOrCreate(
            ['stripe_id' => $stripeInvoice->id],
            [
                'business_id' => $business->id,
                'customer_id' => $stripeInvoice->customer,
                'subscription_id' => $stripeInvoice->subscription,
                'status' => $stripeInvoice->status,
                'due_date' => $stripeInvoice->due_date ? Carbon::createFromTimestamp($stripeInvoice->due_date) : null,
                'amount_due' => $stripeInvoice->amount_due,
                'amount_paid' => $stripeInvoice->amount_paid,
                'amount_remaining' => $stripeInvoice->amount_remaining,
                'currency' => $stripeInvoice->currency,
                'period_start' => Carbon::createFromTimestamp($stripeInvoice->lines->data[0]->period->start),
                'period_end' => Carbon::createFromTimestamp($stripeInvoice->lines->data[0]->period->end),
                'invoice_pdf' => $stripeInvoice->invoice_pdf,
                'hosted_invoice_url' => $stripeInvoice->hosted_invoice_url,
                'paid' => $stripeInvoice->paid,
                'payment_intent_id' => $stripeInvoice->payment_intent,
                'paid_at' => $stripeInvoice->status === 'paid' && isset($stripeInvoice->status_transitions->paid_at)
                    ? Carbon::createFromTimestamp($stripeInvoice->status_transitions->paid_at)
                    : null,
                'stripe_invoice_number' => $stripeInvoice->number,
            ]
        );

        // foreach ($stripeInvoice->lines->data as $item) {
        //     InvoiceItem::updateOrCreate(
        //         ['stripe_id' => $item->id],
        //         [
        //             'invoice_id' => $invoice->id,
        //             'amount' => $item->amount,
        //             'currency' => $item->currency,
        //             'description' => $item->description,
        //             'period_start' => Carbon::createFromTimestamp($item->period->start),
        //             'period_end' => Carbon::createFromTimestamp($item->period->end),
        //         ]
        //     );
        // }

        switch ($event->type) {
            case 'invoice.paid':
                // Handle paid invoice
                break;
            case 'invoice.payment_failed':
                // Handle failed payment
                break;
        }
    }

    private function handleProductEvent(Event $event)
    {
        $stripeProduct = $event->data->object;

        $plan = Plan::where('stripe_product_id', $stripeProduct->id)->first();

        if (!$plan) {
            Log::error("Plan not found for Stripe product ID: {$stripeProduct->id}");
            return;
        }

        switch ($event->type) {
            case 'product.updated':
                $plan->name = $stripeProduct->name;
                $plan->description = $stripeProduct->description;
                $plan->save();
                break;

            case 'product.deleted':
                $plan->update(['is_active' => false]);
                break;
        }
    }

    // private function handleSubscriptionEvent(Event $event)
    // {
    //     $stripeSubscription = $event->data->object;

    //     info('Handling subscription event', ['type' => $event->type, 'subscription_id' => $stripeSubscription]);

    //     $subscription = Subscription::where('stripe_id', $stripeSubscription->id)->first();

    //     if (!$subscription) {
    //         Log::error("Subscription not found for Stripe subscription ID: {$stripeSubscription->id}");
    //         return;
    //     }

    //     switch ($event->type) {
    //         case 'customer.subscription.created':
    //         case 'customer.subscription.updated':
    //             $subscription->update([
    //                 'stripe_status' => $stripeSubscription->status,
    //                 'stripe_price' => $stripeSubscription->items->data[0]->price->id,
    //                 'quantity' => $stripeSubscription->items->data[0]->quantity,
    //                 'trial_ends_at' => $stripeSubscription->trial_end ? Carbon::createFromTimestamp($stripeSubscription->trial_end) : null,
    //                 'ends_at' => $stripeSubscription->cancel_at ? Carbon::createFromTimestamp($stripeSubscription->cancel_at) : null,
    //             ]);

    //             $planId = $stripeSubscription->items->data[0]->price->product;
    //             $plan = Plan::where('stripe_product_id', $planId)->first();
    //             if ($plan) {
    //                 $subscription->update(['plan_id' => $plan->id]);
    //             }

    //             break;

    //         case 'customer.subscription.deleted':
    //             $subscription->update([
    //                 'stripe_status' => 'canceled',
    //                 'ends_at' => now(),
    //             ]);
    //             break;
    //     }

    //     $business = $subscription->business;
    //     $business->update([
    //         'is_active' => in_array($subscription->stripe_status, ['active', 'trialing']),
    //     ]);
    // }

    protected function handleSubscriptionEvent($event)
    {
        $stripeSubscription = $event->data->object;

        info('Handling subscription event', ['type' => $event->type, 'subscription_id' => $stripeSubscription->id]);

        $subscription = Subscription::where('stripe_id', $stripeSubscription->id)->first();

        // If subscription doesn't exist, create it
        if (!$subscription) {
            if ($event->type === 'customer.subscription.created') {
                return $this->createNewSubscription($stripeSubscription);
            }

            Log::error("Subscription not found for Stripe subscription ID: {$stripeSubscription->id}");
            return new Response('Webhook Handled', 200);
        }

        switch ($event->type) {
            case 'customer.subscription.created':
            case 'customer.subscription.updated':
                $subscription->update([
                    'stripe_status' => $stripeSubscription->status,
                    'stripe_price' => $stripeSubscription->items->data[0]->price->id,
                    'quantity' => $stripeSubscription->items->data[0]->quantity,
                    'trial_ends_at' => $stripeSubscription->trial_end ? Carbon::createFromTimestamp($stripeSubscription->trial_end) : null,
                    'ends_at' => $stripeSubscription->cancel_at ? Carbon::createFromTimestamp($stripeSubscription->cancel_at) : null,
                ]);

                $planId = $stripeSubscription->items->data[0]->price->product;
                $plan = Plan::where('stripe_product_id', $planId)->first();
                if ($plan) {
                    $subscription->update(['plan_id' => $plan->id]);
                }

                break;

            case 'customer.subscription.deleted':
                $subscription->update([
                    'stripe_status' => 'canceled',
                    'ends_at' => now(),
                ]);
                break;
        }

        $business = $subscription->business;
        $business->update([
            'is_active' => in_array($subscription->stripe_status, ['active', 'trialing']),
        ]);

        return new Response('Webhook Handled', 200);
    }

    protected function createNewSubscription($stripeSubscription)
    {
        // Find the customer (user or business) by Stripe ID
        $customer = Business::where('stripe_id', $stripeSubscription->customer)->first();

        if (!$customer) {
            Log::error("Customer not found for Stripe ID: {$stripeSubscription->customer}");
            return;
        }

        // Create the subscription record
        $subscription = Subscription::create([
            'creator_id' => $customer->primary_user_id,
            'stripe_id' => $stripeSubscription->id,
            'stripe_status' => $stripeSubscription->status,
            'stripe_price' => $stripeSubscription->items->data[0]->price->id,
            'quantity' => $stripeSubscription->items->data[0]->quantity,
            'trial_ends_at' => $stripeSubscription->trial_end ? Carbon::createFromTimestamp($stripeSubscription->trial_end) : null,
            'ends_at' => $stripeSubscription->cancel_at ? Carbon::createFromTimestamp($stripeSubscription->cancel_at) : null,
        ]);

        // Associate with plan if available
        $planId = $stripeSubscription->items->data[0]->price->product;
        $plan = Plan::where('stripe_product_id', $planId)->first();
        if ($plan) {
            $subscription->update(['plan_id' => $plan->id]);
        }

        // Update business status
        $business = $customer->business; // Adjust based on your relationship
        if ($business) {
            $business->update([
                'is_active' => in_array($stripeSubscription->status, ['active', 'trialing']),
            ]);
        }

        Log::info("New subscription created: {$subscription->id}");
    }

    private function handleCouponEvent(Event $event)
    {
        $stripeProduct = $event->data->object;
        // Validate required Stripe properties
        if (!isset($stripeProduct->id)) {
            Log::error("Invalid Stripe coupon event: missing ID", [
                'event_type' => $event->type,
                'stripe_data' => $stripeProduct,
            ]);
            return;
        }

        // Find or initialize coupon
        $coupon = Coupon::where('stripe_coupon_id', $stripeProduct->id)->first();

        try {
            switch ($event->type) {
                case 'coupon.created':
                    if ($coupon) {
                        Log::warning("Coupon already exists for Stripe coupon ID: {$stripeProduct->id}", [
                            'coupon_id' => $coupon->id,
                            'stripe_coupon_id' => $stripeProduct->id,
                        ]);
                        // Optionally update instead of returning
                        // break;
                    }

                    $coupon = Coupon::create([
                        'stripe_coupon_id' => $stripeProduct->id,
                        'code' => $stripeProduct->name ?? null,
                        'discount_type' => $stripeProduct->amount_off ? 'amount' : 'percent', // Default to 'fixed' or 'percentage'
                        'discount_value' => $this->normalizeDiscountValue(($stripeProduct->amount_off ?? $stripeProduct->percent_off) ?? 0),
                        'duration' => $stripeProduct->duration ?? 'once',
                        'max_redemptions' => $stripeProduct->max_redemptions ?? 1,
                        'used_count' => 0,
                        'redeem_by' => $stripeProduct->redeem_by ? Carbon::createFromTimestamp($stripeProduct->redeem_by) : null,
                        'currency' => $stripeProduct->currency ?? 'usd',
                        'is_active' => $stripeProduct->active ?? true,
                    ]);

                    Log::info('Coupon created successfully', [
                        'coupon_id' => $coupon->id,
                        'stripe_coupon_id' => $stripeProduct->id,
                        'code' => $coupon->code,
                    ]);
                    break;

                case 'coupon.updated':
                    if (!$coupon) {
                        Log::error("Coupon not found for update with Stripe coupon ID: {$stripeProduct->id}");
                        return;
                    }

                    $coupon->update([
                        'code' => $stripeProduct->name ?? $coupon->code,
                        'discount_type' => $stripeProduct->amount_off ? 'amount' : 'percent' ?? $coupon->discount_type,
                        'discount_value' => $this->normalizeDiscountValue(($stripeProduct->amount_off ?? $stripeProduct->percent_off) ?? $coupon->discount_value),
                        'duration' => $stripeProduct->duration ?? $coupon->duration,
                        'max_redemptions' => $stripeProduct->max_redemptions ?? $coupon->max_redemptions,
                        'redeem_by' => $stripeProduct->redeem_by ? Carbon::createFromTimestamp($stripeProduct->redeem_by) : $coupon->redeem_by,
                        'currency' => $stripeProduct->currency ?? $coupon->currency,
                        'is_active' => $stripeProduct->active ?? $coupon->is_active,
                    ]);

                    Log::info('Coupon updated successfully', [
                        'coupon_id' => $coupon->id,
                        'stripe_coupon_id' => $stripeProduct->id,
                        'code' => $coupon->code,
                    ]);
                    break;

                case 'coupon.deleted':
                    if (!$coupon) {
                        Log::error("Coupon not found for deletion with Stripe coupon ID: {$stripeProduct->id}");
                        return;
                    }

                    // $coupon->update([
                    //     'is_active' => false,
                    // ]);
                    PromoCode::where('coupon_id', $stripeProduct->id)->delete();
                    $coupon->delete();

                    Log::info('Coupon archived successfully', [
                        'coupon_id' => $coupon->id,
                        'stripe_coupon_id' => $coupon->stripe_coupon_id,
                        'code' => $coupon->code,
                    ]);
                    break;

                default:
                    Log::warning("Unhandled coupon event type: {$event->type}", [
                        'stripe_coupon_id' => $stripeProduct->id,
                    ]);
                    break;
            }
        } catch (\Exception $e) {
            Log::error("Error handling coupon event: {$event->type}", [
                'stripe_coupon_id' => $stripeProduct->id,
                'error' => $e->getMessage(),
            ]);
            // Optionally rethrow or handle the error based on your webhook retry logic
            // throw $e;
        }
    }

    private function handlePromoCodeEvent(Event $event)
    {
        $stripePromoCode = $event->data->object;

        // Validate required Stripe properties
        if (!isset($stripePromoCode->id)) {
            Log::error("Invalid Stripe promo code event: missing ID", [
                'event_type' => $event->type,
                'stripe_data' => $stripePromoCode,
            ]);
            return;
        }

        // Find or initialize coupon
        $promoCode = PromoCode::firstOrNew([
            'stripe_promo_code_id' => $stripePromoCode->id,
        ]);

        try {
            switch ($event->type) {
                case 'promotion_code.created':
                    if ($promoCode) {
                        Log::warning("Coupon already exists for Stripe promotion_code ID: {$stripePromoCode->id}", [
                            'promo_code_id' => $promoCode->id,
                            'stripe_promo_code_id' => $stripePromoCode->id,
                        ]);
                    }

                    $promoCode->fill([
                        'code' => $stripePromoCode->code,
                        'coupon_id' => $stripePromoCode->coupon->id ?? null,
                        'max_redemptions' => $stripePromoCode->max_redemptions,
                        'used_count' => $stripePromoCode->times_redeemed ?? 0,
                        'expires_at' => $stripePromoCode->expires_at
                            ? date('Y-m-d H:i:s', $stripePromoCode->expires_at)
                            : null,
                        'is_active' => $stripePromoCode->active,
                    ]);

                    $promoCode->save();

                    Log::info('Coupon created successfully', [
                        'stripe_coupon_id' => $stripePromoCode->coupon->id,
                        'stripe_promo_code_id' => $stripePromoCode->id,
                        'code' => $promoCode->code,
                    ]);
                    break;

                case 'promotion_code.deleted':
                    if (!$promoCode) {
                        Log::error("Promo code not found for deletion with Stripe coupon ID: {$stripePromoCode->id}");
                        return;
                    }

                    $promoCode->update([
                        'is_active' => false,
                    ]);

                    Log::info('Promo code archived successfully', [
                        'coupon_id' => $promoCode->id,
                        'stripe_coupon_id' => $promoCode->stripe_coupon_id,
                        'code' => $promoCode->code,
                    ]);
                    break;

                default:
                    Log::warning("Unhandled coupon event type: {$event->type}", [
                        'stripe_coupon_id' => $stripeProduct->id,
                    ]);
                    break;
            }
        } catch (\Exception $e) {
            Log::error("Error handling coupon event: {$event->type}", [
                'stripe_coupon_id' => $stripePromoCode->id,
                'error' => $e->getMessage(),
            ]);
            // Optionally rethrow or handle the error based on your webhook retry logic
            // throw $e;
        }
    }

    /**
     * Normalize discount value (e.g., convert cents to dollars if needed).
     *
     * @param mixed $value
     * @return float
     */
    private function normalizeDiscountValue($value)
    {
        // Assuming Stripe sends amounts in cents for fixed-amount discounts
        if (is_numeric($value)) {
            // Convert cents to dollars if discount_type is 'fixed' (adjust based on your logic)
            return $value / 100; // e.g., 127500 cents -> 1275.00 dollars
        }
        return $value; // Return as-is for percentage discounts or invalid values
    }
}
