<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\AdCategory;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class AdCategoryDestroyRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('delete', AdCategory::class);
    }

    public function rules()
    {
        return [];
    }

    public function validateResolved()
    {
        $adCategory = $this->route('ad_category');

        if ($adCategory->ads()->count() > 0) {
            throw new HttpResponseException(response()->json([
                'errors' => ['category' => 'Cannot delete category. There are ads assigned to it.'],
            ], 422));
        }

        parent::validateResolved();
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'errors' => $validator->errors(),
        ], 422));
    }
}