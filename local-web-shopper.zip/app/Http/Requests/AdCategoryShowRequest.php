<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\AdCategory;

class AdCategoryShowRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('view', AdCategory::class);
    }

    public function rules()
    {
        return [

        ];
    }
}