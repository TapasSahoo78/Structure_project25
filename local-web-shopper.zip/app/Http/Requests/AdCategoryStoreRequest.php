<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Models\AdCategory;

class AdCategoryStoreRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('create', AdCategory::class);
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('ad_categories', 'name'),
            ],
        ];
    }

    public function messages()
    {
        return [
            'name.unique' => 'This category name already exists. Please choose a different name.',
        ];
    }
}