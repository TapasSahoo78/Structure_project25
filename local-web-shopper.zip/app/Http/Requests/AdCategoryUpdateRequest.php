<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Models\AdCategory;

class AdCategoryUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('update', AdCategory::class);
    }

    public function rules()
    {
        return [
            'name' => [
                'sometimes',
                'string',
                'max:255',
                Rule::unique('ad_categories', 'name'),
            ],
        ];
    }

    public function messages()
    {
        return [
            'name.unique' => 'This category name already exists. Please choose a different name.',
        ];
    }
}