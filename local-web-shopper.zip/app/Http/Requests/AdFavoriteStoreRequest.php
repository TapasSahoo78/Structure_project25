<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AdFavoriteStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'user_id' => [
                'required',
                'string',
                'max:255',
                Rule::in([auth()->id()]), // Ensure user_id matches the current authenticated user
            ],
            'ad_id' => 'required|string|max:255',
        ];
    }

    public function messages()
    {
        return [
            'user_id.in' => 'The user ID must match the currently authenticated user.',
        ];
    }
}