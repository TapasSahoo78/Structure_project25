<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'subscription_id' => [
                'nullable',
                'required_with:start_date',
                'exists:subscriptions,id',
            ],
            'start_date' => [
                'nullable',
                'date',
                // 'after_or_equal:today',
            ],
            'end_date' => [
                'nullable',
                'date',
                'after:start_date +23 hours',
            ],
            // 'street_number' => 'sometimes|string|max:255',
            // 'street_name' => 'sometimes|string|max:255',
            // 'city' => 'sometimes|string|max:255',
            // 'state' => 'sometimes|string|max:255',
            // 'postal_code' => 'sometimes|string|max:20',
            // 'country' => 'sometimes|string|max:255',
            'longitude' => 'required|numeric',
            'latitude' => 'required|numeric',
            'category_id' => 'required|exists:ad_categories,id',
            'file_id' => 'nullable|exists:files,id',
        ];
    }
}
