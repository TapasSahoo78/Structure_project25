<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BusinessPaymentMethodShowRequest extends FormRequest
{
    public function authorize()
    {
        $business = $this->route('business');
        return $this->user()->can('view', $business);
    }


    public function rules()
    {
        return [
           
        ];
    }
}