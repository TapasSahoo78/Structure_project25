<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BusinessPaymentMethodUpdateRequest extends FormRequest
{
    public function authorize()
    {
        $business = $this->route('business');
        return $this->user()->can('update', $business);
    }

    public function rules()
    {
        return [
            'stripe_payment_method_id' => 'required|string',
        ];
    }
}