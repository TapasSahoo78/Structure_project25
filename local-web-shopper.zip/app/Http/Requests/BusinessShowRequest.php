<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BusinessShowRequest extends FormRequest
{
    public function authorize()
    {
        $business = $this->route('business');
        return $this->user()->can('view', $business);
    }


    public function rules()
    {
        return [];
    }
}