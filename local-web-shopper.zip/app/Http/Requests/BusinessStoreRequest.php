<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BusinessStoreRequest extends FormRequest
{
    public function authorize()
    {
        $business = $this->route('business');
        return $this->user()->can('create', $business);
    }


    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'primary_user_id' => 'required|integer|exists:users,id',
            'address_id' => 'nullable|integer|exists:addresses,id',
            'stripe_id' => 'nullable|string|max:255',
            'stripe_payment_method_id' => 'nullable|string|max:255',
            'pm_type' => 'nullable|string|max:255',
            'pm_last_four' => 'nullable|string|max:4',
            'pm_brand' => 'nullable|string|max:255',
            'pm_exp_month' => 'nullable|string|max:2',
            'pm_exp_year' => 'nullable|string|max:4',
            'pm_card_holder_name' => 'nullable|string|max:255',
            'trial_ends_at' => 'nullable|date',
        ];
    }
}