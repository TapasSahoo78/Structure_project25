<?php

namespace App\Http\Requests;

use App\Models\Coupon;
use Illuminate\Foundation\Http\FormRequest;
use App\Models\Plan;

class CouponIndexRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('viewAny', Plan::class);
    }

    public function rules()
    {
        return [

        ];
    }
}
