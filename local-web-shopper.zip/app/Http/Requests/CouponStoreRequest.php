<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use App\Models\Coupon;
use App\Models\Plan;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class CouponStoreRequest extends FormRequest
{
    public function authorize()
    {
        $user = auth()->user();
        return $user && $user->can('create', Plan::class);
    }

    public function rules(): array
    {
        return [
            'code' => 'required|string|max:255|unique:coupons,code', // Unique human-readable code
            'discount_type' => 'required|in:percent,amount', // Type of discount
            'discount_value' => [
                'required',
                'numeric',
                'min:0',
                function ($attribute, $value, $fail) {
                    $type = $this->input('discount_type');
                    if ($type === 'percent') {
                        if ($value > 100) {
                            $fail('The discount value must not exceed 100 for percentage discounts.');
                        }
                    }
                    // For amount, no max limit, but you can add one if needed (e.g., max:1000)
                },
            ],
            'percent_off' => 'nullable|numeric|min:0|max:100', // If using percent_off directly (alternative to discount_value for percent)
            'amount_off' => 'nullable|numeric|min:0', // If using amount_off directly (alternative to discount_value for amount)
            'duration' => 'required|in:once,repeating,forever', // Duration type
            'max_redemptions' => 'nullable|integer|min:0|max:999999', // Max total uses (optional, defaults to 1)
            'redeem_by' => 'nullable|date|after:now', // Expiration date (optional)
            'currency' => 'nullable|in:usd,eur,gbp', // Currency for amount discounts (optional, defaults to usd)
            'is_active' => 'nullable|boolean', // Active status (optional, defaults to true)
        ];
    }

    /**
     * Get custom error messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'code.required' => 'The coupon code is required.',
            'code.unique' => 'This coupon code is already in use.',
            'discount_type.required' => 'The discount type (percent or amount) is required.',
            'discount_value.required' => 'The discount value is required.',
            'duration.required' => 'The duration type is required.',
            'redeem_by.after' => 'The redeem by date must be in the future.',
        ];
    }

    /**
     * Prepare the data for validation (e.g., handle conditional fields).
     */
    protected function prepareForValidation()
    {
        // If using percent_off or amount_off, map them to discount_value based on type
        $type = $this->input('discount_type');
        if ($type === 'percent' && $this->filled('percent_off')) {
            $this->merge(['discount_value' => $this->input('percent_off')]);
        } elseif ($type === 'amount' && $this->filled('amount_off')) {
            $this->merge(['discount_value' => $this->input('amount_off')]);
        }

        // Set defaults if not provided
        $this->merge([
            'max_redemptions' => $this->input('max_redemptions', 1),
            'currency' => $this->input('currency', 'usd'),
            'is_active' => $this->input('is_active', true),
        ]);
    }
}
