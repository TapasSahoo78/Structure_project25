<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;
use App\Models\Plan;
use Illuminate\Validation\Rule;

class CouponUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('update', Plan::class);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $couponId = $this->route('coupon')?->id ?? $this->input('id'); // Get the coupon ID from route model binding or input

        return [
            'code' => [
                'sometimes',
                'required',
                'string',
                'max:255',
                'unique:coupons,code,' . $couponId, // Allow the same code for this coupon, but unique otherwise
            ],
            'discount_type' => 'sometimes|required|in:percent,amount', // Type of discount (optional for update)
            'discount_value' => [
                'sometimes',
                'required',
                'numeric',
                'min:0',
                function ($attribute, $value, $fail) use ($couponId) {
                    $type = $this->input('discount_type') ?? $this->route('coupon')?->discount_type;
                    if ($type === 'percent') {
                        if ($value > 100) {
                            $fail('The discount value must not exceed 100 for percentage discounts.');
                        }
                    }
                    // For amount, no max limit, but you can add one if needed (e.g., max:1000)
                },
            ],
            'percent_off' => 'nullable|numeric|min:0|max:100', // If using percent_off directly (alternative to discount_value for percent)
            'amount_off' => 'nullable|numeric|min:0', // If using amount_off directly (alternative to discount_value for amount)
            'duration' => 'sometimes|required|in:once,repeating,forever', // Duration type (optional for update)
            'max_redemptions' => 'sometimes|required|integer|min:0|max:999999', // Max total uses (optional)
            'redeem_by' => 'sometimes|required|date|after:now', // Expiration date (optional)
            'currency' => 'sometimes|required|in:usd,eur,gbp', // Currency for amount discounts (optional)
            'is_active' => 'sometimes|required|boolean', // Active status (optional)
        ];
    }

    /**
     * Get custom error messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'code.required' => 'The coupon code is required.',
            'code.unique' => 'This coupon code is already in use by another coupon.',
            'discount_type.required' => 'The discount type (percent or amount) is required.',
            'discount_value.required' => 'The discount value is required.',
            'duration.required' => 'The duration type is required.',
            'redeem_by.after' => 'The redeem by date must be in the future.',
        ];
    }

    /**
     * Prepare the data for validation (e.g., handle conditional fields).
     */
    protected function prepareForValidation()
    {
        $coupon = $this->route('coupon'); // Assuming route model binding for the coupon

        // If using percent_off or amount_off, map them to discount_value based on type
        $type = $this->input('discount_type') ?? ($coupon?->discount_type ?? 'percent');
        if ($type === 'percent' && $this->filled('percent_off')) {
            $this->merge(['discount_value' => $this->input('percent_off')]);
        } elseif ($type === 'amount' && $this->filled('amount_off')) {
            $this->merge(['discount_value' => $this->input('amount_off')]);
        }

        // Only set defaults if the field is not provided (for updates, preserve existing values)
        if (!$this->filled('max_redemptions')) {
            $this->merge(['max_redemptions' => $coupon?->max_redemptions ?? 1]);
        }
        if (!$this->filled('currency')) {
            $this->merge(['currency' => $coupon?->currency ?? 'usd']);
        }
        if (!$this->filled('is_active')) {
            $this->merge(['is_active' => $coupon?->is_active ?? true]);
        }
    }
}
