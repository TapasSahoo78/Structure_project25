<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class InvoiceUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->isAdmin();
    }

    public function rules()
    {
        return [
            'user_id' => 'sometimes|required|string|max:255',
            'status' => 'sometimes|required|string|max:255',
            'due_on' => 'sometimes|required|string|max:255',
            'sent_on' => 'sometimes|required|string|max:255',
            'paid_on' => 'sometimes|required|string|max:255',
            'stripe_invoice_id' => 'sometimes|required|string|max:255',
            'suspension_sent' => 'sometimes|required|string|max:255',
            'termination_sent' => 'sometimes|required|string|max:255',
            'ad_id' => 'sometimes|required|string|max:255',
            'total' => 'sometimes|required|string|max:255',
            'subscription_id' => 'sometimes|required|string|max:255',
        ];
    }
}