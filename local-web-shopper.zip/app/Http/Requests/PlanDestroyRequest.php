<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Plan;
class PlanDestroyRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('delete', Plan::class);
    }

    public function rules()
    {
        return [

        ];
    }
}