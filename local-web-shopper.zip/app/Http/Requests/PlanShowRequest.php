<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Plan;

class PlanShowRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('view', Plan::class);
    }

    public function rules()
    {
        return [

        ];
    }
}