<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use App\Models\Plan;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class PlanStoreRequest extends FormRequest
{
    public function authorize()
    {
        $user = auth()->user();
        return $user && $user->can('create', Plan::class);
    }

    public function rules()
    {
        return [
            'name' => 'required|string|max:255|unique:plans,name',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:0|max:10000|regex:/^\d+(\.\d{1,2})?$/',
            'size' => ['required', new Enum(PageSize::class)],
            'radius' => 'required|numeric|min:0|max:10000',
            'period' => ['required', new Enum(PlanPeriod::class)],
        ];
    }
}