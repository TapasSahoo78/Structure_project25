<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;
use App\Models\Plan;
use Illuminate\Validation\Rule;

class PlanUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('update', Plan::class);
    }

    public function rules()
    {
        $plan = $this->route('plan');

        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('plans', 'name')->ignore($plan->id),
            ],
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:0|max:10000|regex:/^\d+(\.\d{1,2})?$/',
            'size' => ['required', new Enum(PageSize::class)],
            'radius' => 'required|numeric|min:0|max:10000',
            'period' => ['required', new Enum(PlanPeriod::class)],
        ];
    }
}