<?php

namespace App\Http\Requests;

use App\Models\Coupon;
use Illuminate\Foundation\Http\FormRequest;
use App\Models\Plan;

class PromoCodeShowRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('view', Plan::class);
    }

    public function rules()
    {
        return [

        ];
    }
}
