<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use App\Models\Coupon;
use App\Models\Plan;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class PromoCodeStoreRequest extends FormRequest
{
    public function authorize()
    {
        $user = auth()->user();
        return $user && $user->can('create', Plan::class);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'code' => 'required|string|min:2|max:255|unique:promo_codes,code',
            'coupon_id' => 'required|string|exists:coupons,stripe_coupon_id',
            'max_redemptions' => 'nullable|integer|min:0|max:999999',
            'expires_at' => 'nullable|date|after:now',
            'is_active' => 'nullable|boolean',
        ];
    }

    /**
     * Get custom error messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'code.required' => 'The promo code is required.',
            'code.unique' => 'This promo code is already in use.',
            'code.min' => 'The promo code must be at least 2 characters.',
            'coupon_id.required' => 'The associated coupon ID is required.',
            'coupon_id.exists' => 'The selected coupon does not exist.',
            'expires_at.after' => 'The expiration date must be in the future.',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_active' => $this->input('is_active', true),
            'max_redemptions' => $this->input('max_redemptions', null),
        ]);
    }
}
