<?php

namespace App\Http\Requests;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;
use App\Models\Plan;
use App\Models\PromoCode;
use Illuminate\Validation\Rule;

class PromoCodeUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return auth()->user()->can('update', Plan::class);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $promoCodeId = $this->route('id') ?? $this->input('stripe_promo_code_id');
        return [
            'code' => [
                'sometimes',
                'required',
                'string',
                'min:2',
                'max:255',
                'unique:promo_codes,code,' . $promoCodeId . ',stripe_promo_code_id',
            ],
            'max_redemptions' => 'sometimes|nullable|integer|min:0|max:999999',
            'expires_at' => 'sometimes|nullable|date|after:now',
            'is_active' => 'sometimes|boolean',
        ];
    }

    /**
     * Get custom error messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'code.required' => 'The promo code is required.',
            'code.unique' => 'This promo code is already in use.',
            'code.min' => 'The promo code must be at least 2 characters.',
            'expires_at.after' => 'The expiration date must be in the future.',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $promo = PromoCode::where('stripe_promo_code_id', $this->route('id'))->first();

        if (!$this->filled('is_active')) {
            $this->merge(['is_active' => $promo?->is_active ?? true]);
        }
        if (!$this->filled('max_redemptions')) {
            $this->merge(['max_redemptions' => $promo?->max_redemptions ?? null]);
        }
    }
}
