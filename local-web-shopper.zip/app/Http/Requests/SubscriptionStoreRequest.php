<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Auth\Access\AuthorizationException;
use App\Models\Subscription;

class SubscriptionStoreRequest extends FormRequest
{
    public function authorize()
    {
        $user = auth()->user();

        if (!$user->business->hasPaymentMethod()) {
            throw new AuthorizationException('You do not have a payment method on file. Please add a payment method before creating a subscription.');
        }
        
        return $user->can('create', Subscription::class);
        
    }

    public function rules()
    {
        return [
            'plan_id' => 'required|exists:plans,id',
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('subscriptions')->where(function ($query) {
                    return $query->where('business_id', auth()->id());
                }),
            ],
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after:start_date',
            'auto_renew' => 'required|boolean',
            'cycles' => 'nullable|integer|min:1|max:50|required_if:auto_renew,false',
        ];
    }
}