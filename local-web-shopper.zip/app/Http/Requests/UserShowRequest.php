<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserShowRequest extends FormRequest
{
    public function authorize()
    {
        $user = $this->route('user');
        return auth()->user()->can('view', $user);
    }

    public function rules()
    {
        return [

        ];
    }
}