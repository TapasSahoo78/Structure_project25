<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class UserUpdateRequest extends FormRequest
{
    public function authorize()
    {
        $user = $this->route('user');
        return auth()->user()->can('update', $user);
    }

    public function rules()
    {
        return [
            'name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|string|max:255',
            'email_verified_at' => 'sometimes|required|string|max:255',
            'password' => [
                // 'required',
                'sometimes',
                'string',
                Password::min(12)
                    ->mixedCase()
                    ->numbers()
                    ->symbols(),
            ],
            'remember_token' => 'sometimes|required|string|max:255',
            // 'phone' => 'sometimes|required|string|max:255',
            'phone' => 'sometimes|max:255',
            'address' => 'sometimes|required|string|max:255',
            // 'is_admin' => 'sometimes|required|string|max:255',
            'is_admin' => 'sometimes|max:255',
            'stripe_id' => 'sometimes|required|string|max:255',
            'pm_type' => 'sometimes|required|string|max:255',
            'pm_last_four' => 'sometimes|required|string|max:255',
            'trial_ends_at' => 'sometimes|required|string|max:255',
            'stripe_payment_method_id' => 'sometimes|required|string|max:255',
            'pm_brand' => 'sometimes|required|string|max:255',
            'longitude' => 'sometimes|required|string|max:255',
            'latitude' => 'sometimes|required|string|max:255',
        ];
    }
}
