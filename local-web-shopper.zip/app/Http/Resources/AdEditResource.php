<?php

namespace App\Http\Resources;

use App\Enums\AdStatus;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdEditResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'business_id' => $this->business_id,
            'creator_id' => $this->creator_id,
            'file_id' => $this->file_id,
            'subscription_id' => $this->subscription_id,
            'category_id' => $this->category_id,
            'title' => $this->title,
            'description' => $this->description,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'status' => $this->status instanceof AdStatus ? $this->status->value : $this->status,
            'file' => new FileResource($this->whenLoaded('file')),
            'category' => new AdCategoryResource($this->whenLoaded('category')),
            'plan' => new PlanResource($this->whenLoaded('plan')),
            'address' => new AddressResource($this->whenLoaded('address')),
            'subscription' => new SubscriptionResource($this->whenLoaded('subscription')),
        ];
    }
}