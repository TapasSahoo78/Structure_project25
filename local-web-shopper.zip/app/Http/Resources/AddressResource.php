<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AddressResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'business_id' => $this->business_id,
            'street_number' => $this->street_number,
            'street_name' => $this->street_name,
            'city' => $this->city,
            'state' => $this->state,
            'postal_code' => $this->postal_code,
            'country' => $this->country,
            'formatted_address' => $this->formatted_address,
            'full_address' => $this->full_address,
            'longitude' => $this->longitude,
            'latitude' => $this->latitude,
        ];
    }
}