<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BusinessPaymentMethodResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'stripe_payment_method_id' => $this->stripe_payment_method_id,
            'pm_type' => $this->pm_type,
            'pm_last_four' => $this->pm_last_four,
            'pm_brand' => $this->pm_brand,
            'pm_exp_month' => $this->pm_exp_month,
            'pm_exp_year' => $this->pm_exp_year,
            'pm_card_holder_name' => $this->pm_card_holder_name,
        ];
    }
}
