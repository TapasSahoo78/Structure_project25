<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BusinessResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'phone' => $this->phone,
            'primary_user_id' => $this->primary_user_id,
            // 'address' => new AddressResource($this->whenLoaded('address')),
            'address' => new AddressResource($this->address),
            'primaryUser' => new UserResource($this->whenLoaded('primaryUser')),
        ];
    }
}
