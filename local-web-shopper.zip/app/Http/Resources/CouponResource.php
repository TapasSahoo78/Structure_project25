<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CouponResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'stripe_coupon_id' => $this->stripe_coupon_id,
            'code' => $this->code,
            'discount_type' => $this->discount_type,
            'discount_value' => number_format($this->discount_value, 2, '.', ','),
            'duration' => $this->duration,
            'max_redemptions' => $this->max_redemptions,
            'used_count' => $this->used_count,
            'redeem_by' => $this->redeem_by,
            'currency' => $this->currency,
            'is_active' => $this->is_active,
        ];
    }
}
