<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class FileResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'business_id' => $this->business_id,
            'creator_id' => $this->creator_id,
            'real' => $this->real,
            'name' => $this->name,
            'mime_type' => $this->mime_type,
            'path' => url('storage' . '/' . $this->path . '/' . $this->real), // Concat app URL with path and real filename
            'hash' => $this->hash,
            'size' => $this->size,
            'url' => $this->getUrl(),
        ];
    }
}