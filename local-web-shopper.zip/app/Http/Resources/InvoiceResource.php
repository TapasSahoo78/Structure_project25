<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'stripe_invoice_number' => $this->stripe_invoice_number,
            'status' => ucwords($this->status),
            'due_date' => $this->due_date,
            'amount_due' => $this->amount_due,
            'amount_paid' => $this->amount_paid,
            'amount_remaining' => $this->amount_remaining,
            'currency' => $this->currency,
            'hosted_invoice_url' => $this->hosted_invoice_url,
            'paid' => $this->paid,
            'paid_at' => $this->paid_at,

            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'customer_id' => $this->customer_id,
            'subscription_id' => $this->subscription_id,
            'period_start' => $this->period_start,
            'period_end' => $this->period_end,
            'invoice_pdf' => $this->invoice_pdf,
            'payment_intent_id' => $this->payment_intent_id,
        ];
    }
}