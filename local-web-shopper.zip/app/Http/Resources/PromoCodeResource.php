<?php

namespace App\Http\Resources;

use App\Models\Coupon;
use Illuminate\Http\Resources\Json\JsonResource;

class PromoCodeResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'stripe_promo_code_id' => $this->stripe_promo_code_id,
            'code' => $this->code,
            'coupon_id' => $this->coupon_id,
            'coupon_code' => Coupon::where('stripe_coupon_id', $this->coupon_id)->value('code'),
            'max_redemptions' => $this->max_redemptions ?? 0,
            'used_count' => $this->used_count ?? 0,
            'expires_at' => $this->expires_at ? $this->expires_at->toIso8601String() : null,
            'is_active' => $this->is_active,
            'created_at' => $this->created_at->toIso8601String(),
            'updated_at' => $this->updated_at->toIso8601String(),
        ];
    }
}
