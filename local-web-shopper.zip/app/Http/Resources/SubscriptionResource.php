<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class SubscriptionResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'plan_id' => $this->plan_id,
            'name' => $this->name,
            'status' => ucwords($this->stripe_status),
            'ends_at' => $this->ends_at ? Carbon::parse($this->ends_at)->format('Y-m-d') : null,
            'business' => new BusinessResource($this->whenLoaded('business')),
            'ads' => AdResource::collection($this->whenLoaded('ads')),
            'plan' => new PlanResource($this->whenLoaded('plan')),
        ];
    }
}