<?php

namespace App\Http\Resources;

use App\Http\Resources\BusinessResource;
use App\Models\Subscription;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;

class UserResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'fname' => $this->fname,
            'lname' => $this->lname,
            'email' => $this->email,
            'is_admin' => $this->is_admin,
            'login_code' => $this->login_code,
            'business' => new BusinessResource($this->whenLoaded('business')),
            'latestActive' => Subscription::where('creator_id', $this->id)
                ->where(function ($query) {
                    $query->whereNull('ends_at')
                        ->orWhere('ends_at', '>=', Carbon::now());
                })
                ->orderBy('ends_at', 'desc')
                ->first() ?? null,
        ];
    }
}
