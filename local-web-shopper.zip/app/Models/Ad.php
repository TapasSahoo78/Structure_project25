<?php

namespace App\Models;

use App\Enums\AdFailureType;
use App\Enums\AdStatus;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;
use Illuminate\Database\Eloquent\Relations\HasOne;
use App\Models\Subscription;
use App\Models\AdCategory;
use App\Models\File;

/**
 * Class Ad
 *
 * @package App\Models
 *
 * @property int $id
 * @property string $title
 * @property string $description
 * @property int $business_id
 * @property int $creator_id
 * @property int $view_count
 * @property \Carbon\Carbon $start_date
 * @property int $subscription_id
 * @property \Carbon\Carbon $end_date
 * @property \Carbon\Carbon $suspended_on
 * @property int $suspended_by
 * @property string $suspended_reason
 * @property \App\Enums\AdStatus $status
 * @property int $category_id
 */
class Ad extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'status' => AdStatus::class,
        'start_date' => 'date',
        'end_date' => 'date',
        'suspended_on' => 'date',
    ];

    protected $hidden = [
        'laravel_through_key'
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'creator_id');
    }

    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(AdCategory::class);
    }

    public function suspendedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'suspended_by');
    }

    public function images(): HasMany
    {
        return $this->hasMany(AdImage::class);
    }
    public function primaryImage(): HasOne
    {
        return $this->hasOne(AdImage::class)->where('is_primary', true);
    }

    public function file(): HasOneThrough
    {
        return $this->hasOneThrough(
            File::class,
            AdImage::class,
            'ad_id',
            'id',
            'id',
            'file_id'
        )->where('ad_images.is_primary', true);
    }

    public function plan(): HasOneThrough
    {
        return $this->hasOneThrough(
            Plan::class,
            Subscription::class,
            'id',
            'id',
            'subscription_id',
            'plan_id'
        )->withoutGlobalScopes()
            ->select(['plans.id as id', 'plans.radius', 'plans.size']);
    }

    // public static function dailyAdCheck()
    // {
    //     $now = Carbon::now();
    //     // Find ads that are scheduled to go live now or earlier but still not live
    //     $adsToActivate = self::where('status', 'SCHEDULED')
    //         ->where('start_date', '<=', $now)
    //         ->get();
    //     foreach ($adsToActivate as $ad) {
    //         $ad->status = 'LIVE';
    //         $ad->save();
    //     }
    // }

    public static function dailyAdCheck()
    {
        $now = Carbon::now();

        // Find ads that are scheduled to go live now or earlier but still not live
        $adsToActivate = self::where('status', 'SCHEDULED')
            ->where('start_date', '<=', $now)
            ->get();
        foreach ($adsToActivate as $ad) {
            $ad->status = 'LIVE';
            $ad->save();
        }

        // Find live ads that have an end_date (not null) and are expired (end_date < now)
        $adsToEnd = self::where('status', 'LIVE')
            ->whereNotNull('end_date')
            ->where('end_date', '<', $now)
            ->get();
        foreach ($adsToEnd as $ad) {
            $ad->status = 'ENDED';
            $ad->save();
        }
    }
}
