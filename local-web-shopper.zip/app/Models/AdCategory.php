<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class AdCategory
 *
 * @package App\Models
 *
 * @property int $id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $name
 */
class AdCategory extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    protected $fillable = ['name'];


    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the ads associated with this category.
     *
     * @return HasMany
     */
    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class, 'category_id');
    }

    /**
     * Scope a query to only include categories with active ads.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeWithActiveAds($query)
    {
        return $query->whereHas('ads', function ($query) {
            $query->where('status', 'LIVE');
        });
    }

    /**
     * Get the number of active ads in this category.
     *
     * @return int
     */
    public function getActiveAdCountAttribute(): int
    {
        return $this->ads()->where('status', 'LIVE')->count();
    }

    /**
     * Check if the category has any active ads.
     *
     * @return bool
     */
    public function hasActiveAds(): bool
    {
        return $this->ads()->where('status', 'LIVE')->exists();
    }
}