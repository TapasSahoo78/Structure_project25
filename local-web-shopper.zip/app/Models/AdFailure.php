<?php

namespace App\Models;

use App\Enums\AdFailureType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class AdFailure
 *
 * @package App\Models
 *
 * @property int $id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property \App\Enums\AdFailureType $type
 * @property string $human_reason
 * @property string $log
 * @property int $ad_id
 * @property int|null $resolved_by
 * @property \Carbon\Carbon|null $resolved_on
 * @property string|null $resolution
 * @property int|null $invoice_id
 * @property int|null $subscription_id
 */
class AdFailure extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'type' => AdFailureType::class,
        'resolved_on' => 'datetime',
        'ad_id' => 'integer',
        'resolved_by' => 'integer',
        'invoice_id' => 'integer',
        'subscription_id' => 'integer',
    ];

    /**
     * Get the ad associated with the failure.
     *
     * @return BelongsTo
     */
    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    /**
     * Get the invoice associated with the failure.
     *
     * @return BelongsTo
     */
    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    /**
     * Get the subscription associated with the failure.
     *
     * @return BelongsTo
     */
    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    /**
     * Get the user who resolved the failure.
     *
     * @return BelongsTo
     */
    public function resolvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }

    /**
     * Check if the failure has been resolved.
     *
     * @return bool
     */
    public function isResolved(): bool
    {
        return !is_null($this->resolved_on);
    }

    /**
     * Resolve the failure.
     *
     * @param int $userId
     * @param string $resolution
     * @return bool
     */
    public function resolve(int $userId, string $resolution): bool
    {
        return $this->update([
            'resolved_by' => $userId,
            'resolved_on' => now(),
            'resolution' => $resolution,
        ]);
    }

    /**
     * Scope a query to only include unresolved failures.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeUnresolved($query)
    {
        return $query->whereNull('resolved_on');
    }

    /**
     * Scope a query to only include failures of a specific type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  \App\Enums\AdFailureType  $type
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfType($query, AdFailureType $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Get a summary of the failure.
     *
     * @return string
     */
    public function getSummaryAttribute(): string
    {
        return "[{$this->created_at->format('Y-m-d H:i:s')}] {$this->type->name}: {$this->human_reason}";
    }
}