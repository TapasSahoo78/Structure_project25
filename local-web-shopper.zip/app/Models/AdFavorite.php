<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class AdFavorite
 *
 * @package App\Models
 *
 * @property int $id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property int $user_id
 * @property int $ad_id
 */
class AdFavorite extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'ad_id',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'integer',
        'ad_id' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the user who favorited the ad.
     *
     * @return BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the favorited ad.
     *
     * @return BelongsTo
     */
    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    /**
     * Scope a query to only include favorites for a specific user.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  int  $userId
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeForUser($query, int $userId)
    {
        return $query->where('user_id', $userId);
    }

    /**
     * Check if a specific ad is favorited by a user.
     *
     * @param int $userId
     * @param int $adId
     * @return bool
     */
    public static function isFavorited(int $userId, int $adId): bool
    {
        return static::where('user_id', $userId)
                     ->where('ad_id', $adId)
                     ->exists();
    }

    /**
     * Toggle the favorite status for a user and ad.
     *
     * @param int $userId
     * @param int $adId
     * @return bool
     */
    public static function toggleFavorite(int $userId, int $adId): bool
    {
        $favorite = static::where('user_id', $userId)
                          ->where('ad_id', $adId)
                          ->first();

        if ($favorite) {
            $favorite->delete();
            return false;
        } else {
            static::create([
                'user_id' => $userId,
                'ad_id' => $adId,
            ]);
            return true;
        }
    }
}