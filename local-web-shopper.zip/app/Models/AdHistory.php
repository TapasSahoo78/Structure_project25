<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdHistory extends Model
{
    protected $fillable = ['ad_id', 'subscription_id', 'date'];

    public function ad()
    {
        return $this->belongsTo(Ad::class);
    }
}
