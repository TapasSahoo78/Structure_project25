<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class AdImage
 *
 * @package App\Models
 *
 * @property int $id
 * @property int $ad_id
 * @property int $file_id
 * @property bool $is_primary
 * @property int $order
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 *
 * @property-read \App\Models\Ad $ad
 * @property-read \App\Models\File $file
 */
class AdImage extends Model
{
    protected $fillable = ['ad_id', 'file_id', 'is_primary', 'order'];

    /**
     * Get the ad that owns the image.
     */
    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    /**
     * Get the file associated with the image.
     */
    public function file(): BelongsTo
    {
        return $this->belongsTo(File::class);
    }
}