<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property int $id
 * @property int $business_id
 * @property string|null $street_number
 * @property string|null $street_name
 * @property string|null $city
 * @property string|null $state
 * @property string|null $postal_code
 * @property string|null $country
 * @property string|null $formatted_address
 * @property float|null $longitude
 * @property float|null $latitude
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|Business[] $businesses
 * @property-read \Illuminate\Database\Eloquent\Collection|Ad[] $ads
 */
class Address extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'longitude' => 'float',
        'latitude' => 'float',
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }


    public function ads()
    {
        return $this->hasMany(Ad::class);
    }

    public function getFullAddressAttribute(): ?string
    {
        return $this->formatted_address ?? $this->generateFormattedAddress();
    }

    // private function generateFormattedAddress(): ?string
    // {
    //     $parts = [
    //         $this->street_number . ' ' . $this->street_name,
    //         $this->city,
    //         $this->state,
    //         $this->postal_code,
    //         $this->country
    //     ];

    //     $address = implode(', ', array_filter($parts));
    //     return $address ?: null;
    // }

    private function generateFormattedAddress(): ?string
    {
        $parts = [];

        // Add street number and street name if available
        if (!empty($this->street_number) || !empty($this->street_name)) {
            $parts[] = trim($this->street_number . ' ' . $this->street_name);
        }

        // Add other address components if available
        if (!empty($this->city)) {
            $parts[] = $this->city;
        }
        if (!empty($this->state)) {
            $parts[] = $this->state;
        }
        if (!empty($this->postal_code)) {
            $parts[] = $this->postal_code;
        }
        if (!empty($this->country)) {
            $parts[] = $this->country;
        }

        // Join the parts with a comma and return
        $address = implode(', ', $parts);

        // Return null if the address is empty
        return !empty($address) ? $address : null;
    }

    public function setAddressFromGoogleMaps(array $addressComponents): void
    {
        foreach ($addressComponents as $component) {
            $types = $component['types'];
            if (in_array('street_number', $types)) {
                $this->street_number = $component['long_name'];
            } elseif (in_array('route', $types)) {
                $this->street_name = $component['long_name'];
            } elseif (in_array('locality', $types)) {
                $this->city = $component['long_name'];
            } elseif (in_array('administrative_area_level_1', $types)) {
                $this->state = $component['short_name'];
            } elseif (in_array('postal_code', $types)) {
                $this->postal_code = $component['long_name'];
            } elseif (in_array('country', $types)) {
                $this->country = $component['long_name'];
            }
        }
    }
}
