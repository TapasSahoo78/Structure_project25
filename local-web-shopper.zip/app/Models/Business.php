<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;
use Laravel\Cashier\Billable;

/**
 * @property int $id
 * @property string $name
 * @property string|null $phone
 * @property int $primary_user_id
 * @property int|null $address_id
 * @property string|null $stripe_id
 * @property string|null $stripe_payment_method_id
 * @property string|null $pm_type
 * @property string|null $pm_last_four
 * @property string|null $pm_brand
 * @property string|null $pm_exp_month
 * @property string|null $pm_exp_year
 * @property string|null $pm_card_holder_name
 * @property \Carbon\Carbon|null $trial_ends_at
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 *
 * @property-read User $primaryUser
 * @property-read Address|null $address
 * @property-read \Illuminate\Database\Eloquent\Collection|Ad[] $ads
 */
class Business extends Model
{
    use Billable;

    protected $guarded = ['id'];

    protected $casts = [
        'trial_ends_at' => 'datetime',
        'ends_at' => 'datetime'
    ];

    public function primaryUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'primary_user_id');
    }

    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    public function activeSubscriptions(): HasMany
    {
        return $this->subscriptions()->where('stripe_status', 'active');
    }

    public function getSelectableSubscriptions(): Collection
    {
        return $this->activeSubscriptions()->get();
    }

    public function hasStripeDetails(): bool
    {
        return !is_null($this->stripe_id);
    }

    public function hasPaymentMethod(): bool
    {

        return !is_null($this->stripe_payment_method_id);
    }

    public function getMaskedPhoneAttribute(): ?string
    {
        return $this->phone ? substr($this->phone, 0, -4) . '****' : null;
    }

    public function scopeActive($query)
    {
        return $query->where('ends_at', '>=', Carbon::now());
    }

    public function isActive($query)
    {
        return $this->ends_at && $this->ends_at->greaterThanOrEqualTo(Carbon::now());
    }
}
