<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $fillable = [
        'stripe_coupon_id',
        'code',
        'discount_type',
        'discount_value',
        'duration',
        'max_redemptions',
        'used_count',
        'redeem_by',
        'currency',
        'is_active',
    ];
    protected $casts = [
        'redeem_by' => 'datetime',
        'discount_value' => 'decimal:2',
    ];
}
