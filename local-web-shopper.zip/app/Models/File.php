<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;

use Illuminate\Support\Facades\Storage;

/**
 * Class File
 *
 * @package App\Models
 *
 * @property int $id
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * @property int $business_id
 * @property int $creator_id
 * @property string $real
 * @property string $name
 * @property string $mime_type
 * @property string $path
 * @property string $hash
 * @property int $size
 *
 * @property-read User $user
 * @property-read AdImage[] $adImages
 */
class File extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'business_id' => 'integer',
        'size' => 'integer',
    ];

    /**
     * Get the business who owns the file.
     */
    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    /**
     * Get the user who created file.
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'creator_id');
    }

    /**
     * Get the ad images associated with the file.
     */
    public function adImages(): HasMany
    {
        return $this->hasMany(AdImage::class);
    }

    /**
     * Get the full path of the file.
     *
     * @return string
     */
    public function getFullPath(): string
    {
        return $this->path . '/' . $this->real;
    }

    public function getUrl()
    {
        return Storage::disk('public')->url($this->getFullPath());;
    }

    /**
     * Get the file size in a human-readable format.
     *
     * @return string
     */
    public function getHumanReadableSize(): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $size = $this->size;
        $i = 0;

        while ($size >= 1024 && $i < 4) {
            $size /= 1024;
            $i++;
        }

        return round($size, 2) . ' ' . $units[$i];
    }

    /**
     * Check if the file exists in the storage.
     *
     * @return bool
     */
    public function exists(): bool
    {
        return file_exists($this->getFullPath());
    }

    /**
     * Delete the file from storage.
     *
     * @return bool
     */
    public function deleteFile(): bool
    {
        if ($this->exists()) {
            return unlink($this->getFullPath());
        }
        return false;
    }
}