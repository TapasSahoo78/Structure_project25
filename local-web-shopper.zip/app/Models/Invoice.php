<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;
use Stripe\InvoiceItem;

/**
 * Class Invoice
 *
 * @package App\Models
 *
 * @property string $id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $business_id
 * @property string $customer_id
 * @property string $subscription_id
 * @property string $status
 * @property \Carbon\Carbon $due_date
 * @property int $amount_due
 * @property int $amount_paid
 * @property int $amount_remaining
 * @property string $currency
 * @property \Carbon\Carbon|null $period_start
 * @property \Carbon\Carbon|null $period_end
 * @property string|null $invoice_pdf
 * @property string|null $hosted_invoice_url
 * @property bool $paid
 * @property string|null $payment_intent_id
 * @property \Carbon\Carbon|null $paid_at
 */
class Invoice extends Model
{
    protected $guarded = ['id'];

    protected $fillable = [
        'business_id',
        'customer_id',
        'subscription_id',
        'status',
        'due_date',
        'amount_due',
        'amount_paid',
        'amount_remaining',
        'currency',
        'period_start',
        'period_end',
        'invoice_pdf',
        'hosted_invoice_url',
        'paid',
        'payment_intent_id',
        'paid_at',
        'stripe_invoice_number', 
        'stripe_id',
    ];

    protected $casts = [
        'customer_id' => 'string',
        'subscription_id' => 'string',
        'due_date' => 'datetime',
        'amount_due' => 'integer',
        'amount_paid' => 'integer',
        'amount_remaining' => 'integer',
        'period_start' => 'datetime',
        'period_end' => 'datetime',
        'paid' => 'boolean',
        'paid_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }


    /**
     * Get the customer associated with the invoice.
     *
     * @return BelongsTo
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id', 'stripe_id');
    }

    /**
     * Get the subscription associated with the invoice.
     *
     * @return BelongsTo
     */
    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class,'subscription_id', 'stripe_id');
    }

    /**
     * Get the items associated with the invoice.
     *
     * @return HasMany
     */
    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    /**
     * Mark the invoice as paid.
     *
     * @return void
     */
    public function markAsPaid(): void
    {
        if (!$this->paid) {
            $this->update([
                'status' => 'paid',
                'paid' => true,
                'paid_at' => now(),
                'amount_paid' => $this->amount_due,
                'amount_remaining' => 0,
            ]);

            info("INVOICE : PAID Invoice #{$this->id} marked as paid");

            // send payment email
            $this->sendPaymentEmail();
        } else {
            info("INVOICE : ERROR Invoice #{$this->id} could not be marked as PAID. Invoice is already paid.");
        }
    }

    /**
     * Send payment success email.
     *
     * @return void
     */
    private function sendPaymentEmail(): void
    {
        sendEmail([
            'address' => $this->customer->email,
            'template' => 'email.invoices.payment_success',
            'subject' => "Payment Received for Invoice #{$this->id}",
            'mailData' => [
                'invoice' => $this,
                'customer' => $this->customer
            ]
        ]);
    }

    /**
     * Sync invoice data with Stripe.
     *
     * @param array $stripeInvoiceData
     * @return void
     */
    public function syncWithStripe(array $stripeInvoiceData): void
    {
        $this->update([
            'status' => $stripeInvoiceData['status'],
            'due_date' => Carbon::createFromTimestamp($stripeInvoiceData['due_date']),
            'amount_due' => $stripeInvoiceData['amount_due'],
            'amount_paid' => $stripeInvoiceData['amount_paid'],
            'amount_remaining' => $stripeInvoiceData['amount_remaining'],
            'currency' => $stripeInvoiceData['currency'],
            'period_start' => Carbon::createFromTimestamp($stripeInvoiceData['period_start']),
            'period_end' => Carbon::createFromTimestamp($stripeInvoiceData['period_end']),
            'invoice_pdf' => $stripeInvoiceData['invoice_pdf'],
            'hosted_invoice_url' => $stripeInvoiceData['hosted_invoice_url'],
            'paid' => $stripeInvoiceData['paid'],
            'payment_intent_id' => $stripeInvoiceData['payment_intent'] ?? null,
            'paid_at' => $stripeInvoiceData['status'] === 'paid' ? Carbon::createFromTimestamp($stripeInvoiceData['status_transitions']['paid_at']) : null,
        ]);
    }
}