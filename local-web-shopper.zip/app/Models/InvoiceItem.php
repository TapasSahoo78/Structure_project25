<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class InvoiceItem
 *
 * @package App\Models
 *
 * @property int $id
 * @property int $invoice_id
 * @property string $stripe_id
 * @property string $type
 * @property int $amount
 * @property string $currency
 * @property string $description
 * @property int $quantity
 */
class InvoiceItem extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'invoice_id' => 'integer',
        'amount' => 'integer',
        'quantity' => 'integer',
    ];

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }
}