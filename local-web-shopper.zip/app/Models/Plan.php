<?php

namespace App\Models;

use App\Enums\PlanPeriod;
use App\Enums\PageSize;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;

/**
 * Class Plan
 *
 * @package App\Models
 *
 * @property int $id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $name
 * @property string $description
 * @property float $price
 * @property string $stripe_product_id
 * @property string $stripe_price_id
 * @property \App\Enums\PageSize $size
 * @property int $radius
 * @property \App\Enums\PlanPeriod $period
 */
class Plan extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    public $casts = [
        'price' => 'float',
        'size' => PageSize::class,
        'radius' => 'integer',
        'period' => PlanPeriod::class,
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'laravel_through_key'
    ];

    /**
     * Get the subscriptions for the plan.
     *
     * @return HasMany
     */
    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    /**
     * Get the ads that belong to the plan through subscription
     * @return HasManyThrough<Ad, Subscription, Plan>
     */
    public function ads(): HasManyThrough
    {
        return $this->hasManyThrough(Ad::class, Subscription::class);
    }

    /**
     * Scope a query to only include plans of a specific size.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  \App\Enums\PageSize  $size
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfSize($query, PageSize $size)
    {
        return $query->where('size', $size);
    }

    /**
     * Scope a query to only include plans of a specific period.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  \App\Enums\PlanPeriod  $period
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfPeriod($query, PlanPeriod $period)
    {
        return $query->where('period', $period);
    }
}