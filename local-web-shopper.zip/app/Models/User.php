<?php

namespace App\Models;

use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

/**
 * @property int $id
 * @property string $name
 * @property string|null $fname
 * @property string|null $lname
 * @property string|null $phone
 * @property string $email
 * @property int|null $business_id
 * @property \Carbon\Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property bool $is_admin
 *
 * @property-read Business|null $business
 * @property-read \Illuminate\Database\Eloquent\Collection|Business[] $ownedBusinesses
 */
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, CanResetPassword;

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            $user->login_code = static::passwordGenerate();
        });
    }

    public static function passwordGenerate($length = 8)
    {
        $sets = [];
        $sets[] = 'ABCDEFGHJKLMNPQRSTUVWXYZ';  // Uppercase (excluding easily confused chars)
        $sets[] = 'abcdefghjkmnpqrstuvwxyz';    // Lowercase
        $sets[] = '23456789';                   // Numbers (excluding 0 and 1)
        $sets[] = '!@#$%^&*()_+-=[]{}|;:,.<>?'; // Special characters

        $password = '';

        // Ensure at least one character from each set
        foreach ($sets as $set) {
            $password .= $set[random_int(0, strlen($set) - 1)];
        }

        // Fill the rest with random characters from all sets combined
        $allChars = implode('', $sets);
        for ($i = 0; $i < $length - count($sets); $i++) {
            $password .= $allChars[random_int(0, strlen($allChars) - 1)];
        }

        // Shuffle the password to avoid predictable patterns
        return str_shuffle($password);
    }


    protected $guarded = ['id'];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_admin' => 'boolean',
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(UserLog::class);
    }

    public function favorites(): BelongsToMany
    {
        return $this->belongsToMany(Ad::class, 'ad_favorites', 'user_id', 'ad_id')->withTimestamps();
    }

    public function isAdmin(): bool
    {
        return $this->is_admin;
    }

    public function logAction(string $action, array $details = []): void
    {
        $this->logs()->create([
            'action' => $action,
            'ip_address' => request()->ip(),
            'details' => json_encode($details),
        ]);
    }

    public function scopeAdmins($query)
    {
        return $query->where('is_admin', true);
    }

    public function getMaskedPhoneAttribute(): ?string
    {
        return $this->phone ? substr($this->phone, 0, -4) . '****' : null;
    }
}
