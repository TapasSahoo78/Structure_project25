<?php

namespace App\Observers;

use App\Models\Business;
use App\Services\BusinessService;

class BusinessObserver
{
    protected $businessService;

    public function __construct(BusinessService $businessService)
    {
        $this->businessService = $businessService;
    }

    public function created(Business $business): void
    {
        $this->businessService->syncWithStripe($business);
    }

    public function updated(Business $business): void
    {
        if ($business->wasChanged(['name', 'phone']) || 
            $business->primaryUser->wasChanged(['email'])) {
            $this->businessService->syncWithStripe($business);
        }
    }

    public function saving(Business $business): void
    {
        if ($business->isDirty('stripe_payment_method_id')) {
            $this->businessService->syncWithStripe($business);
        }
    }
}