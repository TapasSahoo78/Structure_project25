<?php

namespace App\Observers;

use App\Models\Plan;
use App\Services\PlanService;

class PlanObserver
{
    protected $planService;

    public function __construct(PlanService $planService)
    {
        $this->planService = $planService;
    }

    public function created(Plan $plan): void
    {
        $this->planService->createStripeProduct($plan);
    }

    public function updated(Plan $plan): void
    {
        if ($plan->wasChanged(['name', 'description', 'price', 'period'])) {
            $this->planService->updateStripeProduct($plan);
        }
    }
}