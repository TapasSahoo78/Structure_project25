<?php

namespace App\Observers;

use App\Models\Subscription;
use App\Services\SubscriptionService;

class SubscriptionObserver
{
    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService)
    {
        $this->subscriptionService = $subscriptionService;
    }

    public function created(Subscription $subscription): void
    {
        $this->subscriptionService->syncWithStripe($subscription);
    }

    public function updated(Subscription $subscription): void
    {
        if ($subscription->wasChanged(['plan_id', 'quantity', 'trial_ends_at', 'ends_at'])) {
            $this->subscriptionService->syncWithStripe($subscription);
        }
    }

    public function deleting(Subscription $subscription): void
    {
        if ($subscription->stripe_id) {
            $this->subscriptionService->cancelSubscription($subscription);
        }
    }
}