<?php

namespace App\Policies;

use App\Models\User;
use App\Models\AdCategory;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdCategoryPolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true; // All authenticated users can view categories
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, AdCategory $adCategory): bool
    {
        return true; // All authenticated users can view a specific category
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return false; // Non-admin users cannot create
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, AdCategory $adCategory): bool
    {
        return false; // Non-admin users cannot update
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, AdCategory $adCategory): bool
    {
        return false; // Non-admin users cannot delete
    }
}