<?php

namespace App\Policies;

use App\Models\User;
use App\Models\AdFavorite;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdFavoritePolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(): bool
    {
        return false; // Only admins can view all ad favorites
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, AdFavorite $adFavorite): bool
    {
        return $user->id === $adFavorite->user_id; // Users can only view their own favorites
    }

   /**
     * Determine whether the user can create models.
     */
    public function create(User $user, User $model): bool
    {
        return $user->id === $model->id; // Users can only create favorites for themselves
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, AdFavorite $adFavorite): bool
    {
        return $user->id === $adFavorite->user_id; // Users can only update their own favorites
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, AdFavorite $adFavorite): bool
    {
        return $user->id === $adFavorite->user_id; // Users can only delete their own favorites
    }
}