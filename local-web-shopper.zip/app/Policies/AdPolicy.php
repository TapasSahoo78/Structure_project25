<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Ad;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdPolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true; // Any one can view all ads
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(): bool
    {
        return true; // Any one can view all any ad
    }

   /**
     * Determine whether the user can create models.
     */
    public function create(User $user, User $model): bool
    {
        return $user->id === $model->id; // Users can only create ads for themselves
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Ad $ad): bool
    {
        return $user->id === $ad->user_id; // Users can only update their own ads
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Ad $ad): bool
    {
        return $user->id === $ad->user_id; // Users can only delete their own ads
    }
}