<?php

namespace App\Policies;

use App\Models\User;
use App\Models\File;
use Illuminate\Auth\Access\HandlesAuthorization;

class FilePolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    public function viewAny(User $user): bool
    {
        return false; // Non-admin users cannot view all files
    }

    public function view(User $user, File $file): bool
    {
        return $user->id === $file->user_id; // Users can only view their own files
    }

    public function create(User $user): bool
    {
        // Allow users to create subscriptions for themselves
        return true;
    }

    public function update(User $user, File $file): bool
    {
        return true; // Non-admin users can update files
    }

    public function delete(User $user, File $file): bool
    {
        return true; // Non-admin users can delete files
    }
}