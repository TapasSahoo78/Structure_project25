<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Invoice;
use Illuminate\Auth\Access\HandlesAuthorization;

class InvoicePolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    public function viewAny(User $user): bool
    {
        return false; // Non-admin users cannot view all invoices
    }

    public function view(User $user, Invoice $invoice): bool
    {
        return $user->id === $invoice->user_id; // Users can only view their own invoices
    }

    public function create(User $user): bool
    {
        return false; // Non-admin users cannot create invoices
    }

    public function update(User $user, Invoice $invoice): bool
    {
        return false; // Non-admin users cannot update invoices
    }

    public function delete(User $user, Invoice $invoice): bool
    {
        return false; // Non-admin users cannot delete invoices
    }
}