<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Plan;
use Illuminate\Auth\Access\HandlesAuthorization;

class PlanPolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(): bool
    {
        return true; // All authenticated users can view plans
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(): bool
    {
        return true; // All authenticated users can view a specific plan
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(): bool
    {
        return false; // Non-admin users cannot create
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(): bool
    {
        return false; // Non-admin users cannot update
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(): bool
    {
        return false; // Non-admin users cannot delete
    }
}