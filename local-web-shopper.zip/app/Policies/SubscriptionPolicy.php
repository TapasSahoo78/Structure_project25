<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Subscription;
use Illuminate\Auth\Access\HandlesAuthorization;

class SubscriptionPolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability): bool|null
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return null;
    }

    public function viewAny(User $user): bool
    {
        return false; // Non-admin users cannot view all subscriptions
    }

    public function view(User $user, Subscription $subscription): bool
    {
        return $user->business_id === $subscription->business_id; // Users can only view their own subscriptions
    }

    public function create(User $user): bool
    {
        // Allow users to create subscriptions only if they have Stripe details and a payment method
        return $user->business->hasStripeDetails() && $user->business->hasPaymentMethod();
    }

    public function update(User $user, Subscription $subscription): bool
    {
        return $user->business_id === $subscription->business_id; // Users can only update their own subscriptions
    }

    public function delete(User $user, Subscription $subscription): bool
    {
        return $user->business_id === $subscription->business_id; // Users can only delete their own subscriptions
    }
}