<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\Business;
use App\Models\Plan;
use App\Models\Subscription;
use App\Observers\BusinessObserver;
use App\Observers\PlanObserver;

use Laravel\Cashier\Cashier;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Cashier::useCustomerModel(Business::class);
        Cashier::useSubscriptionModel(Subscription::class);
        Business::observe(BusinessObserver::class);
        //Plan::observe(PlanObserver::class);
    }
}
