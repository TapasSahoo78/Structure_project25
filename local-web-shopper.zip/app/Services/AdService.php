<?php

namespace App\Services;

use App\Models\Ad;
use App\Models\Address;
use App\Models\AdImage;
use App\Models\Subscription;
use App\Models\File;
use App\Enums\AdStatus;
// use App\Jobs\ActivateScheduledAd;
// use App\Jobs\DeactivateExpiredAd;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\HtmlString;

class AdService
{
    protected $addressService;
    protected $fileService;

    public function __construct(AddressService $addressService, FileService $fileService)
    {
        $this->addressService = $addressService;
        $this->fileService = $fileService;
    }

    public function createAd(array $data): Ad
    {
        return DB::transaction(function () use ($data) {
            if (!isset($data['category_id']) || is_null($data['category_id'])) {
                throw new \InvalidArgumentException('Category must be assigned to create an ad.');
            }

            $address = $this->createOrUpdateAddress($data);

            $ad = Ad::create([
                'business_id' => Auth::user()->business_id,
                'creator_id' => Auth::id(),
                'subscription_id' => $data['subscription_id'] ?? null,
                'start_date' => $data['start_date'] ?? null,
                'end_date' => $data['end_date'] ?? null,
                'category_id' => $data['category_id'],
                'address_id' => $address->id,
                'status' => AdStatus::DRAFT,
                'title' => $data['title'],
                'description' => $this->sanitizeHtml($data['description']),
            ]);

            if (isset($data['file_id'])) {
                AdImage::create([
                    'ad_id' => $ad->id,
                    'file_id' => $data['file_id'],
                    'is_primary' => true,
                    'order' => 1,
                ]);
            }

            $this->updateAdStatus($ad);
            return $ad;
        });
    }

    public function updateAd(Ad $ad, array $data): Ad
    {
        return DB::transaction(function () use ($ad, $data) {
            if (isset($data['category_id']) && is_null($data['category_id'])) {
                throw new \InvalidArgumentException('Category cannot be unset for an ad.');
            }

            $address = $this->createOrUpdateAddress($data, $ad->address);

            $ad->update([
                'subscription_id' => $data['subscription_id'] ?? $ad->subscription_id,
                // 'start_date' => $data['start_date'] ?? $ad->start_date,
                // 'end_date' => $data['end_date'] ?? $ad->end_date,
                'start_date' => $data['start_date'] ?? NULL,
                'end_date' => $data['end_date'] ?? NULL,
                'category_id' => $data['category_id'] ?? $ad->category_id,
                'address_id' => $address->id,
                'title' => $data['title'] ?? $ad->title,
                'description' => isset($data['description']) ? $this->sanitizeHtml($data['description']) : $ad->description,
            ]);

            if (isset($data['file_id'])) {
                $this->updateAdImage($ad, $data['file_id']);
            }

            $this->updateAdStatus($ad);
            return $ad;
        });
    }

    private function updateAdStatus(Ad $ad): void
    {
        if ($ad->start_date) {
            if ($this->canActivateAd($ad)) {
                $startDate = new Carbon($ad->start_date);
                if ($startDate->isToday()) {
                    $this->transitionAdStatus($ad, AdStatus::LIVE);
                } else {
                    $this->scheduleAd($ad, $startDate, new Carbon($ad->end_date));
                }
            } else {
                $this->transitionAdStatus($ad, AdStatus::DRAFT);
            }
        } else {
            $this->transitionAdStatus($ad, AdStatus::DRAFT);
        }
    }

    private function canActivateAd(Ad $ad): bool
    {
        return $ad->primaryImage &&
            $this->hasValidSubscription($ad) &&
            $ad->address &&
            $this->hasValidTitleAndDescription($ad) &&
            $ad->category_id !== null;
    }

    private function hasValidSubscription(Ad $ad): bool
    {
        if (!$ad->subscription_id) {
            return false;
        }

        $subscription = Subscription::find($ad->subscription_id);
        return $subscription && $subscription->valid();
    }

    private function hasValidTitleAndDescription(Ad $ad): bool
    {
        return !empty(trim($ad->title)) && !empty(trim($ad->description));
    }

    private function createOrUpdateAddress(array $data, ?Address $address = null): Address
    {
        $addressData = [
            'street_number' => $data['street_number'] ?? NULL,
            'street_name' => $data['street_name'] ?? NULL,
            'city' => $data['city'] ?? NULL,
            'state' => $data['state'] ?? NULL,
            'postal_code' => $data['postal_code'] ?? NULL,
            'country' => $data['country'] ?? NULL,
            'longitude' => $data['longitude'],
            'latitude' => $data['latitude'],
        ];

        return $this->addressService->createOrUpdateAddress($addressData, $address);
    }

    private function sanitizeHtml(string $html): HtmlString
    {
        $allowed_tags = '<p><br><strong><em><u><h1><h2><h3><h4><h5><h6><img>';
        $allowed_tags .= '<blockquote><code><del><ins><ul><ol><li><dl><dt><dd><sup><sub><small>';

        $sanitized = strip_tags($html, $allowed_tags);
        return new HtmlString($sanitized);
    }

    public function transitionAdStatus(Ad $ad, AdStatus $newStatus, array $additionalData = []): Ad
    {
        return DB::transaction(function () use ($ad, $newStatus, $additionalData) {
            if (in_array($newStatus, [AdStatus::SCHEDULED, AdStatus::LIVE])) {
                $this->validateAdForActiveStatus($ad);
            }
            $ad->status = $newStatus;

            foreach ($additionalData as $key => $value) {
                $ad->{$key} = $value;
            }
            $ad->save();
            return $ad;
        });
    }

    private function validateAdForActiveStatus(Ad $ad): void
    {
        if (!$ad->subscription_id) {
            throw new \InvalidArgumentException('Ad must have a subscription assigned.');
        }

        $subscription = Subscription::find($ad->subscription_id);
        if (!$subscription || !$subscription->valid()) {
            throw new \InvalidArgumentException('Ad must have an active subscription.');
        }

        if (!$ad->primaryImage) {
            throw new \InvalidArgumentException('Ad must have an image.');
        }

        if (!$ad->category_id) {
            throw new \InvalidArgumentException('Ad must have a category assigned.');
        }
    }
    public function makeAdLive(Ad $ad): Ad
    {
        if ($ad->status === AdStatus::SCHEDULED && $ad->start_date <= Carbon::now()) {
            return $this->transitionAdStatus($ad, AdStatus::LIVE);
        }
        return $ad;
    }

    public function scheduleAd(Ad $ad, Carbon $startDate, Carbon $endDate): Ad
    {
        $ad = $this->transitionAdStatus($ad, AdStatus::SCHEDULED, [
            'start_date' => $startDate,
            // 'end_date' => $endDate
        ]);

        // ActivateScheduledAd::dispatch($ad)->delay($startDate);
        // DeactivateExpiredAd::dispatch($ad)->delay($endDate);
        return $ad;
    }

    public function cancelAd(Ad $ad, int $canceledBy, string $reason): Ad
    {
        // return $this->transitionAdStatus($ad, AdStatus::CANCELED, [
        return $this->transitionAdStatus($ad, AdStatus::ENDED, [
            'canceled_on' => Carbon::now(),
            'canceled_by' => $canceledBy,
            'canceled_reason' => $reason
        ]);
    }

    public function endAd(Ad $ad): Ad
    {
        // Set end_date to today
        $ad->end_date = Carbon::today();

        if ($ad->status === AdStatus::LIVE) {
            return $this->transitionAdStatus($ad, AdStatus::ENDED);
        }
        return $ad;
    }

    public function pauseAd(Ad $ad): Ad
    {
        if ($ad->status === AdStatus::LIVE) {
            return $this->transitionAdStatus($ad, AdStatus::PAUSED);
        }
        return $ad;
    }

    public function suspendAd(Ad $ad, string $reason): Ad
    {
        return $this->transitionAdStatus($ad, AdStatus::SUSPENDED, [
            'suspended_reason' => $reason,
            'suspended_at' => Carbon::now()
        ]);
    }

    public function reinstateAd(Ad $ad): Ad
    {
        if (in_array($ad->status, [AdStatus::PAUSED, AdStatus::SUSPENDED])) {
            return $this->transitionAdStatus($ad, AdStatus::LIVE);
        }
        return $ad;
    }

    public function archiveAd(Ad $ad): Ad
    {
        return $this->transitionAdStatus($ad, AdStatus::ARCHIVED);
    }

    public function activateScheduledAds()
    {
        $scheduledAds = Ad::where('status', AdStatus::SCHEDULED)
            ->where('start_date', '<=', Carbon::now())
            ->get();

        foreach ($scheduledAds as $ad) {
            $this->makeAdLive($ad);
        }
    }

    public function endExpiredAds()
    {
        $expiredAds = Ad::where('status', AdStatus::LIVE)
            ->where('end_date', '<=', Carbon::now())
            ->get();

        foreach ($expiredAds as $ad) {
            $this->endAd($ad);
        }
    }

    private function updateAdImage(Ad $ad, int $newFileId): void
    {
        DB::transaction(function () use ($ad, $newFileId) {
            $oldImage = $ad->primaryImage;

            if ($oldImage) {
                $oldFile = $oldImage->file;

                // Delete the old AdImage record
                $oldImage->delete();

                // Delete the old file if it's not used by any other AdImage
                if ($oldFile->adImages()->count() === 0) {
                    $oldFile->deleteFile();
                    $oldFile->delete();
                }
            }

            // Create a new AdImage record
            AdImage::create([
                'ad_id' => $ad->id,
                'file_id' => $newFileId,
                'is_primary' => true,
                'order' => 1,
            ]);
        });
    }

    public function deleteAd(Ad $ad): bool
    {
        return DB::transaction(function () use ($ad) {
            // Delete associated AdImages and their Files
            foreach ($ad->images as $adImage) {
                $file = $adImage->file;

                // Delete the AdImage
                $adImage->delete();

                // Check if the File is not used by any other AdImage
                if ($file->adImages()->count() === 0) {
                    // Use FileService to delete the file
                    $this->fileService->deleteFile($file);
                }
            }

            // Delete the Ad
            return $ad->delete();
        });
    }

    public function publishAd(Ad $ad): Ad
    {
        if ($ad->status === AdStatus::LIVE) {
            throw new \InvalidArgumentException('Ad is already published.');
        }

        if (!$this->canActivateAd($ad)) {
            throw new \InvalidArgumentException('Ad is not ready to be published. Please check all requirements are met.');
        }
        // Set start_date to today
        if (empty($ad->status)) {
            $ad->start_date = Carbon::today();
        }

        return $this->transitionAdStatus($ad, AdStatus::LIVE);
    }
}
