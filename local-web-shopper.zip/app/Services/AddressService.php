<?php

namespace App\Services;

use App\Models\Address;
use Illuminate\Support\Facades\Auth;

class AddressService
{

    public function createOrUpdateAddress(array $data, ?Address $address = null): Address
    {
        if (!$address) {
            $address = new Address();
        }

        $address->fill($data);
        $address->business_id = Auth::user()?->business_id;
        $address->formatted_address = $this->generateFormattedAddress($address);
        $address->save();

        return $address;
    }

    // public function generateFormattedAddress(Address $address): ?string
    // {
    //     $parts = [
    //         $address->street_number . ' ' . $address->street_name,
    //         $address->city,
    //         $address->state,
    //         $address->postal_code,
    //         $address->country
    //     ];

    //     $formattedAddress = implode(', ', array_filter($parts));
    //     return $formattedAddress ?: null;
    // }

    private function generateFormattedAddress(Address $address): ?string
    {
        $parts = [];

        // Add street number and street name if available
        if (!empty($address->street_number) || !empty($address->street_name)) {
            $parts[] = trim($address->street_number . ' ' . $address->street_name);
        }

        // Add other address components if available
        if (!empty($address->city)) {
            $parts[] = $address->city;
        }
        if (!empty($address->state)) {
            $parts[] = $address->state;
        }
        if (!empty($address->postal_code)) {
            $parts[] = $address->postal_code;
        }
        if (!empty($address->country)) {
            $parts[] = $address->country;
        }

        // Join the parts with a comma and return
        $formattedAddress = implode(', ', array_filter($parts));

        // Return null if the address is empty
        return !empty($formattedAddress) ? $formattedAddress : null;
    }
}
