<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Address;
use Stripe\StripeClient;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class BusinessService
{
    protected StripeClient $stripe;
    protected AddressService $addressService;

    public function __construct(AddressService $addressService)
    {
        // info(config('services.stripe.secret'));
        $this->stripe = new StripeClient(config('services.stripe.secret'));
        $this->addressService = $addressService;
    }

    public function syncWithStripe(Business $business): void
    {
        if (!$business->stripe_id) {
            $this->createStripeCustomer($business);
        } else {
            $this->updateStripeCustomer($business);
        }
    }

    public function updatePaymentMethod(Business $business, string $paymentMethodId): array
    {
        try {
            if ($business->stripe_payment_method_id) {
                $this->removeOldPaymentMethod($business);
            }
            $this->attachPaymentMethodToCustomer($business, $paymentMethodId);
            $this->setDefaultPaymentMethod($business, $paymentMethodId);
            $paymentMethod = $this->retrievePaymentMethod($paymentMethodId);
            $this->updateBusinessPaymentDetails($business, $paymentMethod);
            return $this->formatPaymentMethodResponse($business);
        } catch (\Exception $e) {
            // Log::error('Error updating payment method: ' . $e->getMessage());
            Log::error('Error in ' . get_class($this) . '::' . __METHOD__ . ' on line ' . __LINE__ . ': ' . $e->getMessage());
            throw $e;
        }
    }

    protected function removeOldPaymentMethod(Business $business): void
    {
        try {
            $this->stripe->paymentMethods->detach($business->stripe_payment_method_id);
        } catch (\Exception $e) {
            Log::warning("Failed to remove old payment method: " . $e->getMessage());
        }
    }

    protected function createStripeCustomer(Business $business): void
    {
        $customer = $this->stripe->customers->create([
            'name' => $business->name,
            'email' => $business->primaryUser->email,
            'phone' => $business->phone,
        ]);

        $business->stripe_id = $customer->id;
        $business->save();
    }

    protected function updateStripeCustomer(Business $business): void
    {
        $this->stripe->customers->update($business->stripe_id, [
            'name' => $business->name,
            'email' => $business->primaryUser->email,
            'phone' => $business->phone,
        ]);
    }

    protected function attachPaymentMethodToCustomer(Business $business, string $paymentMethodId): void
    {
        $this->stripe->paymentMethods->attach($paymentMethodId, [
            'customer' => $business->stripe_id
        ], [
            // 'stripe_account' => "acct_1OUmkPSIkK0U1wfd"
        ]);
    }

    protected function setDefaultPaymentMethod(Business $business, string $paymentMethodId): void
    {
        $this->stripe->customers->update($business->stripe_id, [
            'invoice_settings' => ['default_payment_method' => $paymentMethodId]
        ]);
    }

    protected function retrievePaymentMethod(string $paymentMethodId): object
    {
        return $this->stripe->paymentMethods->retrieve($paymentMethodId);
    }

    protected function updateBusinessPaymentDetails(Business $business, object $paymentMethod): void
    {
        $business->update([
            'stripe_payment_method_id' => $paymentMethod->id,
            'pm_type' => $paymentMethod->type,
            'pm_last_four' => $paymentMethod->card->last4,
            'pm_brand' => $paymentMethod->card->brand,
            'pm_exp_month' => $paymentMethod->card->exp_month,
            'pm_exp_year' => $paymentMethod->card->exp_year,
            'pm_card_holder_name' => $paymentMethod->billing_details->name ?? null,
        ]);
    }

    protected function formatPaymentMethodResponse(Business $business): array
    {
        return [
            'message' => 'Payment method updated successfully',
            'payment_method' => [
                'id' => $business->stripe_payment_method_id,
                'type' => $business->pm_type,
                'last_four' => $business->pm_last_four,
                'brand' => $business->pm_brand,
                'exp_month' => $business->pm_exp_month,
                'exp_year' => $business->pm_exp_year,
                'card_holder_name' => $business->pm_card_holder_name,
            ]
        ];
    }

    public function updateBusiness(Business $business, array $data): Business
    {
        return DB::transaction(function () use ($business, $data) {
            if ($this->hasAddressFields($data)) {
                $address = $this->createOrUpdateAddress($data, $business->address);
                $business->address_id = $address->id;
            }

            $business->fill([
                'name' => $data['name'] ?? $business->name,
                'phone' => $data['phone'] ?? $business->phone,
                'primary_user_id' => $data['primary_user_id'] ?? $business->primary_user_id,
            ]);

            $business->save();

            $this->syncWithStripe($business);

            return $business;
        });
    }

    protected function hasAddressFields(array $data): bool
    {
        $addressFields = ['street_number', 'street_name', 'city', 'state', 'postal_code', 'country', 'longitude', 'latitude'];
        return count(array_intersect_key(array_flip($addressFields), $data)) > 0;
    }

    protected function createOrUpdateAddress(array $data, ?Address $address = null): Address
    {
        $addressData = [
            'street_number' => $data['street_number'] ?? ($address->street_number ?? null),
            'street_name' => $data['street_name'] ?? ($address->street_name ?? null),
            'city' => $data['city'] ?? ($address->city ?? null),
            'state' => $data['state'] ?? ($address->state ?? null),
            'postal_code' => $data['postal_code'] ?? ($address->postal_code ?? null),
            'country' => $data['country'] ?? ($address->country ?? null),
            'longitude' => $data['longitude'] ?? ($address->longitude ?? null),
            'latitude' => $data['latitude'] ?? ($address->latitude ?? null),
        ];

        return $this->addressService->createOrUpdateAddress($addressData, $address);
    }
}
