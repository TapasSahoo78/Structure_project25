<?php

namespace App\Services;

use App\Models\Coupon;
use App\Models\PromoCode;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Laravel\Cashier\Cashier;
use Stripe\Stripe;
use Stripe\Coupon as StripeCoupon;
use Stripe\Exception\ApiErrorException;

class CouponService
{
    protected $stripe;

    public function __construct()
    {
        $this->stripe = Cashier::stripe();
    }

    /**
     * Create a new coupon in Stripe and the database.
     *
     * @param array $data
     * @return Coupon
     * @throws ApiErrorException
     */
    public function createCoupon(array $data): Coupon
    {
        if (!config('services.stripe.secret')) {
            throw new ApiErrorException('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        return DB::transaction(function () use ($data) {
            try {
                // Prepare Stripe coupon parameters
                $stripeParams = [
                    'name' => $data['code'],
                    'duration' => $data['duration'],
                    'max_redemptions' => $data['max_redemptions'] ?? 1,
                    'redeem_by' => $this->parseRedeemBy($data['redeem_by'] ?? null),
                ];

                // Handle discount type
                if ($data['discount_type'] === 'percent') {
                    $stripeParams['percent_off'] = $data['discount_value'];
                } elseif ($data['discount_type'] === 'amount') {
                    $stripeParams['amount_off'] = $this->convertToCents($data['discount_value'], $data['currency'] ?? 'usd');
                    $stripeParams['currency'] = $data['currency'] ?? 'usd';
                } else {
                    throw new ApiErrorException('Invalid discount type provided.');
                }

                // Create the coupon in Stripe
                $stripeCoupon = StripeCoupon::create($stripeParams);

                // Create the coupon in the database
                $coupon = Coupon::create([
                    'stripe_coupon_id' => $stripeCoupon->id,
                    'code' => $data['code'],
                    'discount_type' => $data['discount_type'],
                    'discount_value' => $data['discount_value'],
                    'duration' => $data['duration'],
                    'max_redemptions' => $data['max_redemptions'] ?? 1,
                    'used_count' => 0,
                    'redeem_by' => $data['redeem_by'] ?? null,
                    'currency' => $data['currency'] ?? 'usd',
                    'is_active' => $data['is_active'] ?? true,
                ]);

                Log::info('Coupon created successfully', [
                    'coupon_id' => $coupon->id,
                    'stripe_coupon_id' => $stripeCoupon->id,
                    'code' => $data['code'],
                ]);

                return $coupon;
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during coupon creation', [
                    'code' => $data['code'] ?? 'unknown',
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()->message ?? 'Unknown Stripe error',
                ]);
                throw new ApiErrorException('Failed to create coupon in Stripe: ' . $e->getError()->message);
            } catch (\Exception $e) {
                Log::error('Unexpected error during coupon creation', [
                    'code' => $data['code'] ?? 'unknown',
                    'error' => $e->getMessage(),
                ]);
                throw new ApiErrorException('An unexpected error occurred while creating the coupon: ' . $e->getMessage());
            }
        });
    }

    /**
     * Update an existing coupon in the database and Stripe.
     *
     * @param Coupon $coupon The existing coupon model to update
     * @param array $data The data to update the coupon with
     * @return Coupon The updated coupon model
     * @throws ApiErrorException
     */
    public function updateCoupon(Coupon $coupon, array $data): Coupon
    {
        if (!config('services.stripe.secret')) {
            throw new ApiErrorException('Stripe configuration is missing.');
        }

        \Stripe\Stripe::setApiKey(config('services.stripe.secret'));

        return DB::transaction(function () use ($coupon, $data) {
            try {
                // Define which fields can safely be updated in Stripe
                $stripeUpdateableParams = [
                    'name' => $data['code'] ?? $coupon->code,
                    'metadata' => [
                        'updated_at' => now()->toISOString(),
                    ],
                ];

                // Detect if any immutable field has changed
                $immutableFieldsChanged = $this->hasImmutableChanges($coupon, $data);

                if ($immutableFieldsChanged) {
                    Log::info('Immutable coupon fields changed, creating new coupon on Stripe', [
                        'coupon_id' => $coupon->id,
                        'old_stripe_coupon_id' => $coupon->stripe_coupon_id,
                    ]);

                    // 1️⃣ Soft archive the existing Stripe coupon
                    try {
                        // \Stripe\Coupon::update($coupon->stripe_coupon_id, [
                        //     'metadata' => ['archived' => 'true', 'replaced_at' => now()->toISOString()],
                        // ]);
                        \Stripe\Coupon::retrieve($coupon->stripe_coupon_id)->delete();
                    } catch (\Exception $e) {
                        Log::warning('Failed to archive old Stripe coupon', [
                            'coupon_id' => $coupon->id,
                            'error' => $e->getMessage(),
                        ]);
                    }

                    // 2️⃣ Create new coupon parameters
                    $stripeParams = [
                        'name' => $data['code'] ?? $coupon->code,
                        'duration' => $data['duration'] ?? $coupon->duration,
                        'max_redemptions' => $data['max_redemptions'] ?? $coupon->max_redemptions ?? 1,
                        'redeem_by' => $this->parseRedeemBy($data['redeem_by'] ?? $coupon->redeem_by),
                        'metadata' => [
                            'previous_coupon_id' => $coupon->stripe_coupon_id,
                            'created_from_update' => 'true',
                        ],
                    ];

                    // 3️⃣ Handle discount type
                    $discountType = $data['discount_type'] ?? $coupon->discount_type;
                    $discountValue = $data['discount_value'] ?? $coupon->discount_value;
                    $currency = $data['currency'] ?? $coupon->currency;

                    if ($discountType === 'percent') {
                        $stripeParams['percent_off'] = $discountValue;
                    } elseif ($discountType === 'amount') {
                        $stripeParams['amount_off'] = $this->convertToCents($discountValue, $currency);
                        $stripeParams['currency'] = $currency;
                    } else {
                        throw new ApiErrorException('Invalid discount type provided.');
                    }

                    // 4️⃣ Create new Stripe coupon
                    $newStripeCoupon = \Stripe\Coupon::create($stripeParams);

                    // 5️⃣ Clone any existing promo codes linked to the old coupon
                    $this->clonePromoCodesToNewCoupon($coupon, $newStripeCoupon->id);

                    // 6️⃣ Update local DB coupon record
                    $coupon->update([
                        'stripe_coupon_id' => $newStripeCoupon->id,
                        'code' => $data['code'] ?? $coupon->code,
                        'discount_type' => $discountType,
                        'discount_value' => $discountValue,
                        'duration' => $data['duration'] ?? $coupon->duration,
                        'max_redemptions' => $data['max_redemptions'] ?? $coupon->max_redemptions ?? 1,
                        'redeem_by' => $data['redeem_by'] ?? $coupon->redeem_by,
                        'currency' => $currency,
                        'is_active' => $data['is_active'] ?? $coupon->is_active,
                    ]);
                } else {
                    // Only updatable fields changed — simple update
                    \Stripe\Coupon::update($coupon->stripe_coupon_id, $stripeUpdateableParams);

                    $coupon->update([
                        'code' => $data['code'] ?? $coupon->code,
                        'max_redemptions' => $data['max_redemptions'] ?? $coupon->max_redemptions ?? 1,
                        'redeem_by' => $data['redeem_by'] ?? $coupon->redeem_by,
                        'is_active' => $data['is_active'] ?? $coupon->is_active,
                    ]);
                }

                Log::info('Coupon updated successfully', [
                    'coupon_id' => $coupon->id,
                    'stripe_coupon_id' => $coupon->stripe_coupon_id,
                    'code' => $coupon->code,
                ]);

                return $coupon;
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during coupon update', [
                    'coupon_id' => $coupon->id,
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()->message ?? 'Unknown Stripe error',
                ]);
                throw new ApiErrorException('Failed to update coupon in Stripe: ' . ($e->getError()->message ?? $e->getMessage()));
            } catch (\Exception $e) {
                Log::error('Unexpected error during coupon update', [
                    'coupon_id' => $coupon->id,
                    'error' => $e->getMessage(),
                ]);
                throw new ApiErrorException('An unexpected error occurred while updating the coupon: ' . $e->getMessage());
            }
        });
    }

    /**
     * Archive a coupon by marking it inactive in the database and Stripe.
     *
     * @param Coupon $coupon
     * @return void
     * @throws ApiErrorException
     */
    public function archiveCoupon(Coupon $coupon): void
    {
        if (!config('services.stripe.secret')) {
            throw new ApiErrorException('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        DB::transaction(function () use ($coupon) {
            try {
                // Mark the Stripe coupon as archived via metadata
                // StripeCoupon::update($coupon->stripe_coupon_id, [
                //     'metadata' => ['archived' => 'true'],
                // ]);
                PromoCode::where('coupon_id', $coupon->stripe_coupon_id)->delete();
                $coupon->delete();
                StripeCoupon::retrieve($coupon->stripe_coupon_id)->delete();

                // Update the coupon in the database to inactive
                // $coupon->update([
                //     'is_active' => false,
                // ]);

                Log::info('Coupon archived successfully', [
                    'coupon_id' => $coupon->id,
                    'stripe_coupon_id' => $coupon->stripe_coupon_id,
                    'code' => $coupon->code,
                ]);
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during coupon archival', [
                    'coupon_id' => $coupon->id,
                    'code' => $coupon->code,
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()->message ?? 'Unknown Stripe error',
                ]);
                return back()->withErrors(['error' => 'Failed to archive coupon in Stripe: ' . $e->getError()->message]);
            } catch (\Exception $e) {
                Log::error('Unexpected error during coupon archival', [
                    'coupon_id' => $coupon->id,
                    'code' => $coupon->code,
                    'error' => $e->getMessage(),
                ]);
                return back()->withErrors(['error' => 'An unexpected error occurred while archiving the coupon: ' . $e->getMessage()]);
            }
        });
    }

    private function hasImmutableChanges(Coupon $coupon, array $data): bool
    {
        $fields = ['discount_type', 'discount_value', 'currency', 'duration', 'redeem_by'];
        $changed = false;

        foreach ($fields as $field) {
            $new = $data[$field] ?? $coupon->$field;
            $old = $coupon->$field;

            // Normalize both
            $newNorm = $this->normalizeField($field, $new);
            $oldNorm = $this->normalizeField($field, $old);

            if ($newNorm !== $oldNorm) {
                Log::debug("Immutable field changed", [
                    'field' => $field,
                    'old' => $oldNorm,
                    'new' => $newNorm,
                ]);
                $changed = true;
            }
        }

        return $changed;
    }

    private function normalizeField(string $field, $value)
    {
        if (is_null($value)) {
            return null;
        }

        switch ($field) {
            case 'discount_value':
                // Always numeric for comparison
                return (float)$value;

            case 'discount_type':
            case 'currency':
            case 'duration':
                // Case-insensitive string compare
                return strtolower(trim((string)$value));

            case 'redeem_by':
                // Normalize dates to Carbon date string (Y-m-d)
                try {
                    return \Carbon\Carbon::parse($value)->format('Y-m-d');
                } catch (\Exception $e) {
                    // In case of invalid date string, fallback to trimmed value
                    return trim((string)$value);
                }

            default:
                return $value;
        }
    }

    /**
     * Parse redeem_by date string to Unix timestamp (Stripe expects seconds since epoch).
     *
     * @param string|null $date YYYY-MM-DD format or null
     * @return int|null Unix timestamp or null
     * @throws ApiErrorException
     */
    private function parseRedeemBy(?string $date): ?int
    {
        if (!$date) {
            return null;
        }

        try {
            return \Carbon\Carbon::parse($date)->endOfDay()->timestamp;
        } catch (\Exception $e) {
            throw new ApiErrorException('Invalid redeem_by date format: ' . $e->getMessage());
        }
    }

    /**
     * Convert decimal amount to cents (Stripe expects integers in smallest currency unit).
     *
     * @param float $amount e.g., 5.00
     * @param string $currency e.g., 'usd'
     * @return int e.g., 500
     * @throws ApiErrorException
     */
    private function convertToCents(float $amount, string $currency): int
    {
        if ($amount < 0) {
            throw new ApiErrorException('Discount value must be non-negative.');
        }

        $decimals = $this->getCurrencyDecimals($currency);
        return (int) round($amount * pow(10, $decimals));
    }

    /**
     * Get the number of decimal places for a currency.
     *
     * @param string $currency
     * @return int
     */
    private function getCurrencyDecimals(string $currency): int
    {
        $decimals = [
            'usd' => 2,
            'eur' => 2,
            'gbp' => 2,
            'jpy' => 0,
            'krw' => 0,
            'vnd' => 0,
        ];

        return $decimals[strtolower($currency)] ?? 2;
    }
    /**
     * Clone all promo codes from an existing coupon to a new Stripe coupon.
     */
    private function clonePromoCodesToNewCoupon(Coupon $coupon, string $newStripeCouponId): void
    {
        $promoCodes = PromoCode::where('coupon_id', $coupon->stripe_coupon_id)->get();
        foreach ($promoCodes as $promoCode) {
            try {
                // Deactivate old promo code first (to reuse same code)
                try {
                    \Stripe\PromotionCode::update($promoCode->stripe_promo_code_id, [
                        'active' => false,
                        'metadata' => ['archived' => 'true', 'archived_at' => now()->toISOString()],
                    ]);
                } catch (\Exception $e) {
                    Log::warning('Failed to deactivate old promo code before cloning', [
                        'promo_code' => $promoCode->code,
                        'error' => $e->getMessage(),
                    ]);
                }
                // Create new promo code on Stripe
                $newStripePromoCode = \Stripe\PromotionCode::create([
                    'coupon' => $newStripeCouponId,
                    'code' => $promoCode->code, // reuse same human-readable code
                    'max_redemptions' => $promoCode->max_redemptions,
                    'expires_at' => $promoCode->expires_at ? Carbon::parse($promoCode->expires_at)->timestamp : null,
                    'metadata' => [
                        'cloned_from' => $promoCode->stripe_promo_code_id,
                        'cloned_at' => now()->toISOString(),
                    ],
                ]);

                info($newStripePromoCode);
                Log::info('-=====================', [
                    'details' => $newStripePromoCode
                ]);

                // Update promo code in DB
                $promoCode->update([
                    'stripe_promo_code_id' => $newStripePromoCode->id,
                    'coupon_id' => $newStripeCouponId,
                ]);

                Log::info('Promo code cloned for new coupon', [
                    'promo_code' => $promoCode->code,
                    'new_stripe_promo_code_id' => $newStripePromoCode->id,
                ]);
            } catch (\Stripe\Exception\InvalidRequestException $e) {
                if (str_contains($e->getMessage(), 'already exists')) {
                    Log::warning('Promo code already exists, skipping', [
                        'promo_code' => $promoCode->code,
                    ]);
                    continue;
                }

                Log::error('Stripe error cloning promo code', [
                    'promo_code' => $promoCode->code,
                    'error' => $e->getMessage(),
                ]);
            } catch (\Exception $e) {
                Log::error('Unexpected error cloning promo code', [
                    'promo_code' => $promoCode->code,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
}
