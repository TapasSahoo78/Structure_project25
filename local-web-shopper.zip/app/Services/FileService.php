<?php

namespace App\Services;

use App\Models\File;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

class FileService
{
    public function uploadFile(UploadedFile $uploadedFile, int $businessId, int $creatorId): File
    {
        $path = 'uploads/images';
        $filename = Str::uuid() . '.' . $uploadedFile->getClientOriginalExtension();

        $file = new File([
            'business_id' => $businessId,
            'creator_id' => $creatorId,
            'real' => $filename,
            'name' => $uploadedFile->getClientOriginalName(),
            'mime_type' => $uploadedFile->getMimeType(),
            'path' => $path,
            'hash' => hash_file('md5', $uploadedFile->getRealPath()),
            'size' => $uploadedFile->getSize(),
        ]);

        Storage::disk('public')->putFileAs($path, $uploadedFile, $filename);

        $file->save();

        return $file;
    }

    public function getFile(File $file): StreamedResponse
    {
        $path = $file->getFullPath();
        
        if (!Storage::disk('public')->exists($path)) {
            throw new \Exception('File not found');
        }

        return Storage::disk('public')->response($path, $file->name, [
            'Content-Type' => $file->mime_type,
            'Content-Length' => $file->size,
        ]);
    }

    public function updateFileName(File $file, string $newName): File
    {
        $file->name = $newName;
        $file->save();

        return $file;
    }

    public function deleteFile(File $file): bool
    {
        $file->adImages()->delete();
        if (Storage::disk('public')->exists($file->getFullPath())) {
            Storage::disk('public')->delete($file->getFullPath());
            return $file->delete();
        }
        return false;
    }
}