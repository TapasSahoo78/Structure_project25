<?php

namespace App\Services;

use App\Models\UserLog;
use Illuminate\Support\Facades\Auth;

class LogService
{
    public static function logAction(string $action, array $details = [])
    {
        $user = Auth::user();

        if (!$user) {
            return;
        }

        UserLog::create([
            'user_id' => $user->id,
            'action' => $action,
            'ip_address' => request()->ip(),
            'details' => json_encode($details),
        ]);
    }
}
