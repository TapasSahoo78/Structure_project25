<?php

namespace App\Services;

use App\Models\Plan;
use App\Enums\PlanPeriod;
use Illuminate\Support\Facades\Log;
use Laravel\Cashier\Cashier;
use Stripe\Exception\ApiErrorException;

class PlanService
{
    protected $stripe;

    public function __construct()
    {
        $this->stripe = Cashier::stripe();
    }

    public function createPlan(array $data): Plan
    {
        try {
            $period = PlanPeriod::from($data['period']);
            $product = $this->stripe->products->create([
                'name' => $data['name'],
                'description' => $data['description'],
                'default_price_data' => [
                    'currency' => 'usd',
                    'unit_amount' => $data['price'] * 100,
                    'recurring' => [
                        'interval' => $period->getStripeValue(),
                        'interval_count' => $period->getIntervalCount(),
                    ],
                ],
                'metadata' => [
                    'size' => $data['size'],
                    'radius' => $data['radius'],
                    'period' => $data['period'],
                ],
            ]);

            $data['stripe_price_id'] = $product->default_price;
            $data['stripe_product_id'] = $product->id;

            return Plan::create($data);
        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error: ' . $e->getMessage());
            throw $e;
        }
    }

    public function updatePlan(Plan $plan, array $data): Plan
    {
        try {
            $this->stripe->products->update($plan->stripe_product_id, [
                'name' => $data['name'],
                'description' => $data['description'],
                'metadata' => [
                    'size' => $data['size'] ?? $plan->size,
                    'radius' => $data['radius'] ?? $plan->radius,
                    'period' => $data['period'] ?? $plan->period,
                ],
            ]);

            $priceChanged = isset($data['price']) && $data['price'] != $plan->price;
            $periodChanged = isset($data['period']) && $data['period'] != $plan->period;

            if ($priceChanged || $periodChanged) {
                $period = $periodChanged ? PlanPeriod::from($data['period']) : PlanPeriod::from($plan->period);
                $newPrice = $this->stripe->prices->create([
                    'product' => $plan->stripe_product_id,
                    'unit_amount' => ($priceChanged ? $data['price'] : $plan->price) * 100,
                    'currency' => 'usd',
                    'recurring' => [
                        'interval' => $period->getStripeValue(),
                        'interval_count' => $period->getIntervalCount(),
                    ],
                ]);

                // Set the new price as the default for the product
                $this->stripe->products->update($plan->stripe_product_id, [
                    'default_price' => $newPrice->id,
                ]);

                $data['stripe_price_id'] = $newPrice->id;
            }

            $plan->update($data);

            return $plan;
        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error: ' . $e->getMessage());
            throw $e;
        }
    }

    public function archivePlan(Plan $plan): void
    {
        try {
            $dummyPrice = $this->stripe->prices->create([
                'product' => $plan->stripe_product_id,
                'unit_amount' => 999999,
                'currency' => 'usd',
            ]);

            $this->stripe->products->update($plan->stripe_product_id, [
                'default_price' => $dummyPrice->id,
                'active' => false,
            ]);

            $prices = $this->stripe->prices->all(['product' => $plan->stripe_product_id]);
            foreach ($prices->data as $price) {
                if ($price->id !== $dummyPrice->id) {
                    $this->stripe->prices->update($price->id, ['active' => false]);
                }
            }

            $plan->delete();
        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error: ' . $e->getMessage());
            throw $e;
        }
    }
}