<?php

namespace App\Services;

use App\Models\PromoCode;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Laravel\Cashier\Cashier;
use Stripe\Stripe;
use Stripe\PromotionCode;
use Stripe\Exception\ApiErrorException;

class PromoCodeService
{
    protected $stripe;

    public function __construct()
    {
        $this->stripe = Cashier::stripe();
    }

    /**
     * Create a new promo code in Stripe and the database.
     *
     * @param array $data
     * @return PromoCode
     * @throws ApiErrorException
     */
    public function createPromoCode(array $data): PromoCode
    {
        if (!config('services.stripe.secret')) {
            throw new \Exception('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        return DB::transaction(function () use ($data) {
            try {
                // Prepare Stripe promo code parameters
                $stripeParams = [
                    'coupon' => $data['coupon_id'],
                    'code' => $data['code'],
                    'active' => $data['is_active'] ?? true,
                ];

                if (isset($data['max_redemptions'])) {
                    $stripeParams['max_redemptions'] = $data['max_redemptions'];
                }

                if (isset($data['expires_at'])) {
                    $stripeParams['expires_at'] = strtotime($data['expires_at']);
                }

                // Create the promo code in Stripe
                $stripePromoCode = PromotionCode::create($stripeParams);

                // Create the promo code in the database
                $promoCode = PromoCode::create([
                    'stripe_promo_code_id' => $stripePromoCode->id,
                    'code' => $stripePromoCode->code,
                    'coupon_id' => $stripePromoCode->coupon->id,
                    'max_redemptions' => $stripePromoCode->max_redemptions,
                    'used_count' => 0,
                    'expires_at' => $stripePromoCode->expires_at ? date('Y-m-d H:i:s', $stripePromoCode->expires_at) : null,
                    'is_active' => $stripePromoCode->active,
                ]);

                Log::info('PromoCode created successfully', [
                    'promo_code_id' => $promoCode->id,
                    'stripe_promo_code_id' => $stripePromoCode->id,
                    'code' => $data['code'],
                ]);

                return $promoCode;
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during promo code creation', [
                    'code' => $data['code'] ?? 'unknown',
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()->message ?? 'Unknown Stripe error',
                ]);
                throw new \Exception('Failed to create promo code in Stripe: ' . $e->getMessage() ?? $e->getError()->message);
            } catch (\Exception $e) {
                Log::error('Unexpected error during promo code creation', [
                    'code' => $data['code'] ?? 'unknown',
                    'error' => $e->getMessage(),
                ]);
                throw new \Exception('An unexpected error occurred while creating the promo code: ' . $e->getMessage());
                // return back()->withErrors(['error' => 'An unexpected error occurred while creating the promo code: ' . $e->getMessage()]);
            }
        });
    }

    /**
     * Update an existing coupon in the database and Stripe.
     *
     * @param PromoCode $promoCode The existing coupon model to update
     * @param array $data The data to update the coupon with
     * @return PromoCode The updated coupon model
     * @throws \Exception
     */
    public function updatePromoCode(PromoCode $promoCode, array $data): PromoCode
    {
        if (!config('services.stripe.secret')) {
            throw new \Exception('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        return DB::transaction(function () use ($promoCode, $data) {
            try {
                // Only allow updating fields that Stripe supports
                $stripeParams = [
                    'active' => $data['is_active'] ?? $promoCode->is_active,
                    'metadata' => [
                        'updated_at' => now()->toISOString(),
                    ],
                ];

                // Log what we're sending to Stripe
                info('Updating Stripe promo code with params:', $stripeParams);

                // Retrieve and update only allowed fields
                $stripePromoCode = PromotionCode::retrieve($promoCode->stripe_promo_code_id);
                $stripePromoCode->active = $stripeParams['active'];
                $stripePromoCode->metadata = $stripeParams['metadata'];
                $stripePromoCode->save();

                // For safety, we keep the Stripe-truth values in DB
                $promoCode->update([
                    'code' => $stripePromoCode->code, // unchanged
                    'max_redemptions' => $stripePromoCode->max_redemptions, // unchanged
                    'expires_at' => $stripePromoCode->expires_at ? date('Y-m-d H:i:s', $stripePromoCode->expires_at) : null, // unchanged
                    'is_active' => $stripePromoCode->active,
                ]);

                Log::info('PromoCode updated successfully', [
                    'promo_code_id' => $promoCode->id,
                    'stripe_promo_code_id' => $stripePromoCode->id,
                    'code' => $stripePromoCode->code,
                ]);

                return $promoCode;
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during promo code update', [
                    'promo_code_id' => $promoCode->id,
                    'code' => $data['code'] ?? $promoCode->code,
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()?->message ?? 'Unknown Stripe error',
                ]);
                throw new \Exception('Failed to update promo code in Stripe: ' . ($e->getError()?->message ?? $e->getMessage()));
            } catch (\Exception $e) {
                Log::error('Unexpected error during promo code update', [
                    'promo_code_id' => $promoCode->id,
                    'code' => $data['code'] ?? $promoCode->code,
                    'error' => $e->getMessage(),
                ]);
                throw new \Exception('An unexpected error occurred while updating the promo code: ' . $e->getMessage());
            }
        });
    }

    /**
     * Archive a coupon by marking it inactive in the database and Stripe.
     *
     * @param PromoCode $promoCode
     * @return void
     * @throws ApiErrorException
     */
    public function archivePromoCode(PromoCode $promoCode): void
    {
        if (!config('services.stripe.secret')) {
            throw new \Exception('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        DB::transaction(function () use ($promoCode) {
            try {
                // Mark the Stripe coupon as archived via metadata
                PromotionCode::update($promoCode->stripe_promo_code_id, [
                    'metadata' => ['archived' => 'true'],
                ]);
                // $promoCode->delete();
                // PromotionCode::retrieve($promoCode->stripe_coupon_id)->delete();

                // Update the coupon in the database to inactive
                $promoCode->update([
                    'is_active' => false,
                ]);

                Log::info('PromoCode archived successfully', [
                    'coupon_id' => $promoCode->id,
                    'stripe_coupon_id' => $promoCode->stripe_coupon_id,
                    'code' => $promoCode->code,
                ]);
            } catch (\Stripe\Exception\ApiErrorException $e) {
                Log::error('Stripe API error during coupon archival', [
                    'coupon_id' => $promoCode->id,
                    'code' => $promoCode->code,
                    'error' => $e->getMessage(),
                    'stripe_error' => $e->getError()->message ?? 'Unknown Stripe error',
                ]);
                return back()->withErrors(['error' => 'Failed to archive coupon in Stripe: ' . $e->getError()->message]);
            } catch (\Exception $e) {
                Log::error('Unexpected error during coupon archival', [
                    'coupon_id' => $promoCode->id,
                    'code' => $promoCode->code,
                    'error' => $e->getMessage(),
                ]);
                return back()->withErrors(['error' => 'An unexpected error occurred while archiving the coupon: ' . $e->getMessage()]);
            }
        });
    }

    /**
     * Parse redeem_by date string to Unix timestamp (Stripe expects seconds since epoch).
     *
     * @param string|null $date YYYY-MM-DD format or null
     * @return int|null Unix timestamp or null
     * @throws ApiErrorException
     */
    private function parseRedeemBy(?string $date): ?int
    {
        if (!$date) {
            return null;
        }

        try {
            return \Carbon\Carbon::parse($date)->endOfDay()->timestamp;
        } catch (\Exception $e) {
            throw new ApiErrorException('Invalid redeem_by date format: ' . $e->getMessage());
        }
    }

    /**
     * Convert decimal amount to cents (Stripe expects integers in smallest currency unit).
     *
     * @param float $amount e.g., 5.00
     * @param string $currency e.g., 'usd'
     * @return int e.g., 500
     * @throws ApiErrorException
     */
    private function convertToCents(float $amount, string $currency): int
    {
        if ($amount < 0) {
            throw new ApiErrorException('Discount value must be non-negative.');
        }

        $decimals = $this->getCurrencyDecimals($currency);
        return (int) round($amount * pow(10, $decimals));
    }

    /**
     * Get the number of decimal places for a currency.
     *
     * @param string $currency
     * @return int
     */
    private function getCurrencyDecimals(string $currency): int
    {
        $decimals = [
            'usd' => 2,
            'eur' => 2,
            'gbp' => 2,
            'jpy' => 0,
            'krw' => 0,
            'vnd' => 0,
        ];

        return $decimals[strtolower($currency)] ?? 2;
    }
}
