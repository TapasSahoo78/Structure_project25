<?php

namespace App\Services;

use App\Models\Plan;
use App\Models\Subscription;
use App\Models\Ad;
use App\Models\Business;
use App\Enums\AdStatus;
use App\Models\Coupon;
use App\Models\PromoCode;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Stripe\Stripe;
use Stripe\Exception\ApiErrorException;

class SubscriptionService
{
    public function createSubscriptionFromPlan(Business $business, Plan $plan, Request $request): Subscription
    {
        $params = $this->getSubscriptionParams($request, $plan);
        $subscription = $business->newSubscription($plan->stripe_product_id, $plan->stripe_price_id)
            ->create($business->stripe_payment_method_id, [], $params);

        $endsAt = $this->calculateEndsAt($request, $plan);

        $subscription->forceFill([
            'name'       => $request->name ?? "$plan->name #{$subscription->id}",
            'plan_id' => $plan->id,
            'ends_at' => $endsAt,
            'creator_id' => auth()->user()->id
        ])->save();

        return $subscription;
    }

    // public function createSubscription(Request $request, Plan $plan): Subscription
    // {
    //     $params = $this->getSubscriptionParams($request, $plan);
    //     $subscription = auth()->user()->business->newSubscription($plan->stripe_product_id, $plan->stripe_price_id)
    //         ->create(auth()->user()->business->stripe_payment_method_id, [], $params);

    //     $endsAt = $this->calculateEndsAt($request, $plan);

    //     $subscription->forceFill([
    //         'name'       => $request->name ?? "$plan->name #{$subscription->id}",
    //         'plan_id' => $plan->id,
    //         'ends_at'    => $endsAt,
    //         'creator_id' => auth()->user()->id
    //     ])->save();
    //     return $subscription;
    // }

    // public function createSubscription(Request $request, Plan $plan): Subscription
    // {
    //     // Validate request
    //     $request->validate([
    //         'name' => 'sometimes|string|max:255',
    //         'coupon_code' => 'nullable|string|min:2',
    //         'auto_renew' => 'sometimes|boolean',
    //         'cycles' => 'sometimes|integer|min:1|max:12',
    //     ]);
    //     // Get subscription parameters
    //     $params = $this->getSubscriptionParams($request, $plan);

    //     // Initialize subscription builder
    //     $subscriptionBuilder = Auth::user()->business->newSubscription(
    //         $plan->stripe_product_id,
    //         $plan->stripe_price_id
    //     );

    //     // Apply coupon if provided
    //     $coupon = null;
    //     $discountAmount = null;
    //     if ($request->promo_code) {
    //         $promoCode = PromoCode::where('code', $request->promo_code)
    //             ->where('is_active', true)
    //             ->first();
    //         if (!$promoCode) {
    //             throw ValidationException::withMessages([
    //                 'promo_code' => 'Invalid or inactive promo code.',
    //             ]);
    //         }
    //         $coupon = Coupon::where('stripe_coupon_id', $promoCode->stripe_coupon_id)
    //             ->where('is_active', true)
    //             ->first();
    //         // Check if coupon is expired
    //         if ($promoCode->expires_at && Carbon::parse($promoCode->expires_at)->isPast()) {
    //             throw ValidationException::withMessages([
    //                 'promo_code' => 'This promo code has expired.',
    //             ]);
    //         }
    //         // Check max_redemptions
    //         if ($promoCode->max_redemptions > 0 && $promoCode->used_count >= $promoCode->max_redemptions) {
    //             throw ValidationException::withMessages([
    //                 'promo_code' => 'This promo code has reached its maximum usage limit.',
    //             ]);
    //         }
    //         $promoCodeId = $promoCode->stripe_promo_code_id;
    //         $subscriptionBuilder->withCoupon($coupon->stripe_coupon_id);
    //         $discountAmount = $this->calculateDiscount($coupon, $plan->price);
    //     }

    //     // Create subscription
    //     try {
    //         $stripePromoCode = \Stripe\PromotionCode::retrieve($promoCodeId);

    //         if (!$stripePromoCode->active) {
    //             throw ValidationException::withMessages([
    //                 'code' => 'The promo code is invalid or inactive in Stripe.',
    //             ]);
    //         }
    //         if ($promoCodeId) {
    //             $params['promotion_code'] = $promoCodeId;  // Pass to Stripe API
    //         }
    //         $subscription = $subscriptionBuilder->create(
    //             Auth::user()->business->stripe_payment_method_id,
    //             [],
    //             $params
    //         );

    //         // Increment used_count for coupon
    //         if ($coupon) {
    //             $coupon->increment('used_count');
    //         }

    //         // Calculate end date for non-auto-renewing subscriptions
    //         $endsAt = $this->calculateEndsAt($request, $plan);

    //         // Update database subscription with additional details
    //         $subscription->forceFill([
    //             'name' => $request->name ?? "$plan->name #{$subscription->id}",
    //             'plan_id' => $plan->id,
    //             'ends_at' => $endsAt,
    //             'creator_id' => Auth::user()->id,
    //             'promo_code' => $request->promo_code ?? null,
    //             'coupon_code' => $coupon->code ?? null,
    //             'discount_amount' => $discountAmount,
    //             'stripe_coupon_id' => $coupon ? $coupon->stripe_coupon_id : null,
    //         ])->save();

    //         return $subscription;
    //     } catch (\Stripe\Exception\InvalidRequestException $e) {
    //         if (str_contains($e->getMessage(), 'No such coupon')) {
    //             throw ValidationException::withMessages([
    //                 'coupon_code' => 'The promo code is invalid or no longer active.',
    //             ]);
    //         }
    //         throw $e;
    //     }
    // }

    public function createSubscription(Request $request, Plan $plan): Subscription
    {
        // Validate request
        $request->validate([
            'name' => 'sometimes|string|max:255',
            'promo_code' => 'nullable|string|min:2', // corrected
            'auto_renew' => 'sometimes|boolean',
            'cycles' => 'sometimes|integer|min:1|max:12',
        ]);

        if (!config('services.stripe.secret')) {
            throw new ApiErrorException('Stripe configuration is missing.');
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        $params = $this->getSubscriptionParams($request, $plan);

        $business = Auth::user()->business;
        $subscriptionBuilder = $business->newSubscription(
            $plan->stripe_product_id,
            $plan->stripe_price_id
        );

        $coupon = null;
        $discountAmount = null;
        $promoCodeId = null;

        // Handle promo code if provided
        if ($request->filled('promo_code')) {
            $promoCode = PromoCode::where('code', $request->promo_code)
                ->where('is_active', true)
                ->first();

            if (!$promoCode) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Invalid or inactive promo code.',
                ]);
            }

            // Check expiration
            if ($promoCode->expires_at && Carbon::parse($promoCode->expires_at)->isPast()) {
                throw ValidationException::withMessages([
                    'promo_code' => 'This promo code has expired.',
                ]);
            }

            // Check usage limits
            if ($promoCode->max_redemptions > 0 && $promoCode->used_count >= $promoCode->max_redemptions) {
                throw ValidationException::withMessages([
                    'promo_code' => 'This promo code has reached its maximum usage limit.',
                ]);
            }

            $promoCodeId = $promoCode->stripe_promo_code_id;

            // Verify promo code on Stripe
            try {
                $stripePromoCode = \Stripe\PromotionCode::retrieve($promoCodeId);

                if (!$stripePromoCode->active) {
                    throw ValidationException::withMessages([
                        'promo_code' => 'The promo code is inactive in Stripe.',
                    ]);
                }

                // Attach promotion code to subscription
                $params['promotion_code'] = $promoCodeId;

                // Get associated coupon and discount info
                $coupon = Coupon::where('stripe_coupon_id', $promoCode->stripe_coupon_id)
                    ->where('is_active', true)
                    ->first();

                if ($coupon) {
                    $discountAmount = $this->calculateDiscount($coupon, $plan->price);
                }
            } catch (\Stripe\Exception\InvalidRequestException $e) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Invalid promo code in Stripe.',
                ]);
            }
        }

        // Create subscription in Stripe
        $subscription = $subscriptionBuilder->create(
            $business->stripe_payment_method_id,
            [],
            $params
        );

        // Increment coupon usage
        if ($promoCode ?? false) {
            $promoCode->increment('used_count');
        }

        // Calculate end date if non-renewing
        $endsAt = $this->calculateEndsAt($request, $plan);

        // Update database record
        $subscription->forceFill([
            'name' => $request->name ?? "{$plan->name} #{$subscription->id}",
            'plan_id' => $plan->id,
            'ends_at' => $endsAt,
            'creator_id' => Auth::id(),
            'promo_code' => $request->promo_code,
            'coupon_code' => $coupon->code ?? null,
            'discount_amount' => $discountAmount,
            'stripe_coupon_id' => $coupon->stripe_coupon_id ?? null,
        ])->save();

        return $subscription;
    }

    /**
     * Calculate the discount amount based on the coupon and plan price.
     *
     * @param Coupon $coupon
     * @param float $planPrice
     * @return float|null
     */
    private function calculateDiscount(Coupon $coupon, float $planPrice): ?float
    {
        if ($coupon->discount_type === 'percent') {
            return $planPrice * ($coupon->discount_value / 100);
        }
        return $coupon->discount_value;
    }
    public function cancelSubscription(Subscription $subscription): void
    {
        $subscription->cancel();
        $subscription->refresh();

        Ad::where('business_id', auth()->user()->business_id)
            ->where('status', AdStatus::LIVE)
            ->where('subscription_id', $subscription->id)
            ->update([
                "end_date"        => $subscription->ends_at,
            ]);

        info("SUBSCRIPTION : CANCEL SUBSCRIPTION #{$subscription->id} set to cancel at period end on {$subscription->ends_at}");
    }
    private function calcEndDate($start_date, $cycles, $type): mixed
    {
        return match ($type) {
            'Daily'       => $start_date->addDays($cycles),
            'Monthly'     => $start_date->addMonths($cycles),
            'Quarterly'   => $start_date->addMonths($cycles * 3),
            'Biannually' => $start_date->addMonths($cycles * 6),
            'Annually'    => $start_date->addYears($cycles),
        };
    }
    private function calculateEndsAt(Request $request, Plan $plan): ?Carbon
    {
        if (!$request->auto_renew) {
            return Carbon::parse($this->calcEndDate(now(), $request->cycles, $plan->period->getHuman()));
        }
        return null; // For auto-renewing subscriptions, ends_at should be null
    }
    private function getSubscriptionParams(Request $request, Plan $plan): array
    {
        $params = [
            'metadata'           => ['lws_business_id' => auth()->user()->business_id],
            'proration_behavior' => 'none'
        ];

        if (!$request->auto_renew) {
            $params['cancel_at'] = $this->calculateEndsAt($request, $plan)->getTimestamp();
        }

        return $params;
    }
}
