<?php

namespace App\Services;

use App\Models\User;
use App\Models\Business;
use App\Models\Address;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class UserOnboardingService
{
    protected $addressService;

    public function __construct(AddressService $addressService)
    {
        $this->addressService = $addressService;
    }

    public function onboard(array $data): User
    {
        Log::info('Onboarding data received:', $data);

        return DB::transaction(function () use ($data) {
            // 1. Create the User
            $user = User::create([
                'fname' => $data['fname'],
                'lname' => $data['lname'],
                'name' => $data['fname'] . ' ' . $data['lname'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
            ]);

            // 2. Create the Address
            $addressData = [
                'formatted_address' => $data['formatted_address'],
                'street_number' => $data['street_number'],
                'street_name' => $data['street_name'],
                'city' => $data['city'],
                'state' => $data['state'],
                'postal_code' => $data['postal_code'],
                'country' => $data['country'],
                'latitude' => $data['latitude'],
                'longitude' => $data['longitude'],
            ];
            $address = $this->addressService->createOrUpdateAddress($addressData);

            // 3. Create the Business
            $business = Business::create([
                'name' => $data['business_name'],
                'phone' => $data['phone'],
                'primary_user_id' => $user->id,
                'address_id' => $address->id,
            ]);

            // 4. Link the business to the user and address
            $user->update(['business_id' => $business->id]);
            $address->update(['business_id' => $business->id]);

            return $user;
        });
    }
}
