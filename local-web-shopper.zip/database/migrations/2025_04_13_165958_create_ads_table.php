<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ads', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description');
            $table->unsignedBigInteger('business_id');
            $table->unsignedBigInteger('creator_id');
            $table->unsignedBigInteger('address_id')->nullable();
            $table->integer('view_count')->default(0);
            $table->timestamp('start_date')->nullable();
            $table->timestamp('end_date')->nullable();
            $table->unsignedBigInteger('subscription_id')->nullable();
            $table->date('suspended_on')->nullable();
            $table->unsignedBigInteger('suspended_by')->nullable();
            $table->string('suspended_reason')->nullable();
            $table->string('status');
            $table->unsignedBigInteger('category_id');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ads');
    }
};