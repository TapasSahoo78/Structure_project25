<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('business_id');
            $table->string('stripe_id')->unique();
            $table->string('customer_id');
            $table->string('subscription_id')->nullable();
            $table->string('status');
            $table->timestamp('due_date');
            $table->integer('amount_due');
            $table->integer('amount_paid');
            $table->integer('amount_remaining');
            $table->string('currency');
            $table->timestamp('period_start')->nullable();
            $table->timestamp('period_end')->nullable();
            $table->string('invoice_pdf')->nullable();
            $table->string('hosted_invoice_url')->nullable();
            $table->boolean('paid');
            $table->timestamp('paid_at')->nullable();
            $table->string('payment_intent_id')->nullable();
            $table->json('status_transitions')->nullable();
            $table->string('stripe_invoice_number')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoices');
    }
};