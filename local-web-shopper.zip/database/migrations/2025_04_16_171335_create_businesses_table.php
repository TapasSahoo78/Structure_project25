<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBusinessesTable extends Migration
{
    public function up()
    {
        Schema::create('businesses', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('phone')->nullable();
            $table->unsignedBigInteger('primary_user_id');
            $table->unsignedBigInteger('address_id')->nullable();
            $table->timestamps();

            $table->string('stripe_id')->nullable();
            $table->string('stripe_payment_method_id')->nullable();
            $table->string('pm_type')->nullable();
            $table->string('pm_last_four')->nullable();
            $table->string('pm_brand')->nullable();
            $table->string('pm_exp_month')->nullable();
            $table->string('pm_exp_year')->nullable();
            $table->string('pm_card_holder_name')->nullable();
            $table->timestamp('trial_ends_at')->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('businesses');
    }
}