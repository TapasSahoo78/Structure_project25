<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->id(); // Primary key: coupon ID
            $table->string('stripe_coupon_id')->unique(); // Stripe's coupon ID (e.g., 'SAVE_aBcDeFgH')
            $table->string('code')->unique(); // Human-readable code (e.g., 'SAVE20')
            $table->enum('discount_type', ['percent', 'amount'])->default('percent'); // Type of discount
            $table->decimal('discount_value', 8, 2); // e.g., 20.00 for 20% or $5.00
            $table->enum('duration', ['once', 'repeating', 'forever'])->default('once'); // Stripe duration
            $table->integer('max_redemptions')->default(1); // Max total uses
            $table->integer('used_count')->default(0); // Track how many times used
            $table->timestamp('redeem_by')->nullable(); // Expiration date (from Stripe's redeem_by)
            $table->string('currency')->default('usd'); // Currency (if amount_off)
            $table->boolean('is_active')->default(true); // App-specific: active/inactive
            $table->timestamps(); // created_at and updated_at

            // Optional: Soft deletes for easier management
            $table->softDeletes();

            // Indexes for performance
            $table->index(['code', 'is_active']);
            $table->index('redeem_by');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coupons');
    }
};
