<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('promo_codes', function (Blueprint $table) {
            $table->id();
            $table->string('stripe_promo_code_id')->unique()->comment('Stripe promo code ID');
            $table->string('code')->unique()->comment('Human-readable promo code');
            $table->string('coupon_id')->comment('Associated Stripe coupon ID');
            $table->integer('max_redemptions')->nullable()->comment('Maximum allowed redemptions');
            $table->integer('used_count')->default(0)->comment('Number of times used');
            $table->timestamp('expires_at')->nullable()->comment('Expiration date');
            $table->boolean('is_active')->default(true)->comment('Active status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('promo_codes');
    }
};
