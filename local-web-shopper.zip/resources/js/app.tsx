import '../css/app.css';

import { createInertiaApp } from '@inertiajs/react';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { createRoot } from 'react-dom/client';
import { initializeTheme } from './hooks/use-appearance';
import axios from 'axios';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { LoadScript } from '@react-google-maps/api';
import { ErrorProvider } from '@/contexts/error-context';
import { AlertProvider } from './contexts/alert-context';
import { Toaster } from 'sonner';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';
const stripeKey = import.meta.env.VITE_STRIPE_KEY;
const googleMapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

const stripePromise = loadStripe(stripeKey);

// Set axios defaults
axios.defaults.withCredentials = true;
axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

// Add this part to automatically set the X-XSRF-TOKEN header
axios.interceptors.request.use(function (config) {
    const token = document.cookie.split('; ').find(row => row.startsWith('XSRF-TOKEN'))?.split('=')[1];
    if (token) {
        config.headers['X-XSRF-TOKEN'] = decodeURIComponent(token);
    }
    return config;
});

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => resolvePageComponent(`./pages/${name}.tsx`, import.meta.glob('./pages/**/*.tsx')),
    setup({ el, App, props }) {
        const root = createRoot(el);

        root.render(
            <AlertProvider>
                <ErrorProvider>
                    <LoadScript
                        googleMapsApiKey={googleMapsApiKey}
                        libraries={['places']}
                    >
                        <Elements stripe={stripePromise}>
                            <App {...props} />
                            <Toaster richColors position="top-right" />
                        </Elements>
                    </LoadScript>
                </ErrorProvider>
            </AlertProvider>
        );
    },
    progress: {
        color: '#4B5563',
    },
});

// This will set light / dark mode on load...
// initializeTheme();
