import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';

import { AdCategory, PaginationMeta } from '@/types';

interface ApiResponse {
    data: AdCategory[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface Props {
    adCategories: AdCategory[];
}

const formSchema = z.object({
    name: z.string().min(2, {
        message: 'Name must be at least 2 characters.',
    }),
});

const AdCategoryTable: React.FC<Props> = ({ adCategories: initialCategories }) => {
    const [categories, setCategories] = useState<AdCategory[]>(initialCategories);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ categories?: string }>({});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [editCategory, setEditCategory] = useState<AdCategory | null>(null);
    const [deleteCategory, setDeleteCategory] = useState<AdCategory | null>(null);

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchCategories(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editCategory) {
            form.reset({ name: editCategory.name });
        }
    }, [editCategory, form]);

    useEffect(() => {
        setCategories(initialCategories);
    }, [initialCategories]);

    const fetchCategories = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/ad-categories`, {
                params: { name: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setCategories(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { categories: 'An error occurred while fetching categories.' });
            } else {
                setErrors({ categories: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: z.infer<typeof formSchema>) => {
        setLoading(true);
        try {
            await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/ad-categories/${editCategory!.id}`, values, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchCategories(currentPage);
            setEditCategory(null);
        } catch (error) {
            console.error('Error updating category:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (category: AdCategory) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/ad-categories/${category.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                }
            });
            fetchCategories(currentPage);
            setDeleteCategory(null);
            toast.success('Category deleted successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                const errorMessage = error.response.data.errors?.category || 'An error occurred while deleting the category';
                toast.error(errorMessage);
                console.error('Error response:', error.response.data);
            } else {
                toast.error('An unexpected error occurred');
                console.error('Error deleting category:', error);
            }
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchCategories(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchCategories(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.categories) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.categories}</AlertDescription>
                </Alert>
            );
        }

        if (categories.length === 0) {
            return <p className="text-center text-gray-500">No ad categories found.</p>;
        }

        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>ID</TableHead>
                            <TableHead>Name</TableHead>
                            {/* <TableHead>Created At</TableHead>
                            <TableHead>Updated At</TableHead> */}
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {categories.map((category) => (
                            <TableRow key={category.id}>
                                <TableCell>{category.id}</TableCell>
                                <TableCell>{category.name}</TableCell>
                                {/* <TableCell>{new Date(category.created_at).toLocaleString()}</TableCell>
                                <TableCell>{new Date(category.updated_at).toLocaleString()}</TableCell> */}
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button variant="outline" size="icon" onClick={() => setEditCategory(category)}>
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => setDeleteCategory(category)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search ad categories"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}

            <Dialog open={!!editCategory} onOpenChange={() => setEditCategory(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit Category</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-8">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="submit" disabled={loading}>
                                    {loading ? 'Saving...' : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteCategory} onOpenChange={() => setDeleteCategory(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete the category "{deleteCategory?.name}"? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteCategory(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deleteCategory!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdCategoryTable;
