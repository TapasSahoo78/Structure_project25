import React from 'react';

interface AppLogoIconProps extends React.ImgHTMLAttributes<HTMLImageElement> {
    width?: number;
    height?: number;
}

export default function AppLogoIcon({ width = 150, height = 100, ...props }: AppLogoIconProps) {
    return (
        <img
            src={`${import.meta.env.VITE_APP_URL}/images/logo/logo.png`}
            alt="App Logo"
            width={width}
            height={height}
            {...props}
        />
    );
}
