import { NavFooter } from '@/components/nav-footer';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from '@/components/ui/sidebar';
import { type NavItem } from '@/types';
import { Link } from '@inertiajs/react';
import { BookOpen, Building, Folder, LayoutGrid } from 'lucide-react';
import AppLogoIcon from './logo-icon';
import {
    LayoutDashboard,
    Image,
    Folders,
    PackageOpen,
    BadgePercent,
    Receipt,
    Bookmark,
    Users,
} from 'lucide-react';

const mainNavItems: NavItem[] = [
    // {
    //     title: 'Dashboard',
    //     href: '/admin/dashboard',
    //     icon: LayoutDashboard,
    // },
    {
        title: 'Ads',
        href: '/admin/ads',
        icon: Image,
    },
    {
        title: 'Ad Categories',
        href: '/admin/ad-categories',
        icon: Folders,
    },
    {
        title: 'Businesses',
        href: '/admin/businesses',
        icon: Building,
    },
    {
        title: 'Coupon Code',
        href: '/admin/coupons',
        icon: BadgePercent,
    },
    {
        title: 'Plans',
        href: '/admin/plans',
        icon: PackageOpen,
    },
    {
        title: 'Invoices',
        href: '/admin/invoices',
        icon: Receipt,
    },
    {
        title: 'Subscriptions',
        href: '/admin/subscriptions',
        icon: Bookmark,
    },
    {
        title: 'Users',
        href: '/admin/users',
        icon: Users,
    }
];

const footerNavItems: NavItem[] = [

];

export function AppSidebar() {
    return (
        <Sidebar collapsible="icon" variant="inset">
            <SidebarHeader>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton size="lg" asChild>
                            <Link href="/" prefetch >
                                <AppLogoIcon />
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarHeader>

            <SidebarContent>
                <NavMain items={mainNavItems} />
            </SidebarContent>

            <SidebarFooter>
                <NavFooter items={footerNavItems} className="mt-auto" />
                <NavUser />
            </SidebarFooter>
        </Sidebar>
    );
}
