import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Loader2, Eye, Pencil, Trash2, Image as ImageIcon, Calendar, MapPin, Radius, CreditCard, Maximize2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

import { PaginationMeta, Ad, Address, Plan, File, Subscription } from '@/types';
import { AdStatus } from '@/enums/ad-status';
import { formatDate } from '@/lib/utils';

interface ApiResponse {
    data: Ad[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    ads: Ad[];
    errors: {
        ads?: string;
    };
    [key: string]: any;
}

const AdsCardList: React.FC = () => {
    const { ads: initialAds, errors: initialErrors } = usePage<PageProps>().props;
    const [ads, setAds] = useState<Ad[]>(initialAds || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ ads?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [viewAd, setViewAd] = useState<Ad | null>(null);
    const [deleteAd, setDeleteAd] = useState<Ad | null>(null);
    const [statusFilter, setStatusFilter] = useState<AdStatus | 'all'>('all');

    useEffect(() => {
        fetchAds(1);
    }, [searchTerm, statusFilter]);

    const fetchAds = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/ads`, {
                params: {
                    name: searchTerm,
                    page,
                    status: statusFilter !== 'all' ? statusFilter : undefined,
                },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setAds(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { ads: 'An error occurred while fetching ads.' });
            } else {
                setErrors({ ads: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (ad: Ad) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/ads/${ad.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchAds(currentPage);
            setDeleteAd(null);
        } catch (error) {
            console.error('Error deleting ad:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchAds(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchAds(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.ads) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.ads}</AlertDescription>
                </Alert>
            );
        }

        if (ads.length === 0) {
            return <p className="text-center text-gray-500">No ads found.</p>;
        }

        return (
            <div className="space-y-4">
                {ads.map((ad) => (
                    <div key={ad.id} className="flex items-center space-x-4 p-4 bg-white shadow rounded-lg">
                        <div className="flex-shrink-0">
                            {ad.file && (ad.file as File).path ? (
                                <img
                                    src={(ad.file as File).path}
                                    alt={ad.title}
                                    className="w-16 h-16 object-cover rounded"
                                />
                            ) : (
                                <div className="w-16 h-16 bg-gray-200 flex items-center justify-center rounded">
                                    <ImageIcon className="h-8 w-8 text-gray-400" />
                                </div>
                            )}
                        </div>
                        <div className="flex-grow">
                            <h3 className="font-semibold">{ad.title}</h3>
                            <p className="text-sm text-gray-500 truncate">{(ad.description || 'No description').slice(0, 100)}</p>
                            <div className="flex items-center space-x-2 mt-2">
                                {ad.address && (
                                    <Badge variant="outline" className="flex items-center">
                                        <MapPin className="h-4 w-4 mr-1" />
                                        {(ad.address as Address).formatted_address}
                                    </Badge>
                                )}
                                {ad.plan && (
                                    <>
                                        <Badge variant="outline" className="flex items-center">
                                            <CreditCard className="h-4 w-4 mr-1" />
                                            {(ad.subscription as Subscription).name}

                                            <Radius className="h-4 w-4 ml-2 mr-1" />
                                            {(ad.plan as Plan).radius} mi

                                            <Maximize2 className="h-4 w-4 ml-2 mr-1" />
                                            {(ad.plan as Plan).size}
                                        </Badge>
                                    </>
                                )}
                            </div>
                        </div>
                        <div>
                            {(ad.start_date || ad.end_date) && (
                                <Badge variant="outline" className="flex items-center">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    {ad.start_date && (
                                        <>
                                            {console.log('Start date:', ad.start_date)} {/* Debugging line */}
                                            {formatDate(ad.start_date)}
                                        </>
                                    )}
                                    {ad.start_date && ad.end_date && " - "}
                                    {ad.end_date && (
                                        <>
                                            {console.log('End date:', ad.end_date)} {/* Debugging line */}
                                            {formatDate(ad.end_date)}
                                        </>
                                    )}
                                </Badge>
                            )}
                        </div>
                        <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => setViewAd(ad)}>
                                <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleEdit(ad)}>
                                <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setDeleteAd(ad)}>
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const handleEdit = (ad: Ad) => {
        console.log('Edit ad:', ad);
    };

    return (
        <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
                <Input
                    placeholder="Search ads"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full sm:w-2/3"
                />
                <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as AdStatus | 'all')}>
                    <SelectTrigger className="w-full sm:w-1/3">
                        <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        {Object.values(AdStatus).map((status) => (
                            <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            {renderContent()}
            {renderPagination()}

            <Dialog open={!!viewAd} onOpenChange={() => setViewAd(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Ad Details</DialogTitle>
                    </DialogHeader>
                    {viewAd && (
                        <div className="space-y-2">
                            <p><strong>ID:</strong> {viewAd.id}</p>
                            <p><strong>Title:</strong> {viewAd.title}</p>
                            <p><strong>Description:</strong> {viewAd.description}</p>
                            <p><strong>User ID:</strong> {viewAd.user_id}</p>
                            <p><strong>View Count:</strong> {viewAd.view_count}</p>
                            <p><strong>Start Date:</strong> {formatDate(viewAd.start_date)}</p>
                            <p><strong>End Date:</strong> {formatDate(viewAd.end_date)}</p>
                            <p><strong>Status:</strong> {viewAd.status}</p>
                            {viewAd.plan && (
                                <>
                                    <p><strong>Plan Size:</strong> {(viewAd.plan as Plan).size}</p>
                                    <p><strong>Plan Radius:</strong> {(viewAd.plan as Plan).radius} km</p>
                                </>
                            )}
                            {viewAd.address && (
                                <p><strong>Address:</strong> {(viewAd.address as Address).formatted_address}</p>
                            )}
                            {viewAd.file && (viewAd.file as File).path ? (
                                <div>
                                    <p><strong>File:</strong></p>
                                    <img
                                        src={(viewAd.file as File).path}
                                        alt={viewAd.title}
                                        className="w-32 h-32 object-cover rounded"
                                    />
                                </div>
                            ) : (
                                <div>
                                    <p><strong>File:</strong></p>
                                    <div className="w-32 h-32 bg-gray-200 flex items-center justify-center rounded">
                                        <span className="text-gray-400 text-sm">No image</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteAd} onOpenChange={() => setDeleteAd(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this ad? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteAd(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deleteAd!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdsCardList;
