import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage, router } from '@inertiajs/react';
import { Loader2, Eye, Pencil, Trash2, Image as ImageIcon, Calendar, MapPin, Radius, CreditCard, Maximize2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

import { PaginationMeta, Ad, Address, Plan, File, Subscription } from '@/types';
import { AdStatus } from '@/enums/ad-status';
import { formatDate } from '@/lib/utils';

interface ApiResponse {
    data: Ad[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    ads: Ad[];
    errors: {
        ads?: string;
    };
    [key: string]: any;
}

const AdsCardView: React.FC = () => {
    const { ads: initialAds, errors: initialErrors } = usePage<PageProps>().props;
    const [ads, setAds] = useState<Ad[]>(initialAds || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ ads?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [deleteAd, setDeleteAd] = useState<Ad | null>(null);
    const [statusFilter, setStatusFilter] = useState<AdStatus | 'all'>('all');

    useEffect(() => {
        fetchAds(1);
    }, [searchTerm, statusFilter]);

    const fetchAds = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/ads`, {
                params: {
                    name: searchTerm,
                    page,
                    status: statusFilter !== 'all' ? statusFilter : undefined,
                },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setAds(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { ads: 'An error occurred while fetching ads.' });
            } else {
                setErrors({ ads: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (ad: Ad) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/ads/${ad.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchAds(currentPage);
            setDeleteAd(null);
        } catch (error) {
            console.error('Error deleting ad:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchAds(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchAds(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const handleViewAd = (adId: number) => {
        router.visit(`${import.meta.env.VITE_APP_URL}/portal/ads/${adId}`);
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.ads) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.ads}</AlertDescription>
                </Alert>
            );
        }

        if (ads.length === 0) {
            return <p className="text-center text-gray-500">No ads found.</p>;
        }

        return (
            <div className="space-y-4">
                {ads.map((ad) => (
                    <div key={ad.id} className="saasa flex flex-wrap items-center space-x-2 p-2 bg-white border-[1px] border-[#e9e9e9] rounded-sm">
                        <div className="flex-shrink-0">
                            {ad.file && (ad.file as File).path ? (
                                <img
                                    src={(ad.file as File).path}
                                    alt={ad.title}
                                    className="w-16 h-16 object-cover rounded"
                                />
                            ) : (
                                <div className="w-16 h-16 bg-gray-200 flex items-center justify-center rounded">
                                    <ImageIcon className="h-8 w-8 text-gray-400" />
                                </div>
                            )}
                        </div>
                        <div className="flex-grow">
                            <h3 className="font-semibold">{ad.title}</h3>
                            <p className="text-sm text-gray-500 ">{(ad.description || 'No description').slice(0, 100)}</p>
                            <div className="flex flex-wrap gap-2 items-center space-x-2 mt-2 mb-2">
                                {ad.address?.formatted_address && (
                                    <Badge variant="outline" className="flex items-start sm:items-center whitespace-break-spaces m-0 dark:text-black">
                                        <MapPin className="h-4 w-4" />
                                        {(ad.address as Address).formatted_address}
                                    </Badge>
                                )}
                                {ad.plan && (
                                    <>
                                        <Badge variant="outline" className="flex flex-wrap gap-2 items-center dark:text-black">
                                            <CreditCard className="h-4 w-4 " />
                                            {(ad.subscription as Subscription).name}

                                            <Radius className="h-4 w-4 ml-2" />
                                            {(ad.plan as Plan).radius} mi

                                            <Maximize2 className="h-4 w-4 ml-2 " />
                                            {(ad.plan as Plan).size}
                                        </Badge>
                                    </>
                                )}
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <Badge variant={ad.status === AdStatus.ACTIVE ? "success" : "secondary"}>
                                {ad.status}
                            </Badge>
                            {(ad.start_date || ad.end_date) && (
                                <Badge variant="outline" className="flex items-center dark:text-black">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    {ad.start_date && formatDate(ad.start_date)}
                                    {ad.start_date && formatDate(ad.end_date) && " - "}
                                    {ad.end_date && formatDate(ad.end_date)}
                                </Badge>
                            )}
                        </div>
                        <div className="flex space-x-2">
                            <Button variant="ghost" className='dark:bg-sky-500/10' size="sm" onClick={() => handleViewAd(ad.id)}>
                                <Eye className="h-4 w-4 text-chart-2" />
                            </Button>
                            <Button variant="ghost" className='dark:bg-sky-500/10' size="sm" onClick={() => handleEdit(ad)}>
                                <Pencil className="h-4 w-4 text-[#48A3D7]" />
                            </Button>
                            <Button variant="ghost" className='dark:bg-sky-500/10' size="sm" onClick={() => setDeleteAd(ad)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const handleEdit = (ad: Ad) => {
        console.log('Edit ad:', ad);
        router.visit(`${import.meta.env.VITE_APP_URL}/portal/ads/${ad.id}/edit`);
    };

    return (
        <div className="space-y-4 p-4 bg-white shadow rounded-lg">
            <div className="flex flex-col sm:flex-row gap-4">
                <Input
                    placeholder="Search ads"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full sm:w-2/3 dashedField"
                />
                <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as AdStatus | 'all')}>
                    <SelectTrigger className="w-full sm:w-1/3 selectBtn dark:text-black">
                        <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        {Object.values(AdStatus).map((status) => (
                            <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            {renderContent()}
            {renderPagination()}

            <Dialog open={!!deleteAd} onOpenChange={(open) => !open && setDeleteAd(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this ad? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteAd(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => deleteAd && handleDelete(deleteAd)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdsCardView;
