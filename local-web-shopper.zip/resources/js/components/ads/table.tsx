import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"

import { PaginationMeta } from '@/types';
import { AdStatus } from '@/enums/ad-status';

interface File {
    path: string;
}

interface Ad {
    id: number;
    title: string;
    description: string;
    user_id: number;
    view_count: number;
    start_date: string;
    end_date: string;
    status: AdStatus;
    plan?: {
        size: string;
        radius: number;
    };
    address?: {
        address: string;
        formatted_address: string;
    };
    file?: File;
}

interface ApiResponse {
    data: Ad[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    ads: Ad[];
    errors: {
        ads?: string;
    };
    [key: string]: any;
}

const AdsTable: React.FC = () => {
    const { ads: initialAds, errors: initialErrors } = usePage<PageProps>().props;
    const [ads, setAds] = useState<Ad[]>(initialAds || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ ads?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [viewAd, setViewAd] = useState<Ad | null>(null);
    const [deleteAd, setDeleteAd] = useState<Ad | null>(null);

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchAds(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    const fetchAds = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/ads`, {
                params: { name: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setAds(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { ads: 'An error occurred while fetching ads.' });
            } else {
                setErrors({ ads: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (ad: Ad) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/ads/${ad.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchAds(currentPage);
            setDeleteAd(null);
        } catch (error) {
            console.error('Error deleting ad:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchAds(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchAds(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.ads) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.ads}</AlertDescription>
                </Alert>
            );
        }

        if (ads.length === 0) {
            return <p className="text-center text-gray-500">No ads found.</p>;
        }

        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-24">Image</TableHead>
                            <TableHead className="w-1/4">
                                Title
                                <p className="text-xs text-gray-500">Description</p>
                            </TableHead>
                            <TableHead className="w-1/6">Plan</TableHead>
                            <TableHead className="w-1/6">Address</TableHead>
                            <TableHead className="w-1/8">Start Date</TableHead>
                            <TableHead className="w-1/8">End Date</TableHead>
                            <TableHead className="w-1/8">Status</TableHead>
                            <TableHead className="w-1/8">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {ads.map((ad) => (
                            <TableRow key={ad.id}>
                                <TableCell className="p-2">
                                    {ad.file && ad.file.path ? (
                                        <img
                                            src={ad.file.path}
                                            alt={ad.title}
                                            className="w-16 h-16 object-cover rounded"
                                        />
                                    ) : (
                                        <div className="w-16 h-16 bg-gray-200 flex items-center justify-center rounded">
                                            <span className="text-gray-400 text-xs">No image</span>
                                        </div>
                                    )}
                                </TableCell>
                                <TableCell className="p-2">
                                    <p className="font-medium">{ad.title}</p>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {ad.description ? ad.description.slice(0, 100) + (ad.description.length > 100 ? '...' : '') : 'No description'}
                                    </p>
                                </TableCell>
                                <TableCell className="p-2">
                                    {ad.plan && (
                                        <>
                                            <p>Size: {ad.plan.size}</p>
                                            <p>Radius: {ad.plan.radius} mi</p>
                                        </>
                                    )}
                                </TableCell>
                                <TableCell className="p-2">
                                    {ad?.address?.formatted_address && (
                                        <p>{ad?.address?.formatted_address || 'No address'}</p>
                                    )}
                                </TableCell>
                                <TableCell className="p-2">{ad.start_date ? new Date(ad.start_date).toLocaleDateString() : 'None'}</TableCell>
                                <TableCell className="p-2">{ad.end_date ? new Date(ad.end_date).toLocaleDateString() : 'None'}</TableCell>
                                <TableCell className="p-2">{ad.status}</TableCell>
                                <TableCell className="p-2">
                                    <div className="flex space-x-2">
                                        <Button variant="outline" size="icon" onClick={() => setViewAd(ad)}>
                                            <Eye className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => handleEdit(ad)}>
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => setDeleteAd(ad)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    const handleEdit = (ad: Ad) => {
        console.log('Edit ad:', ad);
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search ads"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}

            <Dialog open={!!viewAd} onOpenChange={() => setViewAd(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Ad Details</DialogTitle>
                    </DialogHeader>
                    {viewAd && (
                        <div className="space-y-2">
                            <p><strong>ID:</strong> {viewAd.id}</p>
                            <p><strong>Title:</strong> {viewAd.title}</p>
                            <p><strong>Description:</strong> {viewAd.description}</p>
                            <p><strong>User ID:</strong> {viewAd.user_id}</p>
                            <p><strong>View Count:</strong> {viewAd.view_count}</p>
                            <p><strong>Start Date:</strong> {new Date(viewAd.start_date).toLocaleDateString()}</p>
                            <p><strong>End Date:</strong> {new Date(viewAd.end_date).toLocaleDateString()}</p>
                            <p><strong>Status:</strong> {viewAd.status}</p>
                            {viewAd.plan && (
                                <>
                                    <p><strong>Plan Size:</strong> {viewAd.plan.size}</p>
                                    <p><strong>Plan Radius:</strong> {viewAd.plan.radius} mi</p>
                                </>
                            )}
                            {viewAd.address && (
                                <p><strong>Address:</strong> {viewAd.address.address}</p>
                            )}
                            {viewAd.file && viewAd.file.path ? (
                                <div>
                                    <p><strong>File:</strong></p>
                                    <img
                                        src={viewAd.file.path}
                                        alt={viewAd.title}
                                        className="w-32 h-32 object-cover rounded"
                                    />
                                </div>
                            ) : (
                                <div>
                                    <p><strong>File:</strong></p>
                                    <div className="w-32 h-32 bg-gray-200 flex items-center justify-center rounded">
                                        <span className="text-gray-400 text-sm">No image</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteAd} onOpenChange={() => setDeleteAd(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this ad? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteAd(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deleteAd!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdsTable;
