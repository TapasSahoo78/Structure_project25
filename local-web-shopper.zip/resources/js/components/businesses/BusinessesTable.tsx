import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Business, ApiResponse, PageProps } from '@/types';

const BusinessesTable: React.FC = () => {
    const { businesses: initialBusinesses, errors: initialErrors } = usePage<PageProps>().props;
    const [businesses, setBusinesses] = useState<Business[]>(initialBusinesses || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ businesses?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<any | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [viewBusiness, setViewBusiness] = useState<Business | null>(null);
    const [deleteBusiness, setDeleteBusiness] = useState<Business | null>(null);

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchBusinesses(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    const fetchBusinesses = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/businesses`, {
                params: { name: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setBusinesses(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { businesses: 'An error occurred while fetching businesses.' });
            } else {
                setErrors({ businesses: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (business: Business) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/businesses/${business.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchBusinesses(currentPage);
            setDeleteBusiness(null);
        } catch (error) {
            console.error('Error deleting business:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchBusinesses(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchBusinesses(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.businesses) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.businesses}</AlertDescription>
                </Alert>
            );
        }

        if (businesses.length === 0) {
            return <p className="text-center text-gray-500">No businesses found.</p>;
        }

        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Address</TableHead>
                            <TableHead>Primary User</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {businesses.map((business) => (
                            <TableRow key={business.id}>
                                <TableCell className="font-medium">{business.name}</TableCell>
                                <TableCell>{business.address?.full_address}</TableCell>
                                <TableCell>{business.primaryUser ? `${business.primaryUser?.name} (${business.primaryUser?.email})` : 'N/A'}</TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button variant="outline" size="icon" onClick={() => setViewBusiness(business)}>
                                            <Eye className="h-4 w-4" />
                                        </Button>

                                        <Button variant="outline" size="icon" onClick={() => setDeleteBusiness(business)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search businesses"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}

            <Dialog open={!!viewBusiness} onOpenChange={() => setViewBusiness(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Business Details</DialogTitle>
                    </DialogHeader>
                    {viewBusiness && (
                        <div className="space-y-2">
                            <p><strong>ID:</strong> {viewBusiness.id}</p>
                            <p><strong>Name:</strong> {viewBusiness.name}</p>
                            <p><strong>Address:</strong> {viewBusiness.address?.full_address}</p>
                            <p><strong>Phone:</strong> {viewBusiness.phone}</p>
                            <p><strong>Primary User:</strong> {viewBusiness.primaryUser?.name} ({viewBusiness.primaryUser?.email})</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteBusiness} onOpenChange={() => setDeleteBusiness(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this business? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteBusiness(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deleteBusiness!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default BusinessesTable;
