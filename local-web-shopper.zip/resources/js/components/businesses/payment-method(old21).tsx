import React, { useState, useEffect } from 'react';
import { useStripe, useElements, CardNumberElement, CardExpiryElement, CardCvcElement } from '@stripe/react-stripe-js';
import axios from 'axios';
import { toast } from 'sonner';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm, Controller } from 'react-hook-form';
import { CreditCard } from 'lucide-react';
import { Link } from '@inertiajs/react';

interface PaymentMethodDetails {
    stripe_payment_method_id: string | null;
    pm_type: string | null;
    pm_last_four: string | null;
    pm_brand: string | null;
    pm_exp_month: string | null;
    pm_exp_year: string | null;
    pm_card_holder_name: string | null;
}

interface PaymentMethodFormData {
    cardHolderName: string;
    cardNumber: string;
    cardExpiry: string;
    cardCvc: string;
}

type DisplayMode = 'card' | 'button' | 'icon';

interface PaymentMethodProps {
    openStatus: boolean;
    businessId: number;
    displayMode?: DisplayMode;
}

export default function PaymentMethod({ openStatus, businessId, displayMode = 'card' }: PaymentMethodProps) {
    const stripe = useStripe();
    const elements = useElements();
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethodDetails | null>(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    const form = useForm<PaymentMethodFormData>({
        defaultValues: {
            cardHolderName: '',
            cardNumber: '',
            cardExpiry: '',
            cardCvc: '',
        },
    });

    useEffect(() => {
        fetchPaymentMethod();
    }, [businessId]);

    const fetchPaymentMethod = async () => {
        try {
            const response = await axios.get<{ data: PaymentMethodDetails }>(`${import.meta.env.VITE_APP_URL}/api/v1/businesses/${businessId}/payment-method`);
            setPaymentMethod(response.data.data);
            form.setValue('cardHolderName', response.data.data.pm_card_holder_name || '');
        } catch (error) {
            console.error('Error fetching payment method:', error);
            // toast.error("Failed to fetch payment method details");
        }
    };

    const handleUpdatePaymentMethod = async (paymentMethodId: string) => {
        try {
            await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/businesses/${businessId}/payment-method`, {
                stripe_payment_method_id: paymentMethodId,
            });
            setIsDialogOpen(false);

            // Show success toast
            // toast.success('Payment method updated successfully');
        } catch (error) {
            // console.error('Error updating payment method:', error);
            if (axios.isAxiosError(error)) {
                if (error.response?.status === 403) {
                    toast.error("You don't have permission to update the payment method. Please check your account status or contact support.");
                } else if (error.response?.data?.message) {
                    toast.error(error.response.data.message);
                } else {
                    toast.error("An unexpected error occurred while updating the payment method. Please try again later.");
                }
            } else {
                toast.error("An unexpected error occurred while updating the payment method. Please try again later.");
            }
        }
    };

    const onSubmit = async (data: PaymentMethodFormData) => {
        if (!stripe || !elements) {
            setError("Stripe has not been initialized");
            return;
        }

        setError(null);
        setIsProcessing(true);

        const cardNumber = elements.getElement(CardNumberElement);
        const cardExpiry = elements.getElement(CardExpiryElement);
        const cardCvc = elements.getElement(CardCvcElement);

        if (!cardNumber || !cardExpiry || !cardCvc) {
            setError("Card elements not found");
            setIsProcessing(false);
            return;
        }

        try {
            const { paymentMethod, error: stripeError } = await stripe.createPaymentMethod({
                type: 'card',
                card: cardNumber,
                billing_details: {
                    name: data.cardHolderName,
                },
            });

            if (stripeError) {
                throw new Error(stripeError.message);
            }

            if (!paymentMethod) throw new Error("Failed to create payment method");

            await handleUpdatePaymentMethod(paymentMethod.id);
            toast.success("Payment method updated successfully");
            cardNumber.clear();
            cardExpiry.clear();
            cardCvc.clear();
            form.reset();
            fetchPaymentMethod();
            setIsDialogOpen(false);
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred");
            toast.error(err instanceof Error ? err.message : "Failed to update payment method");
        } finally {
            setIsProcessing(false);
        }
    };

    const renderPaymentMethodCard = () => {
        if (!paymentMethod) return null;

        const cardBrandColors: { [key: string]: string } = {
            visa: 'from-blue-500 to-blue-700',
            mastercard: 'from-red-500 to-orange-500',
            amex: 'from-blue-600 to-blue-800',
            discover: 'from-orange-500 to-orange-700',
            default: 'from-gray-700 to-gray-900',
        };

        const gradientClass = paymentMethod.pm_brand
            ? (cardBrandColors[paymentMethod.pm_brand.toLowerCase()] || cardBrandColors.default)
            : cardBrandColors.default;

        return (
            <div className={`bg-gradient-to-r ${gradientClass} text-white p-6 rounded-xl shadow-md mb-0 relative w-full max-w-[340px] h-[200px] flex flex-col justify-between`}>
                <div className="flex justify-between items-start">
                    <div className="text-xl font-bold">
                        {paymentMethod.pm_brand?.toUpperCase() || 'Card'}
                    </div>
                    <div className="text-3xl">💳</div>
                </div>
                <div className="text-2xl font-mono mt-4">
                    **** **** **** {paymentMethod.pm_last_four}
                </div>
                <div className="flex justify-between items-end">
                    <div>
                        <div className="text-sm">{paymentMethod.pm_card_holder_name}</div>
                        <div className="text-sm">{`${paymentMethod.pm_exp_month}/${paymentMethod.pm_exp_year}`}</div>
                    </div>
                    {renderDialogTrigger()}
                </div>
            </div>
        );
    };

    const renderDialogTrigger = () => {
        switch (displayMode) {
            case 'button':
                return (
                    <Button variant="secondary" size="sm" onClick={() => setIsDialogOpen(true)}>
                        {paymentMethod?.pm_last_four ? 'Update' : 'Add'} Payment Method
                    </Button>
                );
            case 'icon':
                return (
                    <Button variant="ghost" size="sm" onClick={() => setIsDialogOpen(true)}>
                        <CreditCard className="h-5 w-5" />
                    </Button>
                );
            default:
                return (
                    <Button variant="secondary" size="sm" onClick={() => setIsDialogOpen(true)}>
                        {paymentMethod?.pm_last_four ? 'Update' : 'Add'}
                    </Button>
                );
        }
    };

    const renderUpdateForm = () => (
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="cardHolderName">Card Holder Name</Label>
                <Input
                    id="cardHolderName"
                    type="text"
                    placeholder="John Doe"
                    {...form.register("cardHolderName", { required: "Card holder name is required" })}
                />
                {form.formState.errors.cardHolderName && (
                    <p className="text-red-500 text-sm">{form.formState.errors.cardHolderName.message}</p>
                )}
            </div>
            <div className="space-y-2">
                <Label htmlFor="cardNumber">Card Number</Label>
                <div className="border rounded-md p-3">
                    <Controller
                        name="cardNumber"
                        control={form.control}
                        rules={{ required: "Card number is required" }}
                        render={({ field }) => (
                            <CardNumberElement
                                id="cardNumber"
                                options={{
                                    style: {
                                        base: {
                                            fontSize: '16px',
                                            color: '#424770',
                                            '::placeholder': { color: '#aab7c4' },
                                        },
                                        invalid: { color: '#9e2146' },
                                    },
                                }}
                                onChange={(event) => {
                                    field.onChange(event.complete ? event.complete.toString() : '');
                                }}
                            />
                        )}
                    />
                </div>
                {form.formState.errors.cardNumber && (
                    <p className="text-red-500 text-sm">{form.formState.errors.cardNumber.message}</p>
                )}
            </div>
            <div className="flex space-x-4">
                <div className="flex-1 space-y-2">
                    <Label htmlFor="cardExpiry">Expiration Date</Label>
                    <div className="border rounded-md p-3">
                        <Controller
                            name="cardExpiry"
                            control={form.control}
                            rules={{ required: "Expiration date is required" }}
                            render={({ field }) => (
                                <CardExpiryElement
                                    id="cardExpiry"
                                    options={{
                                        style: {
                                            base: {
                                                fontSize: '16px',
                                                color: '#424770',
                                                '::placeholder': { color: '#aab7c4' },
                                            },
                                            invalid: { color: '#9e2146' },
                                        },
                                    }}
                                    onChange={(event) => {
                                        field.onChange(event.complete ? event.complete.toString() : '');
                                    }}
                                />
                            )}
                        />
                    </div>
                    {form.formState.errors.cardExpiry && (
                        <p className="text-red-500 text-sm">{form.formState.errors.cardExpiry.message}</p>
                    )}
                </div>
                <div className="flex-1 space-y-2">
                    <Label htmlFor="cardCvc">CVC</Label>
                    <div className="border rounded-md p-3">
                        <Controller
                            name="cardCvc"
                            control={form.control}
                            rules={{ required: "CVC is required" }}
                            render={({ field }) => (
                                <CardCvcElement
                                    id="cardCvc"
                                    options={{
                                        style: {
                                            base: {
                                                fontSize: '16px',
                                                color: '#424770',
                                                '::placeholder': { color: '#aab7c4' },
                                            },
                                            invalid: { color: '#9e2146' },
                                        },
                                    }}
                                    onChange={(event) => {
                                        field.onChange(event.complete ? event.complete.toString() : '');
                                    }}
                                />
                            )}
                        />
                    </div>
                    {form.formState.errors.cardCvc && (
                        <p className="text-red-500 text-sm">{form.formState.errors.cardCvc.message}</p>
                    )}
                </div>
            </div>
            {error && (
                <Alert variant="destructive">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}
            <Button type="submit" disabled={!stripe || isProcessing} className="w-full dark:bg-black dark:text-white">
                {isProcessing ? "Processing..." : (paymentMethod?.pm_last_four ? "Update" : "Add") + " Payment Method"}
            </Button>

        </form>
    );

    const renderContent = () => {
        if (!paymentMethod) {
            return (
                <Button onClick={() => setIsDialogOpen(true)}>
                    Add Payment Method
                </Button>
            );
        }

        switch (displayMode) {
            case 'card':
                return renderPaymentMethodCard();
            case 'button':
                return (
                    <Button className='dark:bg-black' onClick={() => setIsDialogOpen(true)}>
                        Update Payment Method
                    </Button>
                );
            case 'icon':
                return (
                    <CreditCard
                        className="cursor-pointer"
                        onClick={() => setIsDialogOpen(true)}
                    />
                );
            default:
                return null;
        }
    };

    return (
        <>
            {renderContent()}
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className='dark:bg-white dark:text-black'>
                    <DialogHeader>
                        <DialogTitle>{paymentMethod ? 'Update' : 'Add'} Payment Method</DialogTitle>
                        <DialogDescription>Enter your card details below</DialogDescription>
                    </DialogHeader>
                    {renderUpdateForm()}
                </DialogContent>
            </Dialog>

            {paymentMethod?.pm_last_four &&
                <Link key={"Subscription"} href={`${import.meta.env.VITE_APP_URL}/portal/subscriptions`} style={{
                    position: 'fixed',
                    bottom: '45px',
                    right: '20px',
                    zIndex: 1000,
                    backgroundColor: '#1878f3',
                    color: 'white',
                    borderRadius: '5%',
                    width: '230px',
                    height: '50px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
                    textDecoration: 'none',
                    fontSize: '18px'
                }}>
                    Next: Pick a Subscription ➤
                </Link>}
        </>
    );
}
