import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, Eye, Pencil, Trash2, BadgePercent } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { parseISO, format } from 'date-fns';
import { Toaster } from 'sonner';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';

// Define constants for coupon options
const DiscountType = {
    PERCENT: 'percent',
    AMOUNT: 'amount',
} as const;

const DurationType = {
    ONCE: 'once',
    REPEATING: 'repeating',
    FOREVER: 'forever',
} as const;

// const CurrencyOptions = ['usd', 'eur', 'gbp'] as const;
const CurrencyOptions = ['usd'] as const;

// Zod schema for coupon update
const formSchema = z.object({
    code: z.string().min(2, {
        message: 'Code must be at least 2 characters.',
    }),
    discount_type: z.enum([DiscountType.PERCENT, DiscountType.AMOUNT], {
        errorMap: () => ({ message: 'Please select a valid discount type (percent or amount).' }),
    }),
    discount_value: z.number({
        required_error: 'Discount value is required.',
        invalid_type_error: 'Discount value must be a number.',
    }).positive('Discount value must be positive.').refine((val) => val <= 500, {
        message: 'For percentage discounts, value must not exceed 500.',
    }),
    duration: z.enum([DurationType.ONCE, DurationType.REPEATING, DurationType.FOREVER], {
        errorMap: () => ({ message: 'Please select a valid duration (once, repeating, or forever).' }),
    }),
    max_redemptions: z.number().int().min(0).max(999999),
    redeem_by: z.string().optional(),
    currency: z.enum(CurrencyOptions),
    is_active: z.boolean(),
}).refine((data) => {
    if (data.discount_type === DiscountType.AMOUNT && !data.currency) {
        return false;
    }
    return true;
}, {
    message: 'Currency is required for amount discounts.',
    path: ['currency'],
});

type FormData = z.infer<typeof formSchema>;

// Define Coupon interface
interface Coupon {
    id: number;
    stripe_coupon_id: string;
    code: string;
    discount_type: 'percent' | 'amount';
    discount_value: number;
    duration: 'once' | 'repeating' | 'forever';
    max_redemptions: number;
    used_count: number;
    redeem_by: string | null;
    currency: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
}

interface ApiResponse {
    data: Coupon[];
    meta: {
        current_page: number;
        last_page: number;
        per_page: number;
        total: number;
    };
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    coupons: Coupon[];
    errors: {
        coupons?: string;
    };
    [key: string]: any;
}

const CouponTable: React.FC = () => {
    const { coupons: initialCoupons, errors: initialErrors } = usePage<PageProps>().props;

    // Normalize coupon data to ensure correct types
    const normalizeCoupon = (coupon: any): Coupon => ({
        ...coupon,
        discount_value: typeof coupon.discount_value === 'string' ? parseFloat(coupon.discount_value) : coupon.discount_value,
        is_active: typeof coupon.is_active === 'number' ? Boolean(coupon.is_active) : coupon.is_active,
        redeem_by: coupon.redeem_by
            ? format(parseISO(coupon.redeem_by), 'yyyy-MM-dd') // Convert ISO timestamp to YYYY-MM-DD
            : null,
    });

    const [coupons, setCoupons] = useState<Coupon[]>(initialCoupons.map(normalizeCoupon) || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ coupons?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<ApiResponse['meta'] | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [viewCoupon, setViewCoupon] = useState<Coupon | null>(null);
    const [editCoupon, setEditCoupon] = useState<Coupon | null>(null);
    const [deleteCoupon, setDeleteCoupon] = useState<Coupon | null>(null);

    const { showAlert } = useAlert();
    const { showError } = useError();

    const form = useForm<FormData>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            code: '',
            discount_type: DiscountType.PERCENT,
            discount_value: 0,
            duration: DurationType.FOREVER,
            max_redemptions: 1,
            redeem_by: '',
            currency: 'usd',
            is_active: true,
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchCoupons(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editCoupon) {
            const formData: FormData = {
                code: editCoupon.code,
                discount_type: editCoupon.discount_type,
                discount_value: editCoupon.discount_value,
                duration: editCoupon.duration,
                max_redemptions: editCoupon.max_redemptions,
                redeem_by: editCoupon.redeem_by || '',
                currency: editCoupon.currency,
                is_active: editCoupon.is_active,
            };
            form.reset(formData);
        }
    }, [editCoupon, form]);

    const fetchCoupons = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons`, {
                params: { code: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            console.log("responseresponse", response.data.data);

            setCoupons(response.data.data.map(normalizeCoupon));
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { coupons: 'An error occurred while fetching coupons.' });
            } else {
                setErrors({ coupons: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchSingleCoupon = async (id: number | string) => {
        setLoading(true);
        try {
            const response = await axios.get<{ data: Coupon }>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            setViewCoupon(normalizeCoupon(response.data.data));
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error('Error fetching coupon:', error.response.data);
                showError(error.response.data.message || 'Failed to fetch coupon details');
            } else {
                console.error('Error fetching coupon:', error);
                showError('An unexpected error occurred while fetching the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: FormData) => {
        if (!editCoupon) return;
        setLoading(true);
        try {
            const dataToSend = {
                code: values.code,
                discount_type: values.discount_type,
                discount_value: Number(values.discount_value.toFixed(2)),
                duration: values.duration,
                max_redemptions: values.max_redemptions,
                redeem_by: values.redeem_by || null,
                currency: values.currency,
                is_active: values.is_active,
            };
            const response = await axios.put<{ data: Coupon }>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${editCoupon.id}`, dataToSend, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            fetchCoupons(currentPage);
            setEditCoupon(null);
            form.reset();
            if (response) {
                showAlert('success', 'Coupon updated successfully');
            }
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error('Error updating coupon:', error.response.data);
                showError(error.response.data.message || 'Failed to update coupon');
            } else {
                console.error('Error updating coupon:', error);
                showError('An unexpected error occurred while updating the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (coupon: Coupon) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${coupon.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            fetchCoupons(currentPage);
            setDeleteCoupon(null);
            showAlert('success', 'Coupon deleted successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error('Error deleting coupon:', error.response.data);
                showError(error.response.data.message || 'Failed to delete coupon');
            } else {
                console.error('Error deleting coupon:', error);
                showError('An unexpected error occurred while deleting the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchCoupons(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchCoupons(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const formatDiscountValue = (coupon: Coupon) => {
        if (coupon.discount_type === 'percent') {
            return `${coupon.discount_value}% off`;
        }
        return `${coupon.currency.toUpperCase()} ${Number(coupon.discount_value).toFixed(2)} off`;
    };

    const formatRedeemBy = (date: string | null) => {
        if (!date) return 'No expiration';
        return format(new Date(date), 'PPP');
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.coupons) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.coupons}</AlertDescription>
                </Alert>
            );
        }

        if (coupons.length === 0) {
            return <p className="text-center text-gray-500">No coupons found.</p>;
        }

        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Code</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Value</TableHead>
                            {/* <TableHead>Duration</TableHead> */}
                            <TableHead>Max Uses</TableHead>
                            <TableHead>Used</TableHead>
                            <TableHead>Expires</TableHead>
                            <TableHead>Currency</TableHead>
                            <TableHead>Active</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {coupons.map((coupon) => (
                            <TableRow key={coupon.id}>
                                <TableCell className="font-medium">{coupon.code}</TableCell>
                                <TableCell>{coupon.discount_type.toUpperCase()}</TableCell>
                                <TableCell>{formatDiscountValue(coupon)}</TableCell>
                                {/* <TableCell>{coupon.duration}</TableCell> */}
                                <TableCell>{coupon.max_redemptions}</TableCell>
                                <TableCell>{coupon.used_count}</TableCell>
                                <TableCell>{formatRedeemBy(coupon.redeem_by)}</TableCell>
                                <TableCell>{coupon.currency.toUpperCase()}</TableCell>
                                <TableCell>{coupon.is_active ? 'Yes' : 'No'}</TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            onClick={() => fetchSingleCoupon(coupon.id)}
                                        >
                                            <BadgePercent className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            onClick={() => fetchSingleCoupon(coupon.id)}
                                        >
                                            <Eye className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            onClick={() => setEditCoupon(coupon)}
                                        >
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            onClick={() => setDeleteCoupon(coupon)}
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search coupons by code"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full max-w-md"
            />
            {renderContent()}

            {/* View Dialog */}
            <Dialog open={!!viewCoupon} onOpenChange={() => setViewCoupon(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>View Coupon: {viewCoupon?.code}</DialogTitle>
                    </DialogHeader>
                    {loading ? (
                        <div className="flex justify-center">
                            <Loader2 className="h-6 w-6 animate-spin" />
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <p><strong>Stripe ID:</strong> {viewCoupon?.stripe_coupon_id}</p>
                            <p><strong>Type:</strong> {viewCoupon?.discount_type.toUpperCase()}</p>
                            <p><strong>Value:</strong> {viewCoupon && formatDiscountValue(viewCoupon)}</p>
                            {/* <p><strong>Duration:</strong> {viewCoupon?.duration}</p> */}
                            <p><strong>Max Redemptions:</strong> {viewCoupon?.max_redemptions}</p>
                            <p><strong>Used Count:</strong> {viewCoupon?.used_count}</p>
                            <p><strong>Expires:</strong> {formatRedeemBy(viewCoupon?.redeem_by)}</p>
                            <p><strong>Currency:</strong> {viewCoupon?.currency.toUpperCase()}</p>
                            <p><strong>Active:</strong> {viewCoupon?.is_active ? 'Yes' : 'No'}</p>
                            <p><strong>Created:</strong> {viewCoupon?.created_at ? format(new Date(viewCoupon.created_at), 'PPP') : ''}</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Edit Dialog */}
            <Dialog open={!!editCoupon} onOpenChange={() => setEditCoupon(null)}>
                <DialogContent className="w-screen h-screen max-w-full sm:h-auto sm:max-h-[90vh] sm:max-w-[90vw] sm:w-full overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit Coupon: {editCoupon?.code}</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Left Column: Code, Discount Type, Discount Value, Duration */}
                                <div className="space-y-6">
                                    <FormField
                                        control={form.control}
                                        name="code"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Code</FormLabel>
                                                <FormControl>
                                                    <Input placeholder="e.g., SAVE20" {...field} />
                                                </FormControl>
                                                <FormDescription>Human-readable coupon code (unique).</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="discount_type"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Discount Type</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select discount type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value={DiscountType.PERCENT}>Percentage (% off)</SelectItem>
                                                        <SelectItem value={DiscountType.AMOUNT}>Fixed Amount ($ off)</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <FormDescription>Choose whether the discount is a percentage or fixed amount.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="discount_value"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Discount Value</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="number"
                                                        step="0.01"
                                                        min="0"
                                                        max={form.watch('discount_type') === DiscountType.PERCENT ? "500" : undefined}
                                                        placeholder={form.watch('discount_type') === DiscountType.PERCENT ? "e.g., 20 for 20%" : "e.g., 5 for $5 off"}
                                                        {...field}
                                                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                                        value={field.value || ''}
                                                    />
                                                </FormControl>
                                                <FormDescription>
                                                    {form.watch('discount_type') === DiscountType.PERCENT ? 'Percentage off (0-500).' : 'Fixed amount off.'}
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    {/* <FormField
                                        control={form.control}
                                        name="duration"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Duration</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select duration" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value={DurationType.ONCE}>Once</SelectItem>
                                                        <SelectItem value={DurationType.REPEATING}>Repeating</SelectItem>
                                                        <SelectItem value={DurationType.FOREVER}>Forever</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <FormDescription>How long the coupon applies (once, repeating, or forever).</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    /> */}
                                </div>

                                {/* Right Column: Max Redemptions, Redeem By, Currency, Active */}
                                <div className="space-y-6">
                                    <FormField
                                        control={form.control}
                                        name="max_redemptions"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Max Redemptions</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="number"
                                                        min="0"
                                                        max="999999"
                                                        placeholder="e.g., 100"
                                                        {...field}
                                                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                                        value={field.value || ''}
                                                    />
                                                </FormControl>
                                                <FormDescription>Maximum number of times this coupon can be used (0 for unlimited).</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="redeem_by"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Expiration Date</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="date"
                                                        {...field}
                                                        value={field.value || ''}
                                                        onChange={(e) => field.onChange(e.target.value)}
                                                    />
                                                </FormControl>
                                                <FormDescription>Optional expiration date for the coupon.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="currency"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Currency</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select currency" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {CurrencyOptions.map((currency) => (
                                                            <SelectItem key={currency} value={currency}>
                                                                {currency.toUpperCase()}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormDescription>
                                                    Required for fixed amount discounts.
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="is_active"
                                        render={({ field }) => (
                                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                                <FormControl>
                                                    <Checkbox
                                                        checked={field.value}
                                                        onCheckedChange={field.onChange}
                                                    />
                                                </FormControl>
                                                <div className="space-y-1 leading-none">
                                                    <FormLabel>Active</FormLabel>
                                                    <FormDescription>
                                                        Whether the coupon is currently active.
                                                    </FormDescription>
                                                </div>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setEditCoupon(null)}>
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading}>
                                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation Dialog */}
            <Dialog open={!!deleteCoupon} onOpenChange={() => setDeleteCoupon(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Delete Coupon: {deleteCoupon?.code}</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to delete this coupon? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setDeleteCoupon(null)}>
                            Cancel
                        </Button>
                        <Button
                            type="button"
                            variant="destructive"
                            onClick={() => deleteCoupon && handleDelete(deleteCoupon)}
                            disabled={loading}
                        >
                            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Delete'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default CouponTable;
