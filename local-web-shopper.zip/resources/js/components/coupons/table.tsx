import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, Eye, Pencil, Trash2, BadgePercent } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { parseISO, format } from 'date-fns';
import { Toaster } from 'sonner';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';
import { router } from '@inertiajs/react';

// Constants for coupon and promo code options
const DiscountType = {
    PERCENT: 'percent',
    AMOUNT: 'amount',
} as const;

const DurationType = {
    ONCE: 'once',
    REPEATING: 'repeating',
    FOREVER: 'forever',
} as const;

const CurrencyOptions = ['usd'] as const;

// Zod schema for coupon
const couponSchema = z.object({
    code: z.string().min(2, { message: 'Code must be at least 2 characters.' }),
    discount_type: z.enum([DiscountType.PERCENT, DiscountType.AMOUNT], {
        errorMap: () => ({ message: 'Please select a valid discount type (percent or amount).' }),
    }),
    discount_value: z.number({
        required_error: 'Discount value is required.',
        invalid_type_error: 'Discount value must be a number.',
    }).positive('Discount value must be positive.').refine((val) => val <= 500, {
        message: 'For percentage discounts, value must not exceed 500.',
    }),
    duration: z.enum([DurationType.ONCE, DurationType.REPEATING, DurationType.FOREVER], {
        errorMap: () => ({ message: 'Please select a valid duration (once, repeating, or forever).' }),
    }),
    max_redemptions: z.number().int().min(0).max(999999),
    redeem_by: z.string().optional(),
    currency: z.enum(CurrencyOptions),
    is_active: z.boolean(),
}).refine((data) => {
    if (data.discount_type === DiscountType.AMOUNT && !data.currency) {
        return false;
    }
    return true;
}, {
    message: 'Currency is required for amount discounts.',
    path: ['currency'],
});

// Zod schema for promo code
const promoCodeSchema = z.object({
    code: z.string().min(2, { message: 'Promo code must be at least 2 characters.' }),
    max_redemptions: z.number().int().min(0).max(999999).optional(),
    expires_at: z.string().optional(),
    is_active: z.boolean(),
});

type CouponFormData = z.infer<typeof couponSchema>;
type PromoCodeFormData = z.infer<typeof promoCodeSchema>;

// Interfaces
interface Coupon {
    id: number;
    stripe_coupon_id: string;
    code: string;
    discount_type: 'percent' | 'amount';
    discount_value: number;
    duration: 'once' | 'repeating' | 'forever';
    max_redemptions: number;
    used_count: number;
    redeem_by: string | null;
    currency: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
}

interface PromoCode {
    id: number;
    stripe_promo_code_id: string;
    code: string;
    coupon_id: string;
    coupon_code: string;
    max_redemptions: number;
    used_count: number;
    expires_at: string | null;
    is_active: boolean;
    created_at: string;
    updated_at: string;
}

interface ApiResponse<T> {
    data: T[];
    meta: {
        current_page: number;
        last_page: number;
        per_page: number;
        total: number;
    };
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    coupons: Coupon[];
    errors: { coupons?: string; promo_codes?: string };
    [key: string]: any;
}

const CouponTable: React.FC = () => {
    const { coupons: initialCoupons, errors: initialErrors } = usePage<PageProps>().props;

    // Normalize coupon data
    const normalizeCoupon = (coupon: any): Coupon => ({
        ...coupon,
        discount_value: typeof coupon.discount_value === 'string' ? parseFloat(coupon.discount_value) : coupon.discount_value,
        is_active: typeof coupon.is_active === 'number' ? Boolean(coupon.is_active) : coupon.is_active,
        redeem_by: coupon.redeem_by ? format(parseISO(coupon.redeem_by), 'yyyy-MM-dd') : null,
    });

    // Normalize promo code data
    const normalizePromoCode = (promo: any): PromoCode => ({
        ...promo,
        used_count: promo.used_count || 0,
        is_active: typeof promo.is_active === 'number' ? Boolean(promo.is_active) : promo.is_active,
        expires_at: promo.expires_at ? format(parseISO(promo.expires_at), 'yyyy-MM-dd') : null,
    });

    const [coupons, setCoupons] = useState<Coupon[]>(initialCoupons.map(normalizeCoupon) || []);
    const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ coupons?: string; promo_codes?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<ApiResponse<Coupon>['meta'] | null>(null);
    const [promoPagination, setPromoPagination] = useState<ApiResponse<PromoCode>['meta'] | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [promoCurrentPage, setPromoCurrentPage] = useState(1);

    const [viewCoupon, setViewCoupon] = useState<Coupon | null>(null);
    const [editCoupon, setEditCoupon] = useState<Coupon | null>(null);
    const [deleteCoupon, setDeleteCoupon] = useState<Coupon | null>(null);
    const [createPromoCode, setCreatePromoCode] = useState<Coupon | null>(null);
    const [viewPromoCode, setViewPromoCode] = useState<PromoCode | null>(null);
    const [editPromoCode, setEditPromoCode] = useState<PromoCode | null>(null);
    const [deletePromoCode, setDeletePromoCode] = useState<PromoCode | null>(null);

    const { showAlert } = useAlert();
    const { showError } = useError();

    const couponForm = useForm<CouponFormData>({
        resolver: zodResolver(couponSchema),
        defaultValues: {
            code: '',
            discount_type: DiscountType.PERCENT,
            discount_value: 0,
            duration: DurationType.FOREVER,
            max_redemptions: 1,
            redeem_by: '',
            currency: 'usd',
            is_active: true,
        },
    });

    const promoCodeForm = useForm<PromoCodeFormData>({
        resolver: zodResolver(promoCodeSchema),
        defaultValues: {
            code: '',
            max_redemptions: 1,
            expires_at: '',
            is_active: true,
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchCoupons(1);
            fetchPromoCodes(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editCoupon) {
            couponForm.reset({
                code: editCoupon.code,
                discount_type: editCoupon.discount_type,
                discount_value: editCoupon.discount_value,
                duration: editCoupon.duration,
                max_redemptions: editCoupon.max_redemptions,
                redeem_by: editCoupon.redeem_by || '',
                currency: editCoupon.currency,
                is_active: editCoupon.is_active,
            });
        }
    }, [editCoupon, couponForm]);

    useEffect(() => {
        if (editPromoCode) {
            promoCodeForm.reset({
                code: editPromoCode.code,
                max_redemptions: editPromoCode.max_redemptions,
                expires_at: editPromoCode.expires_at || '',
                is_active: editPromoCode.is_active,
            });
        }
    }, [editPromoCode, promoCodeForm]);

    const fetchCoupons = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse<Coupon>>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons`, {
                params: { code: searchTerm, page },
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            setCoupons(response.data.data.map(normalizeCoupon));
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors((prev) => ({ ...prev, coupons: undefined }));
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors((prev) => ({ ...prev, coupons: error?.response.data.message || 'An error occurred while fetching coupons.' }));
            } else {
                setErrors((prev) => ({ ...prev, coupons: 'An unexpected error occurred.' }));
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchPromoCodes = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse<PromoCode>>(`${import.meta.env.VITE_APP_URL}/api/v1/promo-codes`, {
                params: { code: searchTerm, page },
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            setPromoCodes(response.data.data.map(normalizePromoCode));
            setPromoPagination(response.data.meta);
            setPromoCurrentPage(page);
            setErrors((prev) => ({ ...prev, promo_codes: undefined }));
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors((prev) => ({ ...prev, promo_codes: error?.response?.data.message || 'An error occurred while fetching promo codes.' }));
            } else {
                setErrors((prev) => ({ ...prev, promo_codes: 'An unexpected error occurred.' }));
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchSingleCoupon = async (id: number | string) => {
        setLoading(true);
        try {
            const response = await axios.get<{ data: Coupon }>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${id}`, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            setViewCoupon(normalizeCoupon(response.data.data));
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to fetch coupon details');
            } else {
                showError('An unexpected error occurred while fetching the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchSinglePromoCode = async (id: number | string) => {
        setLoading(true);
        try {
            const response = await axios.get<{ data: PromoCode }>(`${import.meta.env.VITE_APP_URL}/api/v1/promo-codes/${id}`, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            setViewPromoCode(normalizePromoCode(response.data.data));
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to fetch promo code details');
            } else {
                showError('An unexpected error occurred while fetching the promo code');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEditCoupon = async (values: CouponFormData) => {
        if (!editCoupon) return;
        setLoading(true);
        try {
            const dataToSend = {
                code: values.code,
                discount_type: values.discount_type,
                discount_value: Number(values.discount_value.toFixed(2)),
                duration: values.duration,
                max_redemptions: values.max_redemptions,
                redeem_by: values.redeem_by || null,
                currency: values.currency,
                is_active: values.is_active,
            };
            await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${editCoupon.id}`, dataToSend, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            fetchCoupons(currentPage);
            setEditCoupon(null);
            couponForm.reset();
            showAlert('success', 'Coupon updated successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to update coupon');
            } else {
                showError('An unexpected error occurred while updating the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteCoupon = async (coupon: Coupon) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/${coupon.id}`, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            fetchCoupons(currentPage);
            setDeleteCoupon(null);
            showAlert('success', 'Coupon deleted successfully');
            router.reload({ only: ['promoCodes'] });
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to delete coupon');
            } else {
                showError('An unexpected error occurred while deleting the coupon');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleCreatePromoCode = async (values: PromoCodeFormData) => {
        if (!createPromoCode) return;
        setLoading(true);
        try {
            const dataToSend = {
                code: values.code,
                coupon_id: createPromoCode.stripe_coupon_id,
                max_redemptions: values.max_redemptions || null,
                expires_at: values.expires_at || null,
                is_active: values.is_active,
            };
            await axios.post(`${import.meta.env.VITE_APP_URL}/api/v1/promo-codes`, dataToSend, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            fetchPromoCodes(promoCurrentPage);
            setCreatePromoCode(null);
            promoCodeForm.reset();
            showAlert('success', 'Promo code created successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to create promo code');
            } else {
                showError('An unexpected error occurred while creating the promo code');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEditPromoCode = async (values: PromoCodeFormData) => {
        if (!editPromoCode) return;
        setLoading(true);
        try {
            const dataToSend = {
                stripe_promo_code_id: editPromoCode.stripe_promo_code_id,
                code: values.code,
                max_redemptions: values.max_redemptions || null,
                expires_at: values.expires_at || null,
                is_active: values.is_active,
            };
            await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/promo-codes/${editPromoCode.id}`, dataToSend, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            fetchPromoCodes(promoCurrentPage);
            setEditPromoCode(null);
            promoCodeForm.reset();
            showAlert('success', 'Promo code updated successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to update promo code');
            } else {
                showError('An unexpected error occurred while updating the promo code');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDeletePromoCode = async (promoCode: PromoCode) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/promo-codes/${promoCode.id}`, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            fetchPromoCodes(promoCurrentPage);
            setDeletePromoCode(null);
            showAlert('success', 'Promo code deactivated successfully');
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                showError(error.response.data.message || 'Failed to deactivate promo code');
            } else {
                showError('An unexpected error occurred while deactivating the promo code');
            }
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = (type: 'coupon' | 'promo') => {
        const pag = type === 'coupon' ? pagination : promoPagination;
        const page = type === 'coupon' ? currentPage : promoCurrentPage;
        const setPage = type === 'coupon' ? setCurrentPage : setPromoCurrentPage;
        const fetchData = type === 'coupon' ? fetchCoupons : fetchPromoCodes;

        if (!pag || pag.total <= pag.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchData(page - 1)}
                    disabled={page === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchData(page + 1)}
                    disabled={page === pag.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const formatDiscountValue = (coupon: Coupon) => {
        if (coupon.discount_type === 'percent') {
            return `${coupon.discount_value}% off`;
        }
        return `${coupon.currency.toUpperCase()} ${Number(coupon.discount_value).toFixed(2)} off`;
    };

    const formatDate = (date: string | null) => {
        if (!date) return 'No expiration';
        return format(new Date(date), 'PPP');
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.coupons || errors.promo_codes) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.coupons || errors.promo_codes}</AlertDescription>
                </Alert>
            );
        }

        return (
            <>
                <h2 className="text-xl font-semibold mb-4">Coupons</h2>
                {coupons.length === 0 ? (
                    <p className="text-center text-gray-500">No coupons found.</p>
                ) : (
                    <>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Code</TableHead>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Value</TableHead>
                                    <TableHead>Max Uses</TableHead>
                                    {/* <TableHead>Used</TableHead> */}
                                    <TableHead>Expires</TableHead>
                                    <TableHead>Currency</TableHead>
                                    <TableHead>Active</TableHead>
                                    <TableHead>Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {coupons.map((coupon) => (
                                    <TableRow key={coupon.id}>
                                        <TableCell className="font-medium">{coupon.code}</TableCell>
                                        <TableCell>{coupon.discount_type.toUpperCase()}</TableCell>
                                        <TableCell>{formatDiscountValue(coupon)}</TableCell>
                                        <TableCell>{coupon.max_redemptions}</TableCell>
                                        {/* <TableCell>{coupon.used_count}</TableCell> */}
                                        <TableCell>{formatDate(coupon.redeem_by)}</TableCell>
                                        <TableCell>{coupon.currency.toUpperCase()}</TableCell>
                                        <TableCell>{coupon.is_active ? 'Yes' : 'No'}</TableCell>
                                        <TableCell>
                                            <div className="flex space-x-2">
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => setCreatePromoCode(coupon)}
                                                    title="Generate Promo Code"
                                                >
                                                    <BadgePercent className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => fetchSingleCoupon(coupon.id)}
                                                >
                                                    <Eye className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => setEditCoupon(coupon)}
                                                >
                                                    <Pencil className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => setDeleteCoupon(coupon)}
                                                    disabled={loading || coupon.used_count > 0} // Disable if coupon has been used
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {renderPagination('coupon')}
                    </>
                )}

                {/* Delete Coupon Confirmation Dialog */}
                <Dialog open={!!deleteCoupon} onOpenChange={() => setDeleteCoupon(null)}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Delete Coupon: {deleteCoupon?.code}</DialogTitle>
                            <DialogDescription>
                                Are you sure you want to delete this coupon? This action cannot be undone.
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setDeleteCoupon(null)}>
                                Cancel
                            </Button>
                            <Button
                                type="button"
                                variant="destructive"
                                onClick={() => deleteCoupon && handleDeleteCoupon(deleteCoupon)}
                                disabled={loading}
                            >
                                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Delete'}
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                <h2 className="text-xl font-semibold mt-8 mb-4">Promo Codes</h2>
                {promoCodes.length === 0 ? (
                    <p className="text-center text-gray-500">No promo codes found.</p>
                ) : (
                    <>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Code</TableHead>
                                    <TableHead>Coupon ID</TableHead>
                                    <TableHead>Max Uses</TableHead>
                                    <TableHead>Used</TableHead>
                                    <TableHead>Expires</TableHead>
                                    <TableHead>Active</TableHead>
                                    <TableHead>Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {promoCodes.map((promo) => (
                                    <TableRow key={promo.id}>
                                        <TableCell className="font-medium">{promo.code}</TableCell>
                                        <TableCell>{promo?.coupon_code}</TableCell>
                                        <TableCell>{promo.max_redemptions || 'Unlimited'}</TableCell>
                                        <TableCell>{promo.used_count}</TableCell>
                                        <TableCell>{formatDate(promo.expires_at)}</TableCell>
                                        <TableCell>{promo.is_active ? 'Yes' : 'No'}</TableCell>
                                        <TableCell>
                                            <div className="flex space-x-2">
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => fetchSinglePromoCode(promo.id)}
                                                >
                                                    <Eye className="h-4 w-4" />
                                                </Button>
                                                {/* <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => setEditPromoCode(promo)}
                                                >
                                                    <Pencil className="h-4 w-4" />
                                                </Button> */}
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => setDeletePromoCode(promo)}
                                                    disabled={loading || promo.used_count > 0} // Disable if coupon has been used
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>

                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {renderPagination('promo')}
                    </>
                )}
            </>
        );
    };

    return (
        <div className="space-y-4">
            {/* <Toaster /> */}
            <Input
                placeholder="Search coupons or promo codes by code"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full max-w-md"
            />
            {renderContent()}

            {/* View Coupon Dialog */}
            <Dialog open={!!viewCoupon} onOpenChange={() => setViewCoupon(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>View Coupon: {viewCoupon?.code}</DialogTitle>
                    </DialogHeader>
                    {loading ? (
                        <div className="flex justify-center">
                            <Loader2 className="h-6 w-6 animate-spin" />
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <p><strong>Stripe ID:</strong> {viewCoupon?.stripe_coupon_id}</p>
                            <p><strong>Type:</strong> {viewCoupon?.discount_type.toUpperCase()}</p>
                            <p><strong>Value:</strong> {viewCoupon && formatDiscountValue(viewCoupon)}</p>
                            <p><strong>Max Redemptions:</strong> {viewCoupon?.max_redemptions}</p>
                            {/* <p><strong>Used Count:</strong> {viewCoupon?.used_count}</p> */}
                            <p><strong>Expires:</strong> {formatDate(viewCoupon?.redeem_by)}</p>
                            <p><strong>Currency:</strong> {viewCoupon?.currency.toUpperCase()}</p>
                            <p><strong>Active:</strong> {viewCoupon?.is_active ? 'Yes' : 'No'}</p>
                            <p><strong>Created:</strong> {viewCoupon?.created_at ? format(new Date(viewCoupon.created_at), 'PPP') : ''}</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Edit Coupon Dialog */}
            <Dialog open={!!editCoupon} onOpenChange={() => setEditCoupon(null)}>
                <DialogContent className="w-screen h-screen max-w-full sm:h-auto sm:max-h-[90vh] sm:max-w-[90vw] sm:w-full overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit Coupon: {editCoupon?.code}</DialogTitle>
                    </DialogHeader>
                    <Form {...couponForm}>
                        <form onSubmit={couponForm.handleSubmit(handleEditCoupon)} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-6">
                                    <FormField
                                        control={couponForm.control}
                                        name="code"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Code</FormLabel>
                                                <FormControl>
                                                    <Input placeholder="e.g., SAVE20" {...field} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={couponForm.control}
                                        name="discount_type"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Discount Type</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select discount type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value={DiscountType.PERCENT}>Percentage (% off)</SelectItem>
                                                        <SelectItem value={DiscountType.AMOUNT}>Fixed Amount ($ off)</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={couponForm.control}
                                        name="discount_value"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Discount Value</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="number"
                                                        step="0.01"
                                                        min="0"
                                                        max={couponForm.watch('discount_type') === DiscountType.PERCENT ? "500" : undefined}
                                                        placeholder={couponForm.watch('discount_type') === DiscountType.PERCENT ? "e.g., 20 for 20%" : "e.g., 5 for $5 off"}
                                                        {...field}
                                                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                                        value={field.value || ''}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                                <div className="space-y-6">
                                    <FormField
                                        control={couponForm.control}
                                        name="max_redemptions"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Max Redemptions</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="number"
                                                        min="0"
                                                        max="999999"
                                                        placeholder="e.g., 100"
                                                        {...field}
                                                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                                        value={field.value || ''}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={couponForm.control}
                                        name="redeem_by"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Expiration Date</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="date"
                                                        {...field}
                                                        value={field.value || ''}
                                                        onChange={(e) => field.onChange(e.target.value)}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={couponForm.control}
                                        name="currency"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Currency</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select currency" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {CurrencyOptions.map((currency) => (
                                                            <SelectItem key={currency} value={currency}>
                                                                {currency.toUpperCase()}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={couponForm.control}
                                        name="is_active"
                                        render={({ field }) => (
                                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                                <FormControl>
                                                    <Checkbox
                                                        checked={field.value}
                                                        onCheckedChange={field.onChange}
                                                    />
                                                </FormControl>
                                                <div className="space-y-1 leading-none">
                                                    <FormLabel>Active</FormLabel>
                                                </div>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setEditCoupon(null)}>
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading}>
                                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            {/* Create Promo Code Dialog */}
            <Dialog open={!!createPromoCode} onOpenChange={() => setCreatePromoCode(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Create Promo Code for Coupon: {createPromoCode?.code}</DialogTitle>
                    </DialogHeader>
                    <Form {...promoCodeForm}>
                        <form onSubmit={promoCodeForm.handleSubmit(handleCreatePromoCode)} className="space-y-6">
                            <FormField
                                control={promoCodeForm.control}
                                name="code"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Promo Code</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g., PROMO20" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="max_redemptions"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Max Redemptions</FormLabel>
                                        <FormControl>
                                            <Input
                                                type="number"
                                                min="0"
                                                max="999999"
                                                placeholder="e.g., 100"
                                                {...field}
                                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                                value={field.value || ''}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="expires_at"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Expiration Date</FormLabel>
                                        <FormControl>
                                            <Input
                                                type="date"
                                                {...field}
                                                value={field.value || ''}
                                                onChange={(e) => field.onChange(e.target.value)}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="is_active"
                                render={({ field }) => (
                                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                        <FormControl>
                                            <Checkbox
                                                checked={field.value}
                                                onCheckedChange={field.onChange}
                                            />
                                        </FormControl>
                                        <div className="space-y-1 leading-none">
                                            <FormLabel>Active</FormLabel>
                                        </div>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setCreatePromoCode(null)}>
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading}>
                                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Promo Code'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            {/* View Promo Code Dialog */}
            <Dialog open={!!viewPromoCode} onOpenChange={() => setViewPromoCode(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>View Promo Code: {viewPromoCode?.code}</DialogTitle>
                    </DialogHeader>
                    {loading ? (
                        <div className="flex justify-center">
                            <Loader2 className="h-6 w-6 animate-spin" />
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <p><strong>Stripe ID:</strong> {viewPromoCode?.stripe_promo_code_id}</p>
                            <p><strong>Coupon ID:</strong> {viewPromoCode?.coupon_id}</p>
                            <p><strong>Max Redemptions:</strong> {viewPromoCode?.max_redemptions || 'Unlimited'}</p>
                            <p><strong>Used Count:</strong> {viewPromoCode?.used_count}</p>
                            <p><strong>Expires:</strong> {formatDate(viewPromoCode?.expires_at)}</p>
                            <p><strong>Active:</strong> {viewPromoCode?.is_active ? 'Yes' : 'No'}</p>
                            <p><strong>Created:</strong> {viewPromoCode?.created_at ? format(new Date(viewPromoCode.created_at), 'PPP') : ''}</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Edit Promo Code Dialog */}
            <Dialog open={!!editPromoCode} onOpenChange={() => setEditPromoCode(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit Promo Code: {editPromoCode?.code}</DialogTitle>
                    </DialogHeader>
                    <Form {...promoCodeForm}>
                        <form onSubmit={promoCodeForm.handleSubmit(handleEditPromoCode)} className="space-y-6">
                            <FormField
                                control={promoCodeForm.control}
                                name="code"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Promo Code</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g., PROMO20" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="max_redemptions"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Max Redemptions</FormLabel>
                                        <FormControl>
                                            <Input
                                                type="number"
                                                min="0"
                                                max="999999"
                                                placeholder="e.g., 100"
                                                {...field}
                                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                                value={field.value || ''}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="expires_at"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Expiration Date</FormLabel>
                                        <FormControl>
                                            <Input
                                                type="date"
                                                {...field}
                                                value={field.value || ''}
                                                onChange={(e) => field.onChange(e.target.value)}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={promoCodeForm.control}
                                name="is_active"
                                render={({ field }) => (
                                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                        <FormControl>
                                            <Checkbox
                                                checked={field.value}
                                                onCheckedChange={field.onChange}
                                            />
                                        </FormControl>
                                        <div className="space-y-1 leading-none">
                                            <FormLabel>Active</FormLabel>
                                        </div>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setEditPromoCode(null)}>
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading}>
                                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            {/* Delete Promo Code Confirmation Dialog */}
            <Dialog open={!!deletePromoCode} onOpenChange={() => setDeletePromoCode(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Deactivate Promo Code: {deletePromoCode?.code}</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to deactivate this promo code? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setDeletePromoCode(null)}>
                            Cancel
                        </Button>
                        <Button
                            type="button"
                            variant="destructive"
                            onClick={() => deletePromoCode && handleDeletePromoCode(deletePromoCode)}
                            disabled={loading}
                        >
                            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Deactivate'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default CouponTable;
