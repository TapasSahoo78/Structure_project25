import React, { useState } from 'react';
import { X, Edit2, Check, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { File } from '@/types';

interface FileDisplayProps {
    file: File;
    onRemove: () => void;
    onUpdateName: (newName: string) => void;
}

export function FileDisplay({ file, onRemove, onUpdateName }: FileDisplayProps) {
    const [isEditing, setIsEditing] = useState(false);
    const [editedName, setEditedName] = useState(file.filename);

    const handleSave = () => {
        onUpdateName(editedName);
        setIsEditing(false);
    };

    const renderPreview = () => {
        if (file.mime_type.startsWith('image/')) {
            return <img src={file.path} alt={file.filename} className="max-w-full max-h-[80vh] object-contain" />;
        } else if (file.mime_type.startsWith('video/')) {
            return <video src={file.path} controls className="max-w-full max-h-[80vh]" />;
        } else {
            return <div className="text-center p-4">No preview available for this file type</div>;
        }
    };

    return (
        <div className="bg-white border rounded-lg overflow-hidden">
            <div className="p-3 relative">
                <div className="flex items-center justify-between mb-2">
                    {file.mime_type.startsWith('image/') ? (
                        <img
                            src={file.path}
                            alt={file.filename}
                            className="w-16 h-16 object-cover rounded"
                        />
                    ) : (
                        <div className="w-16 h-16 bg-gray-200 rounded flex items-center justify-center text-gray-500">
                            {file.mime_type.split('/')[0]}
                        </div>
                    )}
                    <div className="flex space-x-2 absolute top-3 right-3">
                        <Dialog>
                            <DialogTrigger asChild>
                                <button
                                    onClick={(e) => e.preventDefault()}
                                    className="text-blue-500 hover:text-blue-700"
                                >
                                    <Eye className="w-5 h-5" />
                                </button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[80vw]">
                                <div className="mt-4">{renderPreview()}</div>
                            </DialogContent>
                        </Dialog>
                        <button
                            onClick={(e) => { e.preventDefault(); onRemove(); }}
                            className="text-red-500 hover:text-red-700"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                </div>
                {isEditing ? (
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={editedName}
                            onChange={(e) => setEditedName(e.target.value)}
                            className="flex-grow text-sm text-gray-700 border rounded px-2 py-1"
                        />
                        <button
                            onClick={(e) => { e.preventDefault(); handleSave(); }}
                            className="text-green-500 hover:text-green-700"
                        >
                            <Check className="w-5 h-5" />
                        </button>
                        <button
                            onClick={(e) => { e.preventDefault(); setIsEditing(false); }}
                            className="text-gray-500 hover:text-gray-700"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                ) : (
                    <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-700 truncate">{file.filename}</span>
                        <button
                            onClick={(e) => { e.preventDefault(); setIsEditing(true); }}
                            className="text-blue-500 hover:text-blue-700"
                        >
                            <Edit2 className="w-5 h-5" />
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}