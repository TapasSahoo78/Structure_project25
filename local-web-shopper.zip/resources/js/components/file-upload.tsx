import React, { useState, useRef, DragEvent, FormEvent, useEffect } from 'react';
import { Upload } from 'lucide-react';
import axios from 'axios';
import { z } from 'zod';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';
import { FileDisplay } from './file-display';
import { type File } from '@/types';

interface FileUploadProps {
    id: string;
    onFileSelect: (file_id: number | null) => void;
    initialFile?: File;
}

const fileSchema = z.object({
    file: z.instanceof(File).refine((file) => file.size <= 10 * 1024 * 1024, {
        message: "File size must be 10MB or less",
    }),
});

export function FileUpload({ id, onFileSelect, initialFile }: FileUploadProps) {
    const [file, setFile] = useState<File | null>(null);
    const [uploading, setUploading] = useState<boolean>(false);
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { showAlert } = useAlert();
    const { setInputError, clearInputError, setGlobalError } = useError();

    useEffect(() => {
        if (initialFile) {
            setFile(initialFile);
        }
    }, [initialFile]);
    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        event.preventDefault();
        const selectedFile = event.target.files?.[0];
        if (selectedFile) {
            await uploadFile(selectedFile);
        }
    };

    const handleDragEnter = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(false);
    };

    const handleDragOver = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
    };

    const handleDrop = async (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(false);
        const droppedFile = event.dataTransfer.files[0];
        if (droppedFile) {
            await uploadFile(droppedFile);
        }
    };

    const uploadFile = async (newFile: File) => {
        setUploading(true);
        try {
            const validatedData = fileSchema.parse({ file: newFile });
            const formData = new FormData();
            formData.append('file', validatedData.file);

            const response = await axios.post(`${import.meta.env.VITE_APP_URL}/api/v1/files`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            console.log('Upload response:', response);
            const uploadedFile = response.data.data;
            setFile(uploadedFile);
            onFileSelect(uploadedFile.id);
            clearInputError('file');
        } catch (error) {
            console.error('Error in file upload:', error);
            if (error instanceof z.ZodError) {
                error.errors.forEach((err) => {
                    setInputError(err.path.join('.'), err.message);
                });
            } else if (axios.isAxiosError(error)) {
                setGlobalError(error.response?.data?.message || 'An error occurred while uploading the file');
            } else {
                console.error('Error uploading file:', error);
                setGlobalError('An unexpected error occurred');
            }
        } finally {
            setUploading(false);
        }
    };

    const removeFile = async () => {
        if (!file) return;
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/files/${file.id}`);
            setFile(null);
            onFileSelect(null);
        } catch (error) {
            console.error('Error removing file:', error);
            setGlobalError('An error occurred while removing the file');
        }
    };

    const updateFileName = async (newName: string) => {
        if (!file) return;
        try {
            const response = await axios.patch(`${import.meta.env.VITE_APP_URL}/api/v1/files/${file.id}`, { filename: newName });
            const updatedFile = response.data.data;
            setFile(updatedFile);
        } catch (error) {
            console.error('Error updating file name:', error);
            setGlobalError('An error occurred while updating the file name');
        }
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    return (
        <div className="space-y-4">
            {!file && (
                <div
                    className={`relative p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ease-in-out ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
                        }`}
                    onDragEnter={handleDragEnter}
                    onDragLeave={handleDragLeave}
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onClick={handleClick}
                >
                    <input
                        type="file"
                        id={id}
                        ref={fileInputRef}
                        className="hidden"
                        onChange={handleFileChange}
                    />
                    <div className="flex flex-col items-center justify-center text-center">
                        <Upload className="w-12 h-12 mb-4 text-gray-400" />
                        <p className="mb-2 text-sm font-semibold text-gray-700">
                            Click to upload or drag and drop
                        </p>
                        <p className="text-xs text-gray-500">Upload a file</p>
                    </div>
                </div>
            )}

            {uploading && (
                <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                    <div className="bg-blue-600 h-2.5 rounded-full w-1/2"></div>
                </div>
            )}

            {file && (
                <FileDisplay
                    file={file}
                    onRemove={removeFile}
                    onUpdateName={updateFileName}
                />
            )}
        </div>
    );
}
