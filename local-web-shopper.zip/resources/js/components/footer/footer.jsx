import React from 'react'
import { Link } from '@inertiajs/react';

export function Footer() {
    return (
        <>
            <div className="foote py-8 lg:py-16">
                <div className="container mx-auto">
                    <div className="flex flex-col md:flex-row gap-2 md:gap-4 lg:gap-6 items-center">
                        <div className="w-1/1 sm:w-1/1 md:w-1/4 lg:w-1/3">
                            <div className="ftlogo text-cente">
                                <img src={`${import.meta.env.VITE_APP_URL}/images/logo/logo_light.png`} alt="Local Web Shopper Logo" className="max-w-[200px] w-auto mx-auto" />
                            </div>
                        </div>
                        <div className="w-1/1 sm:w-1/1 md:w-1/4 lg:w-1/3">
                            <h1 className='text-center text-white text-2xl mb-4'>Quick Links</h1>
                            <ul className='footerMenu'>
                                <li className='mb-3 text-white text-sm'><Link href="">About Us</Link></li>
                                <li className='mb-3 text-white text-sm'><Link href="">Privacy Policy</Link></li>
                                <li className='mb-3 text-white text-sm'><Link href="">Support</Link></li>
                                <li className='mb-3 text-white text-sm'><Link href="">Content Policy</Link></li>
                                <li className=' text-white text-sm'><Link href="">Terms & Conditions</Link></li>
                            </ul>
                        </div>
                        <div className="w-1/1 sm:w-1/1 md:w-1/3 lg:w-1/3">
                            {/* <div className="">
                                <img src={`${import.meta.env.VITE_APP_URL}/images/landing/app_store.png`} alt="Local Web Shopper Logo" className=" max-w-[200px] mx-auto" />
                            </div> */}

                            <div className="mt-8 space-x-4">
                                <div className="flex flex-col gap-2 max-w-[300px] sm:max-w-[360px]">
                                    <>
                                        <a href="https://apps.apple.com/us/app/local-web-shopper/id6449487847" target="_blank" rel="noopener noreferrer">
                                            {/* Download on App Store */}
                                            <img
                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/app-store.png`}
                                                alt="Download on App Store"
                                                className="rounded-lg w-50"
                                            />
                                        </a>
                                        <a href="https://play.google.com/store/apps/details?id=com.localweb.south&pli=1" target="_blank" rel="noopener noreferrer">
                                            {/* Get it on Google Play */}
                                            <img
                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/playstore.png`}
                                                alt="Get it on Google Play"
                                                className="rounded-lg w-50"
                                            />
                                        </a>
                                    </>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

