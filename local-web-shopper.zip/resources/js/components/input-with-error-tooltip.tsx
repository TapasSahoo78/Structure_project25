import React, { useState, useEffect } from 'react';
import { Input, InputProps } from '@/components/ui/input';
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import { Eye, EyeOff, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { useError } from '@/contexts/error-context';

interface InputWithErrorTooltipProps extends Omit<InputProps, 'required' | 'type'> {
    onValueChange: (value: string) => void;
    label?: string;
    required?: boolean;
    type?: string; // allow type prop but handle password separately
}

export const InputWithErrorTooltip: React.FC<InputWithErrorTooltipProps> = ({
    onValueChange,
    className,
    label,
    required,
    id,
    name,
    type = "text", // default type text
    ...props
}) => {
    const { inputErrors } = useError();
    const [showTooltip, setShowTooltip] = useState(false);
    const errorMessage = name ? inputErrors[name] : undefined;

    // Only enable show/hide toggle if input type is password
    const isPasswordField = type === "password";

    const [showPassword, setShowPassword] = useState(false);
    const handleToggleShow = () => {
        setShowPassword((prev) => !prev);
    };

    useEffect(() => {
        if (errorMessage) {
            setShowTooltip(true);
            const timer = setTimeout(() => setShowTooltip(false), 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onValueChange(e.target.value);
    };

    return (
        <div className="w-full">
            {label && (
                <Label htmlFor={id} className="mb-2 block">
                    {label}
                    {required && <span className="text-destructive ml-1">*</span>}
                </Label>
            )}

            <div className="relative">
                <Input
                    id={id}
                    name={name}
                    type={isPasswordField ? (showPassword ? "text" : "password") : type}
                    {...props}
                    onChange={handleChange}
                    required={required}
                    className={cn(
                        className,
                        errorMessage && "pr-16 border-destructive focus-visible:ring-destructive" // increased padding-right
                    )}
                />

                {(errorMessage || isPasswordField) && (
                    <div className="absolute inset-y-0 right-0 pr-2 flex items-center gap-x-2">
                        {isPasswordField && (
                            <button
                                type="button"
                                onClick={handleToggleShow}
                                className="text-sm text-gray-500"
                                tabIndex={-1}
                                aria-label={showPassword ? "Hide password" : "Show password"}
                            >
                                {/* {showPassword ? "Hide" : "Show"} */}
                                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>
                        )}

                        {errorMessage && (
                            <TooltipProvider>
                                <Tooltip open={showTooltip}>
                                    <TooltipTrigger asChild>
                                        <button
                                            type="button"
                                            className="flex items-center text-destructive"
                                            onClick={() => setShowTooltip(!showTooltip)}
                                            onMouseEnter={() => setShowTooltip(true)}
                                            onMouseLeave={() => setShowTooltip(false)}
                                            aria-label="Show error message"
                                        >
                                            <AlertCircle className="h-5 w-5" />
                                        </button>
                                    </TooltipTrigger>
                                    <TooltipContent
                                        side="top"
                                        align="end"
                                        className="bg-background border border-destructive text-destructive text-sm py-1 px-2"
                                        sideOffset={5}
                                    >
                                        <p>{errorMessage}</p>
                                    </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        )}
                    </div>
                )}
            </div>


            {/* <div className="relative">
                <Input
                    id={id}
                    name={name}
                    type={isPasswordField ? (showPassword ? "text" : "password") : type}
                    {...props}
                    onChange={handleChange}
                    required={required}
                    className={cn(
                        className,
                        errorMessage && "pr-10 border-destructive focus-visible:ring-destructive"
                    )}
                />
                {isPasswordField && (
                    <button
                        type="button"
                        onClick={handleToggleShow}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-sm text-gray-500"
                        tabIndex={-1}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                        {showPassword ? "Hide" : "Show"}
                    </button>
                )}

                {errorMessage && (
                    <TooltipProvider>
                        <Tooltip open={showTooltip}>
                            <TooltipTrigger asChild>
                                <div
                                    className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                                    onClick={() => setShowTooltip(!showTooltip)}
                                    onMouseEnter={() => setShowTooltip(true)}
                                    onMouseLeave={() => setShowTooltip(false)}
                                >
                                    <AlertCircle className="h-5 w-5 text-destructive" />
                                </div>
                            </TooltipTrigger>
                            <TooltipContent
                                side="top"
                                align="end"
                                className="bg-background border border-destructive text-destructive text-sm py-1 px-2"
                                sideOffset={5}
                            >
                                <p>{errorMessage}</p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                )}
            </div> */}
        </div>
    );
};
