import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatDate, formatCurrency } from "@/lib/utils";

interface InvoiceDetailsProps {
    invoiceId: string;
}

interface InvoiceData {
    id: string;
    number: string;
    status: string;
    due_date: number;
    amount_due: number;
    amount_paid: number;
    amount_remaining: number;
    currency: string;
    customer_name: string;
    customer_email: string;
    lines: {
        description: string;
        amount: number;
        quantity: number;
    }[];
}

export function InvoiceDetails({ invoiceId }: InvoiceDetailsProps) {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [invoiceData, setInvoiceData] = useState<InvoiceData | null>(null);

    useEffect(() => {
        const fetchInvoiceDetails = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_APP_URL}/api/v1/invoices/${invoiceId}`, {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    }
                });
                setInvoiceData(response.data);
            } catch (err) {
                setError('Failed to fetch invoice details. Please try again.');
            } finally {
                setLoading(false);
            }
        };

        fetchInvoiceDetails();
    }, [invoiceId]);

    if (loading) {
        return <div className="flex justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    if (error) {
        return <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>;
    }

    if (!invoiceData) {
        return <Alert variant="destructive"><AlertDescription>No invoice data found.</AlertDescription></Alert>;
    }

    return (
        <div className="w-full max-w-4xl mx-auto">
            <header className="flex flex-row items-center justify-between space-y-0 pb-2">
                <h1 className="text-2xl font-bold">Invoice</h1>
                <img
                    src={`${import.meta.env.VITE_APP_URL}/images/logo/logo.png`}
                    alt="Company Logo"
                    width={100}
                    height={50}
                    className="object-contain"
                />
            </header>
            <main className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <p><span className="font-medium">Number:</span> {invoiceData.number}</p>
                        <p><span className="font-medium">Status:</span> {invoiceData.status}</p>
                        <p><span className="font-medium">Due Date:</span> {formatDate(invoiceData.due_date)}</p>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold mb-2">Customer Information</h3>
                        <p><span className="font-medium">Name:</span> {invoiceData.customer_name}</p>
                        <p><span className="font-medium">Email:</span> {invoiceData.customer_email}</p>
                    </div>
                </div>

                <div>
                    <h3 className="text-lg font-semibold mb-2">Line Items</h3>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Description</TableHead>
                                <TableHead className="text-right">Quantity</TableHead>
                                <TableHead className="text-right">Amount</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {invoiceData.lines.map((line, index) => (
                                <TableRow key={index}>
                                    <TableCell>{line.description}</TableCell>
                                    <TableCell className="text-right">{line.quantity}</TableCell>
                                    <TableCell className="text-right">{formatCurrency(line.amount)}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>

                <div className="flex justify-end">
                    <div className="w-1/2">
                        <h3 className="text-lg font-semibold mb-2">Total</h3>
                        <Table>
                            <TableBody>
                                <TableRow>
                                    <TableCell>Amount Due</TableCell>
                                    <TableCell className="text-right">{formatCurrency(invoiceData.amount_due)}</TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>Amount Paid</TableCell>
                                    <TableCell className="text-right">{formatCurrency(invoiceData.amount_paid)}</TableCell>
                                </TableRow>
                                <TableRow className="font-semibold">
                                    <TableCell>Amount Remaining</TableCell>
                                    <TableCell className="text-right">{formatCurrency(invoiceData.amount_remaining)}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </div>
                </div>
            </main>
        </div>
    );
}
