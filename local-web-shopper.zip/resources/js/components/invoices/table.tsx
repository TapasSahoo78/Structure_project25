import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, ExternalLink, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Invoice, PaginationMeta } from '@/types';
import { InvoiceDetails } from '@/components/invoices/details';

interface ApiResponse {
    data: Invoice[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    invoices: Invoice[];
    errors: {
        invoices?: string;
    };
    [key: string]: any;
}

const formSchema = z.object({
    status: z.string(),
    due_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, {
        message: 'Due date must be in YYYY-MM-DD format.',
    }),
    amount_due: z.number().positive({
        message: 'Amount due must be a positive number.',
    }),
    currency: z.string().min(3, {
        message: 'Currency must be at least 3 characters.',
    }),
});

export default function InvoiceTable() {
    const { invoices: initialInvoices, errors: initialErrors } = usePage<PageProps>().props;
    const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ invoices?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
    const [editInvoice, setEditInvoice] = useState<Invoice | null>(null);
    const [deleteInvoice, setDeleteInvoice] = useState<Invoice | null>(null);
    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            status: '',
            due_date: '',
            amount_due: 0,
            currency: '',
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchInvoices(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editInvoice) {
            form.reset({
                status: editInvoice.status,
                due_date: formatDateForInput(editInvoice.due_date),
                amount_due: editInvoice.amount_due / 100,
                currency: editInvoice.currency,
            });
        }
    }, [editInvoice, form]);

    const fetchInvoices = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/invoices`, {
                params: { search: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setInvoices(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { invoices: 'An error occurred while fetching invoices.' });
            } else {
                setErrors({ invoices: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: z.infer<typeof formSchema>) => {
        setLoading(true);
        try {
            const dataToSend = {
                ...values,
                amount_due: Math.round(values.amount_due * 100),
            };
            await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/invoices/${editInvoice!.id}`, dataToSend, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchInvoices(currentPage);
            setEditInvoice(null);
        } catch (error) {
            console.error('Error updating invoice:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (invoice: Invoice) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/invoices/${invoice.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchInvoices(currentPage);
            setDeleteInvoice(null);
        } catch (error) {
            console.error('Error deleting invoice:', error);
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (amount: number, currency: string): string => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency }).format(amount / 100);
    };

    const formatDate = (date: Date | string): string => {
        return new Date(date).toLocaleDateString();
    };

    const formatDateForInput = (date: Date | string): string => {
        return new Date(date).toISOString().split('T')[0];
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchInvoices(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchInvoices(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.invoices) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.invoices}</AlertDescription>
                </Alert>
            );
        }

        if (invoices.length === 0) {
            return <p className="text-center text-gray-500">No invoices found.</p>;
        }

        return (
            <>
                <Table className='dark:text-black'>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Invoice Number</TableHead>
                            <TableHead>Due Date</TableHead>
                            <TableHead>Total</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {invoices.map((invoice) => (
                            <TableRow key={invoice.id}>
                                <TableCell>{invoice.stripe_invoice_number}</TableCell>
                                <TableCell>{invoice.due_date ? formatDate(invoice.due_date) : 'N/A'}</TableCell>
                                <TableCell>
                                    {formatCurrency(invoice.amount_due, invoice.currency)}
                                    {invoice.amount_remaining > 0 && (
                                        <span className="text-sm text-gray-500 ml-2">
                                            (Remaining: {formatCurrency(invoice.amount_remaining, invoice.currency)})
                                        </span>
                                    )}
                                </TableCell>
                                <TableCell>{invoice.status}</TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        {invoice.hosted_invoice_url && (
                                            <Button
                                            className='dark:text-white'
                                                variant="outline"
                                                size="icon"
                                                onClick={() => setSelectedInvoiceId(invoice.id)}
                                            >
                                                <ExternalLink className="h-4 w-4" />
                                            </Button>
                                        )}
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search invoices"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full dashedField"
            />
            {renderContent()}

            <Dialog open={!!selectedInvoiceId} onOpenChange={() => setSelectedInvoiceId(null)}>
                <DialogContent className="sm:max-w-[800px]">
                    <DialogHeader>
                        <DialogTitle>Invoice Details</DialogTitle>
                    </DialogHeader>
                    {selectedInvoiceId && <InvoiceDetails invoiceId={selectedInvoiceId} />}
                </DialogContent>
            </Dialog>

            <Dialog open={!!editInvoice} onOpenChange={() => setEditInvoice(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit Invoice</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-8">
                            <FormField
                                control={form.control}
                                name="status"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Status</FormLabel>
                                        <FormControl>
                                            <Input {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="due_date"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Due Date</FormLabel>
                                        <FormControl>
                                            <Input {...field} type="date" />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="amount_due"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Amount Due</FormLabel>
                                        <FormControl>
                                            <Input {...field} type="number" step="0.01" />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="currency"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Currency</FormLabel>
                                        <FormControl>
                                            <Input {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="submit" disabled={loading}>
                                    {loading ? 'Saving...' : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteInvoice} onOpenChange={() => setDeleteInvoice(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this invoice? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteInvoice(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deleteInvoice!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
