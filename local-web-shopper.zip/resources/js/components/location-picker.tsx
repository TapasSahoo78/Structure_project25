import React, { useEffect, useRef } from 'react';

export default function LocationPicker({ value, onChange }) {
    const mapRef = useRef(null);
    const markerRef = useRef(null);
    const circleRef = useRef(null);
    const autocompleteRef = useRef(null);

    useEffect(() => {
        const initMap = () => {
            const defaultLocation = { lat: 37.7749, lng: -122.4194 }; // San Francisco
            const map = new window.google.maps.Map(mapRef.current, {
                center: defaultLocation,
                zoom: 10,
            });

            const input = document.getElementById('autocomplete');
            const autocomplete = new window.google.maps.places.Autocomplete(input);
            autocomplete.bindTo("bounds", map);
            autocomplete.addListener("place_changed", () => {
                const place = autocomplete.getPlace();
                if (!place.geometry || !place.geometry.location) return;

                const location = {
                    lat: place.geometry.location.lat(),
                    lng: place.geometry.location.lng(),
                    address: place.formatted_address,
                    radius: 10,
                };

                map.setCenter(location);
                map.setZoom(13);

                if (!markerRef.current) {
                    markerRef.current = new window.google.maps.Marker({
                        map,
                        position: location,
                    });
                } else {
                    markerRef.current.setPosition(location);
                }

                if (!circleRef.current) {
                    circleRef.current = new window.google.maps.Circle({
                        map,
                        radius: location.radius * 1609.34,
                        fillColor: '#FF0000',
                        fillOpacity: 0.1,
                        strokeColor: '#FF0000',
                        strokeOpacity: 0.3,
                        strokeWeight: 1,
                    });
                }
                circleRef.current.setCenter(location);
                circleRef.current.setRadius(location.radius * 1609.34);

                onChange(location);
            });
        };

        if (window.google && window.google.maps) initMap();
    }, [onChange]);

    return (
        <div className="space-y-2">
            <input id="autocomplete" type="text" className="w-full p-2 border rounded" placeholder="Enter address..." ref={autocompleteRef} />
            <div ref={mapRef} style={{ height: '300px', width: '100%' }} className="rounded-xl border" />
        </div>
    );
}
