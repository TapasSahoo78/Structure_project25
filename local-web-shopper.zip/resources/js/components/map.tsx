import React, { useMemo } from 'react';
import { GoogleMap, Marker, Circle } from '@react-google-maps/api';
import { Card } from "@/components/ui/card";

interface MapProps {
    latitude?: number;
    longitude?: number;
    radius?: number; // in miles
}

const mapContainerStyle = {
    width: '100%',
    height: '400px',
};

export function Map({ latitude, longitude, radius }: MapProps) {
    if (!latitude || !longitude || latitude <= 1) {
        return (
            <Card className="flex items-center justify-center h-[400px] shadow-none dark:bg-white">
                <p className="text-lg text-gray-600">Set an address to display the map.</p>
            </Card>
        );
    }

    const center = useMemo(() => ({
        lat: latitude,
        lng: longitude
    }), [latitude, longitude]);

    // Calculate zoom based on radius
    const zoom = useMemo(() => {
        if (!radius) return 13;  // Default zoom slightly zoomed out
        return Math.max(1, Math.min(14, Math.floor(13.5 - Math.log2(radius / 1.5))));
    }, [radius]);

    return (
        <Card className="overflow-hidden shadow-lg p-0">
            <GoogleMap
                mapContainerStyle={mapContainerStyle}
                center={center}
                zoom={zoom}
                options={{
                    streetViewControl: false,
                    mapTypeControl: false,
                    fullscreenControl: false,
                }}
            >
                <Marker position={center} />
                {radius && (
                    <Circle
                        center={center}
                        radius={radius * 1609.34} // Convert miles to meters
                        options={{
                            fillColor: 'var(--primary)',
                            fillOpacity: 0.2,
                            strokeColor: 'var(--primary)',
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                        }}
                    />
                )}
            </GoogleMap>
        </Card>
    );
}
