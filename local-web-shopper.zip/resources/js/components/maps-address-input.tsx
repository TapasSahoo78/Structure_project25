import { useEffect, useRef, useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Command, CommandEmpty, CommandGroup, CommandItem, CommandList } from '@/components/ui/command';
import { Address } from '@/types';

type AddressData = Omit<Address, 'id' | 'businesses' | 'ads' | 'full_address'>;

interface MapsAddressInputProps {
    onAddressChange: (addressData: AddressData) => void;
    disabled?: boolean;
    placeholder?: string;
    initialAddress?: Partial<AddressData>;
}

export function MapsAddressInput({ onAddressChange, disabled = false, placeholder = "Enter your address", initialAddress }: MapsAddressInputProps) {
    const [inputValue, setInputValue] = useState(initialAddress?.formatted_address || '');
    const [predictions, setPredictions] = useState<google.maps.places.AutocompletePrediction[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const autocompleteSuggestion = useRef<google.maps.places.AutocompleteService | null>(null);
    const placesService = useRef<google.maps.places.PlacesService | null>(null);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        autocompleteSuggestion.current = new google.maps.places.AutocompleteService();
        placesService.current = new google.maps.places.PlacesService(document.createElement('div'));
    }, []);

    useEffect(() => {
        if (initialAddress?.formatted_address && initialAddress.formatted_address !== inputValue) {
            setInputValue(initialAddress.formatted_address);
        }
    }, [initialAddress]);

    const handleInputChange = useCallback((newValue: string) => {
        setInputValue(newValue);
        setIsOpen(true);

        if (timeoutRef.current) clearTimeout(timeoutRef.current);

        timeoutRef.current = setTimeout(() => {
            if (newValue.length > 0 && autocompleteSuggestion.current) {
                autocompleteSuggestion.current.getPlacePredictions(
                    { input: newValue, componentRestrictions: { country: "us" } },
                    // { input: newValue, componentRestrictions: { country: "ind" } },
                    (results: google.maps.places.AutocompletePrediction[] | null, status: google.maps.places.PlacesServiceStatus) => {
                        if (status === google.maps.places.PlacesServiceStatus.OK && results) {
                            setPredictions(results);
                        } else {
                            setPredictions([]);
                        }
                    }
                );
            } else {
                setPredictions([]);
            }
        }, 300);
    }, []);

    const handleSelectPrediction = (placeId: string) => {
        if (placesService.current) {
            placesService.current.getDetails(
                { placeId: placeId },
                (place, status) => {
                    if (status === google.maps.places.PlacesServiceStatus.OK && place) {
                        const addressComponents = place.address_components || [];
                        const addressData: AddressData = {
                            formatted_address: place.formatted_address || "",
                            latitude: place.geometry?.location?.lat() || 0 as number,
                            longitude: place.geometry?.location?.lng() || 0 as number,
                            street_number: "",
                            street_name: '',
                            city: '',
                            state: '',
                            postal_code: '',
                            country: '',
                        };

                        addressComponents.forEach((component) => {
                            const types = component.types;
                            if (types.includes('street_number')) {
                                //  console.log("Selected Place Details ---:", component.long_name);
                                addressData.street_number = component.long_name;
                            } else if (types.includes('route')) {
                                addressData.street_name = component.long_name;
                            } else if (types.includes('locality')) {
                                addressData.city = component.long_name;
                            } else if (types.includes('administrative_area_level_1')) {
                                addressData.state = component.short_name;
                            } else if (types.includes('postal_code')) {
                                addressData.postal_code = component.long_name;
                            } else if (types.includes('country')) {
                                addressData.country = component.long_name;
                            }
                        });
                        onAddressChange(addressData);
                        setInputValue(addressData.formatted_address || "");
                        setPredictions([]);
                        setIsOpen(false);
                    }
                }
            );
        }
    };

    return (
        <div className="relative">
            <Input
                className="dashedField"
                type="text"
                value={inputValue}
                onChange={(e) => handleInputChange(e.target.value)}
                disabled={disabled}
                placeholder={placeholder}
            // className="w-full"
            />
            {isOpen && predictions.length > 0 && (
                <div className=" w-full mt-1">
                    <Command className="rounded-lg border">
                        <CommandList>
                            <CommandEmpty>No results found.</CommandEmpty>
                            <CommandGroup>
                                {predictions.map((prediction) => (
                                    <CommandItem
                                        key={prediction.place_id}
                                        onSelect={() => handleSelectPrediction(prediction.place_id)}
                                    >
                                        {prediction.description}
                                    </CommandItem>
                                ))}
                            </CommandGroup>
                        </CommandList>
                    </Command>
                </div>
            )}
        </div>
    );
}
