import React from 'react';
import { InputWithErrorTooltip } from '@/components/input-with-error-tooltip';

interface PhoneInputWithErrorTooltipProps {
    value: string;
    onValueChange: (value: string) => void;
    error?: string;
    disabled?: boolean;
    id?: string;
    name?: string;
}

export const PhoneInputWithErrorTooltip: React.FC<PhoneInputWithErrorTooltipProps> = ({
    value,
    onValueChange,
    error,
    disabled,
    id,
    name,
}) => {
    const formatPhoneNumber = (input: string) => {
        const cleaned = input.replace(/\D/g, '');
        const match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})$/);
        if (match) {
            return match[1] + (match[2] ? '-' + match[2] : '') + (match[3] ? '-' + match[3] : '');
        }
        return input;
    };

    const handleChange = (input: string) => {
        const digits = input.replace(/\D/g, '');

        if (digits.length <= 10) {
            const formatted = formatPhoneNumber(digits);
            onValueChange(formatted);
        }
    };

    return (
        <InputWithErrorTooltip
            id={id}
            name={name}
            type="tel"
            value={value}
            onValueChange={handleChange}
            error={error}
            disabled={disabled}
            placeholder="xxx-xxx-xxxx"
            maxLength={12}
            className='dashedField'
        />
    );
};
