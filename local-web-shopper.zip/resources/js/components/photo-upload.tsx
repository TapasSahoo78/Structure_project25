import React from 'react';
import { useDropzone } from 'react-dropzone';

export default function PhotoUploader({ value, onChange }) {
    const { getRootProps, getInputProps } = useDropzone({
        accept: { 'image/*': [] },
        onDrop: (acceptedFiles) => {
            onChange([...value, ...acceptedFiles]);
        },
    });

    return (
        <div className="border border-dashed rounded-xl p-4 text-center cursor-pointer" {...getRootProps()}>
            <input {...getInputProps()} />
            <p className="text-sm text-gray-500">Drag and drop images here, or click to browse</p>
            <div className="flex flex-wrap gap-2 mt-2">
                {value.map((file, index) => (
                    <img
                        key={index}
                        src={URL.createObjectURL(file)}
                        alt={`preview-${index}`}
                        className="w-24 h-24 object-cover rounded"
                    />
                ))}
            </div>
        </div>
    );
}
