import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
}

interface PaginationMeta {
    current_page: number;
    last_page: number;
    total: number;
    per_page: number;
    from: number | null;
    to: number | null;
}

interface PaginationLink {
    url: string | null;
    label: string;
    active: boolean;
}

interface ApiResponse {
    data: Plan[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface Props {
    onChange: (plan: Plan | null) => void;
}

interface PageProps {
    plans: Plan[];
    errors: {
        plans?: string;
    };
    [key: string]: any;
}

const PlanCardList: React.FC = () => {
    const { plans: initialPlans, errors: initialErrors } = usePage<PageProps>().props;
    const [plans, setPlans] = useState<Plan[]>(initialPlans || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ plans?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchPlans(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    const fetchPlans = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/plans`, {
                params: { name: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setPlans(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { plans: 'An error occurred while fetching plans.' });
            } else {
                setErrors({ plans: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };
    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;

        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchPlans(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchPlans(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.plans) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.plans}</AlertDescription>
                </Alert>
            );
        }

        if (plans.length === 0) {
            return <p className="text-center text-gray-500">No plans found.</p>;
        }

        return (
            <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {plans.map((plan) => (
                        <Card key={plan.id} className="w-full">
                            <CardHeader>
                                <CardTitle>
                                    <p className="text-lg font-semibold">
                                        {plan.name}
                                    </p>
                                </CardTitle>
                                <CardDescription>{plan.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <p className="text-lg font-semibold">
                                    Price: ${Number(plan.price.replace(/,/g, '')).toFixed(2)} / {plan.period}
                                </p>
                                <p className="text-md">
                                    Radius: {plan?.radius} miles
                                </p>
                                <p className="text-md">
                                    Page Size: {plan?.size}
                                </p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search plans"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}
        </div>
    );
};

export default PlanCardList;
