import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlanPeriod, PlanPeriodUtils } from '@/enums/plan-period';
import { PageSize, PageSizeUtils } from '@/enums/page-size';

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
    period: PlanPeriod;
    radius: number;
    size: number;
}

interface PaginationMeta {
    current_page: number;
    last_page: number;
    total: number;
    per_page: number;
    from: number | null;
    to: number | null;
}

interface ApiResponse {
    data: Plan[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface Props {
    onChange: (plan: Plan | null) => void;
    selected: Plan | null;
}

interface PageProps {
    plans: Plan[];
    errors: {
        plans?: string;
    };
    [key: string]: any;
}

const PlanCards: React.FC<Props> = ({ onChange, selected }) => {
    const { plans: initialPlans, errors: initialErrors } = usePage<PageProps>().props;
    const [plans, setPlans] = useState<Plan[]>(initialPlans || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ plans?: string }>(initialErrors || {});
    const [periodFilter, setPeriodFilter] = useState<PlanPeriod | 'ALL'>('ALL');
    const [sizeFilter, setSizeFilter] = useState<PageSize | 'ALL'>('ALL');
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const fetchPlans = useCallback(async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/plans`, {
                params: {
                    name: searchTerm,
                    period: periodFilter !== 'ALL' ? periodFilter : undefined,
                    size: sizeFilter !== 'ALL' ? sizeFilter : undefined,
                    page
                },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setPlans(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { plans: 'An error occurred while fetching plans.' });
            } else {
                setErrors({ plans: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    }, [searchTerm, periodFilter, sizeFilter]);

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchPlans(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [fetchPlans]);
    const handlePlanSelect = (plan: Plan) => {
        onChange(selected?.id === plan.id ? null : plan);
    };

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value);
    };

    const handlePeriodFilter = (value: string) => {
        setPeriodFilter(value as PlanPeriod | 'ALL');
    };

    const handleSizeFilter = (value: string) => {
        setSizeFilter(value as PageSize | 'ALL');
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchPlans(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchPlans(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderPlanCards = () => {
        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sdfd">
                {plans.map((plan) => (
                    <Card
                        key={plan.id}
                        className={`p-4 cursor-pointer transition-all dark:bg-white dark:text-black ${selected?.id === plan.id ? 'ring-2 ring-primary' : ''}`}
                        onClick={() => handlePlanSelect(plan)}
                    >
                        <CardHeader className='px-0'>
                            <CardTitle>{plan.name}</CardTitle>
                            <CardDescription>{plan.description}</CardDescription>
                        </CardHeader>
                        <CardContent className='px-0'>
                            <p className="text-lg font-semibold">
                                Price: ${Number(plan.price.replace(/,/g, '')).toFixed(2) ?? '0.00'} / {plan.period}
                            </p>
                            <p className="text-md">
                                Radius: {plan.radius} miles
                            </p>
                            <p className="text-md">
                                Page Size: {plan.size}
                            </p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.plans) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.plans}</AlertDescription>
                </Alert>
            );
        }

        if (plans.length === 0) {
            return <p className="text-center text-gray-500">No plans found.</p>;
        }

        return (
            <>
                {renderPlanCards()}
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <div className="flex space-x-2">
                {/* <Input
                    placeholder="Search plans"
                    value={searchTerm}
                    onChange={handleSearch}
                    className="w-full"
                /> */}
                <Select value={periodFilter} onValueChange={handlePeriodFilter}>
                    <SelectTrigger className="w-[150px] selectBtn">
                        <SelectValue placeholder="Filter by period" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="ALL">All periods</SelectItem>
                        {Object.entries(PlanPeriodUtils.getSelectable()).map(([value, label]) => (
                            <SelectItem key={value} value={value}>{label}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <Select value={sizeFilter} onValueChange={handleSizeFilter}>
                    <SelectTrigger className="w-[150px] selectBtn">
                        <SelectValue placeholder="Filter by size" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="ALL">All sizes</SelectItem>
                        {Object.entries(PageSizeUtils.getSelectable()).map(([value, label]) => (
                            <SelectItem key={value} value={value}>{label}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            {renderContent()}
        </div>
    );
};

export default PlanCards;
