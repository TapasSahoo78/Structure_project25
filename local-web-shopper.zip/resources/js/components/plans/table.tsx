import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageSize, PageSizeUtils } from '@/enums/page-size';
import { PlanPeriod, PlanPeriodUtils } from '@/enums/plan-period';

import { Plan, PaginationMeta, PaginationLink } from '@/types';

interface ApiResponse {
    data: Plan[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface Props {
    onChange: (plan: Plan | null) => void;
}

interface PageProps {
    plans: Plan[];
    errors: {
        plans?: string;
    };
    [key: string]: any;
}

const formSchema = z.object({
    name: z.string().min(2, {
        message: 'Name must be at least 2 characters.',
    }),
    description: z.string().min(10, {
        message: 'Description must be at least 10 characters.',
    }),
    // price: z.number().positive({
    //     message: 'Price must be a positive number.',
    // }),
    price: z.union([
        z.number().positive({
            message: 'Price must be a positive number.',
        }),
        z.string().refine((val) => {
            const num = parseFloat(val);
            return !isNaN(num) && num > 0;
        }, {
            message: 'Price must be a positive number.',
        })
    ]),
    size: z.nativeEnum(PageSize),
    radius: z.number().int().positive({
        message: 'Radius must be a positive integer.',
    }),
    period: z.string(),
});

const PlanTable: React.FC = () => {
    const { plans: initialPlans, errors: initialErrors } = usePage<PageProps>().props;
    const [plans, setPlans] = useState<Plan[]>(initialPlans || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ plans?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [viewPlan, setViewPlan] = useState<Plan | null>(null);
    const [editPlan, setEditPlan] = useState<Plan | null>(null);
    const [deletePlan, setDeletePlan] = useState<Plan | null>(null);

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
            description: '',
            price: 0.00,
            size: PageSize.QUARTER,
            radius: 0,
            period: PlanPeriod.MONTHLY,
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchPlans(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editPlan) {
            console.log("editPlan", editPlan);

            const formData = {
                name: editPlan.name,
                description: editPlan.description,
                price: typeof editPlan?.price === "string" ? parseFloat(editPlan?.price.replace(/,/g, "")) : editPlan?.price,
                size: PageSizeUtils.fromHuman(editPlan.size),
                radius: editPlan.radius,
                period: editPlan.period.toUpperCase() as PlanPeriod,
            };
            form.reset(formData);
        }
    }, [editPlan, form]);

    const fetchPlans = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/plans`, {
                params: { name: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setPlans(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { plans: 'An error occurred while fetching plans.' });
            } else {
                setErrors({ plans: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchSinglePlan = async (id: string) => {
        setLoading(true);
        try {
            const response = await axios.get<Plan>(`${import.meta.env.VITE_APP_URL}/api/v1/plans/${id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setViewPlan(response.data);
        } catch (error) {
            console.error('Error fetching plan:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: z.infer<typeof formSchema>) => {
        setLoading(true);
        try {
            const dataToSend = {
                name: values.name,
                description: values.description,
                price: Number(values.price),
                size: values.size,
                radius: Math.round(values.radius),
                period: values.period,
            };
            const response = await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/plans/${editPlan!.id}`, dataToSend, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchPlans(currentPage);
            setEditPlan(null);
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error('Error updating plan:', error.response.data);
            } else {
                console.error('Error updating plan:', error);
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (plan: Plan) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/plans/${plan.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchPlans(currentPage);
            setDeletePlan(null);
        } catch (error) {
            console.error('Error deleting plan:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchPlans(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchPlans(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.plans) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.plans}</AlertDescription>
                </Alert>
            );
        }

        if (plans.length === 0) {
            return <p className="text-center text-gray-500">No plans found.</p>;
        }

        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Radius</TableHead>
                            <TableHead>Page Size</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {plans.map((plan) => (
                            <TableRow key={plan.id}>
                                <TableCell className="font-medium">{plan.name}</TableCell>
                                <TableCell>{plan.description}</TableCell>
                                <TableCell> ${plan?.price ? Number(String(plan.price).replace(/,/g, '')).toFixed(2) : '0.00'}
                                    / {plan.period}</TableCell>
                                <TableCell>{plan.radius} miles</TableCell>
                                <TableCell>{plan.size}</TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button variant="outline" size="icon" onClick={() => setEditPlan(plan)}>
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => setDeletePlan(plan)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            <Input
                placeholder="Search plans"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}

            <Dialog open={!!viewPlan} onOpenChange={() => setViewPlan(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{viewPlan?.name}</DialogTitle>
                    </DialogHeader>
                    {loading ? (
                        <div className="flex justify-center">
                            <Loader2 className="h-6 w-6 animate-spin" />
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <p><strong>Description:</strong> {viewPlan?.description}</p>
                            <p><strong>Price:</strong> ${Number(viewPlan?.price.replace(/,/g, '')).toFixed(2)} / {viewPlan?.period}</p>
                            <p><strong>Radius:</strong> {viewPlan?.radius} miles</p>
                            <p><strong>Page Size:</strong> {viewPlan?.size}</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <Dialog open={!!editPlan} onOpenChange={() => setEditPlan(null)}>
                <DialogContent className="w-screen h-screen max-w-full sm:h-auto sm:max-h-[90vh] sm:max-w-[90vw] sm:w-full overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit Plan: {editPlan?.name}</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                                {/* Column 1: Name and Description (takes up 2/4 = 1/2 of the space) */}
                                <div className="md:col-span-2 space-y-6">
                                    <FormField
                                        control={form.control}
                                        name="name"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Name</FormLabel>
                                                <FormControl>
                                                    <Input {...field} />
                                                </FormControl>
                                                <FormDescription>The name of the plan.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="description"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Description</FormLabel>
                                                <FormControl>
                                                    <Textarea {...field} className="min-h-[100px]" />
                                                </FormControl>
                                                <FormDescription>A brief description of the plan.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>

                                {/* Column 2: Price, Radius, and Period (takes up 1/4 of the space) */}
                                <div className="space-y-6">
                                    <FormField
                                        control={form.control}
                                        name="price"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Price</FormLabel>
                                                <FormControl>
                                                    <Input type="text" {...field}
                                                        onChange={(e) =>
                                                            field.onChange(parseFloat(e.target.value))
                                                        } />
                                                </FormControl>
                                                <FormDescription>The price of the plan.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="radius"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Radius</FormLabel>
                                                <FormControl>
                                                    <Input type="number" {...field} onChange={(e) => field.onChange(parseInt(e.target.value, 10))} />
                                                </FormControl>
                                                <FormDescription>The radius of the ad coverage.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                </div>

                                {/* Column 3: Size (takes up 1/4 of the space) */}
                                <div>
                                    <FormField
                                        control={form.control}
                                        name="period"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Period</FormLabel>
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a period">
                                                                {field.value && PlanPeriodUtils.getHuman(field.value as PlanPeriod)}
                                                            </SelectValue>
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.entries(PlanPeriodUtils.getSelectable()).map(([value, label]) => (
                                                            <SelectItem key={value} value={value}>
                                                                {label}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormDescription>The period of the plan.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="size"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Size</FormLabel>
                                                <Select
                                                    onValueChange={field.onChange}
                                                    value={field.value}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a page size">
                                                                {field.value && PageSizeUtils.getHuman(field.value as PageSize)}
                                                            </SelectValue>
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.entries(PageSize).map(([key, value]) => (
                                                            <SelectItem key={key} value={value}>
                                                                {PageSizeUtils.getHuman(value as PageSize)}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormDescription>The size of the ad.</FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button type="submit" disabled={loading}>
                                    {loading ? 'Saving...' : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>


            <Dialog open={!!deletePlan} onOpenChange={() => setDeletePlan(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete the plan "{deletePlan?.name}"? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeletePlan(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={() => handleDelete(deletePlan!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default PlanTable;
