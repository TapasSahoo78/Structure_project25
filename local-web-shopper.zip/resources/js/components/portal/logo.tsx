import AppLogoIcon from './logo-icon';

export default function AppLogo() {
    return (
        <>
            <div className="ml-2 flex flex-6 items-center text-left text-sm">
                <AppLogoIcon className="size-6 fill-current text-white dark:text-black" />
            </div>
        </>
    );
}
