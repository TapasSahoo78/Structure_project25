import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react"
import { Card, CardContent, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { useError } from '@/contexts/error-context';
import { Subscription, PaginationMeta } from '@/types';
import { PlanPeriod, PlanPeriodUtils } from '@/enums/plan-period';
import { PageSize, PageSizeUtils } from '@/enums/page-size';

interface ApiResponse {
    data: Subscription[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    subscriptions: Subscription[];
    errors: {
        subscriptions?: string;
    };
    [key: string]: any;
}

interface SubscriptionCardsProps {
    onSubscriptionSelect: (subscription: Subscription | null) => void;
    selected: Subscription | null;
}

export default function SubscriptionCards({ onSubscriptionSelect, selected }: SubscriptionCardsProps) {
    const { subscriptions: initialSubscriptions } = usePage<PageProps>().props;
    const [subscriptions, setSubscriptions] = useState<Subscription[]>(initialSubscriptions || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [periodFilter, setPeriodFilter] = useState<PlanPeriod | 'ALL'>('ALL');
    const [sizeFilter, setSizeFilter] = useState<PageSize | 'ALL'>('ALL');

    const { setGlobalError } = useError();

    useEffect(() => {
        fetchSubscriptions();
    }, []);

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchSubscriptions();
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm, periodFilter, sizeFilter]);

    const fetchSubscriptions = async () => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/subscriptions`, {
                params: {
                    search: searchTerm,
                    period: periodFilter !== 'ALL' ? periodFilter : undefined,
                    size: sizeFilter !== 'ALL' ? sizeFilter : undefined
                },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setSubscriptions(response.data.data);
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setGlobalError('An error occurred while fetching subscriptions.');
            } else {
                setGlobalError('An unexpected error occurred.');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value);
    };

    const handlePeriodFilterChange = (value: string) => {
        setPeriodFilter(value as PlanPeriod | 'ALL');
    };

    const handleSizeFilterChange = (value: string) => {
        setSizeFilter(value as PageSize | 'ALL');
    };

    const scrollLeft = () => {
        const container = document.getElementById('subscription-container');
        if (container) {
            container.scrollBy({ left: -300, behavior: 'smooth' });
        }
    };

    const scrollRight = () => {
        const container = document.getElementById('subscription-container');
        if (container) {
            container.scrollBy({ left: 300, behavior: 'smooth' });
        }
    };

    const handleSubscriptionSelect = (subscription: Subscription) => {
        onSubscriptionSelect(selected?.id === subscription.id ? null : subscription);
    };

    const renderContent = () => {
        if (loading) {
            return (
                <Card className="w-full h-32 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </Card>
            );
        }

        if (subscriptions.length === 0) {
            return (
                <Card className="w-full shadow-none h-32 flex items-center justify-center">
                    <p className="text-center text-gray-500">No subscriptions found.</p>
                </Card>
            );
        }

        return (
            <div id="subscription-container" className="flex flex-wrap overflow-x-auto">
                {subscriptions.map((subscription) => (
                    <div className="w-1/1 sm:w-1/2 lg:w-1/2 xl:w-1/3 px-0 py-2 sm:p-2 ">
                        <Card
                            key={subscription.id}
                            className={`py-0 h-56 flex-shrink-0 dark:text-black dark:bg-white cursor-pointer ${selected?.id === subscription.id ? 'ring-2 ring-blue-500' : ''
                                }`}
                            onClick={() => handleSubscriptionSelect(subscription)}
                        >
                            <CardContent className="p-2 h-full">
                                <CardTitle className="text-med font-bold mb-4 truncate" title={subscription.name}>
                                    {subscription.name}
                                </CardTitle>

                                <div className="flex-grow space-y-1 text-sm">
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold">Plan:</p>
                                        <p className="truncate max-w-[60%]" title={subscription?.plan?.name}>
                                            {subscription?.plan?.name}
                                        </p>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold">Period:</p>
                                        <p>{subscription?.plan?.period}</p>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold">Size:</p>
                                        <p>{subscription?.plan?.size}</p>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold">Radius:</p>
                                        <p>{subscription?.plan?.radius} mi</p>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold">Ends:</p>
                                        <p>{subscription.ends_at}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                ))}
            </div>
        );
    };

    return (
        <div className="space-y-4">
            <div className="flex flex-col lg:flex-row gap-4 justify-between items-center">
                <div className="flex flex-col w-full gap-3 md:gap-2 md:flex-row space-x-2">
                    <Input
                        placeholder="Search subscriptions"
                        value={searchTerm}
                        onChange={handleSearchChange}
                        className=" md:w-48 m-0 dashedField dark:text-black"
                    />
                    <Select value={periodFilter} onValueChange={handlePeriodFilterChange}>
                        <SelectTrigger className="w-[100%] md:w-[140px] m-0 selectBtn dark:text-black">
                            <SelectValue placeholder="Filter by period" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="ALL">All periods</SelectItem>
                            {Object.entries(PlanPeriodUtils.getSelectable()).map(([value, label]) => (
                                <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Select value={sizeFilter} onValueChange={handleSizeFilterChange} >
                        <SelectTrigger className="md:w-[140px] m-0 selectBtn dark:text-black">
                            <SelectValue placeholder="Filter by size" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="ALL">All sizes</SelectItem>
                            {Object.entries(PageSizeUtils.getSelectable()).map(([value, label]) => (
                                <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="flex space-x-2">
                    <Button variant="outline" size="icon" onClick={scrollLeft}>
                        <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={scrollRight}>
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
            <div className="min-h-[8rem]">
                {renderContent()}
            </div>
        </div>
    );
}
