import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { router } from '@inertiajs/react';
import axios from 'axios';
import { Button } from "@/components/ui/button";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import PlanCards from '@/components/plans/cards';
import { Plan } from '@/types';
import { Plus, Minus, CreditCard, Calendar, Info } from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import { format, addMonths, isValid, endOfMonth } from 'date-fns';
import { PlanPeriodUtils } from '@/enums/plan-period';
import Schedule from '@/components/subscriptions/schedule';
import { useAlert } from '@/contexts/alert-context';

interface CouponValidation {
    valid: boolean;
    code: string;
    discount_type: 'percent' | 'amount';
    discount_value: number;
    preview_discount?: number;
}

interface FormData {
    name: string;
    plan: Plan | null;
    promo_code: string; // Added to form state
}

const CreateSubscription: React.FC = () => {
    const [selectedCycles, setSelectedCycles] = useState<number>(1);
    const [autoRenew, setAutoRenew] = useState<boolean>(true);
    const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false);
    const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
    const [validatedCoupon, setValidatedCoupon] = useState<CouponValidation | null>(null);
    const [couponError, setCouponError] = useState<string>('');
    const { showAlert } = useAlert();

    const form = useForm<FormData>({
        defaultValues: {
            name: '',
            plan: null,
            promo_code: '', // Added to form
        },
    });

    const selectedPlan = form.watch('plan');
    const couponCode = form.watch('promo_code'); // Bind to form state

    const formatDate = (date: string): string => {
        const parsedDate = new Date(date);
        if (!isValid(parsedDate)) {
            return 'Invalid Date';
        }
        return format(parsedDate, 'MMMM d, yyyy');
    };

    // Validate coupon on change/blur
    const validateCoupon = async (code: string, planId?: number) => {
        if (!code.trim()) {
            setValidatedCoupon(null);
            setCouponError('');
            return;
        }

        setIsValidatingCoupon(true);
        setCouponError('');
        try {
            const response = await axios.post<{ data: CouponValidation }>(`${import.meta.env.VITE_APP_URL}/api/v1/coupons/validate`, {
                code: code.trim(),
                plan_id: planId,
            });
            const data = response.data;
            if (data?.valid) {
                setValidatedCoupon(data);
                setCouponError('');
            } else {
                setValidatedCoupon(null);
                setCouponError('Invalid promo code.');
            }
        } catch (error) {
            if (axios.isAxiosError(error) && error.response?.data?.message) {
                setCouponError(error.response.data.message);
            } else {
                setCouponError('Failed to validate promo code. Please try again.');
            }
            setValidatedCoupon(null);
        } finally {
            setIsValidatingCoupon(false);
        }
    };

    const onSubmit = async (data: FormData) => {
        if (!data.plan) {
            showAlert('error', 'Please select a plan.');
            return;
        }

        // Validate coupon on submit if not already validated
        if (data.promo_code && !validatedCoupon) {
            await validateCoupon(data.promo_code, data.plan.id);
            if (!validatedCoupon) {
                showAlert('error', 'Please enter a valid coupon code.');
                return;
            }
        }

        const startDate = new Date();
        const intervalCount = PlanPeriodUtils.getIntervalCount(data.plan.period);
        let endDate: Date | null = null;

        if (!autoRenew) {
            const monthsToAdd = selectedCycles * intervalCount;
            const rawEndDate = addMonths(startDate, monthsToAdd);
            endDate = endOfMonth(rawEndDate);

            if (!isValid(endDate)) {
                showAlert('error', 'Invalid end date for subscription.');
                return;
            }
        }

        const subscriptionData = {
            plan_id: data.plan.id,
            name: data.name,
            status: 'active',
            start_date: startDate.toISOString(),
            end_date: endDate ? endDate.toISOString() : null,
            auto_renew: autoRenew,
            cycles: selectedCycles,
            promo_code: data.promo_code.trim() || null,
        };

        router.post(`${import.meta.env.VITE_APP_URL}/portal/subscriptions`, subscriptionData, {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                showAlert('success', 'Subscription created successfully!');
                form.reset();
                setValidatedCoupon(null);
                setCouponError('');
            },
            onError: (errors) => {
                console.error('Error creating subscription:', errors);
                showAlert('error', errors?.promo_code || errors?.error || 'Failed to create subscription. Please try again.');
            },
        });
    };

    const incrementCycles = () => setSelectedCycles(prev => Math.min(prev + 1, 12));
    const decrementCycles = () => setSelectedCycles(prev => Math.max(prev - 1, 1));

    // Calculate effective price
    const getEffectivePrice = () => {
        if (!selectedPlan) return 0;
        const basePrice = Number(selectedPlan.price.replace(/,/g, ''));
        if (!validatedCoupon) return basePrice;
        const discount = validatedCoupon.preview_discount || 0;
        return Math.max(0, basePrice - discount);
    };

    return (
        <div className="asdasda w-full">
            <div className="flex flex-col lg:flex-row gap-6">
                <div className="w-full lg:w-2/3 space-y-8">
                    <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                        <Form {...form}>
                            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                                <FormField
                                    control={form.control}
                                    name="name"
                                    rules={{ required: "Please enter a subscription name" }}
                                    render={({ field }) => (
                                        <FormItem className='form-group gap-0'>
                                            <FormLabel className="text-lg">Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} placeholder="Enter subscription name" className="dashedField" />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="plan"
                                    rules={{ required: "Please select a plan" }}
                                    render={({ field }) => (
                                        <FormItem className='form-group gap-0 dark:text-black'>
                                            <FormLabel className="text-lg">Plan</FormLabel>
                                            <FormControl>
                                                <PlanCards onChange={field.onChange} selected={field.value} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="promo_code"
                                    render={({ field }) => (
                                        <FormItem className='form-group gap-0'>
                                            <FormLabel className="text-lg">Promo Code (Optional)</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...field}
                                                    placeholder="Enter promo code (e.g., PROMO20)"
                                                    onChange={(e) => {
                                                        field.onChange(e.target.value);
                                                        setCouponError(''); // Clear error on change
                                                    }}
                                                    disabled={!selectedPlan?.id}
                                                    onBlur={() => validateCoupon(field.value, selectedPlan?.id)}
                                                    className="dashedField"
                                                />
                                            </FormControl>
                                            {!selectedPlan?.id &&
                                                <p className="ml-2 text-sm text-gray-500">Please select a plan before proceeding</p>
                                            }
                                            {isValidatingCoupon && <p className="text-sm text-gray-500">Validating...</p>}
                                            {validatedCoupon && (
                                                <p className="text-sm text-green-600 flex items-center">
                                                    <Info className="h-4 w-4 mr-1" />
                                                    Valid! {validatedCoupon.discount_type === 'percent'
                                                        ? `${validatedCoupon.discount_value}% off`
                                                        : `$${validatedCoupon.discount_value} off`}
                                                </p>
                                            )}
                                            {couponError && <p className="text-sm text-red-600">{couponError}</p>}
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </form>
                        </Form>
                    </div>
                </div>
                <div className="w-full lg:w-1/3 sticky top-8 self-start">
                    <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                        <h2 className="text-2xl font-semibold mb-4 dark:text-black">Summary</h2>
                        {selectedPlan ? (
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <div className="flex justify-between dark:text-black">
                                        <span>Plan:</span>
                                        <span className="font-medium">{selectedPlan.name}</span>
                                    </div>
                                </div>
                                <div className="flex justify-between dark:text-black">
                                    <span>Price per {PlanPeriodUtils.getHuman(selectedPlan.period)}:</span>
                                    <div className="flex items-center space-x-2">
                                        {validatedCoupon && (
                                            <span className="line-through text-gray-500">
                                                ${Number(selectedPlan.price.replace(/,/g, '')).toFixed(2)}
                                            </span>
                                        )}
                                        <span className="font-medium">
                                            ${getEffectivePrice().toFixed(2)}
                                            {validatedCoupon && validatedCoupon.discount_type === 'percent' && ` (-${validatedCoupon.discount_value}%)`}
                                        </span>
                                    </div>
                                </div>

                                <div className="flex justify-between items-center dark:text-black">
                                    <span>Auto-renew:</span>
                                    <div className="flex items-center space-x-2 dark:text-black dark:bg-white">
                                        <Switch
                                            id="auto-renew"
                                            checked={autoRenew}
                                            onCheckedChange={setAutoRenew}
                                        />
                                        <TooltipProvider>
                                            <Tooltip>
                                                <TooltipTrigger asChild>
                                                    <Info className="h-4 w-4 text-gray-500 cursor-help dark:text-black" />
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                    <p>When enabled, your subscription will automatically renew until canceled. Once canceled, it will continue until the end of the cycle.</p>
                                                </TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    </div>
                                </div>
                                <div className="flex justify-between items-center dark:text-black">
                                    <span>Cycles:</span>
                                    <div className="flex items-center space-x-2">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            onClick={decrementCycles}
                                            disabled={autoRenew}
                                        >
                                            <Minus className="h-4 w-4" />
                                        </Button>
                                        <Input
                                            className="w-16 text-center dark:text-black"
                                            type="number"
                                            value={selectedCycles}
                                            onChange={(e) => setSelectedCycles(Math.max(1, Math.min(12, parseInt(e.target.value) || 1)))}
                                            min="1"
                                            max="12"
                                            disabled={autoRenew}
                                        />
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            onClick={incrementCycles}
                                            disabled={autoRenew}
                                        >
                                            <Plus className="h-4 w-4" />
                                        </Button>
                                        <TooltipProvider>
                                            <Tooltip>
                                                <TooltipTrigger asChild>
                                                    <Info className="h-4 w-4 text-gray-500 cursor-help" />
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                    <p>Choose how many cycles you'd like this subscription to run for. Once all cycles are completed, the subscription will automatically cancel.</p>
                                                </TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    </div>
                                </div>
                                <Separator className="my-4" />
                                {!autoRenew && (
                                    <div className="flex justify-between items-center">
                                        <span>Total After All Cycles:</span>
                                        <div className="flex items-center space-x-2">
                                            <span>${(getEffectivePrice() * selectedCycles).toFixed(2)}</span>
                                            <TooltipProvider>
                                                <Tooltip>
                                                    <TooltipTrigger asChild>
                                                        <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
                                                            <DialogTrigger asChild>
                                                                <Button variant="ghost" size="sm">
                                                                    <Calendar className="h-4 w-4 mr-2" />
                                                                </Button>
                                                            </DialogTrigger>
                                                            <Schedule
                                                                plan={selectedPlan}
                                                                selectedCycles={selectedCycles}
                                                                formatDate={formatDate}
                                                            />
                                                        </Dialog>
                                                    </TooltipTrigger>
                                                    <TooltipContent>
                                                        <p>View billing dates</p>
                                                    </TooltipContent>
                                                </Tooltip>
                                            </TooltipProvider>
                                        </div>
                                    </div>
                                )}
                                <div className="flex justify-between text-xl font-semibold dark:text-black">
                                    <span>Total Today:</span>
                                    <span className="font-medium">${getEffectivePrice().toFixed(2)}</span>
                                </div>

                                <Button type="submit" className="w-full text-lg py-6 mt-4 dark:text-white dark:bg-black" onClick={form.handleSubmit(onSubmit)}>
                                    <CreditCard className="mr-2 h-5 w-5" /> Complete Purchase
                                </Button>
                            </div>
                        ) : (
                            <p className="text-gray-500">Select a plan to see the summary</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateSubscription;
