import React from 'react';
import { DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Plan, Subscription } from '@/types';
import { PlanPeriod, PlanPeriodUtils } from '@/enums/plan-period';

interface ScheduleProps {
    subscription?: Subscription;
    plan?: Plan;
    selectedCycles: number;
    formatDate: (date: string) => string;
}

const Schedule: React.FC<ScheduleProps> = ({
    subscription,
    plan,
    selectedCycles,
    formatDate
}) => {
    const activePlan = subscription?.plan || plan;

    if (!activePlan) {
        return null; // Or some error message
    }

    const generateBillingDates = (startDate: Date, cycles: number): Date[] => {
        const dates: Date[] = [];
        let currentDate = new Date(startDate);
        const intervalCount = PlanPeriodUtils.getIntervalCount(activePlan.period as PlanPeriod);

        for (let i = 0; i < cycles; i++) {
            dates.push(new Date(currentDate));
            currentDate.setMonth(currentDate.getMonth() + intervalCount);
        }
        return dates;
    };

    const startDate = new Date(); // Use today's date as the start date
    const billingDates = generateBillingDates(startDate, selectedCycles);

    // Calculate the end date (one cycle after the last billing date)
    const endDate = new Date(billingDates[billingDates.length - 1]);
    const intervalCount = PlanPeriodUtils.getIntervalCount(activePlan.period as PlanPeriod);
    endDate.setMonth(endDate.getMonth() + intervalCount);

    return (
        <DialogContent className="sm:max-w-[800px]">
            <DialogHeader>
                <DialogTitle className="text-2xl font-bold mb-4">Cycle Schedule</DialogTitle>
            </DialogHeader>
            <div className="mt-4 max-h-[60vh] overflow-y-auto">
                <table className="w-full">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="py-2 px-4 text-left">Date</th>
                            <th className="py-2 px-4 text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {billingDates.map((date, index) => (
                            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="py-3 px-4">{formatDate(date.toISOString())}</td>
                                <td className="py-3 px-4 text-right">${Number(activePlan.price.replace(/,/g, '')).toFixed(2)}</td>
                            </tr>
                        ))}
                        <tr className="bg-gray-200">
                            <td><span className="py-3 px-4 font-semibold">Subscription End Date</span>
                                <br />
                                <span className="py-3 px-4 text-sm text-gray-600">
                                    Ads associated with this subscription will expire on this date.
                                </span>
                            </td>
                            <td className="py-3 px-4 text-right">{formatDate(endDate.toISOString())}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <DialogFooter className="mt-6">
                <span>Total After All Cycles:</span>
                <div className="flex items-center space-x-2">
                    <span>${(activePlan.price * selectedCycles).toFixed(2)}</span>
                </div>
            </DialogFooter>
        </DialogContent>
    );
};

export default Schedule;
