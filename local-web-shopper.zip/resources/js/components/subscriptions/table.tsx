import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, XCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Badge } from "@/components/ui/badge"
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';
import { Subscription, Plan, PaginationMeta } from '@/types';

interface ApiResponse {
    data: Subscription[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    subscriptions: Subscription[];
    errors: {
        subscriptions?: string;
    };
    [key: string]: any;
}

const formSchema = z.object({
    name: z.string().min(2, {
        message: 'Name must be at least 2 characters.',
    }),
});

export default function SubscriptionsTable() {
    const { subscriptions: initialSubscriptions } = usePage<PageProps>().props;
    const [subscriptions, setSubscriptions] = useState<Subscription[]>(initialSubscriptions || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [viewSubscription, setViewSubscription] = useState<Subscription | null>(null);
    const [editSubscription, setEditSubscription] = useState<Subscription | null>(null);
    const [deleteSubscription, setDeleteSubscription] = useState<Subscription | null>(null);

    const { showAlert } = useAlert();
    const { setInputError, clearInputError, setGlobalError } = useError();

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchSubscriptions(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm]);

    useEffect(() => {
        if (editSubscription) {
            form.reset({
                name: editSubscription.name,
                // Add other fields here as needed
            });
        }
    }, [editSubscription, form]);

    const fetchSubscriptions = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/subscriptions`, {
                params: { search: searchTerm, page },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setSubscriptions(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setGlobalError('An error occurred while fetching subscriptions.');
            } else {
                setGlobalError('An unexpected error occurred.');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: z.infer<typeof formSchema>) => {
        setLoading(true);
        try {
            const response = await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/subscriptions/${editSubscription!.id}`, values, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });

            const updatedSubscription = response.data.data;
            setSubscriptions(prevSubscriptions =>
                prevSubscriptions.map(sub =>
                    sub.id === updatedSubscription.id ? updatedSubscription : sub
                )
            );
            setEditSubscription(null);
            showAlert('success', 'Subscription updated successfully');

            // Refresh the subscriptions list to ensure we have the latest data
            fetchSubscriptions(currentPage);
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                const { errors } = error.response.data;
                if (errors) {
                    Object.entries(errors).forEach(([field, messages]) => {
                        setInputError(field, (messages as string[])[0]);
                    });
                } else {
                    setGlobalError('Failed to update subscription');
                }
            } else {
                setGlobalError('An unexpected error occurred');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = async (subscription: Subscription) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/subscriptions/${subscription.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchSubscriptions(currentPage);
            setDeleteSubscription(null);
            showAlert('success', 'Subscription canceled successfully');
        } catch (error) {
            setGlobalError('Failed to cancel subscription');
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchSubscriptions(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchSubscriptions(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (subscriptions.length === 0) {
            return <p className="text-center text-gray-500">No subscriptions found.</p>;
        }

        return (
            <>
                <Table className='border-collapse'>
                    <TableHeader>
                        <TableRow className='border-dashed dark:bg-black'>
                            <TableHead className=''>Name</TableHead>
                            <TableHead>Plan</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Period</TableHead>
                            <TableHead>Ends At</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody className='border-[0px]'>
                        {subscriptions.map((subscription) => (
                            <TableRow key={subscription?.id} className='dark:text-black'>
                                <TableCell className='border-b[1px] border-gray-300'>{subscription?.name}</TableCell>
                                <TableCell>{subscription?.plan?.name}</TableCell>
                                <TableCell>${subscription?.plan?.price}</TableCell>
                                <TableCell>{subscription?.plan?.period}</TableCell>
                                <TableCell>{subscription?.ends_at}</TableCell>
                                <TableCell>
                                    <Badge variant={subscription?.status === 'active' ? 'success' : 'secondary'}>
                                        {subscription?.status}
                                    </Badge>
                                </TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button variant="outline" className='dark:bg-white' size="icon" onClick={() => setViewSubscription(subscription)}>
                                            <Eye className="h-4 w-4 text-chart-2" />
                                        </Button>
                                        <Button variant="outline" className='dark:bg-white' size="icon" onClick={() => setEditSubscription(subscription)}>
                                            <Pencil className="h-4 w-4 text-[#48A3D7]" />
                                        </Button>
                                        <Button className='text-destructive dark:bg-white' variant="outline" size="icon" onClick={() => setDeleteSubscription(subscription)}>
                                            <XCircle className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4 bg-white p-4 md:p-4 rounded-xl">
            <Input
                placeholder="Search subscriptions"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full dashedField"
            />
            <hr className='my-5' />
            {renderContent()}

            <Dialog open={!!viewSubscription} onOpenChange={() => setViewSubscription(null)}>
                <DialogContent className="dark:bg-white dark:text-black">
                    <DialogHeader>
                        <DialogTitle>Subscription Details</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-2">
                        <p><strong>Name:</strong> {viewSubscription?.name}</p>
                        <p><strong>Status:</strong> {viewSubscription?.status}</p>
                        <p><strong>Plan:</strong> {viewSubscription?.plan.name}</p>
                        <p><strong>Price:</strong> ${viewSubscription?.plan.price}</p>
                        <p><strong>Period:</strong> {viewSubscription?.plan.period}</p>
                        <p><strong>Size:</strong> {viewSubscription?.plan.size}</p>
                        <p><strong>Radius:</strong> {viewSubscription?.plan.radius}</p>
                        <p><strong>Ends At:</strong> {viewSubscription?.ends_at || 'N/A'}</p>
                    </div>
                </DialogContent>
            </Dialog>

            <Dialog open={!!editSubscription} onOpenChange={() => setEditSubscription(null)}>
                <DialogContent className="dark:bg-white dark:text-black">
                    <DialogHeader>
                        <DialogTitle>Edit Subscription</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-8">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input {...field} onFocus={() => clearInputError('name')} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="submit" disabled={loading} className="dark:bg-black dark:text-white">
                                    {loading ? 'Saving...' : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteSubscription} onOpenChange={() => setDeleteSubscription(null)}>
                <DialogContent className="dark:bg-white dark:text-black">
                    <DialogHeader>
                        <DialogTitle>Cancel Subscription</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to cancel this subscription? This action will set the subscription to end at the end of the current billing period.
                    </DialogDescription>
                    <p className="text-sm text-gray-500 mt-2">
                        Note: Any ads assigned to this subscription will be set to end when the subscription does.
                    </p>
                    <DialogFooter>
                        <Button variant="outline" className="dark:text-white" onClick={() => setDeleteSubscription(null)}>Keep Subscription</Button>
                        <Button variant="destructive" onClick={() => handleCancel(deleteSubscription!)}>Cancel Subscription</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>

    );
}
