import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { usePage } from '@inertiajs/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Eye, Pencil, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

import { User, PaginationMeta } from '@/types';

interface ApiResponse {
    data: User[];
    meta: PaginationMeta;
    links: {
        first: string;
        last: string;
        prev: string | null;
        next: string | null;
    };
}

interface PageProps {
    users: User[];
    errors: {
        users?: string;
    };
    [key: string]: any;
}

const formSchema = z.object({
    name: z.string().min(2, {
        message: 'Name must be at least 2 characters.',
    }),
    fname: z.string().min(1, {
        message: 'First name is required.',
    }),
    lname: z.string().min(1, {
        message: 'Last name is required.',
    }),
    email: z.string().email({
        message: 'Please enter a valid email address.',
    }),
    phone: z.string().nullable(),
    street_number: z.string().nullable(),
    street_name: z.string().nullable(),
    city: z.string().nullable(),
    state: z.string().nullable(),
    postal_code: z.string().nullable(),
    country: z.string().nullable(),
    login_code: z.string().nullable(),
    is_admin: z.boolean(),
});

const UserTable: React.FC = () => {
    const { users: initialUsers, errors: initialErrors } = usePage<PageProps>().props;
    const [users, setUsers] = useState<User[]>(initialUsers || []);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [errors, setErrors] = useState<{ users?: string }>(initialErrors || {});
    const [pagination, setPagination] = useState<PaginationMeta | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const [adminFilter, setAdminFilter] = useState<string>('all'); // New state for admin filter

    const [viewUser, setViewUser] = useState<User | null>(null);
    const [editUser, setEditUser] = useState<User | null>(null);
    const [deleteUser, setDeleteUser] = useState<User | null>(null);

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
            fname: '',
            lname: '',
            email: '',
            phone: '',
            street_number: '',
            street_name: '',
            city: '',
            state: '',
            postal_code: '',
            country: '',
            login_code: '',
            is_admin: false,
        },
    });

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            fetchUsers(1);
        }, 300);

        return () => clearTimeout(delayDebounceFn);
    }, [searchTerm, adminFilter]);

    useEffect(() => {
        if (editUser) {
            form.reset({
                name: editUser?.name,
                fname: editUser?.fname,
                lname: editUser?.lname,
                email: editUser?.email,
                phone: editUser?.business?.phone || '',
                login_code: editUser?.login_code || '',
                street_number: editUser?.business?.address?.street_number || '',
                street_name: editUser?.business?.address?.street_name || '',
                city: editUser?.business?.address?.city || '',
                state: editUser?.business?.address?.state || '',
                postal_code: editUser?.business?.address?.postal_code || '',
                country: editUser?.business?.address?.country || '',
                is_admin: editUser.is_admin,
            });
        }
    }, [editUser, form]);

    const fetchUsers = async (page: number) => {
        setLoading(true);
        try {
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/users`, {
                params: {
                    name: searchTerm, page,
                    // is_admin: adminFilter === 'admins' ? true : adminFilter === 'users' ? false : undefined
                    is_admin: adminFilter === 'all' ? undefined : adminFilter === 'admins' ? true : false
                },
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            setUsers(response.data.data);
            setPagination(response.data.meta);
            setCurrentPage(page);
            setErrors({});
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                setErrors(error.response.data.errors || { users: 'An error occurred while fetching users.' });
            } else {
                setErrors({ users: 'An unexpected error occurred.' });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = async (values: z.infer<typeof formSchema>) => {
        setLoading(true);
        try {
            const response = await axios.put(`${import.meta.env.VITE_APP_URL}/api/v1/users/${editUser!.id}`, values, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchUsers(currentPage);
            setEditUser(null);
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error('Error updating user:', error.response.data);
            } else {
                console.error('Error updating user:', error);
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (user: User) => {
        setLoading(true);
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/users/${user.id}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                }
            });
            fetchUsers(currentPage);
            setDeleteUser(null);
        } catch (error) {
            console.error('Error deleting user:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderPagination = () => {
        if (!pagination || pagination.total <= pagination.per_page) return null;
        return (
            <div className="flex justify-center space-x-2 mt-4">
                <Button
                    onClick={() => fetchUsers(currentPage - 1)}
                    disabled={currentPage === 1}
                    variant="outline"
                >
                    Previous
                </Button>
                <Button
                    onClick={() => fetchUsers(currentPage + 1)}
                    disabled={currentPage === pagination.last_page}
                    variant="outline"
                >
                    Next
                </Button>
            </div>
        );
    };

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex justify-center">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </div>
            );
        }

        if (errors.users) {
            return (
                <Alert variant="destructive">
                    <AlertDescription>{errors.users}</AlertDescription>
                </Alert>
            );
        }

        if (users.length === 0) {
            return <p className="text-center text-gray-500">No users found.</p>;
        }

        console.log('Rendering users:', users);


        return (
            <>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Phone</TableHead>
                            <TableHead>City</TableHead>
                            <TableHead>Admin</TableHead>
                            <TableHead>Login Code</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {users.map((user) => (
                            <TableRow key={user.id}>
                                <TableCell className="font-medium">{user.name}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>{user?.business?.phone || 'N/A'}</TableCell>
                                <TableCell>{user?.business?.address?.city || 'N/A'}</TableCell>
                                <TableCell>{user.is_admin ? 'Yes' : 'No'}</TableCell>
                                <TableCell>{user?.login_code}</TableCell>
                                <TableCell>
                                    <div className="flex space-x-2">
                                        <Button variant="outline" size="icon" onClick={() => setViewUser(user)}>
                                            <Eye className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => setEditUser(user)}>
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button variant="outline" size="icon" onClick={() => setDeleteUser(user)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {renderPagination()}
            </>
        );
    };

    return (
        <div className="space-y-4">
            {/* Dropdown filter for admin status */}
            <select
                value={adminFilter}
                onChange={(e) => setAdminFilter(e.target.value)}
                className="w-full p-2 border rounded"
            >
                <option value="all">All Users</option>
                <option value="admins">Admins</option>
                <option value="users">Users</option>
            </select>
            <Input
                placeholder="Search users"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
            />
            {renderContent()}

            <Dialog open={!!viewUser} onOpenChange={() => setViewUser(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{viewUser?.name}</DialogTitle>
                    </DialogHeader>
                    {loading ? (
                        <div className="flex justify-center">
                            <Loader2 className="h-6 w-6 animate-spin" />
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <p><strong>Email:</strong> {viewUser?.email}</p>
                            <p><strong>Phone:</strong> {viewUser?.business?.phone || 'N/A'}</p>
                            <p><strong>Address:</strong> {viewUser?.business?.address?.formatted_address || 'N/A'}</p>
                            <p><strong>Admin:</strong> {viewUser?.is_admin ? 'Yes' : 'No'}</p>
                            <p><strong>Login Code:</strong> {viewUser?.login_code}</p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            <Dialog open={!!editUser} onOpenChange={() => setEditUser(null)}>
                <DialogContent className="w-screen h-screen max-w-full sm:h-auto sm:max-h-[90vh] sm:max-w-[90vw] sm:w-full overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit User: {editUser?.name}</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(handleEdit)} className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <FormField
                                    control={form.control}
                                    name="name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="email"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Email</FormLabel>
                                            <FormControl>
                                                <Input {...field} type="email" />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="fname"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>First Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="lname"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Last Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="phone"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Phone</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="street_number"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Street Number</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="street_name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Street Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="city"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>City</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="state"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>State</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="postal_code"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Postal Code</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="country"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Country</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="login_code"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Login Code</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {/* <FormField
                                    control={form.control}
                                    name="is_admin"
                                    render={({ field }) => (
                                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                            <FormControl>
                                                <Checkbox
                                                    checked={field.value}
                                                    onCheckedChange={field.onChange}
                                                />
                                            </FormControl>
                                            <div className="space-y-1 leading-none">
                                                <FormLabel>
                                                    Admin
                                                </FormLabel>
                                                <FormDescription>
                                                    This user has administrative privileges
                                                </FormDescription>
                                            </div>
                                        </FormItem>
                                    )}
                                /> */}
                            </div>
                            <DialogFooter>
                                <Button type="submit" disabled={loading}>
                                    {loading ? 'Saving...' : 'Save Changes'}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>

            <Dialog open={!!deleteUser} onOpenChange={() => setDeleteUser(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    {/* <DialogDescription>
                        Are you sure you want to delete the user "{deleteUser?.name}"? This action cannot be undone.
                        {deleteUser?.latestActive?.id}
                    </DialogDescription> */}
                    <DialogDescription>
                        {deleteUser?.latestActive?.id ? (
                            `Cannot delete user "${deleteUser?.name}" because they have an active subscription (ID: ${deleteUser.latestActive.id}).`
                        ) : (
                            `Are you sure you want to delete the user "${deleteUser?.name}"? This action cannot be undone.`
                        )}
                    </DialogDescription>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteUser(null)}>Cancel</Button>
                        <Button variant="destructive" disabled={deleteUser?.latestActive?.id} onClick={() => handleDelete(deleteUser!)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default UserTable;
