import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import * as LucideIcons from 'lucide-react';
import { LucideIcon } from 'lucide-react';
import { z } from 'zod';

export interface WizardStep {
    title: string;
    description: string;
    component: React.ComponentType<{
        onStepSubmit: (data: any) => void;
        isLastStep: boolean;
        initialData: any;
    }>;
    icon?: keyof typeof LucideIcons;
    schema?: z.ZodSchema<any>;
}

interface WizardProps {
    steps: WizardStep[];
    onComplete: (allData: any) => void;
    progressMode: 'steps' | 'percentage';
}

export const Wizard: React.FC<WizardProps> = ({
    steps,
    onComplete,
    progressMode
}) => {
    const [currentStep, setCurrentStep] = useState(1);
    const [stepsData, setStepsData] = useState<Record<number, any>>({});
    const [isProcessing, setIsProcessing] = useState(false);

    const handleStepSubmit = async (data: any) => {
        setIsProcessing(true);
        const updatedStepsData = { ...stepsData, [currentStep]: data };
        setStepsData(updatedStepsData);

        if (currentStep < steps.length) {
            setCurrentStep(currentStep + 1);
        } else {
            await onComplete(updatedStepsData);
        }
        setIsProcessing(false);
    };

    const handleBack = () => {
        if (currentStep > 1) {
            setCurrentStep(currentStep - 1);
        }
    };

    const renderIcon = (step: WizardStep, index: number) => {
        if (step.icon && step.icon in LucideIcons) {
            const IconComponent = LucideIcons[step.icon] as LucideIcon;
            return <IconComponent className="w-6 h-6" />;
        }
        return <span>{index + 1}</span>;
    };

    const renderStepsProgress = () => (
        <div className="flex justify-center items-center mb-4">
            {steps.map((step, index) => (
                <div key={index} className="flex items-center">
                    <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${index < currentStep ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                            }`}
                    >
                        {index < currentStep - 1 ? (
                            <LucideIcons.Check className="w-4 h-4" />
                        ) : (
                            renderIcon(step, index)
                        )}
                    </div>
                    {index < steps.length - 1 && (
                        <div
                            className={`h-0.5 w-12 mx-1 ${index < currentStep - 1 ? 'bg-primary' : 'bg-muted'
                                }`}
                        />
                    )}
                </div>
            ))}
        </div>
    );

    const renderPercentProgress = () => {
        const percent = Math.round((currentStep / steps.length) * 100);
        return (
            <div className="mb-6">
                <div className="flex justify-between text-sm mb-1">
                    <span>Step {currentStep} of {steps.length}</span>
                    <span>{percent}% Complete</span>
                </div>
                <div className="h-2 w-full bg-muted rounded-full">
                    <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${percent}%` }}
                    ></div>
                </div>
            </div>
        );
    };

    const CurrentStepComponent = steps[currentStep - 1].component;

    return (
        <div className="lgCard">
            <div className="">
                {progressMode === 'steps' ? renderStepsProgress() : renderPercentProgress()}
                <h2 className="font-semibold text-center dark:text-black">{steps[currentStep - 1].title}</h2>
                <p className="text-sm text-muted-foreground text-center">{steps[currentStep - 1].description}</p>
            </div>

            <div className="flex-grow overflow-auto">
                <CurrentStepComponent
                    onStepSubmit={handleStepSubmit}
                    isLastStep={currentStep === steps.length}
                    initialData={stepsData[currentStep] || {}}
                />
            </div>

            <div className="flex justify-between items-center lgBtnWrap">
                <Button
                    type="button"
                    onClick={handleBack}
                    disabled={currentStep === 1 || isProcessing}
                    className="lgBtn bg-gray-200 rounded disabled:opacity-50"
                >
                    Previous
                </Button>
                <Button
                    type="submit"
                    form={`step-${currentStep}-form`}
                    className="lgBtn"
                    disabled={isProcessing}
                >
                    {isProcessing ? 'Processing...' : currentStep === steps.length ? 'Complete' : 'Next'}
                </Button>
            </div>
        </div>
    );
};
