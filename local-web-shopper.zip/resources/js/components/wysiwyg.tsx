import React from 'react';
import dynamic from 'next/dynamic';
import 'react-quill/dist/quill.snow.css';

const ReactQuill = dynamic(() => import('react-quill'), { ssr: false });

export default function WYSIWYGEditor({ value, onChange }) {
    return (
        <div className="border rounded-xl overflow-hidden">
            <ReactQuill theme="snow" value={value} onChange={onChange} />
        </div>
    );
}
