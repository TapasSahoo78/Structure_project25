import { duration } from 'node_modules/zod/v4/core/regexes.cjs';
import React, { createContext, useContext, ReactNode } from 'react';
import { toast, ToastOptions } from 'sonner';

type AlertType = 'success' | 'error' | 'warning' | 'info';

interface AlertContextType {
    showAlert: (type: AlertType, message: string, options?: ToastOptions) => void;
}

const AlertContext = createContext<AlertContextType | undefined>(undefined);

export const AlertProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const showAlert = (type: AlertType, message: string, options?: ToastOptions) => {
        const defaultOptions: ToastOptions = {
            duration: type === 'error' ? 30000 : 20000,
            ...options,
        };
        switch (type) {
            case 'success':
                toast.success(message, defaultOptions);
                break;
            case 'error':
                toast.error(message, defaultOptions);
                break;
            case 'warning':
                toast.warning(message, defaultOptions);
                break;
            case 'info':
                toast.info(message, defaultOptions);
                break;
            default:
                toast(message, defaultOptions);
        }
    };

    return (
        <AlertContext.Provider value={{ showAlert }}>
            {children}
        </AlertContext.Provider>
    );
};

export const useAlert = () => {
    const context = useContext(AlertContext);
    if (context === undefined) {
        throw new Error('useAlert must be used within an AlertProvider');
    }
    return context;
};
