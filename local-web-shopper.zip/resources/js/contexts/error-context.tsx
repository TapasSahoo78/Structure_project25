import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useAlert } from '@/contexts/alert-context';

interface ErrorContextType {
    inputErrors: Record<string, string>;
    setInputError: (field: string, message: string) => void;
    clearInputError: (field: string) => void;
    setGlobalError: (message: string) => void;
    showError: (message: string) => void;
}

const ErrorContext = createContext<ErrorContextType | undefined>(undefined);

export const ErrorProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [inputErrors, setInputErrors] = useState<Record<string, string>>({});
    const { showAlert } = useAlert();

    const setInputError = (field: string, message: string) => {
        setInputErrors(prev => ({ ...prev, [field]: message }));
    };

    const clearInputError = (field: string) => {
        setInputErrors(prev => {
            const newErrors = { ...prev };
            delete newErrors[field];
            return newErrors;
        });
    };

    const setGlobalError = (message: string) => {
        showAlert('error', message);
    };

    const showError = (message: string) => {
        showAlert('error', message);
    };

    return (
        <ErrorContext.Provider value={{ inputErrors, setInputError, clearInputError, setGlobalError, showError }}>
            {children}
        </ErrorContext.Provider>
    );
};

export const useError = () => {
    const context = useContext(ErrorContext);
    if (context === undefined) {
        throw new Error('useError must be used within an ErrorProvider');
    }
    return context;
};
