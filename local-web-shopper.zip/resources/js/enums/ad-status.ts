export enum AdStatus {
    DRAFT = 'DRAFT',
    SCHEDULED = 'SCHEDULED',
    LIVE = 'LIVE',     // Ad is visible
    ENDED = 'ENDED',   // Ad goes here after live if not canceled
    CANCELED = 'CANCELED',
    FAILED = 'FAILED', // Ad attempted to go live but failed
}

export const AdStatusUtils = {
    getHuman: (status: AdStatus): string => {
        switch (status) {
            case AdStatus.DRAFT:
                return "Draft";
            case AdStatus.SCHEDULED:
                return "Scheduled";
            case AdStatus.LIVE:
                return "Live";
            case AdStatus.ENDED:
                return "Ended";
            case AdStatus.CANCELED:
                return "Canceled";
            case AdStatus.FAILED:
                return "Failed";
        }
    },

    getColor: (status: AdStatus): string => {
        switch (status) {
            case AdStatus.DRAFT:
            case AdStatus.SCHEDULED:
                return "info";
            case AdStatus.LIVE:
                return "success";
            case AdStatus.ENDED:
                return "secondary";
            case AdStatus.CANCELED:
                return "danger";
            case AdStatus.FAILED:
                return "warning";
        }
    }
};