export enum PageSize {
    QUARTER = 'QUARTER',
    HALF = 'HALF',
    FULL = 'FULL',
    BANNER = 'BANNER',
}

export const PageSizeUtils = {
    getHuman: (size: PageSize): string => {
        switch (size) {
            case PageSize.QUARTER: return "1/4 Page";
            case PageSize.HALF: return "1/2 Page";
            case PageSize.FULL: return "Full Page";
            case PageSize.BANNER: return "Banner";
        }
    },

    fromHuman: (humanSize: string): PageSize => {
        switch (humanSize) {
            case "1/4 Page": return PageSize.QUARTER;
            case "1/2 Page": return PageSize.HALF;
            case "Full Page": return PageSize.FULL;
            case "Banner": return PageSize.BANNER;
            default: throw new Error(`Unknown page size: ${humanSize}`);
        }
    },

    getSelectable: (): Record<string, string> => {
        return Object.values(PageSize).reduce((acc, size) => {
            acc[size] = PageSizeUtils.getHuman(size as PageSize);
            return acc;
        }, {} as Record<string, string>);
    },
};