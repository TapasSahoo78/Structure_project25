export enum PlanPeriod {
    DAILY = 'DAILY',
    MONTHLY = 'MONTHLY',
    QUARTERLY = 'QUARTERLY',
    BIANNUALLY = 'BIANNUALLY',
    ANNUALLY = 'ANNUALLY',
}

export const PlanPeriodUtils = {
    getHuman: (period: PlanPeriod): string => {
        switch (period) {
            case PlanPeriod.DAILY:
                return 'Daily';
            case PlanPeriod.MONTHLY:
                return 'Monthly';
            case PlanPeriod.QUARTERLY:
                return 'Quarterly';
            case PlanPeriod.BIANNUALLY:
                return 'Biannually';
            case PlanPeriod.ANNUALLY:
                return 'Annually';
        }
    },

    getSelectable: (): Record<string, string> => {
        return Object.values(PlanPeriod).reduce(
            (acc, period) => {
                acc[period] = PlanPeriodUtils.getHuman(period as PlanPeriod);
                return acc;
            },
            {} as Record<string, string>,
        );
    },

    getStripeValue: (period: PlanPeriod): string => {
        switch (period) {
            case PlanPeriod.DAILY:
                return 'day';
            case PlanPeriod.MONTHLY:
            case PlanPeriod.QUARTERLY:
            case PlanPeriod.BIANNUALLY:
                return 'month';
            case PlanPeriod.ANNUALLY:
                return 'year';
        }
    },

    getIntervalCount: (period: PlanPeriod | string): number => {
        const normalizedPeriod = typeof period === 'string' ? period.toUpperCase() : period;

        switch (normalizedPeriod) {
            case PlanPeriod.DAILY:
            case 'DAILY':
                return 1;
            case PlanPeriod.MONTHLY:
            case 'MONTHLY':
                return 1;
            case PlanPeriod.QUARTERLY:
            case 'QUARTERLY':
                return 3;
            case PlanPeriod.BIANNUALLY:
            case 'BIANNUALLY':
                return 6;
            case PlanPeriod.ANNUALLY:
            case 'ANNUALLY':
                return 12;
            default:
                console.error('Unknown PlanPeriod:', period);
                return 1; // Default to 1 month
        }
    },
};
