import { useEffect, useState } from 'react';
import { useJsApiLoader } from '@react-google-maps/api';

// const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
// const GOOGLE_MAPS_API_KEY = "AIzaSyAuDmwgjjXxwqMVh1acUTJUdPlwZ3LQpzc";
const GOOGLE_MAPS_API_KEY = "AIzaSyBeL8kIpn9-tfj8OFGZ_3v3_hPEcLqoTxo";

const libraries: ("places" | "drawing" | "geometry" | "localContext" | "visualization")[] = ['places'];

export const useGoogleMaps = () => {
    const [googleMapsLoaded, setGoogleMapsLoaded] = useState(false);

    const { isLoaded, loadError } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: GOOGLE_MAPS_API_KEY || '',
        libraries: libraries,
    });

    useEffect(() => {
        if (isLoaded) {
            setGoogleMapsLoaded(true);
        }
        if (loadError) {
            console.error('Failed to load Google Maps script:', loadError);
            setGoogleMapsLoaded(false);
        }
    }, [isLoaded, loadError]);

    useEffect(() => {
        if (!GOOGLE_MAPS_API_KEY) {
            console.error('Google Maps API key is not set. Please check your environment variables.');
        }
    }, []);

    return googleMapsLoaded;
};
