import AppLogoIcon from '@/components/app-logo-icon';
import { Link } from '@inertiajs/react';
import { type PropsWithChildren } from 'react';

interface AuthLayoutProps {
    name?: string;
    title?: string;
    description?: string;
}

export default function AuthSimpleLayout({ children, title, description }: PropsWithChildren<AuthLayoutProps>) {
    return (
        <div className="flex min-h-svh flex-col items-center justify-center gap-6 py-5">
            <div className="w-full max-w-md">
                <div className="flex flex-col">
                    <div className="lgogWrap">
                        <Link href={route('home')} className="flex flex-col items-center gap-2 font-medium">
                            <AppLogoIcon />
                            {/* <span className="sr-only">{title}</span> */}
                        </Link>
                    </div>
                    <div className=" lgCard">
                    <div className="fromDesc">
                        <h3>{title}</h3>
                        <p>{description}</p>
                    </div>
                    {children}
                    </div>
                </div>
            </div>
        </div>
    );
}
