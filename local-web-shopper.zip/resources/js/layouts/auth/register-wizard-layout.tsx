import AppLogoIcon from '@/components/app-logo-icon';
import { type PropsWithChildren } from 'react';
import { Link } from '@inertiajs/react';
import { ChevronLeft } from 'lucide-react';

interface RegisterWizardLayoutProps {
    title?: string;
    currentStep: number;
    totalSteps: number;
}

export default function RegisterWizardLayout({
    children,
    title,
    currentStep,
    totalSteps
}: PropsWithChildren<RegisterWizardLayoutProps>) {
    return (
        <div className=" flex min-h-screen items-center justify-center p-2">
            <div className="fsgdr w-full max-w-md flex flex-col">
                <div className="lgogWrap">
                    <AppLogoIcon />
                </div>
                <div className="flex-shrink-0 flex items-center justify-between gap-2 mb-4">
                    <Link
                        href="/"
                        className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
                    >
                        <ChevronLeft className="h-5 w-5 mr-1" />
                        <span>Back</span>
                    </Link>
                    <div className="flex items-center gap-2">
                        {/*<div className="flex h-6 w-6 items-center justify-center">
                            <AppLogoIcon />
                        </div>*/}
                        <h1 className="text-base font-medium dark:text-black">{title}</h1>
                    </div>
                </div>

                {/* Uncomment and adjust if you want to include the progress bar
                <div className="text-xs text-gray-600 flex justify-between items-center mb-1">
                    <span>Step {currentStep} of {totalSteps}</span>
                    <span>{Math.round((currentStep / totalSteps) * 100)}% Complete</span>
                </div>
                <div className="h-1 w-full bg-gray-200 rounded-full mb-4">
                    <div
                        className="h-full bg-blue-600 rounded-full"
                        style={{ width: `${(currentStep / totalSteps) * 100}%` }}
                    ></div>
                </div>
                */}

                <div className="sdqsds flex-grow flex flex-col">
                    {children}
                </div>
            </div>
        </div>
    );
}
