import { AppContent } from '@/components/portal/content';
import { AppHeader } from '@/components/portal/header';
import { AppShell } from '@/components/portal/shell';
import { type BreadcrumbItem } from '@/types';
import type { PropsWithChildren } from 'react';
import { Footer } from '@/components/footer/footer';

export default function AppHeaderLayout({ children, breadcrumbs }: PropsWithChildren<{ breadcrumbs?: BreadcrumbItem[] }>) {
    return (
        <AppShell>
            <AppHeader breadcrumbs={breadcrumbs} />
            <AppContent>{children}</AppContent>
            <Footer />
        </AppShell>
    );
}
