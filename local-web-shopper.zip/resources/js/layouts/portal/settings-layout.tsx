import Heading from '@/components/heading';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { type NavItem } from '@/types';
import { Link } from '@inertiajs/react';
import { type PropsWithChildren } from 'react';

const sidebarNavItems: NavItem[] = [
    {
        title: 'Business',
        href: '/portal/settings/business',
        icon: null,
    },
    {
        title: 'Profile',
        href: '/portal/settings/profile',
        icon: null,
    },
    {
        title: 'Password',
        href: '/portal/settings/password',
        icon: null,
    },
    // {
    //     title: 'Appearance',
    //     href: '/portal/settings/appearance',
    //     icon: null,
    // },
];

export default function SettingsLayout({ children }: PropsWithChildren) {
    // When server-side rendering, we only render the layout on the client...
    if (typeof window === 'undefined') {
        return null;
    }

    const currentPath = window.location.pathname;

    return (
        <div className="py-4">
            <div className="container mx-auto">
                <Heading title="Settings" description="Manage your profile and account settings" />

                <div className="flex gap-3 flex-col md:flex-row md:gap-4 lg:gap-6 xl:gap-8">
                    <aside className="sm:w-1/1 md:w-3/10 lg:w-2/10">
                        <nav className="flex flex-col space-y-1 space-x-0 bg-white py-2 px-1 rounded-xl">
                            {sidebarNavItems.map((item, index) => (
                                <Button
                                    key={`${item.href}-${index}`}
                                    size="sm"
                                    variant="ghost"
                                    asChild
                                    className={cn('w-full justify-start rounded-[0px]', {
                                        'bg-muted dark:bg-red': currentPath === item.href,
                                    })}
                                >
                                    <Link className='rounded-[0px] dark:text-black dark:hover:text-white' href={`${import.meta.env.VITE_APP_URL}${item.href}`} prefetch>
                                        {item.title}
                                    </Link>
                                </Button>
                            ))}
                        </nav>
                    </aside>

                    {/* <Separator className="my-6 md:hidden" /> */}

                    <div className="sm:w-1/1 md:w-7/10 lg:w-8/10">
                        <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                            <section className="">{children}</section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
