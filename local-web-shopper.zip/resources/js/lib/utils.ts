import { type ClassValue, clsx } from 'clsx';
import { addDays, addMinutes, format, parseISO } from 'date-fns';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
    }).format(amount / 100);
}

export function formatDate(timestamp: string | number | Date | null | undefined): string {
    if (!timestamp) return 'N/A';

    let date: Date;

    if (typeof timestamp === 'string') {
        // Parse the ISO string and adjust for timezone
        // date = addDays(parseISO(timestamp), 1);
        date = addDays(parseISO(timestamp), 0);
    } else if (timestamp instanceof Date) {
        date = timestamp;
    } else if (typeof timestamp === 'number') {
        // If it's a Unix timestamp (seconds since epoch), convert to milliseconds
        date = new Date(timestamp * 1000);
    } else {
        return 'Invalid Date';
    }

    if (isNaN(date.getTime())) {
        return 'Invalid Date';
    }

    // Format the date
    return format(date, 'MMM d, yyyy');
}

export function formatDateForInput(dateString: string | null | undefined): string {
    if (!dateString) return '';
    const date = parseISO(dateString);
    const userTimezoneOffset = date.getTimezoneOffset();
    const adjustedDate = addMinutes(date, userTimezoneOffset);
    return format(adjustedDate, 'yyyy-MM-dd');
}

export function formatDateForSubmission(dateString: string | null | undefined): string | null {
    if (!dateString) return null;
    const date = new Date(dateString);
    return format(date, 'yyyy-MM-dd');
}
