import { useState } from 'react';
import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem, type AdCategory } from '@/types';
import { Link, useForm, usePage } from '@inertiajs/react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from 'sonner';
import AdCategoriesTable from '@/components/ad-categories/table';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Ad Categories',
        href: '/admin/ad-categories',
    },
];

interface Props {
    adCategories: AdCategory[];
}

export default function AdCategoriesIndex({ adCategories: initialAdCategories }: Props) {
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [adCategories, setAdCategories] = useState(initialAdCategories);
    const { data, setData, post, processing, errors, reset } = useForm<Partial<AdCategory>>({
        name: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        post(`${import.meta.env.VITE_APP_URL}/admin/ad-categories`, {
            preserveState: true,
            onSuccess: (page) => {
                setIsDialogOpen(false);
                reset('name');
                toast.success('Ad category created successfully');

                setAdCategories(page.props.adCategories);
            },
            onError: () => {
                toast.error('Failed to create ad category');
            },
        });
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <h1 className="text-2xl font-bold">Ad Categories</h1>
                    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                        <DialogTrigger asChild>
                            <Button onClick={() => setIsDialogOpen(true)}>Create Ad Category</Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>Create New Ad Category</DialogTitle>
                            </DialogHeader>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <Label htmlFor="name">Category Name</Label>
                                    <Input
                                        id="name"
                                        value={data.name}
                                        onChange={(e) => setData('name', e.target.value)}
                                        placeholder="Enter category name"
                                    />
                                    {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
                                </div>
                                <Button type="submit" disabled={processing}>
                                    {processing ? 'Creating...' : 'Create Category'}
                                </Button>
                            </form>
                        </DialogContent>
                    </Dialog>
                </div>

                <AdCategoriesTable adCategories={adCategories} />
            </div>
        </AppLayout>
    );
}
