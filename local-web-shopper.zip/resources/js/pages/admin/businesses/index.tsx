import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Link } from '@inertiajs/react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import { Button } from "@/components/ui/button";

import BusinessesTable from '@/components/businesses/BusinessesTable';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Businesses',
        href: '/admin/businesses',
    },
];

export default function BusinessesIndex() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>

            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <p>Businesses</p>
                </div>
                <BusinessesTable />
            </div>
        </AppLayout>
    );
}