import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, router } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Toaster } from 'sonner';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';

// Define enums or constants for coupon options (adapt as needed)
const DiscountType = {
    PERCENT: 'percent',
    AMOUNT: 'amount',
} as const;

const DurationType = {
    ONCE: 'once',
    REPEATING: 'repeating',
    FOREVER: 'forever',
} as const;

// const CurrencyOptions = ['usd', 'eur', 'gbp'] as const; // Expand as needed
const CurrencyOptions = ['usd'] as const; // Expand as needed

// Zod schema for coupon creation (based on your Laravel request rules)
const formSchema = z.object({
    code: z.string().min(2, {
        message: 'Code must be at least 2 characters.',
    }),
    discount_type: z.enum([DiscountType.PERCENT, DiscountType.AMOUNT], {
        errorMap: () => ({ message: 'Please select a valid discount type (percent or amount).' }),
    }),
    discount_value: z.number({
        required_error: 'Discount value is required.',
        invalid_type_error: 'Discount value must be a number.',
    }).positive('Discount value must be positive.').refine((val) => {
        // This is client-side; server will enforce stricter rules, but we can approximate
        return val <= 500; // For simplicity, cap at 500; adjust dynamically if needed
    }, {
        message: 'For percentage discounts, value must not exceed 500.',
    }),
    duration: z.enum([DurationType.ONCE, DurationType.REPEATING, DurationType.FOREVER], {
        errorMap: () => ({ message: 'Please select a valid duration (once, repeating, or forever).' }),
    }),
    max_redemptions: z.number().int().min(0).max(999999).optional().or(z.literal(1)), // Defaults to 1
    redeem_by: z.string().optional(), // Date string (YYYY-MM-DD format)
    currency: z.enum(CurrencyOptions).optional().or(z.literal('usd')), // Defaults to 'usd', required for amount
    is_active: z.boolean().optional().or(z.literal(true)), // Defaults to true
}).refine((data) => {
    if (data.discount_type === DiscountType.AMOUNT && !data.currency) {
        return false;
    }
    return true;
}, {
    message: 'Currency is required for amount discounts.',
    path: ['currency'],
});

type FormData = z.infer<typeof formSchema>;

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Coupons',
        href: '/admin/coupons',
    },
    {
        title: 'Create',
        href: '/admin/coupons/create',
    },
];

export default function CouponsCreate() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { showAlert } = useAlert();
    const { showError } = useError();

    const form = useForm<FormData>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            code: '',
            discount_type: DiscountType.PERCENT,
            discount_value: 0,
            duration: DurationType.FOREVER,
            max_redemptions: 1,
            redeem_by: '',
            currency: 'usd',
            is_active: true,
        },
    });

    // Watch discount_type to conditionally show/hide fields
    const discountType = form.watch('discount_type');

    const onSubmit = async (values: FormData) => {
        // Prepare data for submission (map to Laravel request format)
        const dataToSend = {
            code: values.code,
            discount_type: values.discount_type,
            discount_value: Number(values.discount_value.toFixed(2)),
            duration: values.duration,
            max_redemptions: values.max_redemptions ?? 1,
            redeem_by: values.redeem_by || undefined, // Send as empty string or undefined for null
            currency: values.currency ?? 'usd',
            is_active: values.is_active ?? true,
        };

        router.post(`${import.meta.env.VITE_APP_URL}/admin/coupons`, dataToSend, {
            preserveState: true,
            preserveScroll: true,
            onBefore: () => setIsSubmitting(true),
            onSuccess: () => {
                showAlert('success', 'Coupon created successfully');
                // Optionally reset form or redirect
                form.reset();
                // router.visit('/admin/coupons');
            },
            onError: (errors) => {
                console.error('Error creating Coupon:', errors);
                showError('Failed to create Coupon');
            },
            onFinish: () => setIsSubmitting(false),
        });
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="New Coupon" />
            <Toaster />
            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <h1 className="text-2xl font-bold">New Coupon</h1>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                        <FormField
                            control={form.control}
                            name="code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Code</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., SAVE20" {...field} />
                                    </FormControl>
                                    <FormDescription>Human-readable coupon code (unique).</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="discount_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Discount Type</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select discount type" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value={DiscountType.PERCENT}>Percentage (% off)</SelectItem>
                                            <SelectItem value={DiscountType.AMOUNT}>Fixed Amount ($ off)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormDescription>Choose whether the discount is a percentage or fixed amount.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="discount_value"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Discount Value</FormLabel>
                                    <FormControl>
                                        <Input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            max={discountType === DiscountType.PERCENT ? "500" : undefined}
                                            placeholder={discountType === DiscountType.PERCENT ? "e.g., 20 for 20%" : "e.g., 5 for $5 off"}
                                            {...field}
                                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                            value={field.value || ''}
                                        />
                                    </FormControl>
                                    <FormDescription>
                                        {discountType === DiscountType.PERCENT ? 'Percentage off (0-500).' : 'Fixed amount off.'}
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        {/* <FormField
                            control={form.control}
                            name="duration"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Duration</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select duration" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value={DurationType.ONCE}>Once (single use)</SelectItem>
                                            <SelectItem value={DurationType.REPEATING}>Repeating (e.g., monthly)</SelectItem>
                                            <SelectItem value={DurationType.FOREVER}>Forever (no expiration)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormDescription>How long the discount applies after redemption.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        /> */}
                        <FormField
                            control={form.control}
                            name="max_redemptions"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Max Redemptions</FormLabel>
                                    <FormControl>
                                        <Input
                                            type="number"
                                            min="0"
                                            placeholder="e.g., 100 (unlimited if 0)"
                                            {...field}
                                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                            value={field.value || ''}
                                        />
                                    </FormControl>
                                    <FormDescription>Maximum number of times this coupon can be used (default: 1).</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="redeem_by"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Redeem By (Expiration)</FormLabel>
                                    <FormControl>
                                        <Input
                                            type="date"
                                            min={new Date().toISOString().split('T')[0]} // Enforce future dates (today or later)
                                            placeholder="Select expiration date"
                                            {...field}
                                            onChange={(e) => field.onChange(e.target.value || '')}
                                            value={field.value || ''}
                                        />
                                    </FormControl>
                                    <FormDescription>Optional expiration date for the coupon (must be in the future).</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        {discountType === DiscountType.AMOUNT && (
                            <FormField
                                control={form.control}
                                name="currency"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Currency</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Select currency" />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {CurrencyOptions.map((currency) => (
                                                    <SelectItem key={currency} value={currency}>
                                                        {currency.toUpperCase()}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        <FormDescription>Currency for the fixed amount discount (default: USD).</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        )}
                        <FormField
                            control={form.control}
                            name="is_active"
                            render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                    <FormControl>
                                        <Checkbox
                                            checked={field.value}
                                            onCheckedChange={field.onChange}
                                        />
                                    </FormControl>
                                    <div className="space-y-1 leading-none">
                                        <FormLabel>Active</FormLabel>
                                        <FormDescription>Whether this coupon is currently active and usable.</FormDescription>
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? 'Creating...' : 'Create Coupon'}
                        </Button>
                    </form>
                </Form>
            </div>
        </AppLayout>
    );
}
