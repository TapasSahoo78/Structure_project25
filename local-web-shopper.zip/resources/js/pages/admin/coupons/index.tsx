import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Link } from '@inertiajs/react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import { Button } from "@/components/ui/button";

import CouponTable from '@/components/coupons/table';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Coupon Code',
        href: '/admin/coupons',
    },
];

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
}

export default function CouponsIndex() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <p>Coupon Codes</p>
                    <Link href={`${import.meta.env.VITE_APP_URL}/admin/coupons/create`}>
                        <Button>Create Coupon Code</Button>
                    </Link>
                </div>
                <CouponTable />
            </div>
        </AppLayout>
    );
}
