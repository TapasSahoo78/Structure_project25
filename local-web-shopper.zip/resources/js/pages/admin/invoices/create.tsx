import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Link } from '@inertiajs/react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import { Button } from "@/components/ui/button";

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Ad Categories',
        href: '/admin/ad-categories',
    },

    {
        title: 'Create',
        href: '/admin/ad-categories/create',
    },
];

export default function AdCategoriesCreate() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>

            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <p>Ad Categories</p>

                </div>
            </div>
        </AppLayout>
    );
}