import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, router } from '@inertiajs/react';
import { Plan } from '@/types/plan';
import { PageSize, PageSizeUtils } from '@/enums/page-size';
import { PlanPeriod, PlanPeriodUtils } from '@/enums/plan-period';
import { Button } from '@/components/ui/button';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Toaster } from 'sonner';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Plans',
        href: '/admin/plans',
    },
    {
        title: 'Create',
        href: '/admin/plans/create',
    },
];

const formSchema = z.object({
    name: z.string().min(2, {
        message: 'Name must be at least 2 characters.',
    }),
    description: z.string().min(10, {
        message: 'Description must be at least 10 characters.',
    }),
    price: z.number().positive({
        message: 'Price must be a positive number.',
    }),
    size: z.nativeEnum(PageSize),
    radius: z.number().int().positive({
        message: 'Radius must be a positive integer.',
    }),
    period: z.string(),
});

export default function PlansCreate() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { showAlert } = useAlert();
    const { showError } = useError();

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
            description: '',
            price: 0.00,
            size: PageSize.QUARTER,
            radius: 0,
            period: PlanPeriod.MONTHLY,
        },
    });

    const onSubmit = async (values: z.infer<typeof formSchema>) => {
        const dataToSend = {
            name: values.name,
            description: values.description,
            price: Number(values.price.toFixed(2)),
            size: values.size,
            radius: Math.round(values.radius),
            period: values.period,
        };

        router.post(`${import.meta.env.VITE_APP_URL}/admin/plans`, dataToSend, {
            preserveState: true,
            preserveScroll: true,
            onBefore: () => setIsSubmitting(true),
            onSuccess: () => {
                showAlert('success', 'Plan created successfully');
                // Optionally, you can redirect to a different page after success
                // router.visit('/admin/plans');
            },
            onError: (errors) => {
                console.error('Error creating Plan:', errors);
                showError('Failed to create Plan');
            },
            onFinish: () => setIsSubmitting(false),
        });
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="New Plan" />
            <Toaster />
            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <h1 className="text-2xl font-bold">New Plan</h1>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Name</FormLabel>
                                    <FormControl>
                                        <Input {...field} />
                                    </FormControl>
                                    <FormDescription>The name of the plan.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea {...field} />
                                    </FormControl>
                                    <FormDescription>A brief description of the plan.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="price"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Price</FormLabel>
                                    <FormControl>
                                        <Input type="number" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value))} />
                                    </FormControl>
                                    <FormDescription>The price of the plan.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="size"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Size</FormLabel>
                                    <Select
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select a page size">
                                                    {field.value && PageSizeUtils.getHuman(field.value as PageSize)}
                                                </SelectValue>
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {Object.entries(PageSize).map(([key, value]) => (
                                                <SelectItem key={key} value={value}>
                                                    {PageSizeUtils.getHuman(value as PageSize)}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <FormDescription>The size of the ad.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="radius"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Radius</FormLabel>
                                    <FormControl>
                                        <Input type="number" {...field} onChange={(e) => field.onChange(parseInt(e.target.value, 10))} />
                                    </FormControl>
                                    <FormDescription>The radius of the ad coverage.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="period"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Period</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select a period">
                                                    {field.value && PlanPeriodUtils.getHuman(field.value as PlanPeriod)}
                                                </SelectValue>
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {Object.entries(PlanPeriodUtils.getSelectable()).map(([value, label]) => (
                                                <SelectItem key={value} value={value}>
                                                    {label}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <FormDescription>The period of the plan.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? 'Creating...' : 'Create Plan'}
                        </Button>
                    </form>
                </Form>
            </div>
        </AppLayout>
    );
}
