import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Link } from '@inertiajs/react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import { Button } from "@/components/ui/button";

import PlanTable from '@/components/plans/table';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Plans',
        href: '/admin/plans',
    },
];

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
}

export default function PlansIndex() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>

            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <p>Plans</p>
                    <Link href={`${import.meta.env.VITE_APP_URL}/admin/plans/create`}>
                        <Button>Create Plan</Button>
                    </Link>
                </div>
                <PlanTable />
            </div>
        </AppLayout>
    );
}
