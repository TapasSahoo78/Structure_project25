import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, router } from '@inertiajs/react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Toaster } from 'sonner';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Users',
        href: '/admin/users',
    },

    {
        title: 'Create',
        href: '/admin/users/create',
    },
];

const formSchema = z.object({
    fname: z.string().min(2, {
        message: 'First Name must be at least 2 characters.',
    }),
    lname: z.string().min(2, {
        message: 'Last Name must be at least 2 characters.',
    }),
    email: z.string().email({
        message: 'Please enter a valid email.',
    }),
});

export default function UsersCreate() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { showAlert } = useAlert();
    const { showError } = useError();

    const form = useForm({
        resolver: zodResolver(formSchema),
        defaultValues: {
            fname: '',
            lname: '',
            email: '',
        },
    });

    const onSubmit = async (values: z.infer<typeof formSchema>) => {
        router.post(`${import.meta.env.VITE_APP_URL}/admin/users`, values, {
            preserveState: true,
            preserveScroll: true,
            onBefore: () => setIsSubmitting(true),
            onSuccess: () => {
                showAlert(
                    'success',
                    'User created successfully'
                );
            },
            onError: (errors: any) => {
                console.error('Error creating user:', errors);
                showError('Failed to create user');
            },
            onFinish: () => setIsSubmitting(false),
        });
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="New User" />
            <Toaster />
            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <h1 className="text-2xl font-bold">New User</h1>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                        <FormField
                            control={form.control}
                            name="fname"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>First Name</FormLabel>
                                    <FormControl>
                                        <Input {...field} />
                                    </FormControl>
                                    <FormDescription>The first name of the user.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="lname"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Last Name</FormLabel>
                                    <FormControl>
                                        <Input {...field} />
                                    </FormControl>
                                    <FormDescription>The last name of the user.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Email</FormLabel>
                                    <FormControl>
                                        <Input {...field} type="email" />
                                    </FormControl>
                                    <FormDescription>The email of the user.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? 'Creating...' : 'Create User'}
                        </Button>
                    </form>
                </Form>
            </div>
        </AppLayout>
    );
}
