import AppLayout from '@/layouts/admin-layout';
import { type BreadcrumbItem } from '@/types';
import { Link } from '@inertiajs/react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import { Button } from "@/components/ui/button";

import UsersTable from '@/components/users/table';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Users',
        href: '/admin/users',
    },
];

export default function UsersIndex() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>

            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex justify-between items-center">
                    <p>Users</p>
                    <Link href={`${import.meta.env.VITE_APP_URL}/admin/users/create`}>
                        <Button>Create Admin User</Button>
                    </Link>
                </div>
                <UsersTable />
            </div>
        </AppLayout>
    );
}
