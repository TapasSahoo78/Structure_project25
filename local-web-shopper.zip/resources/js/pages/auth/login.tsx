import { Head, useForm } from '@inertiajs/react';
import { LoaderCircle } from 'lucide-react';
import { FormEventHandler } from 'react';
import { z } from 'zod';

import TextLink from '@/components/text-link';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import RegisterWizardLayout from '@/layouts/auth/register-wizard-layout';
import { InputWithErrorTooltip } from '@/components/input-with-error-tooltip';
import { useError } from '@/contexts/error-context';
import { useAlert } from '@/contexts/alert-context';

const loginSchema = z.object({
    email: z.string().email('Invalid email address'),
    password: z
        .string()
        .min(8, "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol")
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]).*$/,
            "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol"),
    // "Password must include uppercase and lowercase letters, numbers, and symbols"),
    remember: z.boolean(),
});

type LoginForm = z.infer<typeof loginSchema>;
interface LoginProps {
    status?: string;
    canResetPassword: boolean;
}

export default function Login({ status, canResetPassword }: LoginProps) {
    const { data, setData, post, processing } = useForm<LoginForm>({
        email: '',
        password: '',
        remember: false,
    });
    const { setInputError, clearInputError, setGlobalError } = useError();
    const { showAlert } = useAlert();

    const handleInputChange = (field: keyof LoginForm, value: string | boolean) => {
        setData(field, value);
        clearInputError(field);
    };

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        const result = loginSchema.safeParse(data);
        if (result.success) {
            post(route('login'), {
                onSuccess: () => showAlert('success', 'Logged in successfully!'),
                onError: (errors) => {
                    Object.entries(errors).forEach(([key, value]) => {
                        setInputError(key, value as string);
                    });
                    setGlobalError('Login failed. Please check your credentials.');
                },
            });
        } else {
            const fieldErrors = result.error.flatten().fieldErrors;
            Object.entries(fieldErrors).forEach(([key, value]) => {
                setInputError(key, value?.[0] || '');
            });
            setGlobalError('Please correct the errors in the form.');
        }
    };

    return (
        <div className="loginBg">
            <RegisterWizardLayout title="Login">
                <Head title="Login" />

                <form className="flex flex-col gap-6" onSubmit={submit}>
                    <div className=" lgCard">
                        <div className="fromDesc">
                            <h3>Sign in to account</h3>
                            <p>Enter your email & password to login</p>
                        </div>
                        <div className="form-group">
                            <Label htmlFor="email">Email address</Label>
                            <InputWithErrorTooltip
                                className="dashedField"
                                id="email"
                                name="email"
                                type="email"
                                autoFocus
                                tabIndex={1}
                                autoComplete="email"
                                value={data.email}
                                onValueChange={(value) => handleInputChange('email', value)}
                                placeholder="email@example.com"
                            />
                        </div>

                        <div className="form-group">
                            <Label htmlFor="password">Password</Label>
                            <InputWithErrorTooltip
                                id="password"
                                name="password"
                                type="password"
                                tabIndex={2}
                                autoComplete="current-password"
                                value={data.password}
                                onValueChange={(value) => handleInputChange('password', value)}
                                placeholder="Password"
                                className="dashedField"
                            />
                        </div>
                        <div className="remForPanel">
                            <div className="flex items-center space-x-2">
                                <Checkbox
                                    id="remember"
                                    name="remember"
                                    checked={data.remember}
                                    onCheckedChange={(checked) => handleInputChange('remember', checked as boolean)}
                                    tabIndex={3}
                                />
                                <Label htmlFor="remember" className='dark:text-black'>Remember me</Label>
                            </div>
                            <div className="">
                                {canResetPassword && (
                                    <TextLink href={route('password.request')} className="text-sm" tabIndex={5}>
                                        Forgot password?
                                    </TextLink>
                                )}
                            </div>
                        </div>

                        <div className="lgBtnWrap text-center">
                            <Button type="submit" className="lgBtn" tabIndex={4} disabled={processing}>
                                {processing && <LoaderCircle className="animate-spin mr-2" />}
                                Log in
                            </Button>
                        </div>
                    </div>

                    <div className="text-muted-foreground text-center text-sm log-bottomText">
                        Don't have an account?{' '}
                        <TextLink href={route('register')} tabIndex={5}>
                            Sign up
                        </TextLink>
                    </div>
                </form>

                {status && <div className="mb-4 text-center text-sm font-medium text-green-600">{status}</div>}
            </RegisterWizardLayout>
        </div>
    );
}
