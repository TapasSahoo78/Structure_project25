import React from 'react';
import { useForm } from '@inertiajs/react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import InputError from '@/components/input-error';
import { z } from 'zod';
import { InputWithErrorTooltip } from '@/components/input-with-error-tooltip';
import { useError } from '@/contexts/error-context';

export const step1Schema = z.object({
    fname: z.string().min(1, "First name is required"),
    lname: z.string().min(1, "Last name is required"),
    email: z.string().email("Invalid email address"),
    password: z
        .string()
        .min(8, "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol")
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]).*$/,
            "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol"),
    // "Password must include uppercase and lowercase letters, numbers, and symbols"),
    password_confirmation: z.string()
}).refine((data) => data.password === data.password_confirmation, {
    message: "Passwords do not match",
    path: ["password_confirmation"],
});

export type Step1Form = z.infer<typeof step1Schema>;

interface Step1Props {
    onStepSubmit: (data: Step1Form) => void;
    isLastStep: boolean;
    initialData: Partial<Step1Form>;
}

export const Step1: React.FC<Step1Props> = ({ onStepSubmit, isLastStep, initialData }) => {
    const form = useForm<Step1Form>({
        fname: initialData.fname || '',
        lname: initialData.lname || '',
        email: initialData.email || '',
        password: initialData.password || '',
        password_confirmation: initialData.password_confirmation || '',
    });

    const { setInputError, clearInputError, setGlobalError } = useError();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const result = step1Schema.safeParse(form.data);
        if (result.success) {
            onStepSubmit(form.data);
        } else {
            const fieldErrors = result.error.flatten().fieldErrors;
            Object.keys(fieldErrors).forEach((key) => {
                form.setError(key as keyof Step1Form, fieldErrors[key]?.[0] || '');
                setInputError(key as keyof Step1Form, fieldErrors[key]?.[0] || '');
            });
        }
    };

    const handleInputChange = (field: keyof Step1Form, value: string) => {
        form.setData(field, value);
        if (form.errors[field]) {
            form.clearErrors(field);
            clearInputError(field);
        }
    };

    return (
        <form id="step-1-form" onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3 mb-0">
                <div className='form-group'>
                    <Label htmlFor="fname">First Name</Label>
                    <InputWithErrorTooltip
                        id="fname"
                        name="fname"
                        value={form.data.fname}
                        onValueChange={(value) => handleInputChange('fname', value)}
                        error={form.errors.fname}
                        disabled={form.processing}
                        className="dashedField"
                    />
                    {/* {form.errors.fname && (
                        <p className="text-red-500 text-sm mt-1">{form.errors.fname}</p>
                    )} */}
                </div>
                <div className='form-group'>
                    <Label htmlFor="lname">Last Name</Label>
                    <InputWithErrorTooltip
                        id="lname"
                        name="lname"
                        value={form.data.lname}
                        onValueChange={(value) => handleInputChange('lname', value)}
                        error={form.errors.lname}
                        disabled={form.processing}
                        className="dashedField"
                    />
                    {/* {form.errors.lname && (
                        <p className="text-red-500 text-sm mt-1">{form.errors.lname}</p>
                    )} */}
                </div>
            </div>
            <div className='form-group'>
                <Label htmlFor="email">Email</Label>
                <InputWithErrorTooltip
                    id="email"
                    name="email"
                    type="email"
                    value={form.data.email}
                    onValueChange={(value) => handleInputChange('email', value)}
                    error={form.errors.email}
                    disabled={form.processing}
                    className="dashedField"
                />
                {/* {form.errors.email && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.email}</p>
                )} */}
            </div>
            <div className='form-group'>
                <Label htmlFor="password">Password</Label>
                <InputWithErrorTooltip
                    id="password"
                    name="password"
                    type="password"
                    value={form.data.password}
                    onValueChange={(value) => handleInputChange('password', value)}
                    error={form.errors.password}
                    disabled={form.processing}
                    className="dashedField"
                />
                {/* {form.errors.password && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.password}</p>
                )} */}
            </div>
            <div className='form-group mb-0'>
                <Label htmlFor="password_confirmation">Confirm Password</Label>
                <InputWithErrorTooltip
                    id="password_confirmation"
                    name="password_confirmation"
                    type="password"
                    value={form.data.password_confirmation}
                    onValueChange={(value) => handleInputChange('password_confirmation', value)}
                    error={form.errors.password_confirmation}
                    disabled={form.processing}
                    className="dashedField"
                />
                {/* {form.errors.password_confirmation && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.password_confirmation}</p>
                )} */}
            </div>
        </form>
    );
};

export default Step1;
