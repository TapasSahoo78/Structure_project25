import React from 'react';
import { useForm } from '@inertiajs/react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputWithErrorTooltip } from '@/components/input-with-error-tooltip';
import { PhoneInputWithErrorTooltip } from '@/components/phone-input-with-error-tooltip';
import { MapsAddressInput } from '@/components/maps-address-input';
import { z } from 'zod';
import { useError } from '@/contexts/error-context';

export const step2Schema = z.object({
    business_name: z.string().min(1, "Business name is required"),
    phone: z.string().min(1, "Phone number is required"),
    formatted_address: z.string().min(1, "Address is required"),
    street_number: z.string().nullable(),
    street_name: z.string().nullable(),
    city: z.string().nullable(),
    state: z.string().nullable(),
    postal_code: z.string().nullable(),
    country: z.string().nullable(),
    latitude: z.number().nullable(),
    longitude: z.number().nullable(),
});

export type Step2Form = z.infer<typeof step2Schema>;

interface PhoneInputProps {
    value: string;
    onChange: (value: string) => void;
    disabled?: boolean;
}

const PhoneInput: React.FC<PhoneInputProps> = ({ value, onChange, disabled }) => {
    const formatPhoneNumber = (input: string) => {
        const cleaned = input.replace(/\D/g, '');
        const match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})$/);
        if (match) {
            return match[1] + (match[2] ? '-' + match[2] : '') + (match[3] ? '-' + match[3] : '');
        }
        return input;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const input = e.target.value;
        const digits = input.replace(/\D/g, '');

        if (digits.length <= 10) {
            const formatted = formatPhoneNumber(digits);
            onChange(formatted);
        }
    };

    return (
        <Input
            type="tel"
            value={value}
            onChange={handleChange}
            disabled={disabled}
            placeholder="xxx-xxx-xxxx"
            maxLength={12}
        />
    );
};

interface Step2Props {
    onStepSubmit: (data: Step2Form) => void;
    isLastStep: boolean;
    initialData: Partial<Step2Form>;
}

export const Step2: React.FC<Step2Props> = ({ onStepSubmit, isLastStep, initialData }) => {
    const form = useForm<Step2Form>({
        business_name: initialData.business_name || '',
        phone: initialData.phone || '',
        formatted_address: initialData.formatted_address || '',
        street_number: initialData.street_number || null,
        street_name: initialData.street_name || null,
        city: initialData.city || null,
        state: initialData.state || null,
        postal_code: initialData.postal_code || null,
        country: initialData.country || null,
        latitude: initialData.latitude || null,
        longitude: initialData.longitude || null,
    });
    const { setInputError, clearInputError, setGlobalError } = useError();
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const result = step2Schema.safeParse(form.data);
        if (result.success) {
            onStepSubmit(form.data);
        } else {
            const fieldErrors = result.error.flatten().fieldErrors;
            Object.keys(fieldErrors).forEach((key) => {
                form.setError(key as keyof Step2Form, fieldErrors[key]?.[0] || '');
                setInputError(key as keyof Step2Form, fieldErrors[key]?.[0] || '');
            });
        }
    };

    const handleInputChange = (field: keyof Step2Form, value: string | number | null) => {
        form.setData(field, value);
        if (form.errors[field]) {
            form.clearErrors(field);
            clearInputError(field);
        }
    };

    return (
        <form id="step-2-form" onSubmit={handleSubmit} className="space-y-4">
            <div>
                <Label htmlFor="business_name">Business Name</Label>
                <InputWithErrorTooltip
                    id="business_name"
                    name="business_name"
                    value={form.data.business_name}
                    onValueChange={(value) => handleInputChange('business_name', value)}
                    error={form.errors.business_name}
                    disabled={form.processing}
                />
                {/* {form.errors.business_name && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.business_name}</p>
                )} */}
            </div>
            <div>
                <Label htmlFor="phone">Phone</Label>
                <PhoneInputWithErrorTooltip
                    id="phone"
                    name="phone"
                    value={form.data.phone}
                    onValueChange={(value) => handleInputChange('phone', value)}
                    error={form.errors.phone}
                    disabled={form.processing}
                />
                {/* {form.errors.phone && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.phone}</p>
                )} */}
            </div>
            <div>
                <Label htmlFor="address">Address</Label>
                <MapsAddressInput
                    onAddressChange={(addressData) => {
                        const newData = {
                            ...form.data,
                            street_number: addressData.street_number,
                            street_name: addressData.street_name,
                            city: addressData.city,
                            state: addressData.state,
                            postal_code: addressData.postal_code,
                            country: addressData.country,
                            formatted_address: addressData.formatted_address,
                            latitude: addressData.latitude,
                            longitude: addressData.longitude,
                        };
                        form.setData(newData);
                        if (form.errors.formatted_address) {
                            form.clearErrors('formatted_address');
                        }
                    }}
                    disabled={form.processing}
                    placeholder="Enter your address"
                />
                {form.errors.formatted_address && (
                    <p className="text-red-500 text-sm mt-1">{form.errors.formatted_address}</p>
                )}
            </div>
        </form>
    );
};

export default Step2;
