import React, { useState } from 'react';
import { Head, router } from '@inertiajs/react';
import RegisterWizardLayout from '@/layouts/auth/register-wizard-layout';
import { Wizard, WizardStep } from '@/components/wizard';
import { Step1, step1Schema } from '@/pages/auth/register-wizard/step-1';
import { Step2, step2Schema } from '@/pages/auth/register-wizard/step-2';
import { toast } from 'sonner';

const Register: React.FC = () => {
    const [errors, setErrors] = useState<Record<string, string>>({});
    const wizardSteps: WizardStep[] = [
        {
            title: "User Information",
            description: "Enter your personal details",
            component: Step1,
            icon: "User",
            schema: step1Schema,
        },
        {
            title: "Business Information",
            description: "Enter your business details",
            component: Step2,
            icon: "Building",
            schema: step2Schema,
        }
    ];

    const handleComplete = async (allData: Record<number, any>) => {
        console.log('Raw wizard data:', allData);

        const flattenedData = { ...allData[1], ...allData[2] };
        console.log('Flattened data:', flattenedData);

        if (Object.keys(flattenedData).length === 0) {
            console.error('Flattened data is empty!');
            toast.error('No data collected from the form.');
            return;
        }

        router.post(route('register'), flattenedData, {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                console.log('Registration successful');
                toast.success('Registration successful!');
            },
            onError: (errors) => {
                console.error("Error during registration:", errors);
                setErrors(errors);
                Object.keys(errors).forEach(key => {
                    toast.error(`${key}: ${errors[key]}`);
                });
            },
        });
    };

    return (
        <div className="loginBg">
            <RegisterWizardLayout
                title="Register"
                currentStep={1}
                totalSteps={wizardSteps.length}
            >
                <Head title="Register" />
                <Wizard
                    steps={wizardSteps}
                    onComplete={handleComplete}
                    progressMode="steps"
                />
            </RegisterWizardLayout>
        </div>
    );
};

export default Register;
