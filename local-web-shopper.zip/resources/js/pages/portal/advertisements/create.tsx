import { useState, useEffect } from 'react';
import { z } from 'zod';
import { useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem, type SharedData, Subscription, Plan } from '@/types';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Map } from '@/components/map';
import { MapsAddressInput } from '@/components/maps-address-input';
import { FileUpload, FileData } from '@/components/file-upload';
import { Link, usePage } from '@inertiajs/react';
import SubscriptionCards from '@/components/subscriptions/cards';
import axios from 'axios';
import { useAlert } from '@/contexts/alert-context';
import { useError } from '@/contexts/error-context';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import DatePicker from "react-datepicker";

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Ads', href: '/portal/ads' },
    { title: 'Create', href: '/portal/ads/create' },
];

interface AddressData {
    formatted_address: string;
    street_number: string;
    street_name: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    latitude: number;
    longitude: number;
}

interface AdCategory {
    id: number;
    name: string;
}

interface ApiResponse {
    data: AdCategory[];
}

const adSchema = z.object({
    title: z.string().min(1, 'Title is required').max(255, 'Title must be less than 255 characters'),
    description: z.string().min(1, 'Description is required'),
    subscription_id: z.string().optional(),
    start_date: z.string().optional(),
    end_date: z.string().optional(),
    // street_number: z.string().min(1, 'Street number is required').max(255).optional(),
    // street_name: z.string().min(1, 'Street name is required').max(255).optional(),
    // street_number: z.string().optional(),
    // street_name: z.string().optional(),
    // city: z.string().min(1, 'City is required').max(255),
    // state: z.string().min(1, 'State is required').max(255),
    // postal_code: z.string().min(1, 'Postal code is required').max(20),
    // country: z.string().min(1, 'Country is required').max(255),
    longitude: z.number(),
    latitude: z.number(),
    category_id: z.string().min(1, 'Category is required'),
    file_id: z.number().nullable(),
}).refine(
    (data) => {
        if (data.start_date) {
            return !!data.subscription_id;
        }
        return true;
    },
    {
        message: "A subscription must be selected when setting a start date",
        path: ['subscription_id'],
    }
).refine(
    (data) => {
        if (data.end_date) {
            return !!data.start_date && !!data.subscription_id;
        }
        return true;
    },
    {
        message: "Start date and subscription are required when setting an end date",
        path: ['start_date', 'subscription_id'],
    }
).refine(
    (data) => {
        if (data.start_date && data.end_date) {
            const start = new Date(data.start_date);
            const end = new Date(data.end_date);
            const minEndDate = new Date(start.getTime() + 24 * 60 * 60 * 1000);
            return end > minEndDate;
        }
        return true;
    },
    {
        message: "End date must be at least 24 hours after the start date",
        path: ['end_date'],
    }
);

type AdFormData = z.infer<typeof adSchema>;

export default function AdCreate() {
    const [categories, setCategories] = useState<AdCategory[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);
    const page = usePage<SharedData>();
    const { auth } = page.props;
    const { showAlert } = useAlert();
    const { setInputError, clearInputError, setGlobalError, inputErrors } = useError();

    const { data, setData, post, processing } = useForm<AdFormData>({
        title: '',
        description: '',
        subscription_id: '',
        start_date: new Date().toISOString().split('T')[0], // Default to today
        end_date: '',
        street_number: '',
        street_name: '',
        city: '',
        state: '',
        postal_code: '',
        country: '',
        longitude: 0,
        latitude: 0,
        category_id: '',
        file_id: null,
    });

    useEffect(() => {
        fetchAdCategories();
    }, []);

    const fetchAdCategories = async () => {
        try {
            setIsLoading(true);
            const response = await axios.get<ApiResponse>(`${import.meta.env.VITE_APP_URL}/api/v1/ad-categories`);
            setCategories(response.data.data || []);
        } catch (error) {
            console.error('Error fetching ad categories:', error);
            setGlobalError('Failed to load ad categories');
            setCategories([]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleAddressChange = (addressData: AddressData) => {
        setData({
            ...data,
            street_number: addressData.street_number,
            street_name: addressData.street_name,
            city: addressData.city,
            state: addressData.state,
            postal_code: addressData.postal_code,
            country: addressData.country,
            latitude: addressData.latitude,
            longitude: addressData.longitude,
        });
    };

    const handleFileSelect = (file_id: number | null) => {
        setData('file_id', file_id);
    };

    const handleDataChange = (field: keyof AdFormData, value: any) => {
        setData(field, value);
        clearInputError(field);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const result = adSchema.safeParse(data);
        if (!result.success) {
            result.error.issues.forEach((issue) => {
                setInputError(issue.path[0] as string, issue.message);
                console.log(`Setting error for ${issue.path[0]}: ${issue.message}`);
            });
            // setGlobalError('Please fill in all required fields correctly');
            return;
        }

        Object.keys(data).forEach(key => clearInputError(key));

        post(`${import.meta.env.VITE_APP_URL}/portal/ads`, {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => showAlert('success', 'Ad created successfully'),
            onError: (inputErrors) => {
                // console.error(inputErrors);
                Object.entries(inputErrors).forEach(([key, value]) => {
                    setInputError(key, value as string);
                    console.log(`Setting error for ${key}: ${value}`);
                });
                setGlobalError('Failed to create ad');
            },
        });
    };

    const getMapRadius = () => {
        if (!selectedSubscription) return 0;
        return selectedSubscription.plan.radius;
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>

            <div className="container mx-auto">
                <div className="py-4">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-bold dark:text-black">Create New Ad</h1>
                        <div className="flex items-center space-x-4">
                            <Button onClick={handleSubmit}>
                                Create
                            </Button>
                            <Button variant="outline" asChild>
                                <Link href="/portal/ads">Cancel</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container mx-auto">
                <div className="py-4">
                    <form onSubmit={handleSubmit}>
                        <div className="flex gap-3 flex-col md:flex-row md:gap-4 lg:gap-6 xl:gap-8">
                            <div className="sm:w-1/1 md:w-3/10 lg:w-3/10">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <h3 className="text-lg font-semibold mb-2 dark:text-black">Advertisement Details</h3>
                                    <p className="text-sm text-gray-600">
                                        Provide the essential information for your advertisement, including a catchy title,
                                        concise description, an eye-catching image or media file, and the appropriate category.
                                    </p>
                                </div>
                            </div>
                            <div className="sm:w-1/1 md:w-7/10 lg:w-7/10 space-y-4">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <div className='form-group'>
                                        <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
                                        <Input
                                            className="dashedField"
                                            id="title"
                                            value={data.title}
                                            onChange={(e) => handleDataChange('title', e.target.value)}
                                        />
                                        {inputErrors.title && <p className="text-red-500 text-sm mt-1">{inputErrors.title}</p>}
                                    </div>
                                    <div className='form-group'>
                                        <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
                                        <Select onValueChange={(value) => handleDataChange('category_id', value)} value={data.category_id}>
                                            <SelectTrigger className="w-full selectBtn">
                                                <SelectValue placeholder={isLoading ? "Loading categories..." : "Select a category"} />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {isLoading ? (
                                                    <SelectItem value="loading">Loading...</SelectItem>
                                                ) : categories.length > 0 ? (
                                                    categories.map((category) => (
                                                        <SelectItem key={category.id} value={category.id.toString()}>
                                                            {category.name}
                                                        </SelectItem>
                                                    ))
                                                ) : (
                                                    <SelectItem value="none">No categories available</SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        {inputErrors.category_id && <p className="text-red-500 text-sm mt-1">{inputErrors.category_id}</p>}
                                    </div>
                                    <div className='form-group'>
                                        <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                                        <Textarea
                                            className="dashedField dark:bg-white"
                                            id="description"
                                            value={data.description}
                                            onChange={(e) => handleDataChange('description', e.target.value)}
                                        />
                                        {inputErrors.description && <p className="text-red-500 text-sm mt-1">{inputErrors.description}</p>}
                                    </div>
                                    <div className='form-group'>
                                        <label htmlFor="file" className="block text-sm font-medium text-gray-700">Upload File</label>
                                        <FileUpload
                                            id="file"
                                            onFileSelect={handleFileSelect}
                                        />
                                        {inputErrors.file_id && <p className="text-red-500 text-sm mt-1">{inputErrors.file_id}</p>}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr className='my-5' />

                        <div className="flex gap-3 flex-col md:flex-row md:gap-4 lg:gap-6 xl:gap-8">
                            <div className="sm:w-1/1 md:w-3/10 lg:w-3/10">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <h3 className="text-lg font-semibold mb-2 dark:text-black">Schedule</h3>
                                    <p className="text-sm text-gray-600">
                                        Set the start and end dates for your advertisement campaign.
                                        The ad will be displayed within this timeframe.
                                    </p>
                                </div>
                            </div>
                            <div className="sm:w-1/1 md:w-7/10 lg:w-7/10 space-y-4">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <div className="flex flex-col sm:flex-row gap-4">
                                        <div className="w-1/1 sm:w-1/2">
                                            <div className='form-group'>
                                                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">Start Date</label>
                                                {/* <Input
                                                    className="dashedField"
                                                    id="startDate"
                                                    type="date"
                                                    min={new Date().toISOString().split('T')[0]}
                                                    value={data.start_date || new Date().toISOString().split('T')[0]}
                                                    onChange={(e) => handleDataChange('start_date', e.target.value)}
                                                /> */}
                                                <DatePicker
                                                    selected={data.start_date ? new Date(data.start_date) : null}
                                                    onChange={(date) => {
                                                        if (date) {
                                                            // Format as local YYYY-MM-DD (avoids timezone shift)
                                                            const year = date.getFullYear();
                                                            const month = String(date.getMonth() + 1).padStart(2, '0');
                                                            const day = String(date.getDate()).padStart(2, '0');
                                                            setData("start_date", `${year}-${month}-${day}`);
                                                        } else {
                                                            setData("start_date", "");
                                                        }
                                                    }}
                                                    minDate={new Date()}
                                                    placeholderText="Select start date"
                                                    isClearable
                                                    className="border rounded px-2 py-1 w-full"
                                                    dateFormat="yyyy-MM-dd"
                                                />
                                                {inputErrors.start_date && <p className="text-red-500 text-sm mt-1">{inputErrors.start_date}</p>}
                                            </div>
                                        </div>
                                        <div className="w-1/1 sm:w-1/2">
                                            <div className='form-group'>
                                                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">End Date</label>
                                                {/* <Input
                                                    className="dashedField"
                                                    id="endDate"
                                                    type="date"
                                                    min={new Date().toISOString().split('T')[0]}
                                                    value={data.end_date ?? ""}
                                                    onChange={(e) => handleDataChange('end_date', e.target.value)}
                                                /> */}
                                                <DatePicker
                                                    selected={data.end_date ? new Date(data.end_date) : null}
                                                    onChange={(date) => {
                                                        if (date) {
                                                            // Format as local YYYY-MM-DD (avoids timezone shift)
                                                            const year = date.getFullYear();
                                                            const month = String(date.getMonth() + 1).padStart(2, '0');
                                                            const day = String(date.getDate()).padStart(2, '0');
                                                            setData("end_date", `${year}-${month}-${day}`);
                                                        } else {
                                                            setData("end_date", "");
                                                        }
                                                    }}
                                                    minDate={new Date()}
                                                    placeholderText="Select end date"
                                                    isClearable
                                                    className="border rounded px-2 py-1 w-full"
                                                    dateFormat="yyyy-MM-dd"
                                                />
                                                {inputErrors.end_date && <p className="text-red-500 text-sm mt-1">{inputErrors.end_date}</p>}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr className='my-5' />

                        <div className="flex gap-3 flex-col md:flex-row md:gap-4 lg:gap-6 xl:gap-8">
                            <div className="sm:w-1/1 md:w-3/10 lg:w-3/10">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <h3 className="text-lg font-semibold mb-2 dark:text-black">Subscription Plan</h3>
                                    <p className="text-sm text-gray-600">
                                        Choose a subscription plan that fits your advertising needs.
                                        Each plan offers different coverage areas and features.
                                    </p>
                                </div>
                            </div>
                            <div className="sm:w-1/1 md:w-7/10 lg:w-7/10">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <SubscriptionCards
                                        onSubscriptionSelect={(subscription) => {
                                            setSelectedSubscription(subscription);
                                            setData('subscription_id', subscription?.id.toString() || '');
                                        }}
                                        selected={selectedSubscription}
                                    />
                                    {inputErrors.subscription_id && <p className="text-red-500 text-sm mt-1">{inputErrors.subscription_id}</p>}
                                </div>
                            </div>
                        </div>

                        <hr className='my-5' />

                        <div className="flex gap-3 flex-col md:flex-row md:gap-4 lg:gap-6 xl:gap-8">
                            <div className="sm:w-1/1 md:w-3/10 lg:w-3/10">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <h3 className="text-lg font-semibold mb-2 dark:text-black">Location</h3>
                                    <p className="text-sm text-gray-600">
                                        Specify the location for your advertisement. This will determine
                                        where your ad is displayed based on your chosen plan's radius.
                                    </p>
                                </div>
                            </div>
                            <div className="sm:w-1/1 md:w-7/10 lg:w-7/10 space-y-4">
                                <div className="bg-white p-3 md:p-4 lg:p-5 xl:p-6 rounded-lg shadow-[0px_0px_44px_0px_#0000000D]">
                                    <div className='form-group'>
                                        <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                                        <MapsAddressInput
                                            onAddressChange={handleAddressChange}
                                            placeholder="Enter address for ad location"
                                        />
                                        {/* {(inputErrors.street_number || inputErrors.street_name || inputErrors.city || inputErrors.state || inputErrors.postal_code || inputErrors.country) && (
                                            <p className="text-red-500 text-sm mt-1">Please enter a valid address</p>
                                        )} */}
                                    </div>
                                    <div className="">
                                        <Map
                                            latitude={data.latitude}
                                            longitude={data.longitude}
                                            radius={getMapRadius()}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div className="container mx-auto">
                <div className="py-4">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-bold dark:text-black"></h1>
                        <div className="flex items-center space-x-4">
                            <Button onClick={handleSubmit}>
                                Create
                            </Button>
                            <Button variant="outline" asChild>
                                <Link href="/portal/ads">Cancel</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </AppLayout>
    );
}
