import { useEffect, useState } from 'react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, Link } from '@inertiajs/react';
import axios from 'axios';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import AdsTable from '@/components/ads/table';
import AdsCards from '@/components/ads/card-view';
import { Button } from "@/components/ui/button";
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Ads',
        href: '/portal/ads',
    },
];

export interface Ad {
    id: number;
    title: string;
    description: string;
    image_url: string;
    target_url: string;
    status: string;
    created_at: string;
}

export default function AdsIndex() {
    const [ads, setAds] = useState<Ad[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchAds();
    }, []);

    const fetchAds = async () => {
        try {
            const response = await axios.get(`${import.meta.env.VITE_APP_URL}/api/v1/ads`);
            if (Array.isArray(response.data)) {
                setAds(response.data);
            } else if (typeof response.data === 'object' && response.data.data) {
                if (Array.isArray(response.data.data)) {
                    setAds(response.data.data);
                } else {
                    throw new Error('Invalid data format: Expected an array under the "data" key');
                }
            } else {
                throw new Error(`Invalid data format: ${JSON.stringify(response.data)}`);
            }
            setLoading(false);
        } catch (error) {
            console.error('Error fetching ads:', error);
            if (axios.isAxiosError(error)) {
                setError(`Unable to fetch ads. ${error.response?.status}: ${error.response?.statusText}`);
            } else if (error instanceof Error) {
                setError(`Unable to fetch ads. ${error.message}`);
            } else {
                setError('An unexpected error occurred while fetching ads.');
            }
            setLoading(false);
        }
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Ads" />
            <div className="py-4">
                <div className="container mx-auto">
                    <div className="flex flex-col gap-2">
                        <div className="flex justify-between items-center mb-4">
                            <h1 className="text-2xl font-bold dark:text-black">Your Ads</h1>
                            <Link href={`${import.meta.env.VITE_APP_URL}/portal/ads/create`}>
                                <Button>Create Ad</Button>
                            </Link>
                        </div>
                        <Accordion type="single" collapsible className="w-full">
                            <AccordionItem value="item-1" className='bg-white rounded-md border-dashed border-[#efefef] border-[1px] mb-3'>
                                <AccordionTrigger className='px-3 dark:text-black'>What are Ads?</AccordionTrigger>
                                <AccordionContent className='p-3 border-dashed border-t-[#efefef] border-t-[1px] dark:text-black'>
                                    Ads consist of several key components: title, description, plan, and location.
                                    The title grabs attention, while the description provides more details about your offer.
                                    The plan you choose determines the radius around the specified location where your ad will be visible.
                                    Use this section to create, edit, and manage these elements to effectively reach your target audience.
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    </div>
                    {loading ? (
                        <div className="border-sidebar-border/70 dark:border-sidebar-border relative h-64 overflow-hidden rounded-xl border">
                            <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" />
                        </div>
                    ) : error ? (
                        <Alert variant="destructive">
                            <AlertTitle>Error</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    ) : ads.length === 0 ? (
                        <Alert>
                            <AlertTitle>No Ads</AlertTitle>
                            <AlertDescription>You don't have any ads.</AlertDescription>
                        </Alert>
                    ) : (
                        <AdsCards />
                        // <AdsTable />
                    )}
                </div>
            </div>
        </AppLayout>
    );
}
