import React, { useState, useEffect } from 'react';
import { usePage, Link } from '@inertiajs/react';
import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem, type SharedData, type Ad } from '@/types';
import { AdStatus } from '@/enums/ad-status';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MapPin, Calendar, Radius, CreditCard, Maximize2, Eye, Pencil, Trash2, ArrowLeft } from "lucide-react";
import { Map } from '@/components/map';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useAlert } from '@/contexts/alert-context';
import axios from 'axios';
import { formatDate } from '@/lib/utils';
import { useForm } from '@inertiajs/react';

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Ads', href: '/portal/ads' },
    { title: 'View Ad', href: '/portal/ads/show' },
];

interface Ad {
    id: number;
    title: string;
    description: string;
    status: string;
    start_date: string;
    end_date: string;
    view_count: number;
    category?: { name: string };
    address: {
        lat: number;
        long: number;
        formatted_address: string;
    };
    plan: {
        id: number;
        size: string;
        radius: number;
    };
    subscription?: { name: string };
    file?: { path: string };
}

interface SharedData {
    ad?: { data: Ad };
}

export default function ShowAdvertisement() {
    const { props } = usePage<SharedData>();
    const id = props.id;
    const initialAdWrapper = props.ad;
    const [ad, setAd] = useState<Ad | null>(initialAdWrapper?.data || null);
    const [loading, setLoading] = useState(!initialAdWrapper);
    const [error, setError] = useState<string | null>(null);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const { showAlert } = useAlert();
    const [publishDialogOpen, setPublishDialogOpen] = useState(false);
    const [endDialogOpen, setEndDialogOpen] = useState(false);
    const { post, processing } = useForm();

    const handleBack = () => {
        window.history.back();
    };

    useEffect(() => {
        if (!initialAdWrapper) {
            fetchAd();
        }
    }, [id, initialAdWrapper]);

    const fetchAd = async () => {
        try {
            setLoading(true);
            const response = await axios.get(`${import.meta.env.VITE_APP_URL}/api/v1/ads/${ad?.id}`);
            setAd(response.data.data);
        } catch (err) {
            setError(err?.response?.data?.message || 'Failed to fetch advertisement');
            showAlert('error', 'Error fetching advertisement');
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async () => {
        try {
            await axios.delete(`${import.meta.env.VITE_APP_URL}/api/v1/ads/${ad?.id}`);
            showAlert('success', 'Advertisement deleted successfully');
            window.location.href = '/portal/ads';
        } catch (error) {
            console.error('Error deleting ad:', error);
            showAlert('error', 'Failed to delete advertisement');
        }
        setDeleteDialogOpen(false);
    };

    const handlePublish = async () => {
        try {
            await axios.post(`${import.meta.env.VITE_APP_URL}/portal/ads/${ad?.id}/publish`);
            setPublishDialogOpen(false);
            showAlert('success', 'Advertisement published successfully', 'success');
            fetchAd(); // Refetch the ad data
        } catch (error) {
            setPublishDialogOpen(false);
            console.error('Error deleting ad:', error);
            showAlert('error', error?.response?.data?.message || 'Failed to publish advertisement');
        }
    };

    // const handlePublish = () => {
    //     post(route('portal.ads.publish', ad?.id), {
    //         preserveState: true,
    //         preserveScroll: true,
    //         onSuccess: (page) => {
    //             alert("aaaaaaaaaaaaaaaaaaaaaaa")

    //             setPublishDialogOpen(false);
    //             showAlert('success', 'Advertisement published successfully', 'success');
    //             fetchAd(); // Refetch the ad data
    //         },
    //         onError: (errors) => {
    //             alert("bbbbbbbbbbbbbbbbbbbbb");
    //             showAlert('error', errors.message || 'Failed to publish advertisement');
    //         },
    //     });
    // };

    const handleEnd = () => {
        post(route('portal.ads.end', ad?.id), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setEndDialogOpen(false);
                showAlert('success', 'Advertisement ended successfully');
                fetchAd(); // Refetch the ad data
            },
            onError: (errors) => {
                showAlert('error', errors.message || 'Failed to end advertisement');
            },
        });
    };


    if (loading) {
        return <AppLayout breadcrumbs={breadcrumbs}>Loading...</AppLayout>;
    }

    if (error) {
        return (
            <AppLayout breadcrumbs={breadcrumbs}>
                <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            </AppLayout>
        );
    }

    if (!ad) {
        return <AppLayout breadcrumbs={breadcrumbs}>Advertisement not found.</AppLayout>;
    }

    const planSize = ad.plan?.size || 'None';
    const planRadius = ad.plan?.radius ? `${ad.plan.radius} mi` : 'None';
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <div className="py-4">
                <div className="container mx-auto">
                    <div className="">
                        <div className="flex flex-col md:flex-row gap-3 justify-between items-start md:items-center mb-4 md:mb-6">
                            <h1 className="text-3xl font-bold dark:text-black">{ad.title}</h1>
                            <div className="flex flex-wrap gap-2">
                                <Button variant="outline" onClick={handleBack}>
                                    <ArrowLeft className="h-4 w-4 mr-1" />
                                    Back
                                </Button>
                                {ad.status === AdStatus.LIVE ? (
                                    <Button
                                        variant="outline"
                                        onClick={() => setEndDialogOpen(true)}
                                    >
                                        <Eye className="h-4 w-4 mr-2" />
                                        End
                                    </Button>
                                ) : (
                                    <Button
                                        variant="outline"
                                        onClick={() => setPublishDialogOpen(true)}
                                        disabled={ad.status === AdStatus.LIVE}
                                    >
                                        <Eye className="h-4 w-4 mr-2" />
                                        Publish
                                    </Button>
                                )}
                                <Button variant="outline" asChild>
                                    <Link href={`/portal/ads/${ad.id}/edit`}>
                                        <Pencil className="h-4 w-4 mr-2" />
                                        Edit
                                    </Link>
                                </Button>
                                <Button variant="destructive" onClick={() => setDeleteDialogOpen(true)}>
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                </Button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-10 gap-4 md:gap-6 lg:gap-8">
                            <div className="col-span-10 md:col-span-6 lg:col-span-7 space-y-8">
                                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                                    <div className="px-4 py-5 sm:p-6">
                                        {ad.file?.path ? (
                                            <img
                                                src={ad.file.path}
                                                alt={ad.title}
                                                className="w-full h-auto object-cover"
                                            />
                                        ) : (
                                            <div className="w-full h-64 bg-gray-200 flex items-center justify-center">
                                                <span className="text-gray-400 text-sm">No image</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
                                        <div className='dark:text-black' dangerouslySetInnerHTML={{ __html: ad.description }} />
                                    </div>
                                </div>
                                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                                    <div className="px-4 py-5 sm:px-6">
                                        <h3 className="text-lg leading-6 font-medium text-gray-900">Location</h3>
                                    </div>
                                    <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
                                        <p className="text-sm text-gray-500 mb-2">
                                            <MapPin className="inline-block h-4 w-4 mr-1" />
                                            {ad.address?.formatted_address || 'None'}
                                        </p>
                                        {ad.address?.formatted_address && (
                                            <p className="text-sm text-gray-500 my-3">
                                                <Radius className="inline-block h-4 w-4 mr-1" />
                                                {ad.plan?.radius > 0 ? (
                                                    `This advertisement is visible within a ${planRadius} radius of the location.`
                                                ) : (
                                                    "Set a plan to see the visibility radius for this advertisement."
                                                )}
                                            </p>
                                        )}
                                        <div className="h-100 mb-4">
                                            {ad.address?.lat && ad.address?.long ? (
                                                <Map
                                                    latitude={ad.address?.lat || 0}
                                                    longitude={ad.address?.long || 0}
                                                    radius={ad.plan?.radius || 0}
                                                />
                                            ) : (
                                                <div className="w-full h-64 bg-gray-200 flex items-center justify-center">
                                                    <span className="text-gray-400 text-sm">Map not available</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-span-10 md:col-span-4 lg:col-span-3">
                                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                                    <div className="px-3 py-5 sm:px-3">
                                        <h3 className="text-lg leading-6 font-medium text-gray-900">Details</h3>
                                    </div>
                                    <div className="border-t border-gray-200 px-2 py-2 sm:p-0">
                                        <dl className="sm:divide-y sm:divide-gray-200">
                                            <DetailItem label="Status">
                                                <Badge variant={ad.status === AdStatus.ACTIVE ? "success" : "secondary"}>
                                                    {ad.status}
                                                </Badge>
                                            </DetailItem>
                                            <DetailItem label="Category">
                                                {ad.category?.name || 'None'}
                                            </DetailItem>
                                            <DetailItem label="Date Range">
                                                <div>
                                                    {(ad.start_date || ad.end_date) ? (
                                                        <Badge variant="outline" className="flex items-center dark:text-black">
                                                            <Calendar className="h-4 w-4 mr-1" />
                                                            {ad.start_date && formatDate(ad.start_date)}
                                                            {ad.start_date && ad.end_date && " - "}
                                                            {ad.end_date && formatDate(ad.end_date)}
                                                        </Badge>
                                                    ) : (
                                                        <p>None</p>
                                                    )}
                                                </div>
                                            </DetailItem>
                                            <DetailItem label="Plan">
                                                <Badge variant="outline" className="flex flex-wrap items-center dark:text-black">
                                                    <CreditCard className="h-4 w-4 mr-1" />
                                                    {ad.subscription?.name || 'None'}
                                                    <Radius className="h-4 w-4 ml-2 mr-1" />
                                                    {planRadius}
                                                    <Maximize2 className="h-4 w-4 ml-2 mr-1" />
                                                    {planSize}
                                                </Badge>
                                            </DetailItem>
                                            <DetailItem label="View Count">
                                                <Badge variant="outline" className="flex items-center dark:text-black">
                                                    <Eye className="h-4 w-4 mr-1" />
                                                    {ad.view_count ?? 0}
                                                </Badge>
                                            </DetailItem>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to delete this advertisement? This action cannot be undone.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
                        <Button variant="destructive" onClick={handleDelete}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <Dialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Publication</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to publish this advertisement? This will make it live and visible to users.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setPublishDialogOpen(false)}>Cancel</Button>
                        <Button onClick={handlePublish}>Publish</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>


            <Dialog open={endDialogOpen} onOpenChange={setEndDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Ending Advertisement</DialogTitle>
                    </DialogHeader>
                    <DialogDescription>
                        Are you sure you want to end this advertisement? This will make it no longer visible to users.
                    </DialogDescription>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setEndDialogOpen(false)}>Cancel</Button>
                        <Button onClick={handleEnd}>End</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </AppLayout>
    );
}

function DetailItem({ label, children }) {
    return (
        <div className="py-3 sm:py-3 sm:grid sm:grid-cols-3 sm:gap-2 sm:px-3">
            <dt className="text-sm font-medium text-gray-500">{label}</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{children}</dd>
        </div>
    );
}
