import React, { useState, useEffect } from 'react';
import { Head, usePage } from '@inertiajs/react';
import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StripeProvider } from '@/providers/stripe-provider';
import InvoiceTable from '@/components/invoices/table';
import PaymentMethod from '@/components/businesses/payment-method';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Billing',
        href: '/portal/billing',
    },
];

export default function BillingIndex() {
    const { auth } = usePage().props;
    const [isOpenModal, setIsOpenModal] = useState(false);

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Billing" />
            <div className="py-4">
                <div className="container mx-auto">
                    <div className="flex flex-col lg:flex-row items-center gap-5 my-8">
                        <h1 className="text-2xl font-bold text-gray-800">Billing</h1>
                        {!auth?.user?.business?.pm_last_four &&
                            <button className="btn px-6 py-3 bg-sky-600 text-white font-medium rounded-lg shadow-sm hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 disabled:opacity-50" /*disabled={!auth.user.business.pm_last_four}*/ style={{
                                marginLeft: "250px"
                            }} onClick={() => setIsOpenModal(true)}>
                                <strong>Step 1:</strong> Add / Confirm Credit Card To Start
                            </button>
                        }
                    </div>

                    <div className="flex flex-col lg:flex-row gap-4">
                        <div className="w-full lg:w-[60%] xl:w-[70%]">
                            <div className="p-4 bg-white rounded-lg">
                                <h1 className="font-bold mb-3 dark:text-black">Invoices</h1>
                                <InvoiceTable />
                            </div>
                        </div>

                        <div className="w-full lg:w-[40%] xl:w-[30%]">
                            <div className="p-4 bg-white rounded-lg">
                                <h1 className="font-bold mb-3 dark:text-black">Payment Method</h1>
                                <StripeProvider>
                                    {/* <PaymentMethod
                                        openStatus={isOpenModal}
                                        setOpenStatus={setIsOpenModal}
                                        displayMode="card"
                                        businessId={auth.user.business_id}
                                    /> */}
                                    <PaymentMethod
                                        isOpen={isOpenModal}
                                        onOpenChange={setIsOpenModal}
                                        displayMode="card"
                                        businessId={auth.user.business_id}
                                    />
                                </StripeProvider>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AppLayout>
    );
}
