import { type BreadcrumbItem, type SharedData } from '@/types';
import { Transition } from '@headlessui/react';
import { Head, Link, useForm, usePage } from '@inertiajs/react';
import { FormEventHandler } from 'react';
import { useState, useEffect } from 'react';
import DeleteUser from '@/components/delete-user';
import HeadingSmall from '@/components/heading-small';
import InputError from '@/components/input-error';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import AppLayout from '@/layouts/portal-layout';
import SettingsLayout from '@/layouts/portal/settings-layout';
import axios from 'axios';
import { MapsAddressInput } from '@/components/maps-address-input';
import { PhoneInputWithErrorTooltip } from '@/components/phone-input-with-error-tooltip';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Profile settings',
        href: '/portal/settings/profile',
    },
];

type ProfileForm = {
    name: string;
    email: string;
}

export default function Business({ mustVerifyEmail, status }: { mustVerifyEmail: boolean; status?: string }) {
    const { auth } = usePage<SharedData>().props;
    const [business, setBusiness] = useState(null);

    const { data, setData, patch, errors, processing, recentlySuccessful } = useForm<Required<BusinessForm>>({
        name: '',
        phone: '',
        formatted_address: '',
        street_number: '',
        street_name: '',
        city: '',
        state: '',
        postal_code: '',
        country: '',
        latitude: null,
        longitude: null,
    });

    useEffect(() => {
        const fetchBusiness = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_APP_URL}/api/v1/businesses/${auth.user.business_id}`)
                const businessData = response.data.data;
                setBusiness(businessData);
                setData(prevData => ({
                    ...prevData,
                    name: businessData.name || '',
                    phone: businessData.phone || '',
                    formatted_address: businessData.address?.formatted_address || '',
                    street_number: businessData.address?.street_number || '',
                    street_name: businessData.address?.street_name || '',
                    city: businessData.address?.city || '',
                    state: businessData.address?.state || '',
                    postal_code: businessData.address?.postal_code || '',
                    country: businessData.address?.country || '',
                    latitude: businessData.address?.latitude || null,
                    longitude: businessData.address?.longitude || null,
                }));
            } catch (error) {
                console.error('Error fetching business data:', error);
            }
        };

        fetchBusiness();
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        patch(route('portal.business.update'), {
            preserveScroll: true,
        });
    };

    const handleAddressChange = (addressData: AddressData) => {
        setData(prevData => ({
            ...prevData,
            ...addressData,
        }));
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Business Profile" />

            <SettingsLayout>
                <div className="space-y-6">
                    <HeadingSmall title="Business information" description="Update your business details" />

                    <form onSubmit={submit} className="space-y-6">
                        <div className="grid gap-2">
                            <Label htmlFor="name">Business Name</Label>
                            <Input
                                id="name"
                                value={data.name}
                                onChange={(e) => setData('name', e.target.value)}
                                required
                                placeholder="Business name"
                                className='dashedField'
                            />
                            <InputError className="mt-2" message={errors.name} />
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="phone">Phone</Label>
                            <PhoneInputWithErrorTooltip
                                value={data.phone}
                                onValueChange={(value) => setData('phone', value)}
                                error={errors.phone}
                                disabled={processing}
                            />
                        </div>
                        <div className="grid gap-2">
                            <Label htmlFor="address">Address</Label>
                            <MapsAddressInput
                                onAddressChange={handleAddressChange}
                                disabled={processing}
                                placeholder="Enter your business address"
                                initialAddress={{
                                    formatted_address: data.formatted_address,
                                    street_number: data.street_number,
                                    street_name: data.street_name,
                                    city: data.city,
                                    state: data.state,
                                    postal_code: data.postal_code,
                                    country: data.country,
                                    latitude: data.latitude,
                                    longitude: data.longitude,
                                }}
                            />
                            <InputError className="mt-2" message={errors.formatted_address} />
                        </div>

                        <div className="flex items-center gap-4">
                            <Button disabled={processing} className='dark:bg-black dark:text-white'>Save</Button>
                            <Transition
                                show={recentlySuccessful}
                                enter="transition ease-in-out"
                                enterFrom="opacity-0"
                                leave="transition ease-in-out"
                                leaveTo="opacity-0"
                            >
                                <p className="text-sm text-neutral-600">Saved</p>
                            </Transition>
                        </div>
                    </form>
                </div>
            </SettingsLayout>
        </AppLayout>
    );
}
