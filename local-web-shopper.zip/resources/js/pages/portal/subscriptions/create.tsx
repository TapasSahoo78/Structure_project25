import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem } from '@/types';
import { Head } from '@inertiajs/react';
import axios from 'axios';
import CreateSubscription from '@/components/subscriptions/create';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'New Subscription',
        href: '/portal/subscriptions/create',
    },
];

export default function SubscriptionsIndex() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="New Subscription" />
            <div className="container mx-auto">
                <h1 className="text-2xl font-bold my-4 dark:text-black">New Subscription</h1>
                <CreateSubscription />
            </div>
        </AppLayout>
    );
}
