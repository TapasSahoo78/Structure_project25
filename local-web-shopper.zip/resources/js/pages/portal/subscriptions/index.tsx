import { useEffect, useState } from 'react';
import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import AppLayout from '@/layouts/portal-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, Link } from '@inertiajs/react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import SubscriptionsTable from '@/components/subscriptions/table';
import { Button } from "@/components/ui/button";

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Subscriptions',
        href: '/portal/subscriptions',
    },
];

export interface Subscription {
    id: number;
    plan_name: string;
    status: string;
    start_date: string;
    end_date: string;
}

export default function SubscriptionsIndex() {
    const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchSubscriptions();
    }, []);

    const fetchSubscriptions = async () => {
        try {
            const response = await axios.get(`${import.meta.env.VITE_APP_URL}/api/v1/subscriptions`);
            if (Array.isArray(response.data)) {
                setSubscriptions(response.data);
            } else if (typeof response.data === 'object' && response.data.data) {
                if (Array.isArray(response.data.data)) {
                    setSubscriptions(response.data.data);
                } else {
                    throw new Error('Invalid data format: Expected an array under the "data" key');
                }
            } else {
                throw new Error(`Invalid data format: ${JSON.stringify(response.data)}`);
            }
            setLoading(false);
        } catch (error) {
            console.error('Error fetching subscriptions:', error);
            if (axios.isAxiosError(error)) {
                setError(`Unable to fetch subscriptions. ${error.response?.status}: ${error.response?.statusText}`);
            } else if (error instanceof Error) {
                setError(`Unable to fetch subscriptions. ${error.message}`);
            } else {
                setError('An unexpected error occurred while fetching subscriptions.');
            }
            setLoading(false);
        }
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Subscriptions" />
            <div className="py-4">
                <div className="container mx-auto">
                    <div className="flex flex-col gap-4 sm:flex-row justify-between sm:items-center mb-4">
                        <h1 className="text-2xl font-bold dark:text-black">Your Subscriptions</h1>
                        <Link href={`${import.meta.env.VITE_APP_URL}/portal/subscriptions/create`}>
                            <Button className='bg-[#48A3D7] rounded-none dark:text-black'>Create Subscription</Button>
                        </Link>
                    </div>
                    {loading ? (
                        <div className="dark:border-sidebar-border relative h-64 overflow-hidden rounded-xl">
                            <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" />
                        </div>
                    ) : error ? (
                        <Alert variant="destructive">
                            <AlertTitle>Error</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    ) : subscriptions.length === 0 ? (
                        <Alert className='shadow-[0px_0px_44px_0px_#0000000D] border-[0]'>
                            <AlertTitle>No Subscriptions</AlertTitle>
                            <AlertDescription>You don't have any subscriptions.</AlertDescription>
                        </Alert>
                    ) : (
                        <SubscriptionsTable />
                    )}
                </div>

                {subscriptions.length !== 0 &&
                    <Link key={"Subscription"} href={`${import.meta.env.VITE_APP_URL}/portal/ads`} style={{
                        position: 'fixed',
                        bottom: '45px',
                        right: '20px',
                        zIndex: 1000,
                        backgroundColor: '#1878f3',
                        color: 'white',
                        borderRadius: '5%',
                        width: '185px',
                        height: '45px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
                        textDecoration: 'none',
                        fontSize: '18px'
                    }}>
                        Next: Create an Ad ➤
                    </Link>}

            </div>
        </AppLayout>
    );
}
