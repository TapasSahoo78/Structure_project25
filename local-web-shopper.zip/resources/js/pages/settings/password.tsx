import { Eye, EyeOff } from 'lucide-react';
import { FormEventHandler, useState, useRef } from 'react';
import InputError from '@/components/input-error';
import AppLayout from '@/layouts/portal-layout';
import SettingsLayout from '@/layouts/portal/settings-layout';
import { type BreadcrumbItem } from '@/types';
import { Transition } from '@headlessui/react';
import { Head, useForm } from '@inertiajs/react';
import HeadingSmall from '@/components/heading-small';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Password settings',
        href: '/settings/password',
    },
];

export default function Password() {
    const passwordInput = useRef<HTMLInputElement>(null);
    const currentPasswordInput = useRef<HTMLInputElement>(null);

    const { data, setData, errors, put, reset, processing, recentlySuccessful } = useForm({
        current_password: '',
        password: '',
        password_confirmation: '',
    });

    const updatePassword: FormEventHandler = (e) => {
        e.preventDefault();

        put(route('portal.password.update'), {
            preserveScroll: true,
            onSuccess: () => reset(),
            onError: (errors) => {
                if (errors.password) {
                    reset('password', 'password_confirmation');
                    passwordInput.current?.focus();
                }

                if (errors.current_password) {
                    reset('current_password');
                    currentPasswordInput.current?.focus();
                }
            },
        });
    };

    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    // toggle handlers
    const toggleCurrentPassword = () => setShowCurrentPassword((v) => !v);
    const toggleNewPassword = () => setShowNewPassword((v) => !v);
    const toggleConfirmPassword = () => setShowConfirmPassword((v) => !v);

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Profile settings" />

            <SettingsLayout>
                <div className="space-y-6">
                    <HeadingSmall title="Update password" description="Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number and one special symbol" />
                    {/* <HeadingSmall title="Update password" description="Ensure your account is using a long, random password to stay secure" /> */}

                    <form onSubmit={updatePassword} className="space-y-6">
                        {/* Current password */}
                        <div className="grid gap-2 relative">
                            <Label htmlFor="current_password">Current password</Label>

                            <Input
                                id="current_password"
                                ref={currentPasswordInput}
                                value={data.current_password}
                                onChange={(e) => setData('current_password', e.target.value)}
                                type={showCurrentPassword ? "text" : "password"}
                                className="dashedField pr-10" // add padding right for button
                                autoComplete="current-password"
                                placeholder="Current password"
                            />

                            <button
                                type="button"
                                onClick={toggleCurrentPassword}
                                className="absolute right-2 top-1/2 transform text-gray-500 hover:text-gray-700"
                                tabIndex={-1}
                                aria-label={showCurrentPassword ? "Hide current password" : "Show current password"}
                            >
                                {showCurrentPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>

                            <InputError message={errors.current_password} />
                        </div>

                        {/* New password */}
                        <div className="grid gap-2 relative">
                            <Label htmlFor="password">New password</Label>

                            <Input
                                id="password"
                                ref={passwordInput}
                                value={data.password}
                                onChange={(e) => setData('password', e.target.value)}
                                type={showNewPassword ? "text" : "password"}
                                className="dashedField pr-10"
                                autoComplete="new-password"
                                placeholder="New password"
                            />

                            <button
                                type="button"
                                onClick={toggleNewPassword}
                                className="absolute right-2 top-1/2 transform text-gray-500 hover:text-gray-700"
                                tabIndex={-1}
                                aria-label={showNewPassword ? "Hide new password" : "Show new password"}
                            >
                                {showNewPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>

                            <InputError message={errors.password} />
                        </div>

                        {/* Confirm password */}
                        <div className="grid gap-2 relative">
                            <Label htmlFor="password_confirmation">Confirm password</Label>

                            <Input
                                id="password_confirmation"
                                value={data.password_confirmation}
                                onChange={(e) => setData('password_confirmation', e.target.value)}
                                type={showConfirmPassword ? "text" : "password"}
                                className="dashedField pr-10"
                                autoComplete="new-password"
                                placeholder="Confirm password"
                            />

                            <button
                                type="button"
                                onClick={toggleConfirmPassword}
                                className="absolute right-2 top-1/2 transform text-gray-500 hover:text-gray-700"
                                tabIndex={-1}
                                aria-label={showConfirmPassword ? "Hide confirm password" : "Show confirm password"}
                            >
                                {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>

                            <InputError message={errors.password_confirmation} />
                        </div>

                        <div className="flex items-center gap-4">
                            <Button disabled={processing} className='dark:bg-black dark:text-white'>Save password</Button>

                            <Transition
                                show={recentlySuccessful}
                                enter="transition ease-in-out"
                                enterFrom="opacity-0"
                                leave="transition ease-in-out"
                                leaveTo="opacity-0"
                            >
                                <p className="text-sm text-neutral-600">Saved</p>
                            </Transition>
                        </div>
                    </form>
                </div>
            </SettingsLayout>
        </AppLayout>
    );
}
