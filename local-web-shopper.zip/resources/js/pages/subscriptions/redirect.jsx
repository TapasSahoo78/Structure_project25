import { useEffect } from 'react';

export default function Redirect() {
    useEffect(() => {
        // Force a hard redirect so Stripe's OTP modal closes
        window.location.href = '/portal/subscriptions';
    }, []);

    return (
        <div className="flex items-center justify-center min-h-screen text-lg">
            Finishing payment, please wait...
        </div>
    );
}
