import React, { useEffect, useState } from 'react';
import { Head, Link, usePage } from '@inertiajs/react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CreditCard, UserPlus, PenTool, Megaphone, ShoppingBag, MapPin, Smartphone } from 'lucide-react';
import { Plus } from 'lucide-react';
import { Footer } from '@/components/footer/footer';

export default function Welcome() {
    const { auth } = usePage().props;
    const [siteTheme, setSiteTheme] = useState('light');

    return (
        <>
            <Head title="Welcome">
                <link rel="preconnect" href="https://fonts.bunny.net" />
                <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
            </Head>
            {/* <div className="sads min-h-screen bg-[#EAF4FF] text-[#1b1b18] lg:justify-center dark:bg-[#0a0a0a]"> */}
            <div className="sads min-h-screen bg-[#EAF4FF] text-[#1b1b18] lg:justify-center">
                <header className="mb-6 w-full  text-sm not-has-[nav]:hidden py-4">
                    <div className="container mx-auto">
                        <div className="flex items-center justify-between">
                            <img src={`${import.meta.env.VITE_APP_URL}/images/logo/logo.png`} alt="Local Web Shopper Logo" className="h-12 w-auto" />
                            <nav className="flex items-center justify-end gap-2 md:gap-4">
                                {auth.user ? (
                                    <Link
                                        href={auth.user.is_admin ? route('admin.ads.index') : route('portal.ads.index')}
                                        className="inline-block rounded-sm border border-[#19140035] px-5 py-1.5 text-sm leading-normal text-[#1b1b18] dark:text-black hover:border-[#1915014a] dark:border-[#3E3E3A] dark:text-[#EDEDEC] dark:hover:border-[#62605b]"
                                    >
                                        {auth.user.is_admin ? 'Admin Portal' : 'Portal'}
                                    </Link>
                                ) : (
                                    <>
                                        <Link
                                            href={route('login')}
                                            className="inline-block rounded-sm border border-transparent px-3 md:px-5 py-1.5 text-sm leading-normal border-[#1b1b18] text-[#1b1b18] hover:border-[#19140035] dark:text-black dark:hover:border-[#3E3E3A]"
                                        >
                                            Log in
                                        </Link>
                                        <Link
                                            href={route('register')}
                                            className="inline-block rounded-sm border border-[#1b1b18] px-5 py-1.5 text-sm leading-normal text-[#1b1b18] hover:border-[#1915014a] dark:border-[#161613] dark:text-black dark:hover:border-[#62605b]"
                                        >
                                            Register
                                        </Link>
                                    </>
                                )}
                            </nav>
                        </div>
                    </div>
                </header>
                <main className="">
                    <section className="container mx-auto">
                        <section className="text-card-foreground flex flex-col gap-6 rounded-xl border py-15 px-4 sm:px-6 md:px-10 shadow-sm mb-8 homeBg">
                            {/* <CardHeader>
                                <CardTitle></CardTitle>
                            </CardHeader> */}
                            <CardContent className='px-0'>
                                <div className="flex flex-col gap-10 lg:gap-20 lg:flex-row items-center">
                                    <div className="w-1/1 sm:w-1/1 md:w-1/1 lg:w-1/2">
                                        <div className="flex items-center justify-between flex-col sm:flex-row gap-4 mb-5">
                                            <img src={`${import.meta.env.VITE_APP_URL}/images/logo/logo_globe.png`} alt="Local Web Shopper Logo" className=" w-auto" />
                                            <span className='bg-destructive rounded-3xl p-2 px-6 inline-block text-white font-medium'>Promote Your Business!</span>
                                        </div>
                                        <h3 className='text-3xl md:text-4xl lg:text-4xl xl:text-5xl font-bold text-white mb-3'>Local Web Shopper</h3>
                                        <p className="mb-4 text-primary text-base">
                                            Local Web Shopper by South Magnolia is your local advertising and marketing Mobile solution for customers on the go! Call us today to help expand and reach more customers in your geographic market!
                                        </p>
                                        <Button asChild className='bg-destructive rounded-md p-3 px-6 inline-block text-white font-medium h-auto inline-flex items-center transition duration-300 ease-in-out dark:hover:text-black'>
                                            <Link href={route('register')}><Plus /> Become an Advertiser!</Link>
                                        </Button>
                                    </div>
                                    <div className="w-1/1 sm:w-1/1 md:w-1/1 lg:w-1/2 ">
                                        <div className="max-w-[100%] lg:max-w-[500px] bg-white p-2 rounded-xl -rotate-[5.42deg] shadow-lg">
                                            <img src={`${import.meta.env.VITE_APP_URL}/images/home-img.jpg`} alt="Local Web Shopper" className="rounded-lg shadow-md w-full" />
                                        </div>
                                        {/* <img
                                            src="https://placehold.co/1200x800"
                                            alt="Local Web Shopper"
                                            className="rounded-lg shadow-md w-full"
                                        /> */}
                                    </div>

                                </div>
                            </CardContent>
                        </section>

                        <section className="mb-8">
                            <h2 className="text-2xl font-bold mb-4 dark:text-black">How It Works</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <Card className=' dark:text-black dark:bg-white'>
                                    <CardContent className="flex flex-col items-center text-center">
                                        <UserPlus className="w-12 h-12 mb-4 text-blue-500" />
                                        <h3 className="font-bold mb-2">Signup</h3>
                                        <p>Register your business with Local Web Shopper. It's quick, easy, and opens up a world of local advertising opportunities.</p>
                                    </CardContent>
                                </Card>
                                <Card className=' dark:text-black dark:bg-white'>
                                    <CardContent className="flex flex-col items-center text-center">
                                        <CreditCard className="w-12 h-12 mb-4 text-purple-500" />
                                        <h3 className="font-bold mb-2">Subscribe to a Plan</h3>
                                        <p>Choose from Monthly, Biannual, Quarterly, or Yearly Advertising Plans. Each plan has a specific radius to target your local audience effectively.</p>
                                    </CardContent>
                                </Card>
                                <Card className=' dark:text-black dark:bg-white'>
                                    <CardContent className="flex flex-col items-center text-center">
                                        <PenTool className="w-12 h-12 mb-4 text-green-500" />
                                        <h3 className="font-bold mb-2">Create an Ad</h3>
                                        <p>Design your perfect ad by adding compelling images, descriptive text, precise location, and selecting your chosen plan.</p>
                                    </CardContent>
                                </Card>
                                <Card className=' dark:text-black dark:bg-white'>
                                    <CardContent className="flex flex-col items-center text-center">
                                        <Megaphone className="w-12 h-12 mb-4 text-red-500" />
                                        <h3 className="font-bold mb-2">Publish your Ads</h3>
                                        <p>Schedule your ad to go live! Once published, it will be visible to users within your plan's radius.</p>
                                    </CardContent>
                                </Card>
                            </div>
                        </section>
                    </section>

                    <section className="gredent-bg py-8">
                        <section className="container mx-auto">
                            <section className="mb-8">
                                <h2 className={`text-2xl font-bold mb-4 dark:text-black`}>Download the App!</h2>
                                <div className="flex flex-col md:flex-row gap-4 lg:gap-8 items-center">
                                    <div className="w-1/1 sm:w-1/1 md:w-1/1 lg:w-1/2">
                                        <div className="flex items-center space-x-4 mb-3">
                                            <ShoppingBag className="w-8 h-8 text-purple-500" />
                                            <p className={`dark:text-black`}>Discover local businesses and exclusive deals</p>
                                        </div>
                                        <div className="flex items-center space-x-4 mb-3">
                                            <MapPin className="w-8 h-8 text-yellow-500" />
                                            <p className={`dark:text-black`}>Find nearby offers with location-based services</p>
                                        </div>
                                        <div className="flex items-center space-x-4 mb-3">
                                            <Smartphone className="w-8 h-8 text-blue-500" />
                                            <p className={`dark:text-black`}>Easy-to-use mobile interface for on-the-go shopping</p>
                                        </div>
                                        <div className="mt-8 space-x-4">
                                            <div className="flex gap-2 max-w-[300px] sm:max-w-[360px]">
                                                {siteTheme && siteTheme === 'light' ? (
                                                    <>
                                                        <a href="https://apps.apple.com/us/app/local-web-shopper/id6449487847" target="_blank" rel="noopener noreferrer">
                                                            {/* Download on App Store */}
                                                            <img
                                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/app-store.png`}
                                                                alt="Download on App Store"
                                                                className="rounded-lg"
                                                            />
                                                        </a>
                                                        <a href="https://play.google.com/store/apps/details?id=com.localweb.south&pli=1" target="_blank" rel="noopener noreferrer">
                                                            {/* Get it on Google Play */}
                                                            <img
                                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/playstore.png`}
                                                                alt="Get it on Google Play"
                                                                className="rounded-lg"
                                                            />
                                                        </a>
                                                    </>
                                                ) : (
                                                    <>
                                                        <a href="https://apps.apple.com/us/app/local-web-shopper/id6449487847" target="_blank" rel="noopener noreferrer">
                                                            {/* Download on App Store for Dark Screen */}
                                                            <img
                                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/dark-appstore-img.png`}
                                                                alt="Download on App Store"
                                                                className="rounded-lg"
                                                            />
                                                        </a>
                                                        <a href="https://play.google.com/store/apps/details?id=com.localweb.south&pli=1" target="_blank" rel="noopener noreferrer">
                                                            {/* Get it on Google Play for Dark Screen */}
                                                            <img
                                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/dark-googlePlay-img.png`}
                                                                alt="Get it on Google Play"
                                                                className="rounded-lg"
                                                            />
                                                        </a>
                                                    </>
                                                )}

                                            </div>
                                        </div>
                                    </div>
                                    <div className="w-1/1 sm:w-1/1 md:w-1/1 lg:w-1/2">
                                        <div className="flex gap-2 md:gap-3 justify-center">
                                            <img
                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/app_1.jpg`}
                                                alt="App Screenshot 1"
                                                className="rounded-lg"
                                                style={{ height: '330px' }}
                                            />
                                            <img
                                                src={`${import.meta.env.VITE_APP_URL}/images/landing/app_2.jpg`}
                                                alt="App Screenshot 2"
                                                className="rounded-lg"
                                                style={{ height: '330px' }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section className="">
                                <h2 className="text-2xl font-bold mb-4 dark:text-black">FAQs</h2>
                                <Accordion type="single" collapsible>
                                    <AccordionItem value="item-1" className='bg-white rounded-md border-dashed border-[#efefef] border-[1px] mb-3'>
                                        <AccordionTrigger className='px-3'>What is Local Web Shopper?</AccordionTrigger>
                                        <AccordionContent className='p-3 border-dashed border-t-[#efefef] border-t-[1px]'>
                                            Local Web Shopper by South Magnolia is your local advertising and marketing Mobile solution for customers on the go! Call us today to help expand and reach more customers in your geographic market!
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="item-2" className='bg-white rounded-md border-dashed border-[#efefef] border-[1px] mb-3'>
                                        <AccordionTrigger className='px-3'>What types of ads does Local Web Shopper allow?</AccordionTrigger>
                                        <AccordionContent className='p-3 border-dashed border-t-[#efefef] border-t-[1px]'>
                                            We allow any type of general advertising ads and marketing materials. We do not allow profanity, pornography, or material that would not be considered PG and appropriate for all ages.
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="item-3" className='bg-white rounded-md border-dashed border-[#efefef] border-[1px] mb-3'>
                                        <AccordionTrigger className='px-3'>What types of businesses advertise and market with Local Web Shopper?</AccordionTrigger>
                                        <AccordionContent className='p-3 border-dashed border-t-[#efefef] border-t-[1px]'>
                                            Local Web Shopper can be used with any type of business, event, or even job advertising. We have several main categories of businesses listed: Home Services, Beauty & Spas, Professional Services, Shopping, Restaurants, Medical & Wellness, Active Lifestyle.
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </section>
                        </section>
                    </section>
                </main>
                <Footer />
            </div>
        </>
    );
}
