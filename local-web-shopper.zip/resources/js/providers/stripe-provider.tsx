import React, { useState, useEffect } from 'react';
import { loadStripe, Stripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

interface StripeProviderProps {
    children: React.ReactNode;
}

export function StripeProvider({ children }: StripeProviderProps) {
    const [stripePromise, setStripePromise] = useState<Promise<Stripe | null> | null>(null);

    useEffect(() => {
        const loadStripeInstance = async () => {
            // const key = "pk_test_51NdpkRBuHqQNZg72XOlkNZRZZO9aXVTnGAyzbNP8QXJkZwW5gVY9r3PxjNQ6e9Yz5htDWyIKuMRaAHmS5EZfk4Oz00sCUF6Kvr";
            const key = import.meta.env.VITE_STRIPE_KEY;
            if (key) {
                const promise = loadStripe(key);
                setStripePromise(promise);
            } else {
                console.error('Stripe publishable key is not set in environment variables');
            }
        };

        loadStripeInstance();
    }, []);

    if (!stripePromise) {
        return <div>Loading Stripe...</div>;
    }

    return (
        <Elements stripe={stripePromise}>
            {children}
        </Elements>
    );
}
