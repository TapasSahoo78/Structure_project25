import { PageSize } from '../enums/page-size';
import { PlanPeriod } from '../enums/plan-period';

export type Plan = {
    id: number;
    created_at: Date;
    updated_at: Date;
    name: string;
    description: string;
    price: number;
    stripe_product_id: string;
    stripe_price_id: string;
    size: PageSize;
    radius: number;
    period: PlanPeriod;
};