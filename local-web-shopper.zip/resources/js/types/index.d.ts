import { LucideIcon } from 'lucide-react';
import type { Config } from 'ziggy-js';
import { PageSize } from '../enums/page-size';
import { PlanPeriod } from '../enums/plan-period';

export interface Auth {
    user: User;
}

export interface BreadcrumbItem {
    title: string;
    href: string;
}

export interface NavGroup {
    title: string;
    items: NavItem[];
}

export interface NavItem {
    title: string;
    href: string;
    icon?: LucideIcon | null;
    isActive?: boolean;
}

export interface SharedData {
    name: string;
    quote: { message: string; author: string };
    auth: Auth;
    ziggy: Config & { location: string };
    sidebarOpen: boolean;
    [key: string]: unknown;
}

export interface PaginationMeta {
    current_page: number;
    last_page: number;
    total: number;
    per_page: number;
    from: number | null;
    to: number | null;
}

export interface PaginationLink {
    url: string | null;
    label: string;
    active: boolean;
}

export type Ad = {
    id: number;
    title: string;
    description: string;
    subscription_id: number | null;
    category_id: number | null;
    start_date: string | null;
    end_date: string | null;
    file_id: number | null;
    plan?: {
        id: number;
        radius: number;
        size: PageSize;
    };
    address?: Address;
    subscription?: Subscription;
};

export type Address = {
    id: number;
    street_number: string;
    street_name: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    formatted_address: string | null;
    longitude: number;
    latitude: number;
    businesses?: Business[];
    ads?: Ad[];
    full_address?: string;
};

export type Business = {
    id: number;
    primary_user_id: number;
    address_id: number;
    trial_ends_at: Date | null;
    stripe_id: string | null;
    stripe_payment_method_id: string | null;
    phone: string | null;
    primaryUser?: User;
    address?: Address;
    ads?: Ad[];
    invoices?: Invoice[];
    subscriptions?: Subscription[];
    masked_phone?: string;
    name: string;
    email: string;
};

export interface ApiResponse {
    data: Business[];
    meta: any;
    links: any;
}

export interface PageProps {
    businesses: Business[];
    errors: {
        businesses?: string;
    };
    [key: string]: any;
}

export type AdCategory = {
    id: number;
    created_at: Date;
    updated_at: Date;
    name: string;
};

export type AdFavorite = {
    id: number;
    created_at: Date;
    updated_at: Date;
    user_id: number;
    ad_id: number;
};

export type AdImage = {
    id: number;
    ad_id: number;
    file_id: number;
    is_primary: boolean;
    order: number;
    created_at: Date | null;
    updated_at: Date | null;
    ad?: Ad;
    file?: File;
};

export type Plan = {
    id: number;
    name: string;
    description: string;
    price: number;
    size: PageSize;
    radius: number;
    period: PlanPeriod;
};

export type File = {
    id: number;
    created_at: Date;
    updated_at: Date;
    user_id: number;
    real: string;
    filename: string;
    mime_type: string;
    path: string;
    hash: string;
    size: number;
    user?: User;
    adImages?: AdImage[];
};

export type Invoice = {
    id: string;
    stripe_invoice_number: string;
    status: string;
    due_date: Date;
    amount_due: number;
    amount_paid: number;
    amount_remaining: number;
    currency: string;
    period_start: Date | null;
    period_end: Date | null;
    invoice_pdf: string | null;
    hosted_invoice_url: string | null;
    paid: boolean;
    payment_intent_id: string | null;
    paid_at: Date | null;
};

export type Subscription = {
    id: number;
    business_id: number;
    type: string;
    stripe_id: string;
    stripe_status: string;
    stripe_price: string;
    quantity: number;
    trial_ends_at: string | null;
    ends_at: string | null;
    created_at: string;
    updated_at: string;
    plan_id: number;
    name: string;
    plan?: Plan;
    creator?: User;
    ads?: Ad[];
    business?: Business;
    formatted_price?: string;
};

export type User = {
    id: number;
    name: string;
    email: string;
    email_verified_at: Date | null;
    is_admin: boolean;
    phone: string | null;
    masked_phone?: string;
    favorites?: Ad[];
    logs?: UserLog[];
    avatar?: string | null;

    fname: string;
    lname: string;
    formatted_address: string;
    street_number: string;
    street_name: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    business: any;
    login_code:string;
    latestActive:any
};

export type UserLog = {
    id: number;
    user_id: number;
    action: string;
    ip_address: string;
    details: string;
    created_at: Date;
    updated_at: Date;
};
