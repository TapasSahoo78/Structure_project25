<!DOCTYPE html>
<html lang="en">

<head>
    <title>Delete Account</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        /* Background gradient animation */
        @keyframes gradientBG {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        body,
        html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(-45deg, #00c6ff, #0072ff, #00c6ff, #0072ff);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 1rem;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
            max-width: 420px;
            width: 90%;
            padding: 2.5rem 2rem;
            color: #fff;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .form-container:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
        }

        h2 {
            font-weight: 600;
            margin-bottom: 1.5rem;
            letter-spacing: 1.2px;
            text-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        }

        .form-floating>input {
            background: rgba(255, 255, 255, 0.25);
            border: none;
            color: #fff;
            box-shadow: none;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-floating>input:focus {
            background: rgba(255, 255, 255, 0.45);
            color: #000;
            box-shadow: 0 0 8px 2px rgba(37, 117, 252, 0.7);
            border-radius: 0.375rem;
        }

        .form-floating>label {
            color: #e0e0e0;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .form-floating>input:focus~label {
            color: #2575fc;
        }

        .btn-danger {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            border: none;
            font-weight: 600;
            letter-spacing: 1px;
            box-shadow: 0 4px 15px rgba(255, 75, 43, 0.6);
            transition: background 0.4s ease, box-shadow 0.4s ease;
        }

        .btn-danger:hover,
        .btn-danger:focus {
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
            box-shadow: 0 6px 20px rgba(255, 65, 108, 0.8);
        }

        /* Modal customizations */
        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 1rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            color: #333;
            font-weight: 600;
            text-align: center;
            padding: 2rem;
        }

        .modal-header {
            border-bottom: none;
            justify-content: center;
            position: relative;
        }

        .modal-title {
            font-size: 1.5rem;
            color: #2575fc;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .modal-title .bi {
            font-size: 1.8rem;
        }

        .btn-close {
            position: absolute;
            right: 1rem;
            top: 1rem;
            filter: invert(0.4);
            transition: filter 0.3s ease;
        }

        .btn-close:hover {
            filter: invert(0);
        }

        .modal-footer {
            border-top: none;
            justify-content: center;
        }

        /* Responsive tweaks */
        @media (max-width: 480px) {
            .form-container {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="form-container shadow-lg">
        <h2>Delete Account</h2>
        <form id="myForm" novalidate>
            <div class="form-floating mb-4">
                <input type="tel" pattern="[0-9]{10}" class="form-control" id="number" name="phoneNumber"
                    placeholder="Phone Number" required>
                <label for="number"><i class="bi bi-telephone-fill me-2"></i>Phone Number</label>
                <div class="invalid-feedback text-start ps-3">
                    Please enter a valid 10-digit phone number.
                </div>
            </div>
            <button type="submit" class="btn btn-danger w-100">
                <i class="bi bi-trash-fill me-2"></i>Delete
            </button>
        </form>
    </div>

    <!-- Bootstrap Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true"
        data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel"><i
                            class="bi bi-exclamation-triangle-fill text-danger"></i> Delete Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modalMessage">
                    <!-- Message will be inserted here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-primary px-4" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    @php
        // Fetch phone numbers from 'businesses' table and normalize by removing non-digit characters
        $phoneDB = DB::table('businesses')->pluck('phone')->map(function ($phone) {
            return preg_replace('/\D/', '', $phone);
        })->toArray();
    @endphp

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Phone numbers array from backend (normalized)
        const phoneDB = @json($phoneDB);

        const myForm = document.getElementById("myForm");
        const phoneInput = document.getElementById("number");
        const modalMessage = document.getElementById("modalMessage");
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));

        myForm.addEventListener("submit", function(event) {
            event.preventDefault();

            if (!myForm.checkValidity()) {
                event.stopPropagation();
                myForm.classList.add('was-validated');
                return;
            }

            // Normalize input by removing all non-digit characters
            const phoneNumberRaw = phoneInput.value.trim();
            const phoneNumber = phoneNumberRaw.replace(/\D/g, '');

            if (phoneDB.includes(phoneNumber)) {
                modalMessage.textContent = "Account deleted successfully!";
                // Optionally remove the number from DB array to simulate deletion
                // phoneDB.splice(phoneDB.indexOf(phoneNumber), 1);
            } else {
                modalMessage.textContent = "Phone number not found!";
            }

            deleteModal.show();
            myForm.reset();
            myForm.classList.remove('was-validated');
        });
    </script>
</body>

</html>
