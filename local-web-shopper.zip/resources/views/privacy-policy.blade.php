<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Local Web Shopper</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            padding: 20px;
            background-color: #f9f9f9;
        }

        h1,
        h2,
        h3 {
            color: #333;
        }

        h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }

        h2 {
            font-size: 1.5em;
            margin-top: 20px;
        }

        h3 {
            font-size: 1.2em;
            margin-top: 15px;
        }

        p {
            margin: 10px 0;
        }

        ul {
            margin: 10px 0 10px 20px;
        }
    </style>
</head>

<body>
    <h1>Privacy Policy</h1>
    <p><strong>Effective Date:</strong> 17th September 2025</p>
    <p>Localwebshopper ("we", "us", or "our") is committed to protecting your privacy. This Privacy Policy explains how we
        collect, use, share, and protect your information when you use our mobile app and related services (“Localwebshopper”
        or the “App”).</p>

    <h2>1. Information We Collect</h2>
    <p>We collect the following types of information to provide and improve our services:</p>
    <h3>a. User-Provided Information</h3>
    <ul>
        <li>Account details: name, email address, password</li>
        <li>Business information: company name, team members</li>
        <li>Tool details: tool names, types, conditions, costs, storage locations, usage history</li>
        <li>Check-in/out data: who used the tool, when, and for how long</li>
    </ul>
    <h3>b. Automatically Collected Information</h3>
    <ul>
        <li>Device information (model, OS version)</li>
        <li>Log data (IP address, access times, app crashes)</li>
        <li>Usage analytics (how users interact with the app)</li>
    </ul>

    <h2>2. How We Use Your Information</h2>
    <p>We use your information to:</p>
    <ul>
        <li>Provide core app functionality (tool tracking, user management, inventory)</li>
        <li>Improve the app experience and performance</li>
        <li>Communicate important updates or support information</li>
        <li>Prevent misuse or unauthorized access</li>
    </ul>

    <h2>3. Data Sharing & Disclosure</h2>
    <p>We do not sell your personal data. We may share information:</p>
    <ul>
        <li>With service providers (e.g., hosting, analytics) under strict confidentiality agreements</li>
        <li>To comply with legal obligations</li>
        <li>In case of a business transfer (e.g., merger, acquisition)</li>
    </ul>

    <h2>4. Data Security</h2>
    <p>We use industry-standard security measures, including encryption and secure storage, to protect your information.
        However, no system is 100% secure, and we cannot guarantee absolute protection.</p>

    <h2>5. Data Retention</h2>
    <p>We retain your information for as long as your account is active or as needed to provide services. You can
        request deletion of your data at any time.</p>

    <h2>6. Your Rights</h2>
    <p>Depending on your location, you may have the right to:</p>
    <ul>
        <li>Access your data</li>
        <li>Correct inaccurate data</li>
        <li>Request deletion</li>
        <li>Object to or restrict processing</li>
        <li>Export your data</li>
    </ul>
    <p>To exercise these rights, contact us at: <a
            href="mailto:support@localwebshopper.com">support@localwebshopper.com</a></p>

    <h2>7. Children’s Privacy</h2>
    <p>Localwebshopper is not intended for users under the age of 16. We do not knowingly collect personal data from children.
    </p>

    <h2>8. Changes to This Policy</h2>
    <p>We may update this policy from time to time. We will notify you of significant changes through the app or by
        email.</p>

    <h2>9. Contact Us</h2>
    <p>If you have questions or concerns, please contact us at:</p>
    <p>📧 <a href="mailto:support@localwebshopper.com">support@localwebshopper.com</a></p>

</body>

</html>
