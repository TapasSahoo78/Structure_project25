<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdController;
use App\Http\Controllers\Admin\AdCategoryController;
use App\Http\Controllers\Admin\BusinessController;
use App\Http\Controllers\Admin\CouponController;
use App\Http\Controllers\Admin\PlanController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\SubscriptionController;
use App\Http\Controllers\Admin\UserController;

Route::middleware(['auth', 'admin'])->group(function () {
    // Admin only routes here

    Route::prefix('admin')->name('admin.')->group(function () {
        Route::redirect('/', '/admin/ads')->name('home');
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // Plans routes
        Route::resource('ads', AdController::class);
        Route::resource('ad-categories', AdCategoryController::class);
        Route::resource('businesses', BusinessController::class);
        Route::resource('plans', PlanController::class);
        Route::resource('coupons', CouponController::class);
        Route::resource('promo-codes', CouponController::class);
        Route::resource('invoices', InvoiceController::class);
        Route::resource('subscriptions', SubscriptionController::class);
        Route::resource('users', UserController::class);
    });
});
