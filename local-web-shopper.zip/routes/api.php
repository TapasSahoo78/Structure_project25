<?php

use App\Http\Controllers\WebhookController;

use App\Http\Controllers\Api\ApiAdCategoryController;
use App\Http\Controllers\Api\ApiAdController;
use App\Http\Controllers\Api\ApiAuthController;
use App\Http\Controllers\Api\ApiAdFavoriteController;
use App\Http\Controllers\Api\ApiCouponController;
use App\Http\Controllers\Api\ApiProfileController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Internal\AuthController;
use App\Http\Controllers\Internal\AdController;
use App\Http\Controllers\Internal\AdCategoryController;
use App\Http\Controllers\Internal\AdFavoriteController;
use App\Http\Controllers\Internal\BusinessController;
use App\Http\Controllers\Internal\CouponController;
use App\Http\Controllers\Internal\PromoCodeController;
use App\Http\Controllers\Internal\PlanController;
use App\Http\Controllers\Internal\FileController;
use App\Http\Controllers\Internal\InvoiceController;
use App\Http\Controllers\Internal\SubscriptionController;
use App\Http\Controllers\Internal\UserController;
use Illuminate\Support\Facades\Log;
use Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('login', [ApiAuthController::class, 'login'])->name('api.login');
Route::post('register', [ApiAuthController::class, 'register'])->name('api.register');

Route::get('delete-button-visibility', [ApiAuthController::class, 'buttonVisibility'])->name('button.visibility');

// Password reset
Route::post('password-reset/send', [ApiAuthController::class, 'sendPasswordReset'])->name('api.password.reset.send');
Route::post('password-reset', [ApiAuthController::class, 'resetPassword'])->name('api.password.reset');

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/user', function (Request $request) {
        return $request->user()->only(['id', 'name', 'email']);
    })->name('api.user');

    Route::post('logout', [ApiAuthController::class, 'logout'])->name('api.logout');
    Route::put('update-password', [ApiAuthController::class, 'updatePassword'])->name('api.password.update');

    // Ads
    Route::post('ads', [ApiAdController::class, 'getAds'])->name('api.ads.index');
    Route::get('ads/{ad}', [ApiAdController::class, 'show'])->name('api.ads.show');

    # DEV ONLY
    Route::post('dev_ads', [ApiAdController::class, 'getDevAds'])->name('api.ads.dev_index');

    // Favorites
    Route::get('favorites', [ApiAdFavoriteController::class, 'index'])->name('api.favorites.index');
    Route::post('favorites', [ApiAdFavoriteController::class, 'store'])->name('api.favorites.store');
    Route::delete('favorites/{id}', [ApiAdFavoriteController::class, 'destroy'])->name('api.favorites.destroy');

    // Ad categories
    Route::get('categories', [ApiAdCategoryController::class, 'getCategories'])->name('api.categories.index');

    // Profile
    Route::get('profile', [ApiProfileController::class, 'show'])->name('api.profile.show');
    Route::put('profile', [ApiProfileController::class, 'update'])->name('api.profile.update');
    Route::delete('profile', [ApiProfileController::class, 'destroy'])->name('api.profile.destroy');
    Route::get('profile/history', [ApiProfileController::class, 'history'])->name('api.profile.history');
});

// v1.0 API Internal only for now
Route::prefix('v1')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);

    Route::middleware([
        'auth:sanctum',
        EnsureFrontendRequestsAreStateful::class,
    ])->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/user', [AuthController::class, 'user']);
        Route::apiResource('ads', AdController::class);
        Route::apiResource('ad-categories', AdCategoryController::class);
        Route::apiResource('ad-favorites', AdFavoriteController::class);
        Route::apiResource('businesses', BusinessController::class);
        Route::apiResource('plans', PlanController::class);
        Route::apiResource('coupons', CouponController::class);
        Route::apiResource('promo-codes', PromoCodeController::class);
        Route::apiResource('files', FileController::class);
        Route::apiResource('invoices', InvoiceController::class);
        Route::apiResource('subscriptions', SubscriptionController::class);
        Route::apiResource('users', UserController::class);

        Route::post('/coupons/validate', [ApiCouponController::class, 'validate']);

        // Ads
        Route::get('/nearby', [AdController::class, 'nearby'])->name('ads.nearby');
        Route::get('/nearby-dev', [AdController::class, 'nearbyDev'])->name('ads.nearby-dev');

        // businesses
        Route::get('/businesses/{business}/payment-method', [BusinessController::class, 'showPaymentMethod']);
        Route::put('/businesses/{business}/payment-method', [BusinessController::class, 'updatePaymentMethod']);

        Route::post('/detach-payment-method', [BusinessController::class, 'detachPaymentMethod'])->name('detach.payment.method');
    });
});

Route::post('stripe/webhook', [WebhookController::class, 'handleWebhook']);
