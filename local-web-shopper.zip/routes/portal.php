<?php

use App\Http\Controllers\Portal\AdController;
use App\Http\Controllers\Portal\BillingController;
use App\Http\Controllers\Portal\DashboardController;
use App\Http\Controllers\Portal\SubscriptionController;
use App\Http\Controllers\Portal\PasswordController;
use App\Http\Controllers\Portal\ProfileController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::middleware(['auth', 'user'])->group(function () {
    Route::get('/portal/subscriptions/redirect', function () {
        return view('success');
    })->name('portal.subscriptions.redirect');
    // Portal only routes here
    Route::prefix('portal')->name('portal.')->group(function () {
        // Root portal route

        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // Subscriptions
        Route::prefix('subscriptions')->name('subscriptions.')->group(function () {
            Route::get('/', [SubscriptionController::class, 'index'])->name('index');
            Route::get('/create', [SubscriptionController::class, 'create'])->name('create');
            Route::post('/', [SubscriptionController::class, 'store'])->name('store');
            Route::get('/{subscription}', [SubscriptionController::class, 'show'])->name('show');
            Route::get('/{subscription}/edit', [SubscriptionController::class, 'edit'])->name('edit');
            Route::put('/{subscription}', [SubscriptionController::class, 'update'])->name('update');
            Route::delete('/{subscription}', [SubscriptionController::class, 'destroy'])->name('destroy');
        });

        // Ads
        Route::prefix('ads')->name('ads.')->group(function () {
            Route::get('/', [AdController::class, 'index'])->name('index');
            Route::get('/create', [AdController::class, 'create'])->name('create');
            Route::post('/', [AdController::class, 'store'])->name('store');
            Route::get('/{ad}', [AdController::class, 'show'])->name('show');
            Route::get('/{ad}/edit', [AdController::class, 'edit'])->name('edit');
            Route::put('/{ad}', [AdController::class, 'update'])->name('update');
            Route::delete('/{ad}', [AdController::class, 'destroy'])->name('destroy');
            Route::post('{ad}/publish', [AdController::class, 'publish'])->name('publish');
            Route::post('{ad}/end', [AdController::class, 'end'])->name('end');
        });

        // Billing
        Route::prefix('billing')->name('billing.')->group(function () {
            Route::get('/', [BillingController::class, 'index'])->name('index');
            Route::get('/invoices', [BillingController::class, 'invoices'])->name('invoices');
            Route::get('/payment-methods', [BillingController::class, 'paymentMethods'])->name('payment-methods');
            Route::post('/payment-methods', [BillingController::class, 'addPaymentMethod'])->name('add-payment-method');
            Route::delete('/payment-methods/{paymentMethod}', [BillingController::class, 'removePaymentMethod'])->name('remove-payment-method');
            Route::post('/set-default-payment-method', [BillingController::class, 'setDefaultPaymentMethod'])->name('set-default-payment-method');
        });

        // Settings
        Route::redirect('settings', 'settings/business');

        //Route::get('settings/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        //Route::patch('settings/profile', [ProfileController::class, 'update'])->name('profile.update');
        //Route::delete('settings/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

        Route::get('settings/password', [PasswordController::class, 'edit'])->name('password.edit');
        Route::put('settings/password', [PasswordController::class, 'update'])->name('password.update');

        Route::get('settings/appearance', function () {
            return Inertia::render('portal/settings/appearance');
        })->name('appearance');


        Route::get('settings/profile', [ProfileController::class, 'edit'])->name('profile');
        Route::patch('settings/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::get('settings/business', [ProfileController::class, 'editBusiness'])->name('business');
        Route::patch('settings/business', [ProfileController::class, 'updateBusiness'])->name('business.update');

        Route::delete('settings/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });
});
