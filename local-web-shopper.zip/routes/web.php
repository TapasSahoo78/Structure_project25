<?php

use App\Models\Ad;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*********************** For Static Page ************************/
Route::get('/', function () {
    return Inertia::render('welcome');
})->name('home');
Route::get('/privacy-policy', function () {
    return view('privacy-policy');
})->name('privacy.policy');
Route::get('/delete-account', function () {
    return view('delete-account');
})->name('delete.account');

require __DIR__ . '/settings.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/portal.php';
require __DIR__ . '/admin.php';
