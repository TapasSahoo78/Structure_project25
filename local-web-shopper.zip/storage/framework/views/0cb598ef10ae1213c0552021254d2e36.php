<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Centered Button</title>
    <style>
        /* Center the button horizontally and vertically */
        body,
        html {
            height: 100%;
            margin: 0;
        }

        .center-container {
            display: flex;
            justify-content: center;
            /* horizontal center */
            align-items: center;
            /* vertical center */
            height: 100vh;
            /* full viewport height */
        }

        .btn {
            padding: 12px 24px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            border: none;
            border-radius: 4px;
            color: white;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="center-container">
        <button id="goToSubscriptions" class="btn">Go to Subscriptions Page</button>
    </div>
    <script>
        document.getElementById('goToSubscriptions').addEventListener('click', function() {
            window.self !== window.top ? window.top.location.href = "<?php echo e(route('portal.subscriptions.index')); ?>" :
                "<?php echo e(route('portal.subscriptions.index')); ?>";
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\APRIL2025\local-web-shopper\resources\views\success.blade.php ENDPATH**/ ?>