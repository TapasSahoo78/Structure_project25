import { Types } from "mongoose";

export interface IGroup {
	group_number: number;
	group_name: string;
	business_type: string | null;
	business_description: string | null;
	phone_number: string | null;
	address: string | null;
	city: string | null;
	state: string | null;
	ZIP: string | null;
	country: string | null;
	created_by: Types.ObjectId | null;
	created_date: Date | null;
	update_by: Types.ObjectId | null;
	update_date: Date | null;
}
