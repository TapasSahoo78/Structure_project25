import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IAddToCartSchema extends ICreated {
	member_ObjectId: Types.ObjectId;
	dog_ObjectId: Types.ObjectId;
	unit_qty: number;
	unit_price: number;
	total_price: number;
	date: SchemaDefinitionProperty<Date>;
	status: "PENDING" | "ACTIVE" | "INACTIVE" | "CANCELLED";
}
export interface IAddtoCart extends IAddToCartSchema, IObjectId { }
