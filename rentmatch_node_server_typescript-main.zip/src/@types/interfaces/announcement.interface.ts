import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IAnnouncementSchema extends ICreated {
	subject: string;
	image: {
		filename: string;
		path: string;
		size: number;
	};
	date: Date;
	description: string;
	link: string;
	status: string | null;
}

export interface IAnnouncement extends IAnnouncementSchema, IObjectId { }
