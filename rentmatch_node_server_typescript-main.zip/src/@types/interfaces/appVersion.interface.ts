import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IAppVersionSchema extends ICreated {
	app_version_android: number;
	app_version_ios: number;
	type: string;
	subscription_status: boolean;
}

export interface IAppVersion extends IAppVersionSchema, IObjectId { }
