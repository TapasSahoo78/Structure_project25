import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
import { Gender } from "../types/gender/gender.types";

export interface ICategorySchema extends ICreated {
	name: string,
	slug: string,
	description: string,
	status: string
}

export interface ICategory extends ICategorySchema, IObjectId { }
