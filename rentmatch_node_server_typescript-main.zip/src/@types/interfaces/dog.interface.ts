import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
import { Gender } from "../types/gender/gender.types";

export interface IDogSchema extends ICreated {
	dog_id: string;
	dog_name: string;
	date_of_birth: SchemaDefinitionProperty<Date | null>;
	gender: Gender;
	owner_id: Types.ObjectId;
	trainer_id: Types.ObjectId;
	dog_price: number;
	color: string | null;
	breed_s: string | null;
	breed_d: string | null;
	status: "PENDING" | "ACTIVE" | "INACTIVE" | "CANCELLED";
	img: [
		{
			filename: String;
			path: String;
			size: Number;
		}
	];
}

export interface IDog extends IDogSchema, IObjectId { }
