import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IGrievenceSchema extends ICreated {
	description: string;
	createdBy: Types.ObjectId;
	reply: {
		message: string;
		repliedBy: {
			role: string;
			memberId: Types.ObjectId;
			groupOwnerId: Types.ObjectId;
			replyTime: SchemaDefinitionProperty<Date | null>;
		};
	}[];
}

export interface IGrievence extends IGrievenceSchema, IObjectId {}
