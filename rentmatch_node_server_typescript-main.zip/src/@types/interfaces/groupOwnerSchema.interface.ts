import { SchemaDefinitionProperty } from "mongoose";
import { ContactLabel } from "../types/contactLabel/contactLabel.types";
import { Gender } from "../types/gender/gender.types";
import { groupOwnerRole } from "../types/role/roles.types";
import { ICreated } from "./general.interface";
import { IObjectId } from "./objectId.interface";

export interface IGroupOwnerSchema extends ICreated {
	first_name: string;
	middle_name: string | null;
	last_name: string;
	user_name: string | null;
	password: string | null;
	role: groupOwnerRole;
	email: string;
	gender: Gender;
	address_line_1: string | null;
	address_line_2: string | null;
	city: string | null;
	state: string | null;
	country: string | null;
	zip: string | null;
	contact_label: ContactLabel;
	phone_number: number | null;
	phone_extension: number | null;
	is_registered: boolean; // This field is for checking whether the user is registered or not.
	is_active: boolean; // This field is for chat support, that whether the user is online or not.
	is_disabled: boolean; // This field is to disable Group Owners from accessing their Profile (i.e if is_disabled = true, then particular owner will not able to login)
	devices_token: string | null;
	subscription: {
		super_admin_registration: {
			email: boolean;
			notification: boolean;
		};
		admin_creation: {
			email: boolean;
			notification: boolean;
		};
		admin_registration: {
			email: boolean;
			notification: boolean;
		};
		payment: {
			email: boolean;
			notification: boolean;
		};
		customer_registration: {
			email: boolean;
			notification: boolean;
		};
		customer_profile_updation: {
			email: boolean;
			notification: boolean;
		};
		lead_addition: {
			email: boolean;
			notification: boolean;
		};
		lead_updation: {
			email: boolean;
			notification: boolean;
		};
		lead_accepted: {
			email: boolean;
			notification: boolean;
		};
		lead_rejected: {
			email: boolean;
			notification: boolean;
		};
		lead_ingested: {
			email: boolean;
			notification: boolean;
		};
		lead_duplicated: {
			email: boolean;
			notification: boolean;
		};
		lead_returned: {
			email: boolean;
			notification: boolean;
		};
	};
	otp: string | null;
	expiresAt: Date | null;
	last_login_date: SchemaDefinitionProperty<Date | null>;
}

export interface IGroupOwner extends IGroupOwnerSchema, IObjectId { }
