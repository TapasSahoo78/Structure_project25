import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IContactUsSchema extends ICreated {
	name: string;
	email: string;
	phone: string;
	description: string;
}

export interface IContactUs extends IContactUsSchema, IObjectId { }
