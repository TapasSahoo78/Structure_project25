import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
import { employeeRole } from "../types/role/roles.types";
import { Gender } from "../types/gender/gender.types";

export interface IMemberDeleteSchema extends ICreated {
	member_object_id: string | null;
	member_id: string | null;
	first_name: string | null;
	middle_name: string | null;
	last_name: string | null;
	email: string; // Primary Key
	otp: string | null;
	expiresAt: Date | null;
	user_name: string | null;
	password: string | null;
	date_of_birth: SchemaDefinitionProperty<Date | null>;
	gender: Gender | null;
	phone_number: number | null;
	phone_extension: number | null;
	role: employeeRole;
	company: string | null;
	address_line_1: string | null;
	address_line_2: string | null;
	city: string | null;
	state: string | null;
	ZIP: string | null;
	country: string | null;
	contact_label: string | null;
	member_status: string | null;
	is_verified: boolean;
	is_registered: boolean;
	is_subscribe: boolean;
	devices_token: string | null;
	date: SchemaDefinitionProperty<Date>;
	last_login_date: SchemaDefinitionProperty<Date | null>;
}

export interface IMemberDelete extends IMemberDeleteSchema, IObjectId { }
