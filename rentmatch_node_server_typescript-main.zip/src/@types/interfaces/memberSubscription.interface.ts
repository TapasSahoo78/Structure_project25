import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
export interface IMemberSubscriptionSchema extends ICreated {
	member_id: Types.ObjectId;
	subscription_id: Types.ObjectId;
	price: number;
	date: SchemaDefinitionProperty<Date>;
	status: {
		type: string;
		enum: ["pending", "active", "inactive", "cancelled"];
		default: "pending";
	};
}

export interface IMemberSubscription extends IMemberSubscriptionSchema, IObjectId { }
