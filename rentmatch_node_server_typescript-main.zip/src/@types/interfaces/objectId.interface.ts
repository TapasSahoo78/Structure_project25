import { Types } from "mongoose";

export interface IObjectId {
	_id: Types.ObjectId;
}
