import { Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IOrderSchema extends ICreated {
	member_ObjectId: Types.ObjectId;
	orders: [
		{
			dog_ObjectId: Types.ObjectId;
			unit_qty: number;
			unit_price: number;
			total_unit_price: number;
		}
	];
	total_price: number;
	tax: number;
	platformCharges: number;
	paybleAmount: number;
	date: Date;
	billing_name: string;
	billing_address: string;
	country: string;
	state: string;
	city: string;
	status: string;
}
export interface IOrder extends IOrderSchema, IObjectId { }
