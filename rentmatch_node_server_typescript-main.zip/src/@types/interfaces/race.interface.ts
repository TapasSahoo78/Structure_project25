import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IRaceSchema extends ICreated {
	race_name: string;
	location: string;
	race_date: SchemaDefinitionProperty<Date | null>;
	race_time: string | null;
	country: string;
	country_image?: [
		{
			filename: String;
			path: String;
			size: Number;
		}
	];
	grade: string;
	type: number | null;
	dogs: [
		{
			rug_image?: [
				{
					filename?: string;
					path?: string;
					size?: number;
				}
			];
			box_number: string | null; // Changed from number | null to number
			rug_number: string; // Changed from number | null to number
			dog_object_id: Types.ObjectId;
		}
	][];
}

export interface IRace extends IRaceSchema, IObjectId { }
