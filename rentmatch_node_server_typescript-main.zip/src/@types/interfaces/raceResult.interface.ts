import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IRaceSResultchema extends ICreated {
	race_object_id: Types.ObjectId;
	race_date: SchemaDefinitionProperty<Date | null>;
	grade: string;
	round: [
		{
			race_round_no: number;
			time: string;
			winners?: [
				{
					position: number;
					dog_object_id: Types.ObjectId;
					race_completion_time?: string;
					box_number?: string;
					mgn?: number;
					split?: number;
					in_run?: number;
					weight?: number;
					dog_price?: number;
				}
			];
		}
	];
}

export interface IRaceResult extends IRaceSResultchema, IObjectId {}
