import { Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface IRewardsSchema extends ICreated {
	race_object_id: Types.ObjectId | null;
	dog_object_id: Types.ObjectId;
	reward_types: string;
	points: number | null;
	member: [
		{
			member_Object_id: Types.ObjectId;
			unit_qty: number | null;
			unit_price: number | null;
			per_unit_point: number | null;
			previous_wallet_balance: number | null;
			after_wallet_balance: number | null;
			description: string | null;
		}
	];
}
export interface IRewards extends IRewardsSchema, IObjectId { }
