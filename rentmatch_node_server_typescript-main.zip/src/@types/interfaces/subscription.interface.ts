import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface ISubscriptionSchema extends ICreated {
	name: string;
	slug: string;
	plan_type: string;
	price: number;
	duration: number;
	description: string;
	features: string;
	is_active: boolean;
	status: boolean;
}

export interface ISubscription extends ISubscriptionSchema, IObjectId { }
