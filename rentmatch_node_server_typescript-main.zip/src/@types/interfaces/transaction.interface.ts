import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface ITransactionSchema extends ICreated {
	payment_intent_id: string;
	member_objectId: IObjectId;
	order_objectId: IObjectId | null;
	subscription_objectId: IObjectId | null;
	wallet_objectId: IObjectId | null;
	type: string | null;
	payment_type: string;
	payment_status: string;
	transaction_status: string;
	amount: number;
	transaction_date: SchemaDefinitionProperty<Date | null>;
	message: SchemaDefinitionProperty<string | null>;
	payment_data: string | null;
	respons_data: string | null;
}

export interface ITransaction extends ITransactionSchema, IObjectId { }
