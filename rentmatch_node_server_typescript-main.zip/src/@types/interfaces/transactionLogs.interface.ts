import { SchemaDefinitionProperty } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface ITransactionLogsSchema extends ICreated {
	payment_intent_id: string;
	transaction_id: string;
	member_id: string;
	payment_type: string | null;
	payment_status: string | null;
	transaction_status: string | null;
	amount: string | null;
	transaction_date: SchemaDefinitionProperty<Date | null>;
	message: SchemaDefinitionProperty<string | null>;
	payment_data: string | null;
}

export interface ITransactionLogs extends ITransactionLogsSchema, IObjectId { }
