import { Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
export interface IWalletSchema extends ICreated {
	member_id: Types.ObjectId;
	amount: number | null;
	type: string | null;
	status: string | null;
}

export interface IWallet extends IWalletSchema, IObjectId { }
