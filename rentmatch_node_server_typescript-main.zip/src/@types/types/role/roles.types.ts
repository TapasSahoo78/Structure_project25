export type groupOwnerRole = "SUPER ADMIN" | "ADMIN";

export type employeeRole = "EMPLOYEE";
