import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { Model } from "mongoose";
import { MESSAGE } from "../../../../../constants/message";
import { STATUS } from "../../../../../constants/status/status";
import slugify from "slugify";


export const categoryList = async (req: Request, res: Response): Promise<any> => {
	const category = await Model.find({ status: STATUS.active }).lean();
	return res.status(StatusCodes.OK).json({
		message: MESSAGE.custom("Admin fetch successfully!"),
		result: category
	});
}

export const categoryDetails = async (req: Request, res: Response): Promise<any> => {
	const category = await Model.find({ _id: req.params.id, status: STATUS.active }).lean();
	return res.status(StatusCodes.OK).json({
		message: MESSAGE.custom("Admin fetch successfully!"),
		result: category
	});
}
export const categoryCreate = async (req: Request, res: Response): Promise<any> => {
	const { name, description } = req.body;
	const slug = slugify(name);
	const categoryData = {
		name,
		slug,
		description
	}
	const categoryInstance = await Model.create(categoryData);
	return res.status(StatusCodes.CREATED).json({
		message: MESSAGE.custom("Category created successfully!"),
		result: categoryInstance
	});
}
export const categoryUpdate = async (req: Request, res: Response): Promise<any> => {
	const { name, description } = req.body;
	const slug = slugify(name);
	const categoryData = {
		name,
		slug,
		description
	}
	const categoryInstance = await Model.findByIdAndUpdate({ _id: req.params.id }, categoryData, { new: true });
	return res.status(StatusCodes.CREATED).json({
		message: MESSAGE.custom("Category created successfully!"),
		result: categoryInstance
	});
}
export const categoryDelete = async (req: Request, res: Response): Promise<any> => {
	const categoryInstance = await Model.findByIdAndDelete({ _id: req.params.id });
	return res.status(StatusCodes.CREATED).json({
		message: MESSAGE.custom("Category deleted successfully!"),
		result: categoryInstance
	});
}