// import { Request, Response } from "express";
// import { Model } from "mongoose";
// import { StatusCodes } from "http-status-codes";
// import { MESSAGE } from "../../../../../constants/message";
// import GroupOwnerModel from "../../../../../model/groupOwner.model";
// import MemberModel from "../../../../../model/member.model";
// import service from "../../../../../services";
// import { uploadImageBase64Service } from "../../../../../services/uploadBase64Image/base64Image.service";
// import { ROLES } from "../../../../../constants/roles/roles";
// import { MEMBER_STATUS } from "../../../../../constants/status/status";

// export const adminList = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		const user = await GroupOwnerModel.find({ 'role': 'ADMIN' });
// 		return res.status(StatusCodes.OK).json({
// 			message: MESSAGE.custom("Admin fetch successfully!"),
// 			user
// 		});
// 	} catch (error) {
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.custom("Admin fetch unsuccessful!"),
// 			error
// 		});
// 	}
// }
// export const ownerList = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		const user = await GroupOwnerModel.find({ 'role': 'SUPER ADMIN' });
// 		return res.status(StatusCodes.OK).json({
// 			message: MESSAGE.custom("Owner fetch successfully!"),
// 			user
// 		});
// 	} catch (error) {
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.custom("Owner fetch unsuccessful!"),
// 			error
// 		});
// 	}
// }
// export const memberList = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		const user = await MemberModel.find();
// 		return res.status(StatusCodes.OK).json({
// 			message: MESSAGE.custom("Member fetch successfully!"),
// 			user
// 		});
// 	} catch (error) {
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.custom("Member fetch unsuccessful!"),
// 			error
// 		});
// 	}
// }
// export const updateFeaturePermission = async (req: Request, res: Response): Promise<any> => {
// 	const { feature_permission, _id } = req.body;
// 	try {
// 		const updatedOwner = await GroupOwnerModel.findByIdAndUpdate(
// 			_id,
// 			{ feature_permission },
// 			{ new: true, runValidators: true }
// 		);
// 		if (!updatedOwner) {
// 			return res.status(404).json({ message: 'Group owner not found' });
// 		}
// 		return res.status(StatusCodes.OK).json({
// 			message: MESSAGE.custom("Permission updated successfully!")
// 		});
// 	} catch (error) {
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.custom("Something went wrong!"),
// 			error
// 		});
// 	}
// }
// // export const memberAdd = async (req: Request, res: Response): Promise<any> => {
// // 	try {
// // 		// Destructure request body
// // 		const {
// // 			role,
// // 			first_name,
// // 			middle_name,
// // 			last_name,
// // 			user_name,
// // 			password,
// // 			email,
// // 			gender,
// // 			address_line_1,
// // 			address_line_2,
// // 			city,
// // 			state,
// // 			country,
// // 			zip,
// // 			contact_label,
// // 			phone_number,
// // 			phone_extension,
// // 			upload_front_side,
// // 			upload_back_side
// // 		} = req.body;


// // 		// const emailExists = await MemberModel.findOne({ email: email, is_verified: true });

// // 		// if (!emailExists) {
// // 		// 	return res.status(StatusCodes.BAD_REQUEST).json({
// // 		// 		message: MESSAGE.custom("Email is not verified!")
// // 		// 	});
// // 		// }

// // 		// // Validate required fields
// // 		// const requiredFields = [first_name, last_name, user_name, password, email, phone_number];
// // 		// if (requiredFields.some((field) => !field)) {
// // 		// 	return res.status(StatusCodes.BAD_REQUEST).json({
// // 		// 		message: MESSAGE.custom("first_name, last_name, user_name, password, email, phone_number are required")
// // 		// 	});
// // 		// }

// // 		// Check for duplicates
// // 		const duplicateFields = ["email, phone_number", "user_name"];
// // 		for (const field of duplicateFields) {
// // 			if (await service.auth.isDuplicateValueCheckService(MemberModel, field, req.body[field])) {
// // 				// if (await isDuplicateValue(field, req.body[field])) {
// // 				return res.status(StatusCodes.CONFLICT).json({
// // 					message: MESSAGE.custom(`Duplicate ${field.replace("_", " ")}! ${req.body[field]} already exists!`)
// // 				});
// // 			}
// // 		}

// // 		let uploadFrontSide = "";
// // 		let uploadBackSide = "";
// // 		if (role === "COMPETITION CREATOR") {
// // 			uploadFrontSide = await uploadImageBase64Service(upload_front_side, "photoId");
// // 			uploadBackSide = await uploadImageBase64Service(upload_back_side, "photoId");
// // 		}
// // 		//check role wise make prefix use switch case
// // 		let prefix = "";
// // 		switch (role) {
// // 			case "COMPETITION CREATOR":
// // 				prefix = "C";
// // 				break;
// // 			case "INDIVIDUAL VOTER":
// // 				prefix = "V";
// // 				break;
// // 			case "PARTICIPANT":
// // 				prefix = "P";
// // 				break;
// // 			default:
// // 				return res.status(StatusCodes.BAD_REQUEST).json({
// // 					message: MESSAGE.custom("Invalid role!")
// // 				});
// // 		}

// // 		// Generate member_id
// // 		const generateMemberId = await service.common.generateId(MemberModel, "member_id", prefix, 6);
// // 		// Hash the password
// // 		const hashPassword = await service.auth.hashPassword(password);
// // 		const isApprovedbyAdmin = role === ROLES.competition_creator ? MEMBER_STATUS.pending : MEMBER_STATUS.approved;
// // 		// Create member data
// // 		const memberData = {
// // 			member_id: generateMemberId,
// // 			role,
// // 			first_name,
// // 			middle_name,
// // 			last_name,
// // 			user_name,
// // 			password: hashPassword,
// // 			email,
// // 			gender,
// // 			address_line_1,
// // 			address_line_2,
// // 			city,
// // 			state,
// // 			country,
// // 			zip,
// // 			contact_label,
// // 			phone_number,
// // 			phone_extension,
// // 			is_registered: true, // Set is_registered to true
// // 			is_approved: isApprovedbyAdmin,
// // 			upload_front_side: uploadFrontSide,
// // 			upload_back_side: uploadBackSide
// // 		};
// // 		// Create or update the member
// // 		const memberInstance = await MemberModel.create(memberData);

// // 		return res.status(StatusCodes.CREATED).json({
// // 			message: MESSAGE.post.succ,
// // 			result: memberInstance // Return relevant user info
// // 		});
// // 	} catch (error) {
// // 		console.error("Registration error:", error); // Log the error for debugging
// // 		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
// // 			message: MESSAGE.custom("Email verification failed!"),
// // 			error
// // 		});
// // 	}
// // }


// export const memberAdd = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		// Destructure request body
// 		const {
// 			role,
// 			first_name,
// 			middle_name,
// 			last_name,
// 			user_name,
// 			password,
// 			email,
// 			gender,
// 			address_line_1,
// 			address_line_2,
// 			city,
// 			state,
// 			country,
// 			zip,
// 			contact_label,
// 			phone_number,
// 			phone_extension,
// 			upload_front_side,
// 			upload_back_side
// 		} = req.body;

// 		// Validate required fields
// 		const requiredFields = [first_name, last_name, user_name, password, email, phone_number];
// 		if (requiredFields.some(field => !field)) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: MESSAGE.custom("first_name, last_name, user_name, password, email, phone_number are required")
// 			});
// 		}

// 		// Check for duplicates
// 		const duplicateFields = ["email", "phone_number", "user_name"];
// 		for (const field of duplicateFields) {
// 			if (await service.auth.isDuplicateValueCheckService(MemberModel, field, req.body[field])) {
// 				return res.status(StatusCodes.CONFLICT).json({
// 					message: MESSAGE.custom(`Duplicate ${field.replace("_", " ")}! ${req.body[field]} already exists!`)
// 				});
// 			}
// 		}

// 		// Handle image uploads based on role
// 		let uploadFrontSide = "";
// 		let uploadBackSide = "";
// 		if (role === "COMPETITION CREATOR") {
// 			uploadFrontSide = await uploadImageBase64Service(upload_front_side, "photoId");
// 			uploadBackSide = await uploadImageBase64Service(upload_back_side, "photoId");
// 		}

// 		// Determine prefix based on role
// 		const rolePrefixMap: Record<string, string> = {
// 			"COMPETITION CREATOR": "C",
// 			"INDIVIDUAL VOTER": "V",
// 			"PARTICIPANT": "P"
// 		};
// 		const prefix = rolePrefixMap[role];
// 		if (!prefix) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: MESSAGE.custom("Invalid role!")
// 			});
// 		}

// 		// Generate member_id
// 		const generateMemberId = await service.common.generateId(MemberModel, "member_id", prefix, 6);
// 		// Hash the password
// 		const hashPassword = await service.auth.hashPassword(password);
// 		const isApprovedbyAdmin = MEMBER_STATUS.approved;

// 		// Create member data
// 		const memberData = {
// 			member_id: generateMemberId,
// 			role,
// 			first_name,
// 			middle_name,
// 			last_name,
// 			user_name,
// 			password: hashPassword,
// 			email,
// 			gender,
// 			address_line_1,
// 			address_line_2,
// 			city,
// 			state,
// 			country,
// 			zip,
// 			contact_label,
// 			phone_number,
// 			phone_extension,
// 			is_registered: true, // Set is_registered to true
// 			is_approved: isApprovedbyAdmin,
// 			upload_front_side: uploadFrontSide,
// 			upload_back_side: uploadBackSide
// 		};

// 		// Create or update the member
// 		const memberInstance = await MemberModel.create(memberData);

// 		return res.status(StatusCodes.CREATED).json({
// 			message: MESSAGE.post.succ,
// 			result: memberInstance // Return relevant user info
// 		});
// 	} catch (error) {
// 		console.error("Registration error:", error); // Log the error for debugging
// 		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
// 			message: MESSAGE.custom("Registration failed!"),
// 			error: error || error
// 		});
// 	}
// };



