import { adminRegistration, addAdmin } from "../registration/adminRegistration/adminregistration.controller";
import { superAdminRegistration } from "../registration/superAdminRegistration/superAdminRegistration.controller";
import { memberRegistration } from "../registration/memberRegistration/memberRegistration.controller";
import { emailVerificationWithPasswordChange } from "./verificationDetails.controller";

const registration = {
	adminRegistration,
	superAdminRegistration,
	memberRegistration,
	emailVerificationWithPasswordChange,
	addAdmin
};
export default registration;
