import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../../../constants/message";
import service from "../../../../../../services";
import GroupOwnerModel from "../../../../../../model/groupOwner.model";
import memberModel from "../../../../../../model/member.model";
import MemberModel from "../../../../../../model/member.model";

export const memberRegistration = async (req: Request, res: Response): Promise<any> => {
	try {
		// Destructure request body
		const {
			role,
			first_name,
			middle_name,
			last_name,
			user_name,
			password,
			email,
			gender,
			address_line_1,
			address_line_2,
			city,
			state,
			country,
			zip,
			contact_label,
			phone_number,
			phone_extension,
			date_of_birth
		} = req.body;

		const emailExists = await memberModel.findOne({ email: email, is_verified: true });

		if (!emailExists) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Email is not verified!")
			});
		}

		// Validate required fields
		const requiredFields = [first_name, last_name, user_name, password, email, phone_number];
		if (requiredFields.some((field) => !field)) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("All fields are required.")
			});
		}

		// Function to check for duplicates
		const isDuplicateValue = async (field: string, value: string) => {
			return (
				(await service.auth.isDuplicateValueCheckService(memberModel, field, value)) ||
				(await service.auth.isDuplicateValueCheckService(GroupOwnerModel, field, value))
			);
		};

		// Check for duplicates
		const duplicateFields = ["phone_number", "user_name"];
		for (const field of duplicateFields) {
			if (await isDuplicateValue(field, req.body[field])) {
				return res.status(StatusCodes.CONFLICT).json({
					message: MESSAGE.custom(`Duplicate ${field.replace("_", " ")}! ${req.body[field]} already exists!`)
				});
			}
		}

		// Create member data
		const memberData = {
			member_id: await service.common.generateId(memberModel, "member_id", "M", 6),
			role,
			first_name,
			middle_name,
			last_name,
			user_name,
			password: await service.auth.hashPassword(password),
			email,
			gender,
			address_line_1,
			address_line_2,
			city,
			state,
			country,
			zip,
			contact_label,
			phone_number,
			phone_extension,
			date_of_birth,
			is_registered: true,
			is_subscribe: true
		};

		// new: true: Returns the updated document instead of the original document.
		// upsert: true: Creates a new document if no matching document is found.
		// runValidators: true: Applies schema validation rules during the update operation.
		// Create or update the member
		const memberInstance = await MemberModel.findOneAndUpdate(
			{ email: email, is_verified: true }, // Query to find the member
			memberData, // Data to update or create
			{ new: true, upsert: true, runValidators: true } // Options
		);

		return res.status(StatusCodes.CREATED).json({
			message: MESSAGE.post.succ,
			result: memberInstance // Return relevant user info
		});
	} catch (error) {
		console.error("Registration error:", error); // Log the error for debugging
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("Email verification failed!"),
			error
		});
	}
};
