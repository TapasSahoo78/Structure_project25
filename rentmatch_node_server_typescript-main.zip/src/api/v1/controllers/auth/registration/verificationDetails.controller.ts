import { Request, Response } from "express";
import { Model } from "mongoose";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../../constants/message";
import { ROLES } from "../../../../../constants/roles/roles";
import service from "../../../../../services";
import memberModel from "../../../../../model/member.model";
import groupOwnerModel from "../../../../../model/groupOwner.model";
import { log } from "node:console";
import { sendEmail } from "../../../../../services/email/email";
import { MEMBER_STATUS } from "../../../../../constants/status/status";
import MemberModel from "../../../../../model/member.model";
import GroupOwnerModel from "../../../../../model/groupOwner.model";
export const emailVerificationWithPasswordChange = async (req: Request, res: Response): Promise<any> => {
	try {
		const { type, email, otp, password, confirmPassword, role, forgotemail } = req.body;

		// Validate required fields
		if (!email || !type) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Email or type is missing!")
			});
		}

		let model: Model<any>;
		if (role === ROLES.super_admin || role === ROLES.admin) {
			model = GroupOwnerModel;
		} else if (role === ROLES.property_manager || role === ROLES.landlord || role === ROLES.tenant) {
			model = MemberModel;
		} else {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Unauthorised Role!")
			});
		}
		let isAdmin = false;
		switch (type) {
			case "email": {
				const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
				const generatedOtp = await service.common.generateOtp(4);
				const isApprovedbyAdmin = role === ROLES.property_manager ? MEMBER_STATUS.pending : MEMBER_STATUS.approved;
				// Check for user role
				if (!role) {
					// Check if the email exists in either model
					const emailExists = await MemberModel.findOne({ email, is_verified: true, is_registered: true }) ||
						await GroupOwnerModel.findOne({ email, is_registered: true });

					// Determine if the user is an admin
					isAdmin = !!emailExists && (emailExists as any).is_registered; // Type assertion added

					if (!emailExists) {
						return res.status(StatusCodes.NOT_FOUND).json({
							message: MESSAGE.custom("Email Not Registered")
						});
					}

					model = isAdmin ? GroupOwnerModel : MemberModel;
				} else {
					// Handle roles for ADMIN or SUPER ADMIN
					if (['ADMIN', 'SUPER ADMIN'].includes(role)) {
						const emailExists = await GroupOwnerModel.findOne({ email });

						if (!emailExists) {
							return res.status(StatusCodes.NOT_FOUND).json({
								message: MESSAGE.custom("Email Not Registered! Contact the Group Owner")
							});
						}
						if (emailExists.is_registered) {
							return res.status(StatusCodes.NOT_FOUND).json({
								message: MESSAGE.custom("Duplicate Email! User Already Exist")
							});
						}
						model = GroupOwnerModel;
					} else {
						// Handle other roles
						const emailExists = await MemberModel.findOne({ email, is_verified: true, is_registered: true });

						if (emailExists) {
							return res.status(StatusCodes.NOT_FOUND).json({
								message: MESSAGE.custom("Email Already Registered and Verified!")
							});
						}
						model = MemberModel;
					}
				}

				// Update or create a new OTP record
				const result = await model.findOneAndUpdate(
					{ email, role },
					{
						otp: generatedOtp, expiresAt, is_approved: isApprovedbyAdmin
					},
					{ new: true, upsert: true, runValidators: true }
				);

				return res.status(StatusCodes.OK).json({
					message: "OTP sent successfully!",
					result: { email: result.email, otp: result.otp, expiresAt: result.expiresAt }
				});
			}
			case "otp": {
				let member = await MemberModel.findOne({ email }) ||
					await GroupOwnerModel.findOne({ email });
				isAdmin = !!member && (member as any).is_registered;

				if (!member) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Email not found!")
					});
				}

				if (!member.otp || !member.expiresAt || member.expiresAt < new Date()) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("OTP expired or invalid!")
					});
				}

				if (member.otp !== otp) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Invalid OTP!")
					});
				}

				// Clear OTP after verification
				await model.findOneAndUpdate(
					{ email },
					{ is_verified: isAdmin ? undefined : true, otp: null, expiresAt: null }
				);

				return res.status(StatusCodes.OK).json({
					message: MESSAGE.custom("OTP Verified Successfully!"),
					result: member
				});
			}
			case "password": {
				if (!password || !confirmPassword) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Password and confirm password are required!")
					});
				}
				if (password !== confirmPassword) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Confirm password doesn't match!")
					});
				}

				let member = await MemberModel.findOne({ email }) ||
					await GroupOwnerModel.findOne({ email });
				isAdmin = !!member && (member as any).is_registered;

				if (!member) {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Email not found!")
					});
				}

				// Update password
				await model.findOneAndUpdate(
					{ email },
					{ password: await service.auth.hashPassword(password) }
				);

				return res.status(StatusCodes.OK).json({
					message: MESSAGE.custom("Password changed successfully!")
				});
			}
			case "forgotpassword": {
				const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
				const generatedOtp = await service.common.generateOtp(4);
				const emailExists = await model.findOne({ email });

				if (emailExists) {
					const result = await model.findOneAndUpdate(
						{ email },
						{ otp: generatedOtp, expiresAt },
						{ new: true, upsert: true, runValidators: true }
					);
					// Implement your forgot email logic here
					return res.status(StatusCodes.OK).json({
						message: "OTP sent successfully!",
						result: { email: result.email, otp: result.otp, expiresAt: result.expiresAt }
					});
				} else {
					return res.status(StatusCodes.NOT_FOUND).json({
						message: MESSAGE.custom("Email not found!")
					});
				}
			}
			default: {
				return res.status(StatusCodes.NOT_FOUND).json({
					message: MESSAGE.custom("Invalid request type!")
				});
			}
		}
	} catch (error) {
		console.error("Error in email verification:", error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("Email verification failed!"),
			error
		});
	}
};

export const changePassword = async (req: Request, res: Response): Promise<any> => {
	try {
		const { email, old_password, new_password, confirm_password } = req.body;
		const user = await MemberModel.findOne({ email });
		if (!user) {
			return res.status(404).json({ message: "User not found" });
		}
		// Check if the old password is correct
		const oldPassword: string = user.password ?? "";
		console.log("oldPassword", oldPassword);

		const isMatch = await service.auth.comparePassword(old_password, oldPassword);
		// const isMatch = await service.auth.hashPassword(old_password);
		if (!isMatch) {
			return res.status(401).json({ message: "Old password is incorrect" });
		}
		// Check if new passwords match
		if (new_password !== confirm_password) {
			return res.status(400).json({ message: "New passwords do not match" });
		}
		// Update the password
		user.password = await service.auth.hashPassword(new_password); // This will be hashed in the pre-save hook
		await user.save();
		res.json({ message: "Password updated successfully" });
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};
