import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import { findEmailToUserDetails } from "../../../../services/common/commonFunction.service";
import memberDeleteModel from "../../../../model/memberDelete.model";
import memberModel from "../../../../model/member.model";
import { app } from "firebase-admin";
import appVersionSchema from "../../../../model/schemaDefiniton/appVersion.schema";
import appVersionModel from "../../../../model/appVersion.model";
export const memberSubscriptionStatus = async (req: Request, res: Response): Promise<any> => {
	try {
		const subscriptionStatus = await appVersionModel.find({}, { subscription_status: 1 });
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: subscriptionStatus
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};
export const memberSubscriptionStatusUpdate = async (req: Request, res: Response): Promise<any> => {
	try {
		const { vlu } = req.params;
		const subscriptionStatus = await appVersionModel.findOneAndUpdate(
			{}, // Empty filter to target the first document
			{ subscription_status: vlu }, // Update operation
			{ new: true, upsert: true } // Options: return the updated document, create if not found
		);
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: subscriptionStatus.subscription_status
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};
export const appVersionUpdate = async (req: Request, res: Response): Promise<any> => {
	try {
		const { type, vlu } = req.body;
		if (type == 'android') {
			const subscriptionStatus = await appVersionModel.findOneAndUpdate(
				{}, // Empty filter to target the first document
				{ app_version_android: vlu }, // Update operation
				{ new: true, upsert: true } // Options: return the updated document, create if not found
			);
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.get.succ,
				result: subscriptionStatus.app_version_android
			});
		} else if (type == 'ios') {
			const subscriptionStatus = await appVersionModel.findOneAndUpdate(
				{}, // Empty filter to target the first document
				{ app_version_ios: vlu }, // Update operation
				{ new: true, upsert: true } // Options: return the updated document, create if not found
			);
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.get.succ,
				result: subscriptionStatus.app_version_ios
			});
		}
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
}
export const appVersionChecking = async (req: Request, res: Response): Promise<any> => {
	try {
		const { type, vlu } = req.params;
		let subscriptionStatus;
		if (type == 'android') {
			subscriptionStatus = await appVersionModel.findOne({ app_version_android: vlu });
		} else if (type == 'ios') {
			subscriptionStatus = await appVersionModel.findOne({ app_version_ios: vlu });
		}
		const exists = !!subscriptionStatus; // Convert to boolean
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: exists
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};

export const deleteAccount = async (req: Request, res: Response): Promise<any> => {
	try {
		const fetchMemberId = await findEmailToUserDetails(req.user.email, req.user.role);

		//create member delete
		const memberDelete = new memberDeleteModel({
			member_object_id: fetchMemberId._id,
			member_id: fetchMemberId.member_id,
			first_name: fetchMemberId.first_name,
			middle_name: fetchMemberId.middle_name,
			last_name: fetchMemberId.last_name,
			email: fetchMemberId.email,
			otp: fetchMemberId.otp,
			expiresAt: fetchMemberId.expiresAt,
			user_name: fetchMemberId.user_name,
			password: fetchMemberId.password,
			date_of_birth: fetchMemberId.date_of_birth,
			gender: fetchMemberId.gender,
			phone_number: fetchMemberId.phone_number,
			phone_extension: fetchMemberId.phone_extension,
			role: fetchMemberId.role,
			company: fetchMemberId.company,
			address_line_1: fetchMemberId.address_line_1,
			address_line_2: fetchMemberId.address_line_2,
			city: fetchMemberId.city,
			state: fetchMemberId.state,
			ZIP: fetchMemberId.ZIP,
			country: fetchMemberId.country,
			contact_label: fetchMemberId.contact_label,
			member_status: fetchMemberId.member_status,
			is_verified: fetchMemberId.is_verified,
			is_registered: fetchMemberId.is_registered,
			is_subscribe: fetchMemberId.is_subscribe,
			devices_token: fetchMemberId.devices_token,
			date: fetchMemberId.date,
			last_login_date: fetchMemberId.last_login_date,
		}).save();

		//delete member
		const deleteMember = await memberModel.deleteOne({ _id: fetchMemberId._id });

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.delete.succ,
			result: fetchMemberId
		});

	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};
export const deleteAccountweb = async (req: Request, res: Response): Promise<any> => {
	try {

		const { email } = req.body;
		const fetchMemberId = await memberModel.findOne({ email: email }).lean();

		console.log("------------------", fetchMemberId);


		//create member delete
		const memberDelete = new memberDeleteModel({
			member_object_id: fetchMemberId?._id,
			member_id: fetchMemberId?.member_id,
			first_name: fetchMemberId?.first_name,
			middle_name: fetchMemberId?.middle_name,
			last_name: fetchMemberId?.last_name,
			email: fetchMemberId?.email,
			otp: fetchMemberId?.otp,
			expiresAt: fetchMemberId?.expiresAt,
			user_name: fetchMemberId?.user_name,
			password: fetchMemberId?.password,
			date_of_birth: fetchMemberId?.date_of_birth,
			gender: fetchMemberId?.gender,
			phone_number: fetchMemberId?.phone_number,
			phone_extension: fetchMemberId?.phone_extension,
			role: fetchMemberId?.role,
			company: fetchMemberId?.company,
			address_line_1: fetchMemberId?.address_line_1,
			address_line_2: fetchMemberId?.address_line_2,
			city: fetchMemberId?.city,
			state: fetchMemberId?.state,
			ZIP: fetchMemberId?.ZIP,
			country: fetchMemberId?.country,
			contact_label: fetchMemberId?.contact_label,
			member_status: fetchMemberId?.member_status,
			is_verified: fetchMemberId?.is_verified,
			is_registered: fetchMemberId?.is_registered,
			is_subscribe: fetchMemberId?.is_subscribe,
			devices_token: fetchMemberId?.devices_token,
			date: fetchMemberId?.date,
			last_login_date: fetchMemberId?.last_login_date,
		}).save();

		//delete member
		const deleteMember = await memberModel.deleteOne({ _id: fetchMemberId?._id });

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.delete.succ,
			result: fetchMemberId
		});

	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};