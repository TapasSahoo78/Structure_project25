import { Request, Response } from "express";
import { MESSAGE } from "../../../../../constants/message";
import { StatusCodes } from "http-status-codes";
import memberSubscriptionModel from "../../../../../model/memberSubscription.model";
import { processPayment } from "../../../../../services/payment/stripe.service";
import MemberSubscriptionModel from "../../../../../model/memberSubscription.model";
export const memberListSubscription = async (req: Request, res: Response): Promise<any> => {
	try {
		const { member_id } = req.params; // Extract member_id correctly
		const subscription = await MemberSubscriptionModel.find({ member_id });
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Subscription fetched successfully!"),
			result: subscription
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Subscription fetch unsuccessful!"),
			error
		});
	}
};
export const memberCreateSubscription = async (req: Request, res: Response): Promise<any> => {
	try {
		const { member_id, subscription_id, price } = req.body;
		const memberSubscription = await MemberSubscriptionModel.findOneAndUpdate(
			{ member_id }, // Find by member_id
			{
				subscription_id,
				price,
				status: "PENDING"
			},
			{ new: true, upsert: true } // Return the updated document, create if it doesn't exist
		);
		// Process payment
		let payment = await processPayment(
			member_id,
			subscription_id,
			"subscriptions",
			price,
			"DEBITED",
			"Your Amount Debited for Subscription",
			"PENDING",
			new Date().toISOString()
		);
		return res.status(StatusCodes.CREATED).json({
			message: MESSAGE.custom("Subscription created/updated successfully!"),
			data: { memberSubscription, payment }
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Subscription creation unsuccessful!"),
			error
		});
	}
};