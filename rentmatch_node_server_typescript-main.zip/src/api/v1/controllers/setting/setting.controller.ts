import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import slugify from "slugify";
import settingModel from "../../../../model/setting.model";
export const updateSetting = async (req: Request, res: Response): Promise<any> => {
	const { name, value, description } = req.body;
	try {
		// Generate the slug from the name
		const slug = slugify(name);
		// Upsert the setting in a single query
		const updatedSetting = await settingModel.findOneAndUpdate(
			{ slug }, // Query to find the setting
			{
				name,
				slug,
				value,
				description
			}, // Update data
			{
				new: true, // Return the updated document
				upsert: true // Create a new document if no document matches the query
			}
		);
		return res.status(StatusCodes.OK).json({
			message: "Setting created or updated successfully!",
			result: updatedSetting
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Dog updated unsuccessful!"),
			error
		});
	}
};
export const listSetting = async (req: Request, res: Response): Promise<any> => {
	try {
		const setting = await settingModel.find();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Setting fetch successfully!"),
			setting
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Setting fetch unsuccessful!"),
			error
		});
	}
};
export const editSetting = async (req: Request, res: Response): Promise<any> => {
	const { key } = req.params;
	// const { id } = req.params;
	try {
		const setting = await settingModel.find({ slug: key });
		// const setting = await settingModel.findById(id);
		if (!setting) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: MESSAGE.custom("Setting not found!")
			});
		}
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Setting updated successfully!"),
			data: setting
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Setting updated unsuccessful!"),
			error
		});
	}
};
