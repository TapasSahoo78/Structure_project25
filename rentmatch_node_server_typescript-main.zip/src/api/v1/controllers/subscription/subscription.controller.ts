import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import subscriptionModel from "../../../../model/subscription.model";
import slugify from "slugify";
import memberSubscriptionModel from "../../../../model/memberSubscription.model";
import SubscriptionModel from "../../../../model/subscription.model";

export const createSubscription = async (req: Request, res: Response): Promise<any> => {
	try {
		const { name, price, plan_type, duration, description, features } = req.body;
		const slugifiedTitle: string = slugify(name, {
			lower: true,
			strict: true,
			replacement: "_" // Use underscore as a separator
		});
		const subscription = new SubscriptionModel({
			name,
			plan_type,
			slug: slugifiedTitle,
			price,
			duration,
			description,
			features
		});
		const result = await subscription.save();
		return res.status(StatusCodes.CREATED).json({
			message: MESSAGE.custom("Subscription created successfully!"),
			data: result
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Subscription creation unsuccessful!"),
			error
		});
	}
};
export const listSubscription = async (req: Request, res: Response): Promise<any> => {
	try {

		// if()
		const subscription = await subscriptionModel.find();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Subscription fetched successfully!"),
			subscription
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Subscription fetch unsuccessful!"),
			error
		});
	}
};
export const editSubscription = async (req: Request, res: Response): Promise<any> => {
	// Logic for editing a subscription
	const updatedSubscription = await subscriptionModel.findById(req.params.id, req.body, { new: true });
	res.status(200).json(updatedSubscription);
};
export const updateSubscription = async (req: Request, res: Response): Promise<any> => {
	// Logic for updating a subscription
	const updatedSubscription = await subscriptionModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
	res.status(200).json(updatedSubscription);
};
export const deleteSubscription = async (req: Request, res: Response): Promise<any> => {
	// Logic for deleting a subscription
	await subscriptionModel.findByIdAndDelete(req.params.id);
	res.status(204).send();
};
export const allMemberlist = async (req: Request, res: Response): Promise<any> => {
	try {
		const subscription = await memberSubscriptionModel.find();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Total Member Subscription List fetched successfully!"),
			subscription
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Total Member Subscription List fetched unsuccessful!"),
			error
		});
	}
};
