import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import groupOwnerModel from "../../../../model/groupOwner.model";
import memberModel from "../../../../model/member.model";

export const changePassword = async (req: Request, res: Response): Promise<any> => {
	try {
		const { email, old_password, new_password, confirm_password } = req.body;

		const user = await memberModel.findOne({ email });
		if (!user) {
			return res.status(404).json({ message: "User not found" });
		}
		// Check if the old password is correct
		const oldPassword: string = user.password ?? "";

		const isMatch = await service.auth.comparePassword(old_password, oldPassword);
		// const isMatch = await service.auth.hashPassword(old_password);
		if (!isMatch) {
			return res.status(401).json({ message: "Old password is incorrect" });
		}

		// Check if new passwords match
		if (new_password !== confirm_password) {
			return res.status(400).json({ message: "New passwords do not match" });
		}

		// Update the password
		user.password = await service.auth.hashPassword(new_password); // This will be hashed in the pre-save hook
		await user.save();

		res.json({ message: "Password updated successfully" });
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};

export const getProfile = async (req: Request, res: Response): Promise<any> => {
	try {
		let role = req.user.role;
		let model: Model<any>,
			jwtPayload = {};

		if (role === ROLES.super_admin || role === ROLES.admin) {
			model = groupOwnerModel;
		} else if (role === ROLES.member) {
			model = memberModel;
		} else {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Unauthorised Role!")
			});
		}
		const userDetails = await model.findOne({
			email: req.user.email
		});

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: {
				userDetails
			}
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};


export const adminList = async (req: Request, res: Response): Promise<any> => {
	try {
		const dog = await groupOwnerModel.find({ role: "ADMIN" }).sort({ createdAt: -1 }).lean();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Admin fetch successfully!"),
			dog
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Admin fetch unsuccessful!"),
			error
		});
	}
};
export const ownerList = async (req: Request, res: Response): Promise<any> => {
	try {
		const dog = await groupOwnerModel.find({ role: "SUPER ADMIN" }).sort({ createdAt: -1 }).lean();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Owner fetch successfully!"),
			dog
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Owner fetch unsuccessful!"),
			error
		});
	}
};
export const memberList = async (req: Request, res: Response): Promise<any> => {
	try {
		const dog = await memberModel.find().sort({ createdAt: -1 }).lean();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Member fetch successfully!"),
			dog
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Member fetch unsuccessful!"),
			error
		});
	}
};

