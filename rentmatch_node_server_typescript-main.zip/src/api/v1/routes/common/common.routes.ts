// import express from "express";
// import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
// import { notifactionList, notifactionStatus, notifactionMarkAsRead } from "../../controllers/notifaction/notifaction.controller";
// import { memberSubscriptionStatus, deleteAccount, memberSubscriptionStatusUpdate, appVersionUpdate, appVersionChecking, deleteAccountweb } from "../../controllers/common/common.controller";

// const router = express.Router();
// module.exports = router; // Exporting the router

