// import express from "express";
// import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
// import {
// 	groupOwnerTotalCounts,
// 	announcementNotificationCartCounts,
// 	dashboardDetails
// } from "../../controllers/dashboard/dashboard.controller";
// const router = express.Router();
// router.route("/member/announcement-notification-cart-counts/:id").get(generalAuth, announcementNotificationCartCounts);
// router.route("/details/:type/:id?").get(generalAuth, dashboardDetails);
// //Admin Dashboard
// router.route("/group-owner/total-counts/").get(generalAuth, groupOwnerTotalCounts);
// module.exports = router; // Exporting the router
