import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import registration from "../../controllers/auth/registration";
import { validators } from "../../validators";

// 
import groupOwnerAuth from "../../../../middlewares/auth/groupOwnerAuth.middleware";

import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import { createSubscription, deleteSubscription, editSubscription, listSubscription, updateSubscription } from "../../controllers/subscription/subscription.controller";
import { categoryCreate, categoryDelete, categoryDetails, categoryList, categoryUpdate } from "../../controllers/GroupOwner/category/category.controller";

const router = express.Router();
//Subscription
router.route("/subscription/add").post(groupOwnerAuth, createSubscription);
router.route("/subscription/list").get(groupOwnerAuth, listSubscription);
router.route("/subscription/edit/:id?").get(groupOwnerAuth, editSubscription);
router.route("/subscription/:id?").put(groupOwnerAuth, updateSubscription);
router.route("/subscription/:id?").delete(groupOwnerAuth, deleteSubscription);

//Category
router.route("category").get(groupOwnerAuth, categoryList);
router.route("category/:id").get(groupOwnerAuth, categoryDetails);
router.route("category").post(groupOwnerAuth, categoryCreate);
router.route("category").put(groupOwnerAuth, categoryUpdate);
router.route("category").delete(groupOwnerAuth, categoryDelete);




module.exports = router;