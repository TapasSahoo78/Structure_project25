import express from "express";

const app = express();

app.use("/auth", require("./auth/auth.routes"));
app.use("/group-owner", require("./group-owner/group-owner.routes"));

// app.use("/member", require("./member/member.routes"));
// app.use("/user-managment", require("./userManagment/userManagment.routes"));
// app.use("/dashboard", require("./dashboard/dashboard.routes"));
// app.use("/setting", require("./setting/setting.routes"));
// app.use("/test", require("./test/test.route"));
// app.use("/common", require("./common/common.routes"));
// app.use("/notifaction", require("./notifaction/notifaction.route"));
// app.use("/cms-page", require("./cms/cms.routes"));

module.exports = app;

