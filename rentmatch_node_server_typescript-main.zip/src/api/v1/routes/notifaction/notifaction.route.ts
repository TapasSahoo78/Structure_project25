// import express from "express";
// import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
// import { notifactionList, notifactionStatus, notifactionMarkAsRead } from "../../controllers/notifaction/notifaction.controller";

// const router = express.Router();

// module.exports = router; // Exporting the router
// //make a route for update status notifaction
// router.route("/send-notifaction-list/:id").get(generalAuth, notifactionList);
// router.route("/update-status-notifaction/:id").patch(generalAuth, notifactionStatus);
// router.route("/notifaction-mark-as-read/:memberId").patch(generalAuth, notifactionMarkAsRead);