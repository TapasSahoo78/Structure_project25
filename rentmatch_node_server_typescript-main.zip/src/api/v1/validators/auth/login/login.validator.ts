import Joi from "joi";
import { ROLES } from "../../../../../constants/roles/roles";

export const loginValidator = Joi.object({
	role: Joi.string()
		.required()
		.valid(
			ROLES.super_admin,
			ROLES.admin,
			ROLES.property_manager,
			ROLES.landlord,
			ROLES.tenant,
			ROLES.guest
		),

	// Conditional fields based on role
	user_id: Joi.when('role', {
		is: ROLES.guest,
		then: Joi.forbidden(), // not allowed for guest
		otherwise: Joi.string().required(),
	}),

	password: Joi.when('role', {
		is: ROLES.guest,
		then: Joi.forbidden(),
		otherwise: Joi.string().required(),
	}),

	devices_token: Joi.when('role', {
		is: ROLES.guest,
		then: Joi.forbidden(),
		otherwise: Joi.string().optional(),
	}),

	guset_token: Joi.when('role', {
		is: ROLES.guest,
		then: Joi.string().optional().allow(null),
		otherwise: Joi.forbidden(), // not allowed for non-guests
	}),
});