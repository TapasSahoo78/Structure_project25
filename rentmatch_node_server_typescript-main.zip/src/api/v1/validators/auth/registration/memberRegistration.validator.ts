import Joi from "joi";
import { ROLES } from "../../../../../constants/roles/roles";
import { GENDER } from "../../../../../constants/gender/gender";
import { CONTACT_LABEL } from "../../../../../constants/contactLabel/contactLabel";
import { EMPLOYEE_STATUS } from "../../../../../constants/customerStatus/employeeStatus";

export const memberRegistrationValidator = Joi.object({
	first_name: Joi.string().min(1).max(50).required(),
	middle_name: Joi.string().allow("").max(50),
	last_name: Joi.string().min(1).max(50).required(),
	email: Joi.string().email().required(),
	user_name: Joi.string().alphanum().min(3).max(30).required(),
	password: Joi.string().min(6).max(100).required(),
	date_of_birth: Joi.date().required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).required(),
	phone_number: Joi.string()
		.pattern(/^[0-9]+$/)
		.min(10)
		.max(15)
		.required(),
	phone_extension: Joi.string().allow("").optional(),
	role: Joi.string().valid(ROLES.member).required(),
	company: Joi.string().max(100).allow(""),
	address_line_1: Joi.string().max(100).required(),
	address_line_2: Joi.string().max(100).allow(""),
	city: Joi.string().max(50).required(),
	state: Joi.string().max(50).required(),
	ZIP: Joi.string()
		.length(6)
		.pattern(/^[0-9]+$/)
		.required(),
	country: Joi.string().max(50).required(),
	contact_label: Joi.string()
		.valid(
			CONTACT_LABEL.home,
			CONTACT_LABEL.business,
			CONTACT_LABEL.mail,
			CONTACT_LABEL.mobile,
			CONTACT_LABEL.other
		)
		.required()
});
