import Joi from "joi";
import { ROLES } from "../../../../../constants/roles/roles";
import { GENDER } from "../../../../../constants/gender/gender";
import { CONTACT_LABEL } from "../../../../../constants/contactLabel/contactLabel";
import { EMPLOYEE_STATUS } from "../../../../../constants/customerStatus/employeeStatus";

export const superAdminregistrationValidator = Joi.object({
	token: Joi.string().required(),
	role: Joi.string().valid(ROLES.super_admin).optional(),
	first_name: Joi.string().min(1).max(30).required(),
	middle_name: Joi.string().allow("", null).max(30),
	last_name: Joi.string().min(1).max(30).required(),
	user_name: Joi.string().alphanum().min(3).max(30).optional(),
	password: Joi.string().min(6).max(100).required(),
	email: Joi.string().email().required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).optional(),
	address_line_1: Joi.string().max(100).optional(),
	address_line_2: Joi.string().allow("").max(100),
	city: Joi.string().max(50).optional(),
	state: Joi.string().max(50).optional(),
	country: Joi.string().max(50).optional(),
	zip: Joi.string()
		.length(6)
		.pattern(/^[0-9]+$/)
		.optional(),
	contact_label: Joi.string()
		.valid(
			CONTACT_LABEL.home,
			CONTACT_LABEL.business,
			CONTACT_LABEL.mail,
			CONTACT_LABEL.mobile,
			CONTACT_LABEL.other
		)
		.optional(),
	phone_number: Joi.string()
		.pattern(/^[0-9]+$/)
		.optional(),
	phone_extension: Joi.string().allow("").optional()
});

export const registrationValidator = Joi.object({
	role: Joi.string().valid(ROLES.admin).required(),
	first_name: Joi.string().min(1).max(30).required(),
	middle_name: Joi.string().allow("").max(30),
	last_name: Joi.string().min(1).max(30).required(),
	user_name: Joi.string().alphanum().min(3).max(30).required(),
	password: Joi.string().min(6).max(100).required(),
	email: Joi.string().email().required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).required(),
	address_line_1: Joi.string().max(100).required(),
	address_line_2: Joi.string().allow("").max(100),
	city: Joi.string().max(50).required(),
	state: Joi.string().max(50).required(),
	country: Joi.string().max(50).required(),
	zip: Joi.string()
		.length(6)
		.pattern(/^[0-9]+$/)
		.required(),
	contact_label: Joi.string()
		.valid(
			CONTACT_LABEL.home,
			CONTACT_LABEL.business,
			CONTACT_LABEL.mail,
			CONTACT_LABEL.mobile,
			CONTACT_LABEL.other
		)
		.required(),
	phone_number: Joi.string()
		.pattern(/^[0-9]+$/)
		.required(),
	phone_extension: Joi.string().allow("").optional()
});
export const memberRegistrationValidator = Joi.object({
	first_name: Joi.string().min(1).max(50).required(),
	middle_name: Joi.string().allow("").max(50),
	last_name: Joi.string().min(1).max(50).required(),
	email: Joi.string().email().required(),
	user_name: Joi.string().alphanum().min(3).max(30).required(),
	password: Joi.string().min(6).max(100).required(),
	date_of_birth: Joi.date().required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).required(),
	phone_number: Joi.string()
		.pattern(/^[0-9]+$/)
		.min(10)
		.max(15)
		.required(),
	phone_extension: Joi.string().allow("").optional(),
	role: Joi.string().valid(ROLES.property_manager, ROLES.landlord, ROLES.tenant).required(),
	company: Joi.string().max(100).allow(""),
	address_line_1: Joi.string().max(100).required(),
	address_line_2: Joi.string().max(100).allow(""),
	city: Joi.string().max(50).required(),
	state: Joi.string().max(50).required(),
	zip: Joi.string()
		.length(6)
		.pattern(/^[0-9]+$/)
		.required(),
	country: Joi.string().max(50).required(),
	contact_label: Joi.string()
		.valid(
			CONTACT_LABEL.home,
			CONTACT_LABEL.business,
			CONTACT_LABEL.mail,
			CONTACT_LABEL.mobile,
			CONTACT_LABEL.other
		)
		.required()
});

export const emailVerificationValidator = Joi.object({
	role: Joi.string().valid(ROLES.super_admin, ROLES.admin, ROLES.property_manager, ROLES.landlord, ROLES.tenant).allow(''),
	type: Joi.string().valid('email', 'otp', 'password', 'veryemail', 'forgotemail').required(),
	email: Joi.string().email().when('type', {
		is: 'otp', // When type is 'otp'
		then: Joi.optional(), // Email is optional when type is 'otp'
		otherwise: Joi.required() // Email is required when type is 'email'
	}),
	otp: Joi.string().allow('').when('type', {
		is: 'otp', // When type is 'otp'
		then: Joi.required(), // OTP is required
		otherwise: Joi.forbidden() // OTP should not be present when type is 'email'
	}),
	password: Joi.string().allow('').when('type', {
		is: 'password', // When type is 'password'
		then: Joi.required(), // Password is required
		otherwise: Joi.forbidden() // Password should not be present when type is 'email or otp'
	}),
	confirmPassword: Joi.string().allow('').when('type', {
		is: 'password', // When type is 'password'
		then: Joi.required(), // Confirm Password is required
		otherwise: Joi.forbidden() // Confirm Password should not be present when type is 'email or otp'
	})
});


export const changePasswordValidator = Joi.object({
	email: Joi.string().email().required(),
	old_password: Joi.string().min(6).max(100).required(),
	new_password: Joi.string().min(6).max(100).required(),
	confirm_password: Joi.string().min(6).max(100).required()
});

export const adminEntryValidator = Joi.object({
	first_name: Joi.string().min(1).max(30).required(),
	last_name: Joi.string().min(1).max(30).required(),
	password: Joi.string().min(6).max(100).required(),
	email: Joi.string().email().required()
});


export const checkDashboardDetailsValidation = Joi.object({
	type: Joi.string().valid("member", "group-owner").required(),
	// when type is member then member_id is required
	member_id: Joi.string().when("type", {
		is: "member", // When type is 'member'
		then: Joi.required(), // member_id is required
		otherwise: Joi.forbidden() // member_id should not be present when type is 'group-owner'
	})
});