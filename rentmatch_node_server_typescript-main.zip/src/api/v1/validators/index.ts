import { loginValidator } from "./auth/login/login.validator";
import {
	superAdminregistrationValidator,
	registrationValidator,
	memberRegistrationValidator,
	emailVerificationValidator,
	changePasswordValidator,
	adminEntryValidator, checkDashboardDetailsValidation
} from "./auth/registration/registration.validator";
import { subscriptionValidator } from "./subscription/subscription.validator";
import { memberSubscriptionValidator } from "./member/subscription/memberSubscription.validator";
import { userValidator } from "./user/user.validator";

import { contactUsValidator } from "./markiting/markiting.validator";

export const validators = {
	loginValidator,
	superAdminregistrationValidator,
	registrationValidator,
	memberRegistrationValidator,
	emailVerificationValidator,
	changePasswordValidator,
	subscriptionValidator,
	memberSubscriptionValidator,
	userValidator,
	adminEntryValidator,

	contactUsValidator,
	checkDashboardDetailsValidation
};
