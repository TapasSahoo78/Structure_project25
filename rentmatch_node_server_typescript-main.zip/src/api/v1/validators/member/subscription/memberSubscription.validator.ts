import Joi from "joi";

export const memberSubscriptionValidator = Joi.object({
	member_id: Joi.string().required(), // Assuming member_id is a string
	subscription_id: Joi.string().required(), // Assuming subscription_id is a string
	price: Joi.number().positive().required() // Positive number for price
});
