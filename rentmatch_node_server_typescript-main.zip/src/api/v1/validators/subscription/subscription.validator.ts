import Joi from "joi";

export const subscriptionValidator = Joi.object({
	name: Joi.string().trim().max(50).required(),
	price: Joi.number().positive().required(),
	type: Joi.string().optional(),
	duration: Joi.number()
		.positive()
		.required()
		.min(1) // Minimum value
		.max(12),
	description: Joi.string().trim().max(200), // Adjusted to allow longer descriptions.required(),
	status: Joi.boolean().default(true) // Default value
});
