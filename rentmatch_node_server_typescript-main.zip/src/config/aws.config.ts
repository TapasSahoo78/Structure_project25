import { S3Client } from "@aws-sdk/client-s3";
import { NODE_ENV } from "./config";
const credential: any = {
	accessKeyId: String(NODE_ENV) === "PROD" ?
		process.env.AWS_PROD_ACCESS_KEY_ID :
		(String(NODE_ENV) === "DEV" || String(NODE_ENV) === "LOCAL" || String(NODE_ENV) === "LOCAL_ATLAS") ?
			process.env.AWS_DEV_ACCESS_KEY_ID : "",
	secretAccessKey: String(NODE_ENV) === "PROD" ?
		process.env.AWS_PROD_SECRET_ACCESS_KEY :
		(String(NODE_ENV) === "DEV" || String(NODE_ENV) === "LOCAL" || String(NODE_ENV) === "LOCAL_ATLAS") ?
			process.env.AWS_DEV_SECRET_ACCESS_KEY : ""
};

export const s3Client = new S3Client({
	region: String(NODE_ENV) === "PROD" ?
		process.env.s3_PROD_REGION : (String(NODE_ENV) === "DEV" || String(NODE_ENV) === "LOCAL" || String(NODE_ENV) === "LOCAL_ATLAS") ?
			process.env.s3_DEV_REGION : "", credentials: credential
});

export const s3Url = String(NODE_ENV) === "PROD" ?
	process.env.s3_PROD_URL : (String(NODE_ENV) === "DEV" || String(NODE_ENV) === "LOCAL" || String(NODE_ENV) === "LOCAL_ATLAS") ?
		process.env.s3_DEV_URL : "";

export const bucketName = String(NODE_ENV) === "PROD" ?
	process.env.s3_PROD_BUCKET_NAME : (String(NODE_ENV) === "DEV" || String(NODE_ENV) === "LOCAL" || String(NODE_ENV) === "LOCAL_ATLAS") ?
		process.env.s3_DEV_BUCKET_NAME : ""; 
