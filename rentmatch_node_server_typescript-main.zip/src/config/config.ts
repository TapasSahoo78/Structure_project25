export const NODE_ENV: "PROD" | "DEV" | "LOCAL" | "LOCAL_ATLAS" = "LOCAL"; // Change to PROD or DEV or LOCAL_ATLAS as needed

export const MONGO_URI = {
    LOCAL: "mongodb://127.0.0.1:27017/Rent_Management_Portal",
    LOCAL_ATLAS: "",
    DEV: `mongodb://${process.env.DEV_MONGODB_USERNAME}:${process.env.DEV_MONGODB_PASSWORD}@${process.env.DEV_MONGODB_LOCALHOST}:${process.env.DEV_MONGODB_PORT}/${process.env.DEV_MONGODB_DATABASE_NAME}?authSource=${process.env.DEV_MONGODB_DATABASE_NAME}&directConnection=true`,
    PROD: `mongodb://${process.env.PROD_MONGODB_USERNAME}:${process.env.PROD_MONGODB_PASSWORD}@${process.env.PROD_MONGODB_LOCALHOST}:${process.env.PROD_MONGODB_PORT}/${process.env.PROD_MONGODB_DATABASE_NAME}?authSource=${process.env.PROD_MONGODB_DATABASE_NAME}&directConnection=true`
};

// Local, Devlopment and Production GreyhoundManagement Portal URL
export const localGreyhoundManagementUrl = "http://localhost:3000";
export const testGreyhoundManagementUrl = "";
export const devGreyhoundManagementUrl = "https://mgps-frontend.shyamfuture.in/";
export const prodGreyhoundManagementUrl = "";

let emailLoginUrl: string = ""; //Has to change in Production and Test Production
if (String(NODE_ENV) === "PROD") {
    emailLoginUrl = `${prodGreyhoundManagementUrl}/`;
} else if (String(NODE_ENV) === "DEV") {
    emailLoginUrl = `${devGreyhoundManagementUrl}/`;
} else if (String(NODE_ENV) === "LOCAL") {
    emailLoginUrl = `${localGreyhoundManagementUrl}/`;
}
export { emailLoginUrl };

export const GREYHOUND_MANAGEMENT_PORTAL_LINK = emailLoginUrl;

export const mongoDump = {
    host: String(NODE_ENV) == "PROD" ? "127.0.0.1" : "localhost",
    port: 27017,
    database: "Greyhound_Management_Portal",
    outputDir: String(NODE_ENV) == "PROD" ? "" : __dirname + "../../../database_backup"
};

//Client Test Stripe Secret Key
export const STRIPE_SECRET_KEY = process.env.LIVE_STRIPE_SECRET_KEY