export const employeeActivity = {
	login: "LOGIN"
};

export const employeeActivityLogStatus = {
	pass: "PASS",
	fail: "FAIL",
	warning: "WARNING"
};

export const employeeActivityLogDescription = {
	login_successful: "Login Successfull!",
	login_unsuccessful: "Login Unsuccessfull due to Server Error!",
	password_incorrect: "Password Incorrect!",
	term_login_employee: "Term employee tried to Login!",
	unregistered_login_employee: "Unregistered employee tried to Login!"
};


export const notifactionStatus = {
	read: "READ",
	unread: "UNREAD",
	all: "ALL"
}
export const NOTIFACTIONSTATUS = notifactionStatus;
