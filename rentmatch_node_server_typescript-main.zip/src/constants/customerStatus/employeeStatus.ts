export const EMPLOYEE_STATUS = {
	active: "ACTIVE",
	inactive: "INACTIVE"
};

export const SUBSCRIPTION_STATUS = {
	pending: "PENDING",
	active: "ACTIVE",
	inactive: "INACTIVE",
	cancelled: "CANCELLED"
};
export const TRANSACTION_STATUS = {
	pending: "PENDING",
	success: "SUCCESS",
	cancel: "CANCEL"
};
export const TRANSACTION_TYPE = {
	credited: "CREDITED",
	debited: "DEBITED"
};
