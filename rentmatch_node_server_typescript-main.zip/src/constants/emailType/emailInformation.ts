// constants for email information

const emailInformation = {
	phone_number: "8017579828",
	ext: "+91"
};

export const EMAIL_INFORMATION = emailInformation;
