const EmailType = {
	verification: "VERIFICATION",
	change_Password: "CHANGE PASSWORD",
	forget_user_name: "FORGET USERNAME",
	forget_password: "FORGET PASSWORD"
};

export const EMAIL_TYPE = EmailType;
