const generalSchemaOptions = {
	timestamps: true,
	validateBeforeSave: true
};

export const GENERAL_SCHEMA_OPTIONS = generalSchemaOptions;
