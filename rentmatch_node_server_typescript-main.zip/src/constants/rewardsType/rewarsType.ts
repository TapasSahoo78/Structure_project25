export const REWARDS_TYPES = {
	gifts: "GIFTS",
	points: "POINTS"
};
