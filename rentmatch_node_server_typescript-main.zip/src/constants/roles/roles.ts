export const roles = {
	super_admin: "SUPER ADMIN",
	admin: "ADMIN",
	member: "MEMBER",
	landlord: "LANDLORD",
	property_manager: "PROPERTY MANAGER",
	tenant: "TENANT",
	guest: "GUEST"
};

export const ROLES = roles;
