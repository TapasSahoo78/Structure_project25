import app from "../../app";

export const STATUS = {
	active: "ACTIVE",
	inactive: "INACTIVE"
};

export const SUBSCRIPTION_STATUS = {
	pending: "PENDING",
	active: "ACTIVE",
	inactive: "INACTIVE",
	cancelled: "CANCELLED"
};
export const TRANSACTION_STATUS = {
	pending: "PENDING",
	success: "SUCCESS",
	cancel: "CANCEL"
};
export const TRANSACTION_TYPE = {
	credited: "CREDITED",
	debited: "DEBITED"
};
export const COMPETITION_STATUS = {
	pending: "PENDING",
	approved: "APPROVED",
	active: "ACTIVE",
	completed: "COMPLETED",
	rejected: "REJECTED",
	ongoing: "ONGOING",
	upcoming: "UPCOMING",
}

export const NOTIFACTION_STATUS = {
	read: "READ",
	unread: "UNREAD",
	all: "ALL"
}
export const PAYMENT_STATUS = {
	pending: "PENDING",
	paid: "PAID",
	unpaid: "UNPAID",
	failed: "FAILED"
}
export const PARTICIPATION_STATUS = {
	participating: "PARTICIPATING",
	participated: "PARTICIPATED",
	eliminated: "ELIMINATED",
	winner: "WINNER"
}

export const PRIZE_TYPES = {
	money: "MONEY",
	gift: "GIFT",
	both: "BOTH"
}

export const MEMBER_STATUS = {
	pending: "PENDING",
	approved: "APPROVED",
	rejected: "REJECTED"
}


export const ROUND_STATUS = {
	upcoming: "UPCOMING",
	ongoing: "ONGOING",
	completed: "COMPLETED",
	cancelled: "CANCELLED",
	saved: "SAVED",
	live: "LIVE",
	ended: "ENDED"
};


export const VOTING_TYPE = {
	unlimited: "UNLIMITED",
	restricted: "RESTRICTED",
	restricted_duration: "RESTRICTED_DURATION"
}
export const SUBSCRIPTION_TYPE = {
	property_owner: "PROPERTY OWNER",
	property_manager: "PROPERTY MANAGER"
}

