import { Request, Response, NextFunction } from "express";
import { StatusCodes } from "http-status-codes";
import jwt from "jsonwebtoken";
import { Model } from "mongoose";
import { MESSAGE } from "../../constants/message";
import { ROLES } from "../../constants/roles/roles";
import groupOwnerModel from "../../model/groupOwner.model";
import memberModel from "../../model/member.model";

export const generalAuth = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
	try {
		if (!req.headers.authorization) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		const token = req.headers.authorization.replace("Bearer ", "");

		if (!token) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		if (!process.env.JWT_KEY) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Token not found")
			});
		}

		const decoded = jwt.verify(token, process.env.JWT_KEY) as Record<string, unknown>;

		if (!(decoded.role === ROLES.super_admin || decoded.role === ROLES.admin || decoded.role === ROLES.member)) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. Invalid Token!"),
				token: req.header("token")
			});
		}

		req.user = decoded; // setting a property of the request object with decoded string. It will be used to be validated against the valid user or member details
		req.user["read_access"] = false;
		req.user["write_access"] = false;
		// so userData or memberData contains _id, user_name, SSN and date_of_birth packed in JWT created in member login route.
		if (req.user.role === ROLES.super_admin) {
			const { _id } = req.user;
			//const filter = { _id }
			req.user.write_access = req.user.read_access = true;
			const data = await groupOwnerModel.findOne({
				$and: [{ _id }, { role: ROLES.super_admin }]
			});

			req.user.info = data;
		} else if (req.user.role === ROLES.admin) {
			const { _id } = req.user;
			//const filter = { _id }
			const data = await groupOwnerModel.findOne({
				$and: [{ _id }, { role: ROLES.admin }]
			});

			req.user.info = data;
		} else if (req.user.role === ROLES.member) {
			const { _id } = req.user;
			//const filter = { _id }
			const data = await memberModel.findOne({
				$and: [{ _id }, { role: ROLES.member }]
			});

			req.user.info = data;
		}

		next();
	} catch (error) {
		console.log("error", error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Invalid Token!"),
			error: error,
			token: req.header("token")
		});
	}
};

export default generalAuth;
