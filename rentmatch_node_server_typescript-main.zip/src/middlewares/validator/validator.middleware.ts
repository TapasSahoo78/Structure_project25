import { NextFunction, Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { ArraySchema, ObjectSchema } from "joi";
import { MESSAGE } from "../../constants/message";

const validator = (validationSchema: ObjectSchema | ArraySchema, parseProperty: string | null = null): any => {
	return async (req: Request, res: Response, next: NextFunction) => {
		try {
			let payload;
			if (parseProperty) {
				payload = JSON.parse(req.body[parseProperty]);
			} else {
				payload = req.body;
			}
			const { error } = validationSchema.validate(payload);
			if (error) {
				throw error;
			}
			next();
		} catch (err) {
			// throw err;
			return res.status(StatusCodes.BAD_REQUEST).json({ err, message: MESSAGE.custom("Invalid payload") });
		}
	};
};

export default validator;
