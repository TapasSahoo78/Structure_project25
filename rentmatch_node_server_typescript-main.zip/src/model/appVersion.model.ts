import { model } from "mongoose";
import { ISetting } from "../@types/interfaces/setting.interface";
import settingSchema from "./schemaDefiniton/setting.schema";
import { IAppVersion } from "../@types/interfaces/appVersion.interface";
import appVersionSchema from "./schemaDefiniton/appVersion.schema";

const AppVersionModel = model<IAppVersion>("app_versions", appVersionSchema);

export default AppVersionModel;
