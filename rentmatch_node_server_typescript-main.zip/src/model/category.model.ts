import { model } from "mongoose";
import memberSchema from "./schemaDefiniton/member.schema";
import { IMember } from "../@types/interfaces/member.interface";
import categorySchema from "./schemaDefiniton/category.schema";
import { ICategory } from "../@types/interfaces/category.interface";

const CategoryModel = model<ICategory>("categorys", categorySchema);

export default CategoryModel;
