import { model } from "mongoose";
import { IGroupOwner } from "../@types/interfaces/groupOwnerSchema.interface";
import groupOwnerSchema from "./schemaDefiniton/groupOwner.schema";

const GroupOwnerModel = model<IGroupOwner>("group_owners", groupOwnerSchema);

export default GroupOwnerModel;
