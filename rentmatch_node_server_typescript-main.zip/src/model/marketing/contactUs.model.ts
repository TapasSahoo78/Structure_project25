import { model } from "mongoose";
import { IContactUs } from "../../@types/interfaces/marketing/contactUs.interface";
import contactUsSchema from "../schemaDefiniton/marketing/contactUs.schema";

const contactUsModel = model<IContactUs>("contact_us", contactUsSchema);

export default contactUsModel;
