import { model } from "mongoose";
import memberSchema from "./schemaDefiniton/member.schema";
import { IMember } from "../@types/interfaces/member.interface";
import memberDeleteSchema from "./schemaDefiniton/memberDelete.schema";
import { IMemberDelete } from "../@types/interfaces/memberDelete.interface";

const MemberDeleteModel = model<IMemberDelete>("member_deletes", memberDeleteSchema);

export default MemberDeleteModel;
