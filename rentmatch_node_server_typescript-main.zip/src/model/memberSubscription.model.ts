import { model } from "mongoose";
import memberSubscriptionSchema from "./schemaDefiniton/memberSubscription.schema";
import { IMemberSubscription } from "../@types/interfaces/memberSubscription.interface";

const MemberSubscriptionModel = model<IMemberSubscription>("member_subscription", memberSubscriptionSchema);

export default MemberSubscriptionModel;
