import { model } from "mongoose";
import notifactionSchema from "./schemaDefiniton/notifaction.schema";
import { INotifaction } from "../@types/interfaces/notifaction.interface";

const NotifactionModel = model<INotifaction>("notifactions", notifactionSchema);

export default NotifactionModel;
