import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ISetting } from "../../@types/interfaces/setting.interface";
import { IAppVersion } from "../../@types/interfaces/appVersion.interface";

const appVersionSchema: Schema<IAppVersion> = new Schema<IAppVersion>({
	app_version_android: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		min: [1, "App version 1"] // Added minimum validation
	},
	app_version_ios: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		min: [1, "App version 1"] // Added minimum validation
	},
	type: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
		enum: ["android", "ios"]
	},
	subscription_status: {
		...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		default: true// Added minimum validation
	}
});

export default appVersionSchema;
