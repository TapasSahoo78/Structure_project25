import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ISetting } from "../../@types/interfaces/setting.interface";
import { STATUS } from "../../constants/status/status";
import { ICategory } from "../../@types/interfaces/category.interface";

const categorySchema: Schema<ICategory> = new Schema<ICategory>({
	name: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		min: [0, "Wallet Widthdrawal Limit must be a positive number"] // Added minimum validation
	},
	slug: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString
	},

	description: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString
	},
	status: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [STATUS.active, STATUS.inactive],
		default: STATUS.active
	}
});

export default categorySchema;
