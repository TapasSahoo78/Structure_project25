import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../../constants/model/model.constant";

import { IContactUs } from "../../../@types/interfaces/marketing/contactUs.interface";

const contactUsSchema: Schema<IContactUs> = new Schema<IContactUs>(
	{
		name: SCHEMA_DEFINITION_PROPERTY.requiredString, // Auto generated for workers and adminstrator member
		email: SCHEMA_DEFINITION_PROPERTY.requiredString,
		phone: SCHEMA_DEFINITION_PROPERTY.requiredString,
		description: SCHEMA_DEFINITION_PROPERTY.requiredString
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default contactUsSchema;
