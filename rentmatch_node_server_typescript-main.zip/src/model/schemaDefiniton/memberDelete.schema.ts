import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { IMember } from "../../@types/interfaces/member.interface";
import { ROLES } from "../../constants/roles/roles";
import { GENDER } from "../../constants/gender/gender";
import { EMPLOYEE_STATUS } from "../../constants/customerStatus/employeeStatus";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { COUNTRY } from "../../constants/country/employeeCountry";
import { IMemberDelete } from "../../@types/interfaces/memberDelete.interface";

const memberDeleteSchema: Schema<IMemberDelete> = new Schema<IMemberDelete>(
	{
		member_object_id: SCHEMA_DEFINITION_PROPERTY.requiredString, // Auto generated for workers and adminstrator member
		member_id: SCHEMA_DEFINITION_PROPERTY.optionalNullString, // Auto generated for workers and adminstrator member
		first_name: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			trim: true,
			maxlength: [50, "First Name cannot be more than 50 characters"]
		},
		middle_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		last_name: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			trim: true,
			maxlength: [50, "First Name cannot be more than 50 characters"]
		},
		// date_of_birth: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		date_of_birth: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		gender: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [GENDER.male, GENDER.female, GENDER.others, null]
		},
		otp: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		expiresAt: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		phone_extension: SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		phone_number: SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		email: SCHEMA_DEFINITION_PROPERTY.requiredString,
		user_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		password: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		role: { ...SCHEMA_DEFINITION_PROPERTY.requiredString, enum: [ROLES.member] },
		address_line_1: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		address_line_2: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		city: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		state: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		ZIP: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		devices_token: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		is_subscribe: SCHEMA_DEFINITION_PROPERTY.optionalBoolean,
		is_registered: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		country: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			default: COUNTRY
		},
		contact_label: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [
				CONTACT_LABEL.business,
				CONTACT_LABEL.home,
				CONTACT_LABEL.mail,
				CONTACT_LABEL.mobile,
				CONTACT_LABEL.other,
				null
			]
		},
		member_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [EMPLOYEE_STATUS.active, EMPLOYEE_STATUS.inactive, null]
		},
		is_verified: {
			...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
			default: false
		},
		date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
			default: Date.now
		},
		last_login_date: SCHEMA_DEFINITION_PROPERTY.optionalNullDate
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default memberDeleteSchema;
