import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { IMember } from "../../@types/interfaces/member.interface";
import { ROLES } from "../../constants/roles/roles";
import { EMPLOYEE_STATUS, SUBSCRIPTION_STATUS } from "../../constants/customerStatus/employeeStatus";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { IMemberSubscription } from "../../@types/interfaces/memberSubscription.interface";

const memberSubscriptionSchema: Schema<IMemberSubscription> = new Schema<IMemberSubscription>({
	member_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: "member"
	},
	subscription_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: "subscription"
	},
	price: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
		min: [0, "Price must be a positive number"] // Added minimum validation
	},
	date: {
		...SCHEMA_DEFINITION_PROPERTY.requiredDate,
		default: Date.now
	},
	status: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [
			SUBSCRIPTION_STATUS.pending,
			SUBSCRIPTION_STATUS.active,
			SUBSCRIPTION_STATUS.inactive,
			SUBSCRIPTION_STATUS.cancelled,
			null
		]
	}
});

export default memberSubscriptionSchema;
