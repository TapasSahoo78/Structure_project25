import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ISetting } from "../../@types/interfaces/setting.interface";
import { INotifaction } from "../../@types/interfaces/notifaction.interface";
import { ROLES } from "../../constants/roles/roles";
import { NOTIFACTIONSTATUS } from "../../constants/activityLog/activityLog";

const notifactionSchema: Schema<INotifaction> = new Schema<INotifaction>({
	title: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		min: [0, "Wallet Widthdrawal Limit must be a positive number"] // Added minimum validation
	},
	message: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		min: [0, "Wallet Widthdrawal Limit must be a positive number"] // Added minimum validation
	},
	created_at: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		min: [0, "Wallet Widthdrawal Limit must be a positive number"] // Added minimum validation
	},
	status: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [NOTIFACTIONSTATUS.read, NOTIFACTIONSTATUS.unread, NOTIFACTIONSTATUS.all],
		default: NOTIFACTIONSTATUS.unread // Default value set to unread
	},
	member_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		ref: "members"
	},
	group_owner_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		ref: "group_owners"
	},
	user_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
	}
});

export default notifactionSchema;
