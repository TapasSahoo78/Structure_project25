import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ISetting } from "../../@types/interfaces/setting.interface";

const settingSchema: Schema<ISetting> = new Schema<ISetting>({
	name: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		min: [0, "Wallet Widthdrawal Limit must be a positive number"] // Added minimum validation
	},
	slug: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString
	},
	value: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		min: [0, "Price must be a positive number"] // Added minimum validation
	},
	description: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString
	}
});

export default settingSchema;
