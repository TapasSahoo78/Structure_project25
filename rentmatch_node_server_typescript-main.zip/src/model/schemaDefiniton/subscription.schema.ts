import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { IMember } from "../../@types/interfaces/member.interface";
import { ROLES } from "../../constants/roles/roles";
import { GENDER } from "../../constants/gender/gender";
import { EMPLOYEE_STATUS } from "../../constants/customerStatus/employeeStatus";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { COUNTRY } from "../../constants/country/employeeCountry";
import { ISubscription } from "../../@types/interfaces/subscription.interface";
import { SUBSCRIPTION_TYPE } from "../../constants/status/status";

const subscriptionSchema: Schema<ISubscription> = new Schema<ISubscription>({
	name: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
		trim: true,
		maxlength: [50, "Name cannot be more than 50 characters"]
	},
	slug: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
		trim: true,
		maxlength: [50, "Slug cannot be more than 50 characters"]
	},
	plan_type: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [SUBSCRIPTION_TYPE.property_manager, SUBSCRIPTION_TYPE.property_owner]
	},
	price: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
		min: [0, "Price must be a positive number"] // Added minimum validation
	},
	duration: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
		min: [1, "month must be a  number"],
		max: [12, "month must be a  number"] // Added minimum validation
	},
	description: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
		trim: true,
		maxlength: [200, "Description cannot be more than 200 characters"] // Updated message
	},
	features: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
	},
	is_active: {
		...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		default: true
	},
	status: {
		...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		default: true
	}
});

export default subscriptionSchema;
