import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { IMember } from "../../@types/interfaces/member.interface";
import { ROLES } from "../../constants/roles/roles";
import { GENDER } from "../../constants/gender/gender";
import { EMPLOYEE_STATUS, TRANSACTION_STATUS, TRANSACTION_TYPE } from "../../constants/customerStatus/employeeStatus";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { COUNTRY } from "../../constants/country/employeeCountry";
import { IDog } from "../../@types/interfaces/dog.interface";
import { ITransactionLogs } from "../../@types/interfaces/transactionLogs.interface";

const transactionLogsSchema: Schema<ITransactionLogs> = new Schema<ITransactionLogs>(
	{
		payment_intent_id: SCHEMA_DEFINITION_PROPERTY.requiredString, // Auto generated for workers and adminstrator member
		transaction_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			ref: "transactions"
		},
		member_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			ref: "members"
		},
		payment_type: SCHEMA_DEFINITION_PROPERTY.requiredString,
		payment_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [TRANSACTION_STATUS.pending, TRANSACTION_STATUS.cancel, TRANSACTION_STATUS.success, null],
			default: TRANSACTION_STATUS.pending
		},
		transaction_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [TRANSACTION_TYPE.credited, TRANSACTION_TYPE.debited, null]
			// default: TRANSACTION_STATUS.pending
		},
		amount: SCHEMA_DEFINITION_PROPERTY.requiredString,
		transaction_date: SCHEMA_DEFINITION_PROPERTY.requiredString,
		message: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		payment_data: SCHEMA_DEFINITION_PROPERTY.optionalNullObject
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default transactionLogsSchema;
