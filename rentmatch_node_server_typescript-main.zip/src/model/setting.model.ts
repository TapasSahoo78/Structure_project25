import { model } from "mongoose";
import { ISetting } from "../@types/interfaces/setting.interface";
import settingSchema from "./schemaDefiniton/setting.schema";

const SettingModel = model<ISetting>("setting", settingSchema);

export default SettingModel;
