import { model } from "mongoose";
import { ISubscription } from "../@types/interfaces/subscription.interface";
import subscriptionSchema from "./schemaDefiniton/subscription.schema";

const SubscriptionModel = model<ISubscription>("subscription", subscriptionSchema);

export default SubscriptionModel;
