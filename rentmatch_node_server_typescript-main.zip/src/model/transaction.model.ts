import { model } from "mongoose";
import { ITransaction } from "../@types/interfaces/transaction.interface";
import ITransactionSchema from "./schemaDefiniton/transaction.schema";
const TransactionModel = model<ITransaction>("transactions", ITransactionSchema);

export default TransactionModel;
