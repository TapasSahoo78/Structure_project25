import { model } from "mongoose";
import transactionLogsSchema from "./schemaDefiniton/transactionLogs.schema";
import { ITransactionLogs } from "../@types/interfaces/transactionLogs.interface";

const TransactionLogsModel = model<ITransactionLogs>("transaction_logs", transactionLogsSchema);

export default TransactionLogsModel;
