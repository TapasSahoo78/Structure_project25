import { ROLES } from "../../constants/roles/roles";
import groupOwnerModel from "../../model/groupOwner.model";
import memberModel from "../../model/member.model";

export const findEmailToUserDetails = async (user_email: string, role: string): Promise<any> => {

	if (role === ROLES.member) {
		return await memberModel.findOne({ email: user_email }).sort({ _id: -1 }).lean();
	} else {
		return await groupOwnerModel.findOne({ email: user_email }).sort({ _id: -1 }).lean();
	}
};

export const findMemberFcmToken = async (): Promise<any> => {
	// if (role === ROLES.member) {
	const members = await memberModel.aggregate([
		{
			$match: {} // Match all documents
		},
		{
			$project: {
				devices_token: 1 // Include only the devices_token field
			}
		},
		{
			$match: {
				devices_token: { $ne: null, $exists: true } // Filter out null and non-existent tokens
			}
		}
	]);
	// Now `members` will only contain non-empty device tokens
	return members.map(member => member.devices_token);

}