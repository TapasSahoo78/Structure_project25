import mongoose from "mongoose";


interface PaginateOptions {
	page?: number;
	limit?: number;
}
export async function paginateQuery<T>(
	query: mongoose.Query<T[], T>,
	options: PaginateOptions = {}
) {
	const page = options.page || 1;
	const limit = options.limit || 10;
	const skip = (page - 1) * limit;

	const [data, total] = await Promise.all([
		query.clone().skip(skip).limit(limit),
		query.clone().countDocuments(),
	]);

	return {
		currentPage: page,
		totalPages: Math.ceil(total / limit),
		totalItems: total,
		data,
	};
}