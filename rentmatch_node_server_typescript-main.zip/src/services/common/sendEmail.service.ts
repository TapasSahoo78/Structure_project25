import { AnyObject } from "mongoose";

const nodemailer = require("nodemailer");

import * as dotenv from "dotenv";
dotenv.config({ path: __dirname + "/.env" });
// Create a transport object
const smtpTransport = nodemailer.createTransport({
	host: process.env.SMTP_HOST,
	port: process.env.SMTP_PORT,
	secure: false, // true for 465, false for other ports
	auth: {
		user: process.env.SMTP_USER,
		pass: process.env.SMTP_PASS
	}
});

// Define an interface for the mail content
interface MailContent {
	from: {
		name: string;
		address: string;
	};
	to: string;
	subject: string;
	html: string;
	attachments?: Array<{
		filename: string;
		path: string;
	}>;
}

export const sendEmail = (email: string, subject: string, content: string, attachments: string | null = null): void => {
	// Ensure the number is a positive integer
	const mailContent: MailContent = {
		from: {
			name: process.env.SENDER_NAME ?? "",
			address: process.env.SENDER_EMAIL ?? ""
		},
		to: email,
		subject: subject,
		html: content
	};

	// Add attachments if provided
	if (attachments) {
		mailContent.attachments = [
			{
				filename: "invoice.pdf",
				path: attachments
			}
		];
	}
	if (process.env.SENDER_EMAIL) {
		smtpTransport.sendMail(mailContent, (error: JSON, response: AnyObject) => {
			if (error) {
				console.log(error, "Error sending email");
			} else {
				console.log(response.response);
			}
		});
	}
};
