import { Model } from "mongoose";

const validEmailRegex1 = /^[a-zA-Z0-9.!#$%&'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/;
const validEmailRegex2 =
	/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

// Check Valid Email entered or not
export const isValidEmailService = (email: string): boolean => {
	try {
		if (!(validEmailRegex1.test(email) && validEmailRegex2.test(email))) return false;

		return true;
	} catch (err) {
		throw err;
	}
};

export const generateId = async (
	Model: Model<any>,
	prefix: string = "MGPS",
	findIdField: string,
	totalDigits: number = 6
): Promise<string> => {
	try {
		// Find the document with the highest findId
		const lastUser = await Model.findOne()
			.sort({ [findIdField]: -1 })
			.exec();

		let nextIdNumber: number;
		if (lastUser && lastUser[findIdField]) {
			// Extract the numeric part from the last findId
			const lastIdNumber = parseInt(lastUser[findIdField].slice(prefix.length)) || 0;
			nextIdNumber = lastIdNumber + 1;
		} else {
			// Start from 1 if no documents exist
			nextIdNumber = 1;
		}

		// Pad the number with leading zeros
		const paddedNumber = nextIdNumber.toString().padStart(totalDigits, "0");

		const newId = `${prefix}${paddedNumber}`;

		return newId;
	} catch (error) {
		console.error("Error generating ID:", error);
		throw new Error("Could not generate ID");
	}
};

export const generateOtp = (digits: number): string => {
	// Ensure the number is a positive integer
	if (digits <= 0 || !Number.isInteger(digits)) {
		throw new Error("Digits must be a positive integer.");
	}

	const min = Math.pow(10, digits - 1); // Minimum value for the given number of digits
	const max = Math.pow(10, digits) - 1; // Maximum value for the given number of digits

	const generateOTP = () => Math.floor(Math.random() * (max - min + 1) + min).toString();
	return generateOTP();
};
