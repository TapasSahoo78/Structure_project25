// const crypto = require('crypto');

// // Use a strong 32-byte (256-bit) key (keep secret!)
// const SECRET_KEY = crypto.createHash('sha256').update('your-secure-secret-key').digest(); // 32 bytes
// const IV_LENGTH = 12; // For GCM

// // ENCRYPT: A → B
// function encrypt(text) {
// 	const iv = crypto.randomBytes(IV_LENGTH);
// 	const cipher = crypto.createCipheriv('aes-256-gcm', SECRET_KEY, iv);

// 	let encrypted = cipher.update(text, 'utf8', 'hex');
// 	encrypted += cipher.final('hex');

// 	const authTag = cipher.getAuthTag();

// 	// Return: iv:encrypted:authTag (all in hex)
// 	return `${iv.toString('hex')}:${encrypted}:${authTag.toString('hex')}`;
// }

// // DECRYPT: B → A
// function decrypt(encryptedData) {
// 	try {
// 		const [ivHex, encryptedHex, authTagHex] = encryptedData.split(':');
// 		if (!ivHex || !encryptedHex || !authTagHex) throw new Error('Invalid format');

// 		const iv = Buffer.from(ivHex, 'hex');
// 		const encrypted = Buffer.from(encryptedHex, 'hex');
// 		const authTag = Buffer.from(authTagHex, 'hex');

// 		const decipher = crypto.createDecipheriv('aes-256-gcm', SECRET_KEY, iv);
// 		decipher.setAuthTag(authTag);

// 		let decrypted = decipher.update(encrypted, null, 'utf8');
// 		decrypted += decipher.final('utf8');

// 		return decrypted;
// 	} catch (error) {
// 		throw new Error('Decryption failed: ' + error.message);
// 	}
// }

// // ——— DEMO ———
// const original = "Hello, World!";

// const encrypted = encrypt(original); // A → B
// console.log("Encrypted (B):", encrypted);

// const decrypted = decrypt(encrypted); // B → A
// console.log("Decrypted (A):", decrypted);

// console.log("Match?", original === decrypted); // true