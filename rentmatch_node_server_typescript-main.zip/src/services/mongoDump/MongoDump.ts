import { exec } from "child_process";
import { mongoDump } from "../../config/config";
import { MONTH_LIST } from "../../constants/month/MonthList";

export const MongoDump = () => {
	console.log("********** Mongo Dump Cron Job Started **************");
	const currentDate = new Date();
	const todayDate = currentDate.getDate() < 10 ? "0" + currentDate.getDate() : currentDate.getDate();
	const host = mongoDump.host;
	const port = mongoDump.port;
	const database = mongoDump.database;
	const outputDir = `${mongoDump.outputDir}/${currentDate.getFullYear()}/${MONTH_LIST[currentDate.getMonth()]}/${todayDate}`; // Change this to your desired backup directory

	// Construct the mongodump command
	const dumpCommand = `mongodump --host=${host} --port=${port} --db=${database} --out=${outputDir} --forceTableScan`;

	// Execute the mongodump command
	exec(dumpCommand, (error, stdout, stderr) => {
		const output = {
			command: dumpCommand,
			stdout: stdout.toString(),
			stderr: stderr.toString()
		};

		if (error) {
			console.error(`Error during backup: ${error.message}`);
			return;
		}
		console.log(`Backup successful:\n${stdout}`, output);
	});
};
