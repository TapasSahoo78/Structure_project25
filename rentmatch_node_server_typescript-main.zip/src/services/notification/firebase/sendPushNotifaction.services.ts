import admin, { ServiceAccount } from "firebase-admin"; // Import Firebase Admin SDK and ServiceAccount type
import serviceAccount from "./firebase-adminsdk.json";
import { findMemberFcmToken } from "../../common/commonFunction.service";

// Initialize Firebase Admin SDK
admin.initializeApp({
	credential: admin.credential.cert(serviceAccount as ServiceAccount) // Type assertion
});

// Define the message structure
interface Message {
	title: string;
	body: string;
}

// Function to send push notification
export const sendPushNotification = async (token: string, message: Message): Promise<string | undefined> => {

	const tokensss = findMemberFcmToken(); // Assuming this function returns a valid FCM token
	console.log("Sending push notification to token:", tokensss);

	const payload = {
		notification: {
			title: message.title,
			body: message.body
		},
		token: token // The device token you want to send the notification to
	};

	try {
		const response = await admin.messaging().send(payload);
		console.log("Successfully sent message:", response);
		return response as string;
	} catch (error) {
		const firebaseError = error as admin.FirebaseError; // Type assertion
		if (firebaseError.code === 'messaging/registration-token-not-registered') {
			console.error("Error sending message: Token not registered. Consider removing this token from your database.");
			// Handle the invalid token (e.g., remove it from your database)
		} else {
			console.error("Error sending message:", firebaseError);
		}
		return undefined; // Ensure the catch block returns undefined
	}
};
// export const sendPushNotification = async (token: string, message: Message): Promise<string | undefined> => {

// 	const payload = {
// 		notification: {
// 			title: message.title,
// 			body: message.body
// 		},
// 		token: token // The device token you want to send the notification to
// 	};

// 	try {
// 		const response = await admin.messaging().send(payload);
// 		console.log("Successfully sent message:", response);
// 		return response as string;
// 	} catch (error) {
// 		const firebaseError = error as admin.FirebaseError; // Type assertion
// 		if (firebaseError.code === 'messaging/registration-token-not-registered') {
// 			console.error("Error sending message: Token not registered. Consider removing this token from your database.");
// 			// Handle the invalid token (e.g., remove it from your database)
// 		} else {
// 			console.error("Error sending message:", firebaseError);
// 		}
// 		return undefined; // Ensure the catch block returns undefined
// 	}
// };
