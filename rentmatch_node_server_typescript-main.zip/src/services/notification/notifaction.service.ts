import { ObjectId } from "mongoose";
import groupOwnerModel from "../../model/groupOwner.model";
import memberModel from "../../model/member.model";
import notifactionModel from "../../model/notifaction.model";
import { getCurrentMongoDBFormattedDate } from "../date/date.service";

export const notifaction = async (noytifactionPayload: any) => {
	try {
		// Fetch all group owners and the specific member for the given member_id
		const member_id = noytifactionPayload.member_id;
		// console.log("member_id", noytifactionPayload);

		const groupOwners = await groupOwnerModel.find().lean();
		const member = await memberModel.findById(member_id).lean(); // Fetch a single member

		const title = noytifactionPayload.title;
		const message = noytifactionPayload.message;

		// Combine user IDs from both owners and the single member
		const userIds = [
			...groupOwners.map(owner => owner._id),
			member ? member._id : null // Add member ID if it exists
		].filter(id => id !== null); // Filter out any null values
		// console.log("member", member);/

		// Create notifications for each user ID
		const notifications = userIds.map(user_id => ({
			title: title,
			message: message,
			user_id: user_id,
			created_at: getCurrentMongoDBFormattedDate()
		}));

		// Insert all notifications into the database
		return await notifactionModel.insertMany(notifications);

	} catch (error) {
		console.error("Error creating notifications:", error);
		throw error; // Handle the error as needed
	}
};

export const notifactionShowAll = async (noytifactionPayload: any) => {
	try {
		const groupOwners = await groupOwnerModel.find().lean();
		const members = await memberModel.find().lean();
		// console.log("fetchMemberId", fetchMemberId);
		const title = noytifactionPayload.title;
		const message = noytifactionPayload.message;
		const userIds = [
			...groupOwners.map(owner => owner._id),
			...members.map(member => member._id)
		];
		// Create notifications for each user ID
		const result = userIds.map(user_id => ({
			title: title,
			message: message,
			user_id: user_id,
			created_at: getCurrentMongoDBFormattedDate()
		}));
		return await notifactionModel.insertMany(result);

	} catch (error: any) {
		console.log("Notifaction Error", error);
		throw error;
	}
};



