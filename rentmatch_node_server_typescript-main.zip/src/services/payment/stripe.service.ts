import exp from "node:constants";
import { getCurrentMongoDBFormattedDate } from "../date/date.service";
import { transaction } from "../transaction/transaction.service";
import { STRIPE_SECRET_KEY } from "../../config/config";
const stripe = require("stripe")(STRIPE_SECRET_KEY);
// const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

export const processPayment = async (
	memberId: string,
	orderId: string,
	orderType: string,
	amount: number,
	transaction_status: string,
	type: string = "card",
	status: string = "PENDING",
	message: string
): Promise<any> => {
	// Validate amount
	if (amount <= 0) {
		throw new Error("Amount must be greater than zero.");
	}

	const paymentIntent = await stripe.paymentIntents.create({
		amount: amount * 100, // Convert amount to cents
		currency: "usd",
		metadata: { memberId, type },
		automatic_payment_methods: {
			enabled: true
		}
	});

	const transactionPayload = {
		payment_intent_id: paymentIntent.id,
		member_objectId: memberId,
		order_objectId: orderId,
		type: "card",
		amount: amount,
		payment_status: status,
		payment_type: type,
		// status: "pending",
		transaction_date: getCurrentMongoDBFormattedDate(),
		payment_data: paymentIntent,
		transaction_status: transaction_status,
		message: message
	};

	const result = await transaction(transactionPayload);

	// console.log("Result", result)
	return result;
};
