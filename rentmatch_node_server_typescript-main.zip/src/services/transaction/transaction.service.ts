import { SUBSCRIPTION_STATUS } from "../../constants/customerStatus/employeeStatus";
import transactionModel from "../../model/transaction.model";
import transactionLogsModel from "../../model/transactionLogs.model";
import { STRIPE_SECRET_KEY } from "../../config/config";
const stripe = require("stripe")(STRIPE_SECRET_KEY);
// const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

export const transaction = async (transactionPayload: any) => {
	try {
		const orderObjectId = transactionPayload.type == "orders" ? transactionPayload.order_objectId : null;
		const subscriptionObjectId =
			transactionPayload.type == "subscriptions" ? transactionPayload.order_objectId : null;
		const wallet_objectId =
			transactionPayload.type == "wallets"
				? transactionPayload.order_objectId
					? transactionPayload.order_objectId
					: null
				: null;
		const transactionData = {
			payment_intent_id: transactionPayload.payment_intent_id,
			member_objectId: transactionPayload.member_objectId,
			order_objectId: orderObjectId ?? null,
			subscription_objectId: subscriptionObjectId ?? null,
			wallet_objectId: wallet_objectId ?? null,
			type: transactionPayload.type,
			payment_type: transactionPayload.payment_type,
			payment_status: transactionPayload.payment_status,
			amount: transactionPayload.amount,
			transaction_date: transactionPayload.transaction_date,
			message: transactionPayload.message,
			payment_data: transactionPayload.payment_data,
			transaction_status: transactionPayload.transaction_status
		};
		const transactionResult = await new transactionModel(transactionData).save();
		await transactionLog({ ...transactionPayload, transaction_id: transactionResult._id });
		return transactionResult;
	} catch (error: any) {
		console.error("Transaction Error", error);
		throw error; // Rethrow the error for further handling
	}
};
export const transactionStatusUpdate = async (transactionPayload: any) => {
	try {
		const updateData = {
			payment_status: transactionPayload.payment_status,
			respons_data: transactionPayload.respons_data ? transactionPayload.respons_data : null
		};
		// Find the transaction by id
		const transactionResult = await transactionModel.findOne({ _id: transactionPayload.id });
		// Update the transaction
		const updatedTransaction = await transactionModel.findOneAndUpdate(
			{ _id: transactionPayload.id }, // Query to find the document by id
			{ $set: updateData }, // Update operation
			{ new: true } // Option to return the updated document
		);
		await transactionLog({ ...transactionPayload, transaction_id: transactionResult?._id });
		return updatedTransaction;
	} catch (error: any) {
		console.error("Transaction Error", error);
		throw new Error(`Transaction update failed: ${error.message}`); // Rethrow with a custom message
	}
};
export const transactionLog = async (transactionPayload: any) => {
	try {
		// Prepare log data
		const logData = {
			transaction_id: transactionPayload.transaction_id,
			payment_intent_id: transactionPayload.payment_intent_id,
			member_id: transactionPayload.member_objectId,
			payment_status: SUBSCRIPTION_STATUS.pending,
			payment_type: transactionPayload.payment_type,
			amount: transactionPayload.amount,
			transaction_date: transactionPayload.transaction_date,
			message: transactionPayload.message,
			payment_data: transactionPayload.payment_data
		};

		// await new transactionLogsModel(logData).save();
	} catch (error: any) {
		console.error("Transaction Log Error", error);
		throw error; // Rethrow the error for further handling
	}
};
