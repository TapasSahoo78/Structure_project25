// import { ObjectId } from "mongoose";
// import walletModel from "../../model/wallet.model";
// import { getCurrentMongoDBFormattedDate } from "../date/date.service";
// import { processPayment } from "../payment/stripe.service";

// export const wallet = async (walletPayload: any) => {
// 	try {
// 		const walletData = {
// 			member_id: walletPayload.member_id,
// 			amount: walletPayload.amount,
// 			currency: walletPayload.currency,
// 			description: walletPayload.description,
// 			payment_method: walletPayload.payment_method,
// 			payment_type: walletPayload.payment_type,
// 			status: walletPayload.status
// 		};
// 		const findMember = await walletModel.findOne({ member_id: walletPayload.member_id });

// 		if (findMember) {
// 			// If the member exists, update the wallet amount
// 			walletData.amount += findMember.amount; // Add the existing amount
// 			await walletModel.updateOne(
// 				{ member_id: walletPayload.member_id },
// 				{ $set: { amount: walletData.amount } }
// 			);
// 		} else {
// 			// If the member does not exist, create a new wallet entry
// 			createWallet(walletData);
// 		}
// 	} catch (error: any) {
// 		console.log("Wallet Error", error);
// 		throw error;
// 	}
// };

// export const walletUpdate = async (member_ObjectId: string, amount: number, orderId: string) => {
// 	try {
// 		const findMember = await walletModel.findOne({ member_id: member_ObjectId });
// 		if (findMember) {
// 			// If the member exists, update the wallet amount
// 			const updateWalletAmount =
// 				findMember && findMember.amount !== undefined && findMember.amount !== null
// 					? findMember.amount - amount
// 					: 0;
// 			await processPayment(
// 				member_ObjectId,
// 				orderId,
// 				"wallets",
// 				amount,
// 				"DEBITED",
// 				"wallet",
// 				"SUCCESS",
// 				"Your Amount Debited from Wallet"
// 			);
// 			await walletModel.updateOne({ member_id: member_ObjectId }, { $set: { amount: updateWalletAmount } });
// 		}
// 	} catch (error: any) {
// 		console.log("Wallet Error", error);
// 		throw error;
// 	}
// };

// export const createWallet = async (walletPayload: any) => {
// 	try {
// 		const walletData = {
// 			member_id: walletPayload.member_id,
// 			amount: walletPayload.amount,
// 			currency: walletPayload.currency,
// 			description: walletPayload.description,
// 			payment_method: walletPayload.payment_method,
// 			payment_type: walletPayload.payment_type,
// 			status: walletPayload.status
// 		};
// 		const findMember = await walletModel.findOne({ member_id: walletPayload.member_id });
// 		if (!findMember) {
// 			// If the member does not exist, create a new wallet entry
// 			return await new walletModel(walletData).save();
// 		}
// 	} catch (error: any) {
// 		console.log("Wallet Error", error);
// 		throw error;
// 	}
// };
