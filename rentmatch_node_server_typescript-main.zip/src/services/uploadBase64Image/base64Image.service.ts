import * as mime from "mime-types";
import { uploadImageToS3Service } from "../uploadImageS3/UploadImageS3";

export const uploadImageBase64Service = async (base64Image: string, folderName: string): Promise<any> => {
	console.log("base64Image", base64Image);

	if (!base64Image) {
		return null;
		// throw new Error('No image provided');
	}
	const base64Data = Buffer.from(base64Image.replace(/^data:image\/\w+;base64,/, ""), "base64");
	// const type = mime.lookup(fileName) || 'application/octet-stream';

	const dogPhotoBuffer = base64Data;
	const dogPhotoUrl = await uploadImageToS3Service(folderName, dogPhotoBuffer);
	console.log("dogPhoto URL-->", dogPhotoUrl);
	return dogPhotoUrl;
};
