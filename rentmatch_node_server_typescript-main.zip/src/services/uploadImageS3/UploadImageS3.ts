import { PutObjectCommand } from "@aws-sdk/client-s3";
import { bucketName, s3Client, s3Url } from "../../config/aws.config";
import { GetObjectCommand } from "@aws-sdk/client-s3";
// import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export const uploadImageToS3Service = async (key: string, thumbnailBuffer: Buffer) => {
	const keyName = `${key}/${Date.now()}photo.png`;
	console.log("bucketName, s3Client, s3Url", bucketName, s3Client, s3Url);

	const command = new PutObjectCommand({
		Bucket: bucketName,
		Key: keyName,
		Body: thumbnailBuffer,
		// ACL: "public-read" // Set the ACL as needed (e.g., public-read for public access)
	});
	console.log("Bucket Command: ", command);

	try {
		const response = await s3Client.send(command);
		console.log("response", response);
		console.log("Image uploaded successfully:", s3Url, keyName);
		if (response) {
			return `${s3Url}/${keyName}`;
		}
		return null;
	} catch (err) {
		console.error(err);
	}
};



// export const uploadImageToS3Service = async (key: string, buffer: Buffer) => {
// 	const keyName = `${key}/${Date.now()}_photo.png`;

// 	const command = new PutObjectCommand({
// 		Bucket: bucketName,
// 		Key: keyName,
// 		Body: buffer,
// 		ContentType: "image/*" // or dynamic based on MIME
// 	});

// 	try {
// 		await s3Client.send(command);
// 		return generatePresignedUrl(keyName);
// 		// return keyName; // return key only, for private access
// 	} catch (err) {
// 		console.error("Upload failed:", err);
// 		return null;
// 	}
// };

// export const generatePresignedUrl = async (keyName: string): Promise<string | null> => {
// 	const command = new GetObjectCommand({
// 		Bucket: bucketName,
// 		Key: keyName
// 	});

// 	try {

// 		// const data = await s3Client.send(command);
// 		const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 }); // 1 hour
// 		console.log("------------------data", data);

// 		return signedUrl;
// 	} catch (err) {
// 		console.error("Failed to generate presigned URL:", err);
// 		return null;
// 	}
// };
