import axios from 'axios';
import Swal from 'sweetalert2';

const apiUrl = process.env.REACT_APP_LOCAL_API_URL; // Ensure this is set in your .env file

// Function to get the token (adjust this based on your authentication method)
const getToken = () => {
    return localStorage.getItem('token'); // Or however you store your token
};

// Add a new category
export const addCategory = async (categoryData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/categories`, categoryData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the added category data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing category
export const editCategory = async (categoryId, categoryData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/categories/${categoryId}`, categoryData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated category data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a category
export const deleteCategory = async (categoryId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/categories/${categoryId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all categories
export const getAllCategories = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/categories`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of categories
    } catch (error) {
        handleError(error);
    }
};

// Get category details
export const getCategory = async (categoryId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/categories/${categoryId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the category details
    } catch (error) {
        handleError(error);
    }
};

// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = (error.response?.data?.err?.details[0]?.message || error.response?.data?.message) || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
};