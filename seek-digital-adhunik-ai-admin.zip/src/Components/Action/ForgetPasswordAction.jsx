// src/components/Action/ForgotPasswordAction.ts
import axios from 'axios';
import Swal from 'sweetalert2';
const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

export const forgotPasswordEmail = async (email) => {
    try {
        const response = await axios.post(`${apiUrl}/email-verification-with-password-change`, { type: 'email', email });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response?.data?.message,
        });
        return response.data;
    }catch (error) {
        handleError(error);
    }
};

export const verifyOtp = async (email, otp) => {
    try {
        const response = await axios.post(`${apiUrl}/email-verification-with-password-change`, { type: 'otp', email, otp });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response?.data?.message,
        });
        return response.data;
    }catch (error) {
        handleError(error);
    }
};

export const resetPassword = async (email, password, confirmPassword) => {
    try {
        const response = await axios.post(`${apiUrl}/email-verification-with-password-change`, { type: 'password', email, password, confirmPassword });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response?.data?.message,
        });
        return response.data;
    }catch (error) {
        handleError(error);
    }
};


// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = error.response?.data?.message || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        console.error('Unexpected error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
};