import axios from 'axios';
import Swal from 'sweetalert2';
import man from "../../assets/images/dashboard/profile.png";

const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

const LoginAction = async (user_id, password, history, layoutURL) => {
    try {
        const response = await axios.post(`${apiUrl}/login`, {
            user_id,
            password,
        });

        // Save the token to local storage
        localStorage.setItem('token', response.data.result.token);
        localStorage.setItem('Name', response.data.result?.userResponse?.first_name + " " + response.data.result?.userResponse?.last_name);
        localStorage.setItem("profileURL", man);
        localStorage.setItem("login", JSON.stringify(true));
        localStorage.setItem("authenticated", true);
        localStorage.setItem("auth0_profile", JSON.stringify(response.data.result?.userResponse));
        // navigate(`/dashboard/default/${layoutURL}`);
        history(`${process.env.REACT_APP_PUBLIC_URL}/dashboard/default/${layoutURL}`);
    } catch (error) {
        // Handle error
        if (axios.isAxiosError(error)) {
            const errorMessage = error.response?.data?.message || error.message; // Adjust based on your API response structure
            // Show SweetAlert with the error message
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
            });
        } else {
            console.error('Unexpected error:', error);
            // Show generic error message
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An unexpected error occurred. Please try again later.',
            });
        }
    }
};

export default LoginAction;
