import axios from 'axios';
import Swal from 'sweetalert2';

const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

// Function to get the token (adjust this based on your authentication method)
const getToken = () => {
    return localStorage.getItem('token'); // Or however you store your token
};

// Add a new menu
export const addMenu = async (menuData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/menus`, menuData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        // navigate('/menus'); // Redirect to menus list or appropriate menu
        return response.data; // Return the added menu data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing menu
export const editMenu = async (menuId, menuData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/menus/${menuId}`, menuData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated menu data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a menu
export const deleteMenu = async (menuId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/menus/${menuId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all menus
export const getAllMenus = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/menus`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of menus
    } catch (error) {
        handleError(error);
    }
};

// Get menu details
export const getMenu = async (menuId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/menus/${menuId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the menu data
    } catch (error) {
        handleError(error);
    }
};

// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = (error.response?.data?.err?.details[0]?.message || error.response?.data?.message) || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        console.log(error)
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
    return false
};
