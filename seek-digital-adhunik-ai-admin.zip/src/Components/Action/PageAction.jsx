import axios from 'axios';
import Swal from 'sweetalert2';

const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

// Function to get the token (adjust this based on your authentication method)
const getToken = () => {
    return localStorage.getItem('token'); // Or however you store your token
};

// Add a new page
export const addPage = async (pageData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/pages`, pageData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        // navigate('/pages'); // Redirect to pages list or appropriate page
        return response.data; // Return the added page data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing page
export const editPage = async (pageId, pageData, blockId = '') => {
    try {
        const token = getToken();

        const blockUrl = blockId
            ? `${apiUrl}/pages/${pageId}/${blockId}`
            : `${apiUrl}/pages/${pageId}`;

        const response = await axios.put(blockUrl, pageData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data;
    } catch (error) {
        handleError(error);
    }
};

// Delete a page
export const deletePage = async (pageId, blockId = '') => {
    try {
        const token = getToken();
        const blockUrl = blockId
            ? `${apiUrl}/pages/${pageId}/${blockId}`
            : `${apiUrl}/pages/${pageId}`;
        const response = await axios.delete(blockUrl, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all pages
export const getAllPages = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/pages`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of pages
    } catch (error) {
        handleError(error);
    }
};

// Get page details
export const getPage = async (pageId, blockId = '') => {
    try {
        const token = getToken();
        const blockUrl = blockId
            ? `${apiUrl}/pages/${pageId}/${blockId}`
            : `${apiUrl}/pages/${pageId}`;
        const response = await axios.get(blockUrl, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response.data;
    } catch (error) {
        handleError(error);
        throw error;
    }
};

// Delete a page
export const deleteBlock = async (blockId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/blocks/${blockId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = (error.response?.data?.err?.details[0]?.message || error.response?.data?.message) || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        console.log(error)
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
    return false
};
