import axios from 'axios';
import Swal from 'sweetalert2';

const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

// Function to get the token (adjust this based on your authentication method)
const getToken = () => {
    return localStorage.getItem('token'); // Or however you store your token
};

// Add a new user
export const addRole = async (roleData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/roles`, roleData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        navigate('/roles'); // Redirect to roles list or appropriate page
        return response.data; // Return the added user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing user
export const editRole = async (roleId, roleData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/roles/${roleId}`, roleData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a user
export const deleteRole = async (roleId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/roles/${roleId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all roles
export const getAllRole = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/roles`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of roles
    } catch (error) {
        handleError(error);
    }
};

//Role Details
export const getRole = async (roleId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/roles/${roleId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of roles
    } catch (error) {
        handleError(error);
    }
};

// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = error.response?.data?.message || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        console.error('Unexpected error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
};
