import axios from 'axios';
import Swal from 'sweetalert2';

const apiUrl = process.env.REACT_APP_LOCAL_API_URL;

// Function to get the token (adjust this based on your authentication method)
const getToken = () => {
    return localStorage.getItem('token'); // Or however you store your token
};

// Add a new user
export const addUser = async (userData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/users`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        // navigate('/users'); // Redirect to users list or appropriate page
        return response.data; // Return the added user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing user
export const editUser = async (userId, userData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/users/${userId}`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a user
export const deleteUser = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/users/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all users
export const getAllUsers = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/users`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of users
    } catch (error) {
        handleError(error);
    }
};

// Get user details
export const getUser = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/users/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the user data
    } catch (error) {
        handleError(error);
    }
};

// Add a new admin user
export const addAdminUser = async (userData, navigate) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/admin-users`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        // navigate('/users'); // Redirect to users list or appropriate page
        return response.data; // Return the added user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing admin user
export const editAdminUser = async (userId, userData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/admin-users/${userId}`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a admin user
export const deleteAdminUser = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/admin-users/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all admin users
export const getAllAdminUsers = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/admin-users`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of users
    } catch (error) {
        handleError(error);
    }
};

// Get admin user details
export const getAdminUser = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/admin-users/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the user data
    } catch (error) {
        handleError(error);
    }
};

// Add a new customer
export const addCustomer = async (userData) => {
    try {
        const token = getToken();
        const response = await axios.post(`${apiUrl}/customers`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the added user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing admin user
export const editCustomer = async (userId, userData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/customers/${userId}`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Delete a customr
export const deleteCustomer = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.delete(`${apiUrl}/customers/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
    } catch (error) {
        handleError(error);
    }
};

// Get all customers
export const getAllCustomers = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/customers`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the list of users
    } catch (error) {
        handleError(error);
    }
};

// Get Customer details
export const getCustomer = async (userId) => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/customers/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the user data
    } catch (error) {
        handleError(error);
    }
};


// Get Customer details
export const getProfile = async () => {
    try {
        const token = getToken();
        const response = await axios.get(`${apiUrl}/get-profile`, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        return response.data; // Return the user data
    } catch (error) {
        handleError(error);
    }
};

// Edit an existing admin user
export const updateProfile = async (userData) => {
    try {
        const token = getToken();
        const response = await axios.put(`${apiUrl}/update-profile`, userData, {
            headers: {
                Authorization: `Bearer ${token}`, // Set the Authorization header
            },
        });
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response.data.message,
        });
        return response.data; // Return the updated user data if needed
    } catch (error) {
        handleError(error);
    }
};

// Handle errors
const handleError = (error) => {
    if (axios.isAxiosError(error)) {
        const errorMessage = (error.response?.data?.err?.details[0]?.message || error.response?.data?.message) || error.message;
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: errorMessage,
        });
    } else {
        console.log(error)
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again later.',
        });
    }
    return false
};
