import React, { useState, useEffect } from "react";
import { Btn, H4 } from "../../../../AbstractElements";
import { Form, FormGroup, Label, Input, Row, Col } from 'reactstrap';
import { getProfile, updateProfile } from '../../../Action/UserAction';
import Swal from 'sweetalert2';

const EditMyProfile = () => {
    const [userData, setUserData] = useState({
        user_name: '',
        email: '',
        first_name: '',
        last_name: '',
        address_line_1: '',
        address_line_2: '',
        city: '',
        state: '',
        country: '',
        ZIP: '',
        phone_number: '',
        phone_extension: '',
        // Add any other fields you need
    });

    useEffect(() => {
        const fetchProfile = async () => {
            const profile = await getProfile();
            const profileData = profile.result.userResponse;
            if (profileData) {
                // Set form values with fetched profile data
                setUserData({
                    user_name: profileData.user_name || '',
                    email: profileData.email || '',
                    first_name: profileData.first_name || '',
                    last_name: profileData.last_name || '',
                    address_line_1: profileData.address_line_1 || '',
                    address_line_2: profileData.address_line_2 || '',
                    city: profileData.city || '',
                    state: profileData.state || '',
                    country: profileData.country || '',
                    ZIP: profileData.ZIP || '',
                    phone_number: profileData.phone_number || '',
                    phone_extension: profileData.phone_extension || '',
                });
            }
        };
        fetchProfile();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({ ...userData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await updateProfile(userData);
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Update Failed',
                text: 'There was an error updating your profile.',
            });
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <H4 attrH4={{ className: "card-title mb-0" }}>Edit Profile</H4>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Username</Label>
                        <Input className="form-control" type="text" name="user_name" placeholder="Username" value={userData.user_name} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Email Address</Label>
                        <Input className="form-control" type="email" name="email" placeholder="Enter email" value={userData.email} onChange={handleChange} required />
                        <small className="form-text text-muted">We'll never share your email with anyone else.</small>
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">First Name</Label>
                        <Input className="form-control" type="text" name="first_name" placeholder="First Name" value={userData.first_name} onChange={handleChange} required />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Last Name</Label>
                        <Input className="form-control" type="text" name="last_name" placeholder="Last Name" value={userData.last_name} onChange={handleChange} required />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Phone Number</Label>
                        <Input className="form-control" type="tel" name="phone_number" placeholder="Phone Number" value={userData.phone_number} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Phone Extension</Label>
                        <Input className="form-control" type="text" name="phone_extension" placeholder="Phone Extension" value={userData.phone_extension} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <FormGroup>
                <Label className="col-form-label pt-0">Address Line 1</Label>
                <Input className="form-control" type="text" name="address_line_1" placeholder="Address Line 1" value={userData.address_line_1} onChange={handleChange} />
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Address Line 2</Label>
                <Input className="form-control" type="text" name="address_line_2" placeholder="Address Line 2" value={userData.address_line_2} onChange={handleChange} />
            </FormGroup>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">City</Label>
                        <Input className="form-control" type="text" name="city" placeholder="City" value={userData.city} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">State</Label>
                        <Input className="form-control" type="text" name="state" placeholder="State" value={userData.state} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Country</Label>
                        <Input className="form-control" type="text" name="country" placeholder="Country" value={userData.country} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">ZIP Code</Label>
                        <Input className="form-control" type="text" name="ZIP" placeholder="ZIP Code" value={userData.ZIP} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <div className="form-group d-flex justify-content-between">
                <Btn attrBtn={{ color: "primary", type: "submit" }}>Update Profile</Btn>
                <Btn attrBtn={{ color: "secondary", type: "button" }} onClick={() => console.log('Cancel action')}>Cancel</Btn>
            </div>
        </Form>
    );
};

export default EditMyProfile;
