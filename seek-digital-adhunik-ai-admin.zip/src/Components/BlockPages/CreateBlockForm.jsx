import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button } from 'reactstrap';
import Swal from 'sweetalert2';
import { addPage, editPage } from '../Action/PageAction'; // Import addPage and editPage actions

const PageForm = ({ onClose, refreshPages, userToEdit }) => {
    const [pageData, setPageData] = useState({
        title: '',
        blocks: [],
        meta_title: '',
        meta_description: '',
        meta_keywords: '',
    });

    const [errors, setErrors] = useState({}); // State for error messages

    useEffect(() => {
        if (userToEdit) {
            setPageData(prevData => ({
                ...prevData,
                ...userToEdit,
                blocks: userToEdit.blocks || [],
                title: userToEdit.title || '',
                meta_title: userToEdit.meta_title || '',
                meta_description: userToEdit.meta_description || '',
                meta_keywords: userToEdit.meta_keywords || '',
            }));
        } else {
            setPageData({
                title: '',
                blocks: [],
                meta_title: '',
                meta_description: '',
                meta_keywords: '',
            });
        }
    }, [userToEdit]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setPageData({ ...pageData, [name]: value });
        setErrors({ ...errors, [name]: '' }); // Clear error for the field being edited
    };

    const validate = () => {
        const newErrors = {};
        if (!pageData.title) newErrors.title = 'Title is required.';
        if (!pageData.meta_title) newErrors.meta_title = 'Meta Title is required.';
        if (!pageData.meta_description) newErrors.meta_description = 'Meta Description is required.';
        if (!pageData.meta_keywords) newErrors.meta_keywords = 'Meta Keywords are required.';
        return newErrors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationErrors = validate();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors); // Set errors if validation fails
            return;
        }

        try {
            let response = false;
            if (userToEdit) {
                response = await editPage(userToEdit._id, pageData);
            } else {
                response = await addPage(pageData);
            }
            if (response) {
                refreshPages();
                onClose();
            }
        } catch (error) {
            Swal.fire('Error', 'Failed to save page.', 'error');
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <FormGroup>
                <Label className="col-form-label pt-0">Title</Label>
                <Input
                    className="form-control"
                    type="text"
                    name="title"
                    placeholder="Page Title"
                    value={pageData.title}
                    onChange={handleChange}
                />
                {errors.title && <div className="text-danger">{errors.title}</div>}
            </FormGroup>

            <FormGroup>
                <Label className="col-form-label pt-0">Meta Title</Label>
                <Input
                    className="form-control"
                    type="text"
                    name="meta_title"
                    placeholder="Meta Title"
                    value={pageData.meta_title}
                    onChange={handleChange}
                />
                {errors.meta_title && <div className="text-danger">{errors.meta_title}</div>}
            </FormGroup>

            <FormGroup>
                <Label className="col-form-label pt-0">Meta Description</Label>
                <Input
                    className="form-control"
                    type="text"
                    name="meta_description"
                    placeholder="Meta Description"
                    value={pageData.meta_description}
                    onChange={handleChange}
                />
                {errors.meta_description && <div className="text-danger">{errors.meta_description}</div>}
            </FormGroup>

            <FormGroup>
                <Label className="col-form-label pt-0">Meta Keywords</Label>
                <Input
                    className="form-control"
                    type="text"
                    name="meta_keywords"
                    placeholder="Meta Keywords"
                    value={pageData.meta_keywords}
                    onChange={handleChange}
                />
                {errors.meta_keywords && <div className="text-danger">{errors.meta_keywords}</div>}
            </FormGroup>

            <div className="form-group d-flex justify-content-between">
                <Button type="submit" color="primary">{userToEdit ? 'Update Page' : 'Create Page'}</Button>
                <Button type="button" color="secondary" onClick={onClose}>Cancel</Button>
            </div>
        </Form>
    );
};

export default PageForm;