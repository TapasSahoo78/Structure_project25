import React, { Fragment, useState, useEffect } from 'react';
import { Container, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import DataTable from 'react-data-table-component';
import { getAllPages, deletePage } from '../Action/PageAction';
import Swal from 'sweetalert2';
import { AddBlock, Delete, Edit } from '../../Constant';
import BlockForm from './CreateBlockForm';
import { useNavigate, useParams } from 'react-router-dom';

const Pages = () => {
    const [users, setPages] = useState([]);
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setModalOpen] = useState(false);
    const [userToEdit, setPageToEdit] = useState(null);

    const { layout, page_id } = useParams();
    console.log(page_id, layout);


    const fetchPages = async () => {
        try {
            const userList = await getAllPages();
            setPages(userList);
        } catch (error) {
            console.error("Error fetching users:", error);
            Swal.fire('Error', 'Failed to fetch users.', 'error');
        }
    };

    useEffect(() => {
        fetchPages();
    }, []);

    const handleDeletePage = async (userId) => {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        });

        if (result.isConfirmed) {
            await deletePage(userId);
            setPages(users.filter(user => user._id !== userId));
        }
    };

    const handleEditPage = (user) => {
        setPageToEdit(user);
        setModalOpen(true);
    };

    const redirectBlockPage = async (layout, pageId) => {
        navigate(`/blocks/${layout}/${pageId}`);
    };

    const columns = [
        {
            name: 'Title',
            selector: row => row.title,
            sortable: true,
        },
        {
            name: 'Block',
            selector: row => row.blocks.length,
            sortable: false,
        },
        {
            name: 'Meta Title',
            selector: row => row.meta_title,
            sortable: false,
        },
        {
            name: 'Meta Description',
            selector: row => row.meta_description,
            sortable: false,
        },
        {
            name: 'Meta Keywords',
            selector: row => row.meta_keywords,
            sortable: false,
        },
        {
            name: 'Actions',
            cell: row => (
                <div>
                    <button className='btn border-button-primary btn-xs' onClick={() => handleEditPage(row)}>
                        <i className='fa fa-pencil'></i> {Edit}
                    </button>
                    <button className='btn border-button-danger btn-xs' onClick={() => handleDeletePage(row._id)}>
                        <i className='fa fa-trash'></i> {Delete}
                    </button>
                    <button className='btn border-button-primary btn-xs' onClick={() => redirectBlockPage(layout, row._id)}>
                        <i className='fa fa-plus'></i> {AddBlock}
                    </button>
                </div>
            ),
        },
    ];

    const filteredPages = users.filter(user =>
        user.title?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Fragment>
            <Breadcrumbs mainTitle='Page List' parent="Page Management" title="Page" />
            <Container fluid={true}>
                <div className='d-flex justify-content-between'>
                    <div className='m-2'>
                        <input
                            type='text'
                            placeholder='Search...'
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className='form-control'
                        />
                    </div>
                    <button className='btn btn-primary btn-sm m-2' onClick={() => { setPageToEdit(null); setModalOpen(true); }}>Create Page</button>
                </div>
                <DataTable
                    data={filteredPages}
                    columns={columns}
                    striped={true}
                    center={true}
                    pagination
                    highlightOnHover
                    pointerOnHover
                    noDataComponent={<div className='text-center'>No pages found</div>}
                    customStyles={{
                        rows: {
                            style: {
                                transition: 'background-color 0.2s ease',
                            },
                        },
                    }}
                />
                <Modal isOpen={isModalOpen} toggle={() => setModalOpen(false)}>
                    <ModalHeader toggle={() => setModalOpen(false)}>{userToEdit ? 'Edit Page' : 'Create Page'}</ModalHeader>
                    <ModalBody>
                        <BlockForm onClose={() => setModalOpen(false)} refreshPages={fetchPages} userToEdit={userToEdit} />
                    </ModalBody>
                </Modal>
            </Container>
        </Fragment>
    );
};

export default Pages;