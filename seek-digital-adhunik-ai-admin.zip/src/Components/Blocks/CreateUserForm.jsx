import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button, Card, CardBody } from 'reactstrap';
import './BlockManagement.css';
import CustomEditor from '../Ckeditor/custom-editor';
import { useParams } from 'react-router-dom';
import { getPage, editPage } from '../Action/PageAction';
import Swal from 'sweetalert2';

const BlockManagement = () => {
    const { page_id, blockId } = useParams();
    const [sectionType, setSectionType] = useState('content');
    const [title, setTitle] = useState('');
    const [subtitle, setSubtitle] = useState('');
    const [content, setContent] = useState('');
    const [order_number, setOrderNumber] = useState('');
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const fetchBlockData = async () => {
            if (blockId) {
                setLoading(true);
                try {
                    const blockData = await getPage(page_id, blockId);
                    if (blockData?.blocks.length > 0) {
                        const block = blockData.blocks[0];
                        setSectionType(block.sectionType || 'content');
                        setTitle(block.title || '');
                        setSubtitle(block.subtitle || '');
                        setContent(block.content || '');
                        setOrderNumber(block.order_number || '');
                    }
                } catch (error) {
                    console.error("Error fetching block data:", error);
                    Swal.fire('Error', 'Failed to fetch block data.', 'error');
                } finally {
                    setLoading(false);
                }
            }
        };

        fetchBlockData();
    }, [page_id, blockId]);

    const handleSectionTypeChange = (e) => {
        setSectionType(e.target.value);
        setTitle('');
        setSubtitle('');
        setContent('');
        setErrors({});
    };

    const validateForm = () => {
        const newErrors = {};
        if (!title) newErrors.title = 'Title is required.';
        if (title.length < 3) newErrors.title = 'Title must be at least 3 characters long.';
        if (sectionType === 'content' && !content) newErrors.content = 'Content is required.';
        if (subtitle && subtitle.length < 3) newErrors.subtitle = 'Subtitle must be at least 3 characters long.';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (validateForm()) {
            setLoading(true);
            try {
                const blockData = {
                    blocks: [
                        {
                            sectionType,
                            title,
                            subtitle,
                            content,
                            order_number
                        }
                    ]
                };

                const response = blockId 
                    ? await editPage(page_id, blockData, blockId) 
                    : await editPage(page_id, blockData);

                if (response) {
                    Swal.fire('Success', 'Successfully saved the page.', 'success');
                    resetForm();
                }
            } catch (error) {
                Swal.fire('Error', 'Failed to save page.', 'error');
            } finally {
                setLoading(false);
            }
        }
    };

    const resetForm = () => {
        setTitle('');
        setSubtitle('');
        setContent('');
        setOrderNumber('');
        setErrors({});
    };

    return (
        <Card className="shadow-lg">
            <CardBody>
                <h2 className="text-center mb-4">{blockId ? 'Edit Block' : 'Create Block'}</h2>
                <Form onSubmit={handleSubmit}>
                    <FormGroup>
                        <Label for="sectionType">Section Type</Label>
                        <Input type="select" name="sectionType" id="sectionType" value={sectionType} onChange={handleSectionTypeChange}>
                            <option value="ai_block">AI Block</option>
                            <option value="content">Content Section</option>
                        </Input>
                    </FormGroup>

                    {sectionType === 'content' && (
                        <>
                            <FormGroup>
                                <Label for="title">Title</Label>
                                <Input
                                    type="text"
                                    name="title"
                                    id="title"
                                    placeholder="Enter title"
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                    className={errors.title ? 'is-invalid' : ''}
                                />
                                {errors.title && <p className='text-danger'>{errors.title}</p>}
                            </FormGroup>
                            <FormGroup>
                                <Label for="subtitle">Subtitle</Label>
                                <Input
                                    type="text"
                                    name="subtitle"
                                    id="subtitle"
                                    placeholder="Enter subtitle"
                                    value={subtitle}
                                    onChange={(e) => setSubtitle(e.target.value)}
                                    className={errors.subtitle ? 'is-invalid' : ''}
                                />
                                {errors.subtitle && <p className='text-danger'>{errors.subtitle}</p>}
                            </FormGroup>
                            <FormGroup>
                                <Label for="content">Description</Label>
                                <CustomEditor
                                    name='content'
                                    className="form-control"
                                    placeholder="Type here...."
                                    value={content}
                                    handleChangeEditor={(name, value) => setContent(value)}
                                    height="100px"
                                />
                                {errors.content && <p className='text-danger'>{errors.content}</p>}
                            </FormGroup>
                        </>
                    )}

                    <Button type="submit" color="primary" className="w-100" disabled={loading}>
                        {loading ? 'Saving...' : (blockId ? 'Update' : 'Submit')}
                    </Button>
                </Form>
            </CardBody>
        </Card>
    );
};

export default BlockManagement;
