import React, { Fragment, useState, useEffect, useCallback } from 'react';
import { Container } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import DataTable from 'react-data-table-component';
import { deleteCustomer } from '../Action/UserAction';
import { getPage, deletePage } from '../Action/PageAction';
import Swal from 'sweetalert2';
import { Delete, Edit } from '../../Constant';
import { Link, useParams } from 'react-router-dom';

const Blocks = () => {
    const [blocks, setBlocks] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    const { layout, page_id } = useParams();

    const fetchBlocks = useCallback(async () => {
        try {
            const blockList = await getPage(page_id);
            setBlocks(blockList.blocks);
        } catch (error) {
            console.error("Error fetching blocks:", error);
            Swal.fire('Error', 'Failed to fetch blocks.', 'error');
        }
    }, [page_id]);

    useEffect(() => {
        fetchBlocks();
    }, [fetchBlocks]);

    const handleDeleteBlock = async (blockId) => {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        });

        if (result.isConfirmed) {
            try {
                const delBlock = await deletePage(page_id, blockId);
                if (delBlock) {
                    setBlocks(blocks.filter(block => block._id !== blockId));
                    Swal.fire('Deleted!', 'Block has been deleted.', 'success');
                }
            } catch (error) {
                console.error("Error deleting block:", error);
                Swal.fire('Error', 'Failed to delete block.', 'error');
            }
        }
    };

    const columns = [
        {
            name: 'SL NO',
            selector: (row, index) => ++index,
            sortable: false,
        },
        {
            name: 'Blocks',
            selector: row => row.title,
            sortable: true,
        },
        {
            name: 'Actions',
            cell: (row) => (
                <div>
                    <Link
                        to={`/blocks/create/${layout}/${page_id}/${row._id}`}
                        className="btn btn-primary btn-sm m-2"
                        aria-label={`Edit ${row.title}`}
                    >
                        <i className='fa fa-pencil'></i> {Edit}
                    </Link>
                    <button
                        className='btn border-button-danger btn-xs'
                        onClick={() => handleDeleteBlock(row._id)}
                        aria-label={`Delete ${row.title}`}
                    >
                        <i className='fa fa-trash'></i> {Delete}
                    </button>
                </div>
            ),
        },
    ];

    const filteredBlocks = blocks.filter(block =>
        block?.title?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Fragment>
            <Breadcrumbs mainTitle='Block List' parent="Block Management" title="Block" />
            <Container fluid={true}>
                <div className='d-flex justify-content-between'>
                    <div className='m-2'>
                        <input
                            type='text'
                            placeholder='Search...'
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className='form-control'
                            aria-label="Search blocks"
                        />
                    </div>
                    <Link
                        to={`/blocks/create/${layout}/${page_id}`}
                        className="btn btn-primary btn-sm m-2"
                    >
                        Create Block
                    </Link>
                </div>
                <DataTable
                    data={filteredBlocks}
                    columns={columns}
                    striped={true}
                    center={true}
                    pagination
                    highlightOnHover
                    pointerOnHover
                    noDataComponent={<div className='text-center'>No blocks found</div>}
                    customStyles={{
                        rows: {
                            style: {
                                transition: 'background-color 0.2s ease',
                            },
                        },
                    }}
                />
            </Container>
        </Fragment>
    );
};

export default Blocks;


