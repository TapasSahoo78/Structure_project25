import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button } from 'reactstrap';
import Swal from 'sweetalert2';
import { addCategory, editCategory, getAllCategories } from '../Action/CategoryAction'; // Ensure correct import

const CategoryForm = ({ onClose, refreshCategories, categoryToEdit }) => {
    const [categoryData, setCategoryData] = useState({
        name: '',
        description: '',
        icon: '',
        parent_id: '', // Add parent_id field
    });

    const [categories, setCategories] = useState([]);

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const categoryList = await getAllCategories(); 
                setCategories(categoryList);
            } catch (error) {
                console.error("Error fetching categories:", error);
                Swal.fire('Error', 'Failed to fetch categories.', 'error');
            }
        };

        fetchCategories();

        if (categoryToEdit) {
            setCategoryData(categoryToEdit);
        }
    }, [categoryToEdit]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCategoryData({ ...categoryData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            let response = false
            if (categoryToEdit) {
                response = await editCategory(categoryData._id, categoryData);
            } else {
                response = await addCategory(categoryData);
            }
            if(response){
                refreshCategories(); // Refresh the category list after adding/updating
                onClose(); // Close the modal
            }
        } catch (error) {
            Swal.fire('Error', 'Failed to save category.', 'error');
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <FormGroup>
                <Label className="col-form-label pt-0">Category Name</Label>
                <Input
                    type="text"
                    name="name"
                    placeholder="Enter category name"
                    value={categoryData.name}
                    onChange={handleChange}
                    required
                />
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Description</Label>
                <Input
                    type="textarea"
                    name="description"
                    placeholder="Enter category description"
                    value={categoryData.description}
                    onChange={handleChange}
                    required
                />
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Icon</Label>
                <Input
                    type="text"
                    name="icon"
                    placeholder="Enter icon URL or name"
                    value={categoryData.icon}
                    onChange={handleChange}
                    required
                />
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Parent Category</Label>
                <Input
                    type="select"
                    name="parent_id"
                    value={categoryData.parent_id}
                    onChange={handleChange}
                >
                    <option value="">None (Root Category)</option>
                    {categories.map((category) => (
                        <option key={category._id} value={category._id}>
                            {category.name}
                        </option>
                    ))}
                </Input>
            </FormGroup>
            <div className="form-group d-flex justify-content-between">
                <Button type="submit" color="primary">{categoryToEdit ? 'Update Category' : 'Create Category'}</Button>
                <Button type="button" color="secondary" onClick={onClose}>Cancel</Button>
            </div>
        </Form>
    );
};

export default CategoryForm;
