import React, { Fragment, useState, useEffect } from 'react';
import { Container, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import DataTable from 'react-data-table-component';
import { getAllCategories, deleteCategory } from '../Action/CategoryAction'; // Adjust the import path as necessary
import Swal from 'sweetalert2';
import { Delete, Edit } from '../../Constant';
import CategoryForm from './CreateCategoryForm'; // Import the CategoryForm

const Categories = () => {
    const [categories, setCategories] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setModalOpen] = useState(false);
    const [categoryToEdit, setCategoryToEdit] = useState(null); // State to hold category data for editing

    const fetchCategories = async () => {
        try {
            const categoryList = await getAllCategories();
            setCategories(categoryList);
        } catch (error) {
            console.error("Error fetching categories:", error);
            Swal.fire('Error', 'Failed to fetch categories.', 'error');
        }
    };

    useEffect(() => {
        fetchCategories();
    }, []);

    const handleDeleteCategory = async (categoryId) => {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        });

        if (result.isConfirmed) {
            await deleteCategory(categoryId);
            setCategories(categories.filter(category => category._id !== categoryId));
        }
    };

    const handleEditCategory = (category) => {
        setCategoryToEdit(category); // Set the category to edit
        setModalOpen(true); // Open the modal
    };

    const columns = [
        {
            name: 'Category Name',
            selector: row => row.name,
            sortable: true,
        },
        {
            name: 'Description',
            selector: row => row.description,
            sortable: true,
        },
        {
            name: 'Icon',
            selector: row => row.icon,
            sortable: true,
        },
        {
            name: 'Parent Category',
            selector: row => row.parent_id ? row.parent : 'None',
            sortable: true,
        },
        {
            name: 'Actions',
            cell: row => (
                <div>
                    <button className='btn border-button-primary btn-xs' onClick={() => handleEditCategory(row)}>
                        <i className='fa fa-pencil'></i> {Edit}
                    </button>
                    <button className='btn border-button-danger btn-xs' onClick={() => handleDeleteCategory(row._id)}>
                        <i className='fa fa-trash'></i> {Delete}
                    </button>
                </div>
            ),
        },
    ];
    

    const filteredCategories = categories.filter(category => 
        category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        category.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Fragment>
            <Breadcrumbs mainTitle='Category List' parent="Category Management" title="Categories" />
            <Container fluid={true}>
                <div className='d-flex justify-content-between'>
                    <div className='m-2'>
                        <input
                            type='text'
                            placeholder='Search...'
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className='form-control'
                        />
                    </div>
                    <button className='btn btn-primary btn-sm m-2' onClick={() => { setCategoryToEdit(null); setModalOpen(true); }}>Create Category</button>
                </div>
                <DataTable
                    data={filteredCategories}
                    columns={columns}
                    striped={true}
                    center={true}
                    pagination
                    highlightOnHover
                    pointerOnHover
                    noDataComponent={<div className='text-center'>No categories found</div>}
                    customStyles={{
                        rows: {
                            style: {
                                transition: 'background-color 0.2s ease',
                            },
                        },
                    }}
                />
                <Modal isOpen={isModalOpen} toggle={() => setModalOpen(false)}>
                    <ModalHeader toggle={() => setModalOpen(false)}>
                        {categoryToEdit ? 'Edit Category' : 'Create Category'}
                    </ModalHeader>
                    <ModalBody>
                        <CategoryForm onClose={() => setModalOpen(false)} refreshCategories={fetchCategories} categoryToEdit={categoryToEdit} />
                    </ModalBody>
                </Modal>
            </Container>
        </Fragment>
    );
};

export default Categories;
