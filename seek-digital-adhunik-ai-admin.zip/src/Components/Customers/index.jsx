import React, { Fragment, useState, useEffect } from 'react';
import { Container, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import DataTable from 'react-data-table-component';
import { getAllCustomers, deleteCustomer } from '../Action/UserAction';
import Swal from 'sweetalert2';
import { Delete, Edit } from '../../Constant';
import UserForm from './CreateUserForm'; // Import the UserForm

const Users = () => {
    const [users, setUsers] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setModalOpen] = useState(false); // State to control modal visibility
    const [userToEdit, setUserToEdit] = useState(null); // State to hold user data for editing

    const fetchUsers = async () => {
        try {
            const userList = await getAllCustomers();
            setUsers(userList);
        } catch (error) {
            console.error("Error fetching users:", error);
            Swal.fire('Error', 'Failed to fetch users.', 'error');
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const handleDeleteUser = async (userId) => {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        });

        if (result.isConfirmed) {
            await deleteCustomer(userId);
            setUsers(users.filter(user => user._id !== userId));
        }
    };

    const handleEditUser = (user) => {
        setUserToEdit(user); // Set the user to edit
        setModalOpen(true); // Open the modal
    };

    const columns = [
        {
            name: 'First Name',
            selector: row => row.first_name,
            sortable: true,
        },
        {
            name: 'Last Name',
            selector: row => row.last_name,
            sortable: true,
        },
        {
            name: 'Email',
            selector: row => row.email,
            sortable: true,
        },
        {
            name: 'Phone Number',
            selector: row => row.phone_number,
            sortable: true,
        },
        {
            name: 'Role',
            selector: row => row.roleName,
            sortable: true,
        },
        {
            name: 'Actions',
            cell: row => (
                <div>
                    <button className='btn border-button-primary btn-xs' onClick={() => handleEditUser(row)}>
                        <i className='fa fa-pencil'></i> {Edit}
                    </button>
                    <button className='btn border-button-danger btn-xs' onClick={() => handleDeleteUser(row._id)}>
                        <i className='fa fa-trash'></i> {Delete}
                    </button>
                </div>
            ),
        },
    ];

    const filteredUsers = users.filter(user => 
        user.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        String(user.phone_number).includes(searchTerm)
    );

    return (
        <Fragment>
            <Breadcrumbs mainTitle='User List' parent="User Management" title="Users" />
            <Container fluid={true}>
                <div className='d-flex justify-content-between'>
                    <div className='m-2'>
                        <input
                            type='text'
                            placeholder='Search...'
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className='form-control'
                        />
                    </div>
                    <button className='btn btn-primary btn-sm m-2' onClick={() => { setUserToEdit(null); setModalOpen(true); }}>Create User</button>
                </div>
                <DataTable
                    data={filteredUsers}
                    columns={columns}
                    striped={true}
                    center={true}
                    pagination
                    highlightOnHover
                    pointerOnHover
                    noDataComponent={<div className='text-center'>No users found</div>}
                    customStyles={{
                        rows: {
                            style: {
                                transition: 'background-color 0.2s ease',
                            },
                        },
                    }}
                />
                <Modal isOpen={isModalOpen} toggle={() => setModalOpen(false)}>
                    <ModalHeader toggle={() => setModalOpen(false)}>{userToEdit ? 'Edit User' : 'Create User'}</ModalHeader>
                    <ModalBody>
                        <UserForm onClose={() => setModalOpen(false)} refreshUsers={fetchUsers} userToEdit={userToEdit} />
                    </ModalBody>
                </Modal>
            </Container>
        </Fragment>
    );
};

export default Users;
