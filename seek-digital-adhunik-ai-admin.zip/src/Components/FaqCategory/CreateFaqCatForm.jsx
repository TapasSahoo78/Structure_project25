import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button, Col, Row, FormFeedback } from 'reactstrap';
import Swal from 'sweetalert2';
import { addCategory, editCategory } from '../Action/FaqAction';

const CreateFaqCatForm = ({ onClose, refreshUsers, userToEdit }) => {
    const [userData, setUserData] = useState({
        name: '',
        description: ''
    });
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (userToEdit) {
            setUserData({
                name: userToEdit.name || '',
                description: userToEdit.description || ''
            });
        } else {
            setUserData({
                name: '',
                description: ''
            });
        }
    }, [userToEdit]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({ ...userData, [name]: value });
        setErrors({ ...errors, [name]: '' });
    };

    const validateForm = () => {
        const newErrors = {};
        if (!userData.name) {
            newErrors.name = 'Category Name is required.';
        }
        if (!userData.description) {
            newErrors.description = 'Description is required.';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        try {
            let response = false;
            if (userToEdit) {
                response = await editCategory(userToEdit._id, userData);
            } else {
                response = await addCategory(userData);
            }
            if (response) {
                refreshUsers();
                onClose();
            }
        } catch (error) {
            Swal.fire('Error', 'Failed to save category.', 'error');
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <Row>
                <Col sm="12">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Category Name</Label>
                        <Input
                            className="form-control"
                            type="text"
                            name="name"
                            placeholder="Category Name"
                            value={userData.name}
                            onChange={handleChange}
                            invalid={!!errors.name}
                        />
                        {errors.name && <FormFeedback>{errors.name}</FormFeedback>}
                    </FormGroup>
                </Col>
                <Col sm="12">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Description</Label>
                        <textarea
                            className="form-control"
                            name="description"
                            placeholder="Description"
                            value={userData.description}
                            onChange={handleChange}
                            invalid={!!errors.description}
                        />
                        {errors.description && <FormFeedback>{errors.description}</FormFeedback>}
                    </FormGroup>
                </Col>
            </Row>
            <div className="form-group d-flex justify-content-between">
                <Button type="submit" color="primary">
                    {userToEdit ? 'Update Category' : 'Create Category'}
                </Button>
                <Button type="button" color="secondary" onClick={onClose}>
                    Cancel
                </Button>
            </div>
        </Form>
    );
};

export default CreateFaqCatForm;
