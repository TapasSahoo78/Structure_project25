import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button, Col, Row, FormFeedback } from 'reactstrap';
import Swal from 'sweetalert2';
import { addFaq, editFaq, getAllCategories } from '../Action/FaqAction';

const CreateFaqForm = ({ onClose, refreshUsers, userToEdit }) => {
    const [userData, setUserData] = useState({
        faqCategoryId: '',
        question: '',
        answer: '',
    });
    const [errors, setErrors] = useState({});
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const categoryList = await getAllCategories();
                setCategories(categoryList);
            } catch (error) {
                console.error("Error fetching categories:", error);
                Swal.fire('Error', 'Failed to fetch categories.', 'error');
            }
        };

        fetchCategories();

        if (userToEdit) {
            setUserData({
                faqCategoryId: userToEdit.faqCategoryId || '',
                question: userToEdit.question || '',
                answer: userToEdit.answer || '',
            });
        } else {
            setUserData({
                faqCategoryId: '',
                question: '',
                answer: '',
            });
        }
    }, [userToEdit]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setUserData({ ...userData, [name]: type === 'checkbox' ? checked : value });
        setErrors({ ...errors, [name]: '' });
    };

    const validateForm = () => {
        const newErrors = {};
        if (!userData.faqCategoryId) {
            newErrors.faqCategoryId = 'Category ID is required.';
        }
        if (!userData.question) {
            newErrors.question = 'Question is required.';
        }
        if (!userData.answer) {
            newErrors.answer = 'Answer is required.';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        try {
            let response = false;
            if (userToEdit) {
                response = await editFaq(userToEdit._id, userData);
            } else {
                response = await addFaq(userData);
            }
            if (response) {
                refreshUsers();
                onClose();
            }
        } catch (error) {
            Swal.fire('Error', 'Failed to save FAQ.', 'error');
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <Row>
                <Col sm="12">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Category</Label>
                        <Input
                            type="select"
                            name="faqCategoryId"
                            value={userData.faqCategoryId}
                            onChange={handleChange}
                            invalid={!!errors.faqCategoryId}>
                            <option value="">Select Category</option>
                            {categories.map(category => (
                                <option key={category._id} value={category._id}>
                                    {category.name}
                                </option>
                            ))}
                        </Input>
                        {errors.faqCategoryId && <FormFeedback>{errors.faqCategoryId}</FormFeedback>}
                    </FormGroup>
                </Col>
                <Col sm="12">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Question</Label>
                        <Input
                            className="form-control"
                            type="text"
                            name="question"
                            placeholder="Question"
                            value={userData.question}
                            onChange={handleChange}
                            invalid={!!errors.question}
                        />
                        {errors.question && <FormFeedback>{errors.question}</FormFeedback>}
                    </FormGroup>
                </Col>
                <Col sm="12">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Answer</Label>
                        <textarea
                            className=" form-control"
                            name="answer"
                            placeholder="Answer"
                            value={userData.answer}
                            onChange={handleChange}
                            invalid={!!errors.answer}
                        />
                        {errors.answer && <FormFeedback>{errors.answer}</FormFeedback>}
                    </FormGroup>
                </Col>
            </Row>
            <div className="form-group d-flex justify-content-between">
                <Button type="submit" color="primary">
                    {userToEdit ? 'Update FAQ' : 'Create FAQ'}
                </Button>
                <Button type="button" color="secondary" onClick={onClose}>
                    Cancel
                </Button>
            </div>
        </Form>
    );
};

export default CreateFaqForm;