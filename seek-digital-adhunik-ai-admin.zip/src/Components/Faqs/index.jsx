import React, { Fragment, useState, useEffect } from 'react';
import { Container, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import DataTable from 'react-data-table-component';
import { getAllFaqs, deleteFaq } from '../Action/FaqAction';
import Swal from 'sweetalert2';
import { Delete, Edit } from '../../Constant';
import CreateFaqForm from './CreateFaqForm';

const Users = () => {
    const [faqs, setFaqs] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setModalOpen] = useState(false);
    const [faqToEdit, setFaqToEdit] = useState(null);

    const fetchFaqs = async () => {
        try {
            const faqList = await getAllFaqs();
            setFaqs(faqList);
        } catch (error) {
            console.error("Error fetching FAQs:", error);
            Swal.fire('Error', 'Failed to fetch FAQs.', 'error');
        }
    };

    useEffect(() => {
        fetchFaqs();
    }, []);

    const handleDeleteFaq = async (faqId) => {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        });

        if (result.isConfirmed) {
            await deleteFaq(faqId);
            setFaqs(faqs.filter(faq => faq._id !== faqId));
            Swal.fire('Deleted!', 'Your FAQ has been deleted.', 'success');
        }
    };

    const handleEditFaq = (faq) => {
        setFaqToEdit(faq);
        setModalOpen(true);
    };

    const columns = [
        {
            name: 'Category',
            selector: row => row.categoryName,
            sortable: true,
        },
        {
            name: 'Question',
            selector: row => row.question,
            sortable: true,
        },
        {
            name: 'Answer',
            selector: row => row.answer,
            sortable: true,
        },
        {
            name: 'Actions',
            cell: row => (
                <div>
                    <button className='btn border-button-primary btn-xs' onClick={() => handleEditFaq(row)}>
                        <i className='fa fa-pencil'></i> {Edit}
                    </button>
                    <button className='btn border-button-danger btn-xs' onClick={() => handleDeleteFaq(row._id)}>
                        <i className='fa fa-trash'></i> {Delete}
                    </button>
                </div>
            ),
        },
    ];

    const filteredFaqs = faqs.filter(faq =>
        faq.question.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Fragment>
            <Breadcrumbs mainTitle='FAQ List' parent="FAQ Management" title="FAQ" />
            <Container fluid={true}>
                <div className='d-flex justify-content-between'>
                    <div className='m-2'>
                        <input
                            type='text'
                            placeholder='Search by question...'
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className='form-control'
                        />
                    </div>
                    <button className='btn btn-primary btn-sm m-2' onClick={() => { setFaqToEdit(null); setModalOpen(true); }}>
                        Create FAQ
                    </button>
                </div>
                <DataTable
                    data={filteredFaqs}
                    columns={columns}
                    striped={true}
                    center={true}
                    pagination
                    highlightOnHover
                    pointerOnHover
                    noDataComponent={<div className='text-center'>No FAQ found</div>}
                    customStyles={{
                        rows: {
                            style: {
                                    transition: 'background-color 0.2s ease',
                                },
                        },
                    }}
                />
                <Modal isOpen={isModalOpen} toggle={() => setModalOpen(false)}>
                    <ModalHeader toggle={() => setModalOpen(false)}>
                        {faqToEdit ? 'Edit FAQ' : 'Create FAQ'}
                    </ModalHeader>
                    <ModalBody>
                        <CreateFaqForm onClose={() => setModalOpen(false)} refreshUsers={fetchFaqs} userToEdit={faqToEdit} />
                    </ModalBody>
                </Modal>
            </Container>
        </Fragment>
    );
};

export default Users;
