import React, { Fragment, useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import { Col, Container, Form, FormGroup, Input, Label, Row } from 'reactstrap';
import { Btn, H4, H6, P, Image } from '../../../AbstractElements';
import logoWhite from '../../../assets/images/logo/logo.png';
import logoDark from '../../../assets/images/logo/logo_dark.png';
import { forgotPasswordEmail, verifyOtp, resetPassword } from '../../Action/ForgetPasswordAction';

const ForgetPwd = ({ logoClassMain }) => {
  const [togglePassword, setTogglePassword] = useState(false);
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    try {
      const response = await forgotPasswordEmail(email);
      setStep(2);
    } catch (error) {
        setErrorMessage("Something Went Wrong");
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    const otpValue = otp.join('');
    setErrorMessage('');
    try {
      const response = await verifyOtp(email, otpValue);
      setStep(3);
    } catch (error) {
        setErrorMessage("Something Went Wrong");
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match!");
      return;
    }
    setErrorMessage('');
    try {
      const response = await resetPassword(email, password, confirmPassword);
      navigate('/login');
    } catch (error) {
      setErrorMessage("Something Went Wrong");
    }
  };

  const handleOtpChange = (index, value) => {
    if (value.length <= 1 && /^[0-9]*$/.test(value)) { // Allow only one digit
      const newOtp = [...otp];
      newOtp[index] = value; // Update the current index with the new value
      setOtp(newOtp);

      // Move to the next input field if the current one is filled
      if (value && index < otp.length - 1) {
        const nextInput = document.getElementById(`otp-input-${index + 1}`);
        if (nextInput) {
          nextInput.focus();
        }
      }
    }
  };
  return (
    <Fragment>
      <section>
        <Container className='p-0 login-page' fluid={true}>
          <Row className='m-0'>
            <Col className='p-0'>
              <div className='login-card'>
                <div>
                  <div>
                    <Link className={`logo`} to={'#'}>
                      <Image attrImage={{ className: 'img-fluid for-light', src: logoWhite, alt: 'loginpage' }} />
                      <Image attrImage={{ className: 'img-fluid for-dark', src: logoDark, alt: 'loginpage' }} />
                    </Link>
                  </div>
                  <div className='login-main'>
                    <Form className='theme-form login-form' onSubmit={step === 1 ? handleEmailSubmit : step === 2 ? handleOtpSubmit : handlePasswordSubmit}>
                      <H4>{step === 1 ? "Reset Your Password" : step === 2 ? "Enter OTP" : "Create Your Password"}</H4>
                      {errorMessage && <p className='text-danger'>{errorMessage}</p>}
                      {step === 1 && (
                        <FormGroup>
                          <Label className='m-0 col-form-label'>Enter Your Email ID</Label>
                          <Row>
                            <Col xs='12' sm='12'>
                              <Input className='form-control' type='email' placeholder='Enter your Email ID' value={email} onChange={(e) => setEmail(e.target.value)} required />
                            </Col>
                          </Row>
                        </FormGroup>
                      )}
                      {step === 2 && (
                        <FormGroup>
                        <Label>Enter OTP</Label>
                        <Row>
                          {otp.map((digit, index) => (
                            <Col key={index}>
                              <Input
                                id={`otp-input-${index}`} // Unique ID for each input
                                className='form-control text-center opt-text'
                                type='text'
                                value={digit}
                                maxLength={1} // Allow only one character
                                onChange={(e) => handleOtpChange(index, e.target.value)}
                              />
                            </Col>
                          ))}
                        </Row>
                      </FormGroup>
                      )}
                      {step === 3 && (
                        <>
                          <H6 attrH6={{ className: 'mt-4' }}>Create Your Password</H6>
                          <FormGroup className='position-relative'>
                            <Label className='col-form-label m-0'>New Password</Label>
                            <div className='position-relative'>
                              <Input className='form-control' type={togglePassword ? "text" : "password"} required placeholder='*********' value={password} onChange={(e) => setPassword(e.target.value)} />
                              <div className='show-hide' onClick={() => setTogglePassword(!togglePassword)}>
                                <span className={togglePassword ? '' : 'show'}></span>
                              </div>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <Label className='col-form-label m-0'>Retype Password</Label>
                            <Input className='form-control' type='password' required placeholder='*********' value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                          </FormGroup>
                        </>
                      )}
                      <FormGroup className='text-end'>
                        <Btn attrBtn={{ className: 'btn-block ', color: 'primary', type: 'submit' }}>
                          {step === 1 ? "Send" : step === 2 ? "Verify OTP" : "Done"}
                        </Btn>
                      </FormGroup>
                      {step === 2 && (
                        <FormGroup className='mb-4 mt-4'>
                          <span className='reset-password-link'>
                            If you don't receive OTP?  
                            <a className='btn-link text-danger' href='#javascript'>
                              Resend
                            </a>
                          </span>
                        </FormGroup>
                      )}
                      <P attrPara={{ className: 'text-start' }}>
                        Already have a password?
                        <Link className='ms-2' to='/login'>
                          Sign in
                        </Link>
                      </P>
                    </Form>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </Fragment>
  );
};

export default ForgetPwd;
