import React, { useState, useEffect } from 'react';
import { Form, FormGroup, Label, Input, Button, Col, Row } from 'reactstrap';
import Swal from 'sweetalert2';
import { addUser, editUser } from '../Action/UserAction'; // Import editUser action
import { getAllRole } from '../Action/RoleAction';

const UserForm = ({ onClose, refreshUsers, userToEdit }) => {
    const [userData, setUserData] = useState({
        first_name: '',
        middle_name: '',
        last_name: '',
        user_name: '',
        email: '',
        phone_number: '',
        address_line_1: '',
        address_line_2: '',
        city: '',
        state: '',
        country: '',
        ZIP: '',
        roleId: '',
        is_active: true,
        is_registered: true,
        gender: 'male' // Default to male for new users
    });

    const [roles, setRoles] = useState([]);

    useEffect(() => {
        const fetchRoles = async () => {
            const fetchedRoles = await getAllRole();
            setRoles(fetchedRoles);
        };
        fetchRoles();
    }, []);

    useEffect(() => {
        if (userToEdit) {
            // Populate form with user data for editing
            setUserData(prevData => ({
                ...prevData,
                ...userToEdit,
                gender: userToEdit.gender || 'male' // Default to 'male' if gender is empty
            }));
        }else {
            // Reset gender to 'male' when adding a new user
            setUserData(prevData => ({
                ...prevData,
                gender: 'male' // Ensure gender is 'male' for new user
            }));
        }
    }, [userToEdit]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({ ...userData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            let response = false;
            if (userToEdit) {
                response = await editUser(userToEdit._id, userData);
            } else {
                response = await addUser(userData);
            }
            if (response) {
                refreshUsers(); // Refresh the user list after adding/updating
                onClose(); // Close the form/modal
            }
        } catch (error) {
            Swal.fire('Error', 'Failed to save user.', 'error');
        }
    };

    return (
        <Form className="theme-form" onSubmit={handleSubmit}>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Role</Label>
                        <Input 
                            type="select" 
                            name="roleId" 
                            onChange={handleChange} 
                            value={userData.roleId} 
                            disabled={userToEdit} // Disable when editing
                            required
                        >
                            <option value="">Select Role</option>
                            {roles.map(role => (
                                <option key={role.id} value={role.id}>{role.name}</option>
                            ))}
                        </Input>
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">First Name</Label>
                        <Input className="form-control" type="text" name="first_name" placeholder="First Name" value={userData.first_name} onChange={handleChange} required />
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Middle Name</Label>
                        <Input className="form-control" type="text" name="middle_name" placeholder="Middle Name" value={userData.middle_name} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Last Name</Label>
                        <Input className="form-control" type="text" name="last_name" placeholder="Last Name" value={userData.last_name} onChange={handleChange} required />
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Username</Label>
                        <Input className="form-control" type="text" name="user_name" placeholder="Username" value={userData.user_name} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Phone Number</Label>
                        <Input className="form-control" type="tel" name="phone_number" placeholder="Phone Number" value={userData.phone_number} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <FormGroup>
                <Label className="col-form-label pt-0">Email Address</Label>
                <Input className="form-control" type="email" name="email" placeholder="Enter email" value={userData.email} onChange={handleChange} required />
                <small className="form-text text-muted">We'll never share your email with anyone else.</small>
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Address Line 1</Label>
                <Input className="form-control" type="text" name="address_line_1" placeholder="Address Line 1" value={userData.address_line_1} onChange={handleChange} required />
            </FormGroup>
            <FormGroup>
                <Label className="col-form-label pt-0">Address Line 2</Label>
                <Input className="form-control" type="text" name="address_line_2" placeholder="Address Line 2" value={userData.address_line_2} onChange={handleChange} />
            </FormGroup>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">City</Label>
                        <Input className="form-control" type="text" name="city" placeholder="City" value={userData.city} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">State</Label>
                        <Input className="form-control" type="text" name="state" placeholder="State" value={userData.state} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Country</Label>
                        <Input className="form-control" type="text" name="country" placeholder="Country" value={userData.country} onChange={handleChange} />
                    </FormGroup>
                </Col>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">ZIP Code</Label>
                        <Input className="form-control" type="text" name="ZIP" placeholder="ZIP Code" value={userData.ZIP} onChange={handleChange} />
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col sm="6">
                    <FormGroup>
                        <Label className="col-form-label pt-0">Gender</Label>
                        <Input 
                            type="select" 
                            name="gender" 
                            onChange={handleChange} 
                            value={userData.gender} 
                            required
                        >
                            <option value="male" >Male</option>
                            <option value="female">Female</option>
                            <option value="others">Others</option>
                        </Input>
                    </FormGroup>
                </Col>
            </Row>
            <div className="form-group d-flex justify-content-between">
                <Button type="submit" color="primary">{userToEdit ? 'Update User' : 'Create User'}</Button>
                <Button type="button" color="secondary" onClick={onClose}>Cancel</Button>
            </div>
        </Form>
    );
};

export default UserForm;
