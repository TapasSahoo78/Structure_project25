export const MENUITEMS = [
  {
    menutitle: "General",
    menucontent: "Dashboards,Widgets",
    Items: [
      { path: `${process.env.REACT_APP_PUBLIC_URL}/dashboard/default`, icon: "home", title: "Dashboard", type: "link" },
      {
        title: "Tool Management",
        icon: "file",
        type: "sub",
        badge: "badge badge-light-primary",
        active: false,
        children: [
          { path: `${process.env.REACT_APP_PUBLIC_URL}/category`, title: "Category", type: "link" },
          { path: `${process.env.REACT_APP_PUBLIC_URL}/tool`, title: "Tools", type: "link" },
        ],
      },
    ],
  },
  {
    menutitle: "User Management",
    menucontent: "Dashboards,Widgets",
    Items: [
      { path: `${process.env.REACT_APP_PUBLIC_URL}/users`, icon: "user", title: "All Users", type: "link" },
      { path: `${process.env.REACT_APP_PUBLIC_URL}/admin-users`, icon: "user", title: "Admin Users", type: "link" },
      { path: `${process.env.REACT_APP_PUBLIC_URL}/customers`, icon: "user", title: "Customer", type: "link" },
    ],
  },
  {
    menutitle: "CMS Management",
    menucontent: "Dashboards,Widgets",
    Items: [
      { path: `${process.env.REACT_APP_PUBLIC_URL}/faq-category`, icon: "file", title: "Faq Category", type: "link" },
      { path: `${process.env.REACT_APP_PUBLIC_URL}/faqs`, icon: "file", title: "Faqs", type: "link" },
      { path: `${process.env.REACT_APP_PUBLIC_URL}/pages`, icon: "file", title: "Pages", type: "link" },
      // { path: `${process.env.REACT_APP_PUBLIC_URL}/blocks`, icon: "file", title: "Blocks", type: "link" },
      { path: `${process.env.REACT_APP_PUBLIC_URL}/menus`, icon: "file", title: "Menus", type: "link" },
    ],
  }
];
