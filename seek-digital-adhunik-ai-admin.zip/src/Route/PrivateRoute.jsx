import { Navigate, Outlet } from "react-router-dom";

const PrivateRoute = ({  }) => {
    const isAuthenticated = !!localStorage.getItem('token');
    
    return !isAuthenticated ? (
        <Navigate to="/login" replace />
    ) : (
        <Outlet />
    );
}

export default PrivateRoute;
