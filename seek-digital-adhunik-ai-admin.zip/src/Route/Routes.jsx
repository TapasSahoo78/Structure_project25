import Default from "../Components/Dashboard/Default";

import SupportTickitContain from "../Components/SupportTicket";
import FAQContent from "../Components/FAQ";
import Users from "../Components/Users";
import Category from "../Components/Category"
import AdminUsers from "../Components/AdminUsers"
import Customers from "../Components/Customers"
import UsersEditContain from "../Components/Application/Users/UsersEdit";
import FaqCategory from "../Components/FaqCategory"
import Faqs from "../Components/Faqs"
import Pages from "../Components/BlockPages"
import Blocks from "../Components/Blocks"
import BlockCreate from "../Components/Blocks/CreateUserForm"
import Menus from "../Components/Menus"

export const routes = [
  { path: `${process.env.REACT_APP_PUBLIC_URL}/dashboard/default/:layout`, Component: <Default /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/users/:layout`, Component: <Users /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/category/:layout`, Component: <Category /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/admin-users/:layout`, Component: <AdminUsers /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/customers/:layout`, Component: <Customers /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/my-account/:layout`, Component: <UsersEditContain /> },

  // //Support Ticket
  { path: `${process.env.REACT_APP_PUBLIC_URL}/app/supportticket/:layout`, Component: <SupportTickitContain /> },

  // //Faq
  { path: `${process.env.REACT_APP_PUBLIC_URL}/app/faq/:layout`, Component: <FAQContent /> },

  //CMS Section
  { path: `${process.env.REACT_APP_PUBLIC_URL}/faq-category/:layout`, Component: <FaqCategory /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/faqs/:layout`, Component: <Faqs /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/pages/:layout`, Component: <Pages /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/blocks/:layout/:page_id?`, Component: <Blocks /> },
  { path: `${process.env.REACT_APP_PUBLIC_URL}/menus/:layout`, Component: <Menus /> },


  { path: `${process.env.REACT_APP_PUBLIC_URL}/blocks/create/:layout/:page_id?/:blockId?`, Component: <BlockCreate /> }
];
