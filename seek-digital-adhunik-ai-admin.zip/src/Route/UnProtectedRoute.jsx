import { Navigate, Outlet } from "react-router-dom";

const UnProtectedRoute = ({  }) => {
    const isAuthenticated = !!localStorage.getItem('token')


    return !isAuthenticated ? <Outlet /> : <Navigate to="/" replace />; // Redirect to home if authenticated
}

export default UnProtectedRoute;
