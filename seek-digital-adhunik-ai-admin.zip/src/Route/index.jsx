import React, { Suspense, useEffect, useState } from "react";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import Loader from "../Layout/Loader";
import { authRoutes } from "./AuthRoutes";
import LayoutRoutes from "../Route/LayoutRoutes";
import Signin from "../Auth/Signin";
import PrivateRoute from "./PrivateRoute";
import UnProtectedRoute from "./UnProtectedRoute";
import { classes } from "../Data/Layouts";
import ForgetPwd from "../Components/Pages/Auth/ForgetPwd";

const Routers = () => {
  const [authenticated, setAuthenticated] = useState(false);
  const defaultLayoutObj = classes.find((item) => Object.values(item).pop(1) === "compact-wrapper");
  const layout = localStorage.getItem("layout") || Object.keys(defaultLayoutObj).pop();

  useEffect(() => {
    const isAuthenticated = JSON.parse(localStorage.getItem("authenticated"));
    setAuthenticated(isAuthenticated);
  }, []);

  return (
    <BrowserRouter basename={"/"}>
      <Suspense fallback={<Loader />}>
        <Routes>
          {/* <Route path="/" element={<PrivateRoute authenticated={authenticated} />}>
            <Route path="/" element={<Navigate to={`${process.env.REACT_APP_PUBLIC_URL}/dashboard/default/${layout}`} />} />
            <Route path={`/*`} element={<LayoutRoutes />} />
          </Route> */}
          <Route element={<PrivateRoute />}>
            <Route path="/" element={<Navigate to={`${process.env.REACT_APP_PUBLIC_URL}/dashboard/default/${layout}`} />} />
            <Route path={`/*`} element={<LayoutRoutes />} />
          </Route>
          <Route element={<UnProtectedRoute />}>
            <Route path={`${process.env.REACT_APP_PUBLIC_URL}/login`} element={<Signin />} />
            <Route path={`${process.env.REACT_APP_PUBLIC_URL}/forget-password`} element={<ForgetPwd />} />
            {authRoutes.map(({ path, Component }, i) => (
              <Route path={path} element={Component} key={i} />
            ))}
          </Route>


        </Routes>
      </Suspense>
    </BrowserRouter>
  );
};

export default Routers;
