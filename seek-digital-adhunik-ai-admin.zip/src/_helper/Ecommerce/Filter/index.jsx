import { createContext } from 'react';

const FilterContext = createContext();

export default FilterContext;
