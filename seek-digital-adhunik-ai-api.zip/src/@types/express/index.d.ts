declare namespace Express {
	interface Request {
		user: any;
	}
}

declare module "googleapis";
