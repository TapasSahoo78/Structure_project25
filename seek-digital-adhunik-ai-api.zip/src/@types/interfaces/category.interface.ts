// src/interfaces/Category.ts
import { ICreated } from "./general.interface"; // Assuming this is where ICreated is defined
import { IObjectId } from "./objectId.interface";

export interface ICategorySchema extends ICreated {
    name: string;
    description: string;
    icon: string;
    parent_id?: string | null; // Optional to allow root categories
}

export interface ICategory extends ICategorySchema, IObjectId { }
