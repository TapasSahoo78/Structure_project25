export interface IBlock {
        title: string;
        subtitle?: string | null;
        content?: string | null;
        order_number?: number | null;
        status: boolean;
        id?: string;
}