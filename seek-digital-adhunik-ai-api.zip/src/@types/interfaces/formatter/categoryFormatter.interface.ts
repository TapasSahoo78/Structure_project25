import { ObjectId, SchemaDefinitionProperty } from "mongoose";
export interface ICategoryResponse {
        _id: string | ObjectId;
        name: string;
        description: string | null;
        icon: string | null;
        parent_id: ObjectId | string | null;
        parent: string | null;
        subcategory: object[] | null;
}