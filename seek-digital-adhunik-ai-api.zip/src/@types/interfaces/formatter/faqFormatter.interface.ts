import { ObjectId, SchemaDefinitionProperty } from "mongoose";
export interface IFaqResponse {
        _id: string | ObjectId;
        faqCategoryId: ObjectId,
        categoryName: string,
        question: string;
        answer: string;
        is_active: boolean;
        is_user: boolean;
}