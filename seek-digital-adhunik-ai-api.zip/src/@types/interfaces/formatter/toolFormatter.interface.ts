import { ObjectId, SchemaDefinitionProperty } from "mongoose";
export interface IToolResponse {
        _id: string | ObjectId;
        name: string;
        overview: string | null;
        updates: string | null;
        pros: string[] | null;
        cons: string[] | null;
        pricing: string;
        gallery: string[] | null;
        faq: { question: string; answer: string }[];
        categoryId: ObjectId | string;
        category: string | null;
        categoryDetails: object | null;
}