// src/interfaces/Role.ts
import { ObjectId, Types } from "mongoose";
import { ICreated } from "./general.interface"; // Assuming this is where ICreated is defined

export interface IMenuSchema extends ICreated {
    _id: ObjectId;
    parentIdId: ObjectId;
    name: string;
    menu_order: string,
    link_type: string;
    pageId: ObjectId;
    menu_group:string;
    menu_link:string,
    is_active: boolean;
}

export interface IMenu extends IMenuSchema { }
