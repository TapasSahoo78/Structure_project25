// src/interfaces/Role.ts
import { ICreated } from "./general.interface"; // Assuming this is where ICreated is defined
import { IObjectId } from "./objectId.interface";
import { IBlock } from "./formatter/blockFormatter.interface";

export interface IPageSchema extends ICreated {
    title: string;
    blocks: IBlock[];
    meta_title: string;
    meta_description: string;
    meta_keywords: string;
}

export interface IPage extends IPageSchema, IObjectId { }
