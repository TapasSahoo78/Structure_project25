import { ObjectId } from "mongoose";

export interface IToolSchema {
	categoryId: ObjectId; // Ensure it's an ObjectId
	name: string;
	overview: string;
	updates: string;
	pros: string[];
	cons: string[];
	pricing: string;
	gallery: string[];
	faq: { question: string; answer: string }[];
	created_date: Date;
	created_by: ObjectId;
}

export interface ITool extends IToolSchema {
	_id: ObjectId;
	__v?: number;
}
