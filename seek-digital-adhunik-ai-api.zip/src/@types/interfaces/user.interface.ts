import { ObjectId, SchemaDefinitionProperty } from "mongoose";
import { ContactLabel } from "../types/contactLabel/contactLabel.types";
import { Gender } from "../types/gender/gender.types";
import { ICreated } from "./general.interface";
import { IObjectId } from "./objectId.interface";

export interface IUserSchema extends ICreated {
    first_name: string;
    middle_name: string | null;
    last_name: string;
    user_name: string | null;
    password: string | null;
    email: string;
    gender: Gender;
    address_line_1: string | null;
    address_line_2: string | null;
    city: string | null;
    state: string | null;
    country: string | null;
    ZIP: string | null;
    contact_label: ContactLabel;
    phone_number: number | null;
    phone_extension: number | null;
    is_registered: boolean; // This field is for checking whether the user is registered or not.
    is_active: boolean; // This field is for chat support, that whether the user is online or not.
    is_disabled: boolean; // This field is to disable Group Owners from accessing their Profile (i.e if is_disabled = true, then particular owner will not able to login)
    devices_token: string | null;
    otp: string | null;
    expiresAt: Date | null;
    last_login_date: SchemaDefinitionProperty<Date | null>;
    roleId: ObjectId; // Added roleId to reference the user's role
}

export interface IUser extends IUserSchema, IObjectId { }
