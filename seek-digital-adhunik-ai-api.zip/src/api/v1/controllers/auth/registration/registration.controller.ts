import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../../constants/message";
import service from "../../../../../services";
import userModel from "../../../../../model/user.model";
import { formatUserResponse } from '../../../../../utils/formatter/userResponseFormatter';

export const emailVerificationWithPasswordChange = async (req: Request, res: Response): Promise<any> => {
	try {
		const { type, email, otp, password, confirmPassword } = req.body;

		if (!email || !type) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Email or type is missing!")
			});
		}
		if (type === "email") {
			const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
			const generatedOtp = await service.common.generateOtp(4);
			let emailExists = await userModel.findOne({ email: email, is_disabled: false });
			if (!emailExists) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Email Not Registered")
				});
			}
			// await service.common.sendEmail(email, "OTP Verification", "Please use the OTP " + generatedOtp + " to verify your email.", null);

			const result = await userModel.findOneAndUpdate(
				{ email: email }, // Condition to find the member by email
				{
					otp: generatedOtp,
					expiresAt: expiresAt // Ensure expiresAt is defined
				},
				{ new: true, upsert: true, runValidators: true } // Options
			);

			return res.status(StatusCodes.OK).json({
				message: "OTP sent successfully!", result: { email: result.email, otp: result.otp, expiresAt: result.expiresAt }
			});
		}
		else if (type === "otp") {
			let member = await userModel.findOne({ email });
			if (!member) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Email not found!")
				});
			}

			if (!member.otp || !member.expiresAt || member.expiresAt < new Date()) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("OTP expired or invalid!")
				});
			}

			if (member.otp !== otp) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Invalid OTP!")
				});
			}

			// OTP verified, clear it from the database
			const result = await userModel.findOneAndUpdate(
				{ email },
				{ otp: null, expiresAt: null }
			);

			return res.status(StatusCodes.OK).json({
				message: MESSAGE.custom("OTP Verified Successfully!")
			});
		}
		else if (type === "password") {
			if (!password) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Password required!")
				});
			}
			if (!confirmPassword) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Confirm password required!")
				});
			}
			if (password !== confirmPassword) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Confirm password doesn't match!")
				});
			}
			let member = await userModel.findOne({ email });
			if (!member) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.custom("Email not found!")
				});
			}

			// OTP verified, clear it from the database
			await userModel.findOneAndUpdate(
				{ email },
				{ password: await service.auth.hashPassword(password) }
			);

			const userResponse = await formatUserResponse(member);
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.custom("Password changed successfully!"),
				userResponse
			});
		}
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Invalid request type!")
		});
	} catch (error) {
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("Email verification failed!"),
			error
		});
	}
};

export const changePassword = async (req: Request, res: Response): Promise<any> => {
	try {
		const {
			email,
			old_password,
			new_password,
			confirm_password
		} = req.body;

		const user = await userModel.findOne({ email });
		if (!user) {
			return res.status(404).json({ message: 'User not found' });
		}
		// Check if the old password is correct
		const oldPassword: string = user.password ?? '';

		const isMatch = await service.auth.comparePassword(old_password, oldPassword);
		// const isMatch = await service.auth.hashPassword(old_password);
		if (!isMatch) {
			return res.status(401).json({ message: 'Old password is incorrect' });
		}

		// Check if new passwords match
		if (new_password !== confirm_password) {
			return res.status(400).json({ message: 'New passwords do not match' });
		}

		// Update the password
		user.password = await service.auth.hashPassword(new_password); // This will be hashed in the pre-save hook
		await user.save();

		res.json({ message: 'Password updated successfully' });
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
}




