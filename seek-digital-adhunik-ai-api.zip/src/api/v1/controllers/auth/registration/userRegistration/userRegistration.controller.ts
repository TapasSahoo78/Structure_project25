import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../../../constants/message";
import roleModel from "../../../../../../model/role.model";
import service from "../../../../../../services";
import userModel from "../../../../../../model/user.model";


export const userRegistration = async (req: Request, res: Response): Promise<any> => {
	try {
		const {
			roleId, // Expecting roleId from the request body
			first_name,
			middle_name,
			last_name,
			user_name,
			password,
			email,
			gender,
			address_line_1,
			address_line_2,
			city,
			state,
			country,
			ZIP,
			contact_label,
			phone_number,
			phone_extension
		} = req.body;

		// Check if the role exists
		const existingRole = await roleModel.findById(roleId);
		if (!existingRole) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom(`Role with ID '${roleId}' does not exist.`)
			});
		}

		// Check for duplicate email
		if (await service.auth.isDuplicateGroupOwnerEmailService(userModel, email)) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom(`Duplicate Email! ${email} already exists!`)
			});
		}

		// Check for duplicate phone number
		if (await service.auth.isDuplicateValueCheckService(userModel, 'phone_number', phone_number)) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom(`Duplicate Phone Number! ${phone_number} already exists!`)
			});
		}

		// Check for duplicate user name
		if (await service.auth.isDuplicateValueCheckService(userModel, 'user_name', user_name)) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom(`Duplicate UserName! ${user_name} already exists!`)
			});
		}

		const isSuperAdmin = existingRole.name === 'Super Admin';

		// Prepare user registration payload
		const userRegistrationPayload = {
			roleId: existingRole._id, // Use the role ID from the existing role
			first_name,
			middle_name,
			last_name,
			user_name,
			password: await service.auth.hashPassword(password),
			email,
			gender,
			address_line_1,
			address_line_2,
			city,
			state,
			country,
			ZIP,
			contact_label,
			phone_number,
			phone_extension,
			subscription: {
				super_admin_registration: {
					email: isSuperAdmin,
					notification: isSuperAdmin
				},
				admin_creation: {
					email: isSuperAdmin,
					notification: isSuperAdmin
				},
				admin_registration: {
					email: isSuperAdmin,
					notification: isSuperAdmin
				},
				member_creation: {
					email: isSuperAdmin,
					notification: isSuperAdmin
				},
				member_profile_updation: {
					email: isSuperAdmin,
					notification: isSuperAdmin
				}
			}
		};

		const userRegistrationInstance = await new userModel(userRegistrationPayload).save();

		console.log("======User registered successfully: ========", userRegistrationInstance);

		return res.status(StatusCodes.CREATED).json({
			message: MESSAGE.post.succAuth,
			result: userRegistrationInstance // Return the registration result
		});

	} catch (error: any) {
		console.error("Error: ", error); // Use console.error for error logging
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.post.fail,
			error: error.message || 'An unexpected error occurred.'
		});
	}
};

// 	try {
// 		const {
// 			role,
// 			first_name,
// 			middle_name,
// 			last_name,
// 			user_name,
// 			password,
// 			email,
// 			gender,
// 			address_line_1,
// 			address_line_2,
// 			city,
// 			state,
// 			country,
// 			ZIP,
// 			contact_label,
// 			phone_number,
// 			phone_extension
// 		} = req.body;

// 		if (await service.auth.isDuplicateGroupOwnerEmailService(userModel, email)) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: MESSAGE.custom(`Duplicate Email! ${email} already exists!`)
// 			});
// 		}
// 		if (await service.auth.isDuplicateValueCheckService(userModel, 'phone_number', phone_number)) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: MESSAGE.custom(`Duplicate Phone Number! ${phone_number} already exists!`)
// 			});
// 		}

// 		if (await service.auth.isDuplicateValueCheckService(userModel, 'user_name', user_name)) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: MESSAGE.custom(`Duplicate UserName! ${user_name} already exists!`)
// 			});
// 		}

// 		const userRegistrationPayload = {
// 			role,
// 			first_name,
// 			middle_name,
// 			last_name,
// 			user_name,
// 			password: await service.auth.hashPassword(password),
// 			email,
// 			gender,
// 			address_line_1,
// 			address_line_2,
// 			city,
// 			state,
// 			country,
// 			ZIP,
// 			contact_label,
// 			phone_number,
// 			phone_extension,
// 			subscription: {
// 				"super_admin_registration": {
// 					"email": true,
// 					"notification": true
// 				},
// 				"admin_creation": {
// 					"email": true,
// 					"notification": true
// 				},
// 				"admin_registration": {
// 					"email": true,
// 					"notification": true
// 				},
// 				"member_creation": {
// 					"email": true,
// 					"notification": true
// 				},
// 				"member_profile_updation": {
// 					"email": true,
// 					"notification": true
// 				}
// 			}
// 		}

// 		// Create new user
// 		const userRegistrationInstance = await new userModel(userRegistrationPayload).save();

// 		console.log("======User registered successfully: ========", userRegistrationInstance);

// 		return res.status(StatusCodes.CREATED).json({
// 			message: MESSAGE.post.succAuth,
// 			result: userRegistrationInstance // Return of the super admin registration result
// 		});

// 	} catch (error: any) {
// 		console.log("Error: ", error);
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.post.fail,
// 			error
// 		});
// 	}
// };