// src/controllers/auth/role/role.controller.ts
import { Request, Response } from "express";
import roleModel from "../../../../../model/role.model";

// Add Role
export const addRole = async (req: Request, res: Response): Promise<any> =>{
    try {
        // Create a new role instance using the model
        const newRole = new roleModel(req.body); // roleModel is the Mongoose model
        const savedRole = await newRole.save(); // Now you can call save()
        res.status(201).json(savedRole);
    } catch (error: unknown) {
        if (error instanceof Error) {
            res.status(500).json({ message: error.message });
        } else {
            res.status(500).json({ message: 'An unknown error occurred' });
        }
    }
};

// Edit Role
export const editRole = async (req: Request, res: Response): Promise<any> =>{
    try {
        const updatedRole = await roleModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedRole) return res.status(404).json({ message: 'Role not found' });
        res.json(updatedRole);
    } catch (error: unknown) {
        if (error instanceof Error) {
            res.status(500).json({ message: error.message });
        } else {
            res.status(500).json({ message: 'An unknown error occurred' });
        }
    }
};

// Delete Role
export const deleteRole = async (req: Request, res: Response): Promise<any> =>{
    try {
        const deletedRole = await roleModel.findByIdAndDelete(req.params.id);
        if (!deletedRole) return res.status(404).json({ message: 'Role not found' });
        res.status(200).json({ message: 'Role deleted successfully' });
    } catch (error: unknown) {
        if (error instanceof Error) {
            res.status(500).json({ message: error.message });
        } else {
            res.status(500).json({ message: 'An unknown error occurred' });
        }
    }
};

// Get Roles
export const getRoles = async (req: Request, res: Response): Promise<any> =>{
    try {
        const roles = await roleModel.find();
        res.json(roles);
    } catch (error: unknown) {
        if (error instanceof Error) {
            res.status(500).json({ message: error.message });
        } else {
            res.status(500).json({ message: 'An unknown error occurred' });
        }
    }
};
