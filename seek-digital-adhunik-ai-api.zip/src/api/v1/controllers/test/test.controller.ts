import { Request, Response } from "express";
import { Model } from "mongoose";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import service from "../../../../services";
import subscriptionModel from "../../../../model/subscription.model";
import slugify from "slugify";
import { transaction, transactionStatusUpdate } from "../../../../services/transaction/transaction.service";
import { createMessage } from "../../../../services/sms/sms.services";
import { processPayment } from "../../../../services/payment/stripe.service";
import { uploadImageToS3Service } from "../../../../services/uploadImageS3/UploadImageS3";
// import { sendPushNotification } from "../../../../services/notifaction/firebase/sendPushNotifaction.services";


export const testStripePayment = async (req: Request, res: Response): Promise<any> => {

	let data = await processPayment("67e66eaace75f5b8723f4737", "67e670ca3af375a8be79c798", "subscriptions", 100);
	// let data = await processPayment("67e66eaace75f5b8723f4737", "67e670ca3af375a8be79c798", "orders", 100);

	console.log("data============================", data);

	//transaction test
	// console.log("transaction test");
	// const transactionPayload = {
	// 	payment_intent_id: "pi_3QurIkBuHqQNZg721HRZi4cf",
	// 	member_id: "67af4847b09273890c854668",
	// 	amount: 100,
	// 	payment_status: "success",
	// 	payment_type: "stripe",   ///stripe, wallet
	// 	status: "success",
	// 	message: "payment success",
	// 	transaction_date: "2023-04-27T06:30:00.000Z",
	// };
	// const transactionPayload = {
	// 	id: "67b888336c21510beb9d3586",
	// 	payment_status: "success",
	// }
	// let data = await transaction(transactionPayload);
	// let data = await transactionStatusUpdate(transactionPayload);

	//wallet test
	// console.log("wallet payment");
	// const $walletPayload = {
	// 	member_id: "67af4847b09273890c854668",
	// 	amount: 100,
	// 	currency: "usd",
	// 	description: "test payment",
	// 	payment_method: "card",
	// 	payment_type: "wallet",
	// 	status: "success"
	// };
	// let data = await wallet($walletPayload);

	//stripe test 
	// console.log("stripe payment");
	// let data = await processPayment('1', 100, "usd", "card");

	return res.status(StatusCodes.OK).json({
		message: MESSAGE.custom("Subscription fetch successfully!"),
		data
	});
}



export const testSmsSend = async (req: Request, res: Response): Promise<any> => {

	return createMessage("+918972344111", '0987');
}


export const testConnection = async (req: Request, res: Response): Promise<any> => {
	console.log("*******MGPS SERVER CONNECTED SUCCESSFULLY**************");

	return res.status(StatusCodes.OK).json({
		message: MESSAGE.custom("Connection Test Successfully!"),
		result: "Connection Test Successfully!"
	});
}

export const testImageUpload = async (req: Request, res: Response): Promise<any> => {
	console.log("*****************Image upload test successfully");
	console.log(req.body);
	console.log("*****************Image upload test successfully");
	console.log(req.files);
	console.log("*****************Image upload test end");

	if (!req.files || !("dog_photo" in req.files)) {
		return res.status(422).json({
			message: MESSAGE.post.custom("Employee Photo not found")
		});
	}

	const employeePhoto = req.files["dog_photo"][0];
	const employeePhotoBuffer = employeePhoto.buffer;
	const employeePhotoUrl = await uploadImageToS3Service("dogphotos", employeePhotoBuffer);
	console.log("employeePhoto URL-->", employeePhotoUrl);

}

// export const sendNotifaction = async (req: Request, res: Response): Promise<any> => {
// 	const {
// 		deviceToken,
// 		message
// 	} = req.body;

// 	const testSendNotifaction = sendPushNotification(deviceToken, message);
// 	console.log("=================================testSendNotifaction", testSendNotifaction);


// }