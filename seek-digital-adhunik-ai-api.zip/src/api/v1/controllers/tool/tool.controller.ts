import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import toolModel from "../../../../model/tool.model";
import { formatToolResponse, formatToolsResponse } from "../../../../utils/formatter/toolResponseFormatter";

// Add a new tool
export const addTool = async (req: Request, res: Response): Promise<any> => {
    try {
        const toolData = req.body;
        const newTool = new toolModel(toolData);
        await newTool.save();
        res.status(StatusCodes.CREATED).json({
            message: "Tool added successfully!",
            tool: newTool,
        });
    } catch (error: unknown) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ message: "Failed to create tool", error });
    }
};


export const getAllTools = async (req: Request, res: Response): Promise<any> => {
    try {
        const tools = await toolModel.find(); // Populate category details
        const toolresponse = await formatToolsResponse(tools)
        res.status(StatusCodes.OK).json(toolresponse);
    } catch (error: unknown) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ message: "Failed to retrieve tools", error });
    }
};


export const getTool = async (req: Request, res: Response): Promise<any> => {
    try {
        const tool = await toolModel.findById(req.params.id);
        if (!tool) return res.status(StatusCodes.NOT_FOUND).json({ message: "Tool not found" });
        const toolresponse = await formatToolResponse(tool)
        res.status(StatusCodes.OK).json(toolresponse);
    } catch (error: unknown) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ message: "Error retrieving tool", error });
    }
};


export const updateTool = async (req: Request, res: Response): Promise<any> => {
    try {
        const updatedTool = await toolModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedTool) return res.status(StatusCodes.NOT_FOUND).json({ message: "Tool not found" });
        res.status(StatusCodes.OK).json({ message: "Tool updated successfully!", tool: updatedTool });
    } catch (error: unknown) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ message: "Error updating tool", error });
    }
};


export const deleteTool = async (req: Request, res: Response): Promise<any> => {
    try {
        const deletedTool = await toolModel.findByIdAndDelete(req.params.id);
        if (!deletedTool) return res.status(StatusCodes.NOT_FOUND).json({ message: "Tool not found" });
        res.status(StatusCodes.OK).json({ message: "Tool deleted successfully!" });
    } catch (error: unknown) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ message: "Error deleting tool", error });
    }
};
