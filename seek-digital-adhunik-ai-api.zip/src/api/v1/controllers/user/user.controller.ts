import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import userModel from "../../../../model/user.model";
import roleModel from "../../../../model/role.model";
import service from "../../../../services";
import { formatUserResponse, formatUsersResponse } from '../../../../utils/formatter/userResponseFormatter';

export const getProfile = async (req: Request, res: Response): Promise<any> => {
	try {
		let role = req.user.role;
		
		let userDetails = await userModel.findOne({
			email: req.user.email
		});
        // Check if userDetails is null
        if (!userDetails) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found!")
            });
        }

        // Format the user response
        const userResponse = await formatUserResponse(userDetails);
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: {
				userResponse
			},
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};

export const updateProfile = async (req: Request, res: Response): Promise<any> => {
	try {
		let userDetail = await userModel.findOne({
			email: req.user.email
		});
        const user = await userModel.findByIdAndUpdate(userDetail?._id, req.body)
		if (!user) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: MESSAGE.custom("User not found!"),
			});
		}
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Profile updated successfully!"),
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Profile updated unsuccessful!"),
			error
		});
	}
}


// Add a new user
export const addUser = async (req: Request, res: Response): Promise<any> => {
    try {
        const password = "123456";
        req.body.password = await service.auth.hashPassword(password);
        const newUser = new userModel(req.body);
        await newUser.save();
        res.status(StatusCodes.CREATED).json({
            message: MESSAGE.custom("User created successfully"),
            user: newUser,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing user
export const editUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const updatedUser = await userModel.findByIdAndUpdate(id, req.body, { new: true });
        if (!updatedUser) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User updated successfully"),
            user: updatedUser,
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a user
export const deleteUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const deletedUser = await userModel.findByIdAndDelete(id);
        if (!deletedUser) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User deleted successfully"),
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a user by ID
export const getUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const user = await userModel.findById(id);
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        const userResponse = await formatUserResponse(user)
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all users
export const getAllUsers = async (req: Request, res: Response): Promise<any> => {
    try {
        const users = await userModel.find();
        const userResponse = await formatUsersResponse(users);
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Add a new admin user
export const addAdminUser = async (req: Request, res: Response): Promise<any> => {
    try {
        const adminRole = await roleModel.findOne({
            name: 'Admin'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        
        req.body.roleId = adminRole._id;
        const password = "123456";
        req.body.password = await service.auth.hashPassword(password);
        const newUser = new userModel(req.body);
        await newUser.save();
        res.status(StatusCodes.CREATED).json({
            message: MESSAGE.custom("User created successfully"),
            user: newUser,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing user
export const editAdminUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Admin'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const updatedUser = await userModel.findByIdAndUpdate(id, req.body, { new: true });
        
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User updated successfully"),
            user: updatedUser,
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a user
export const deleteAdminUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Admin'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const deletedUser = await userModel.findByIdAndDelete(id);
        
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User deleted successfully"),
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a user by ID
export const getAdminUser = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Admin'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const userResponse = await formatUserResponse(user)
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all users
export const getAllAdminUsers = async (req: Request, res: Response): Promise<any> => {
    try {
        const adminRole = await roleModel.findOne({
            name: 'Admin'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const users = await userModel.find({
            roleId: adminRole._id
        });
        const userResponse = await formatUsersResponse(users);
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};


// Add a new customer
export const addCustomer = async (req: Request, res: Response): Promise<any> => {
    try {
        const adminRole = await roleModel.findOne({
            name: 'Customer'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        
        req.body.roleId = adminRole._id;
        const password = "123456";
        req.body.password = await service.auth.hashPassword(password);
        const newUser = new userModel(req.body);
        await newUser.save();
        res.status(StatusCodes.CREATED).json({
            message: MESSAGE.custom("User created successfully"),
            user: newUser,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing customer
export const editCustomer = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Customer'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const updatedUser = await userModel.findByIdAndUpdate(id, req.body, { new: true });
        
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User updated successfully"),
            user: updatedUser,
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a customer
export const deleteCustomer = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Customer'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const deletedUser = await userModel.findByIdAndDelete(id);
        
        res.status(StatusCodes.OK).json({
            message: MESSAGE.custom("User deleted successfully"),
        });
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a customer by ID
export const getCustomer = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const adminRole = await roleModel.findOne({
            name: 'Customer'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const user = await userModel.findOne({
            _id: id
        })
        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        if(user?.roleId.toString() !== adminRole?._id.toString()){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role doesn't match"),
            });
        }
        const userResponse = await formatUserResponse(user)
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all Customers
export const getAllCustomers = async (req: Request, res: Response): Promise<any> => {
    try {
        const adminRole = await roleModel.findOne({
            name: 'Customer'
        })
        if(!adminRole){
            return res.status(StatusCodes.NOT_FOUND).json({
                message: MESSAGE.custom("Role not found"),
            });
        }
        const users = await userModel.find({
            roleId: adminRole._id
        });
        const userResponse = await formatUsersResponse(users);
        res.status(StatusCodes.OK).json(userResponse);
    }catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};



