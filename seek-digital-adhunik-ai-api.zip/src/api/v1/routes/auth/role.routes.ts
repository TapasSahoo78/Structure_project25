import express from 'express';
import { addRole, editRole, deleteRole, getRoles } from '../../controllers/auth/role/role.controller';

const router = express.Router();

router.route("/roles").post(addRole);
router.route("/roles/:id").put(editRole);
router.route("/roles/:id").delete(deleteRole);
router.route("/roles").get(getRoles);


module.exports = router;

