import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import adminAuth from "../../../../middlewares/auth/adminAuth.middleware";
const multer = require('multer');
const upload = multer();
import { validators } from "../../validators";
import { login, customerLogin } from "../../controllers/auth/login/login.controller";
import {
	getProfile, updateProfile, addUser, editUser, deleteUser, getUser, getAllUsers, addAdminUser, editAdminUser, deleteAdminUser, getAdminUser, getAllAdminUsers, addCustomer, editCustomer, getAllCustomers, deleteCustomer,getCustomer
} from "../../controllers/user/user.controller";
import registration from "../../controllers/auth/registration/index";
import { emailVerificationWithPasswordChange, changePassword } from "../../controllers/auth/registration/registration.controller";
const router = express.Router();

router.route("/login").post(validator(validators.loginValidator, null), login);
router.route("/customer-login").post(validator(validators.loginValidator, null), customerLogin);
router.route("/register").post(validator(validators.registrationValidator, null), registration.userRegistration);
router.route("/email-verification-with-password-change").post(validator(validators.emailVerificationValidator, null), emailVerificationWithPasswordChange);

// After Authentication
router.route("/password-change").post(generalAuth, validator(validators.changePasswordValidator, null), changePassword);
router.route("/get-profile").get(generalAuth, getProfile);
router.route("/update-profile").put(generalAuth, upload.none(), validator(validators.adminUserValidator, null), updateProfile);

// User Management Routes (Protected by adminAuth)
router.route("/users").post(adminAuth, validator(validators.userValidator, null), addUser); // Add a new user
router.route("/users/:id").put(adminAuth, validator(validators.userValidator, null), editUser); // Edit an existing user
router.route("/users/:id").delete(adminAuth, deleteUser); // Delete a user
router.route("/users/:id").get(adminAuth, getUser); // Get a user by ID
router.route("/users").get(adminAuth, getAllUsers); // Get all users

//ONLY for ADMIN USERS
router.route("/admin-users").post(adminAuth, validator(validators.adminUserValidator, null), addAdminUser); // Add a new user
router.route("/admin-users/:id").put(adminAuth, validator(validators.adminUserValidator, null), editAdminUser);
router.route("/admin-users").get(adminAuth, getAllAdminUsers);
router.route("/admin-users/:id").delete(adminAuth, deleteAdminUser); // Delete a user
router.route("/admin-users/:id").get(adminAuth, getAdminUser);

//ONLY for Customers
router.route("/customers").post(adminAuth, validator(validators.customerValidator, null), addCustomer); // Add a new user
router.route("/customers/:id").put(adminAuth, validator(validators.customerValidator, null), editCustomer);
router.route("/customers").get(adminAuth, getAllCustomers);
router.route("/customers/:id").delete(adminAuth, deleteCustomer); // Delete a user
router.route("/customers/:id").get(adminAuth, getCustomer);

module.exports = router;
