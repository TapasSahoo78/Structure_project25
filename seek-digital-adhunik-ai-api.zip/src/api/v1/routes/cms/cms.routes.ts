// routes/category.routes.ts
import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import {
    addPage,
    editPage,
    deletePage,
    getPage,
    getAllPages,
} from "../../controllers/cms/page.controller";
import {
    addMenu,
    editMenu,
    deleteMenu,
    getMenu,
    getAllMenus,
} from "../../controllers/cms/menu.controller";

const router = express.Router();

// Page Management Routes
router.route("/pages/:id/:block_id?")
    .put(editPage) // Edit an existing page
    .delete(deletePage) // Delete a page
    .get(getPage); // Get a page by ID
router.route("/pages")
    .get(getAllPages) // Get all faqs categories
    .post(validator(validators.pageValidator, null), addPage); // Add a new page


// Menu Management Routes
router.route("/menus/:id")
    .put(validator(validators.menuValidator, null), editMenu) // Edit an existing menu
    .delete(deleteMenu) // Delete a menu
    .get(getMenu); // Get a menu by ID
router.route("/menus")
    .get(getAllMenus) // Get all menus categories
    .post(validator(validators.menuValidator, null), addMenu); // Add a new menu

module.exports = router;
