// routes/category.routes.ts
import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import {
    addCategory,
    editCategory,
    deleteCategory,
    getCategory,
    getAllCategories,
} from "../../controllers/faq/category.controller";
import {
    editFaq,
    getFaq,
    deleteFaq,
    getAllFaqs,
    addFaq
} from "../../controllers/faq/faqs.controller";

const router = express.Router();

// Category Management Routes
router.route("/faq-categories/:id")
    .put(validator(validators.faqCategoryValidator, null), editCategory) // Edit an existing category
    .delete(deleteCategory) // Delete a category
    .get(getCategory); // Get a category by ID
router.route("/faq-categories")
    .get(getAllCategories) // Get all faqs categories
    .post(validator(validators.faqCategoryValidator, null), addCategory); // Add a new category

// Faq Management Routes
router.route("/faqs/:id")
    .put(validator(validators.faqValidator, null), editFaq) // Edit an existing faq
    .delete(deleteFaq) // Delete a faq
    .get(getFaq); // Get a faq by ID
router.route("/faqs")
    .get(getAllFaqs) // Get all faqs categories
    .post(validator(validators.faqValidator, null), addFaq); // Add a new faq

module.exports = router;
