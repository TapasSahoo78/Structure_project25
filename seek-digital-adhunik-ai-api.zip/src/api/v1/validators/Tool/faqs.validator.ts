// src/validators/category.validator.ts
import Joi from "joi";

export const faqValidator = Joi.object({
    _id: Joi.optional(),
    faqCategoryId: Joi.string()
        .messages({
            'string.base': 'Category ID must be a string.',
            'string.empty': 'Category ID is required.',
            'any.required': 'Category ID is required.'
        }),
    question: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'Question must be a string.',
            'string.empty': 'Question is required.',
            'string.max': 'Question cannot be more than 100 characters.',
            'any.required': 'Question is required.'
        }),
    answer: Joi.string()
        .max(500)
        .required()
        .messages({
            'string.base': 'Answer must be a string.',
            'string.empty': 'Answer is required.',
            'string.max': 'Answer cannot be more than 500 characters.',
            'any.required': 'Answer is required.'
        })
});
