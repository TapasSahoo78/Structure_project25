import Joi from "joi";

export const loginValidator = Joi.object({
	user_id: Joi.string().required(),
	password: Joi.string(),
	devices_token: Joi.string().optional()
});
