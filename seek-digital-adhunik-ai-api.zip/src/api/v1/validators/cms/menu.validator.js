import Joi from 'joi';

const objectIdPattern = /^[0-9a-fA-F]{24}$/;

export const menuValidator = Joi.object({
    parentIdId: Joi.string()
        .pattern(objectIdPattern)
        .optional()
        .messages({
            'string.pattern.base': 'parentIdId must be a valid ObjectId.',
            'any.required': 'parentIdId is required.',
            'string.empty': 'parentIdId cannot be empty.'
        }),
    name: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'name must be a string.',
            'string.empty': 'name is required.',
            'string.max': 'name cannot be more than 100 characters.',
            'any.required': 'name is required.'
        }),
    menu_order: Joi.string()
        .trim()
        .required()
        .messages({
            'string.base': 'menu_order must be a string.',
            'string.empty': 'menu_order is required.',
            'any.required': 'menu_order is required.'
        }),
    link_type: Joi.string()
        .trim()
        .required()
        .messages({
            'string.base': 'link_type must be a string.',
            'string.empty': 'link_type is required.',
            'any.required': 'link_type is required.'
        }),
    pageId: Joi.string()
        .pattern(objectIdPattern)
        .optional()
        .messages({
            'string.pattern.base': 'pageId must be a valid ObjectId.',
            'any.required': 'pageId is required.',
            'string.empty': 'pageId cannot be empty.'
        }),
    menu_group: Joi.string()
        .trim()
        .optional()
        .max(100)
        .messages({
            'string.base': 'menu_group must be a string.',
            'string.empty': 'menu_group is required.',
            'string.max': 'menu_group cannot be more than 100 characters.',
            'any.required': 'menu_group is required.'
        }),
    menu_link: Joi.string()
        .trim()
        .optional()
        .uri()
        .messages({
            'string.base': 'menu_link must be a string.',
            'string.empty': 'menu_link is required.',
            'string.uri': 'menu_link must be a valid URI.',
            'any.required': 'menu_link is required.'
        }),
    is_active: Joi.boolean()
        .required()
        .messages({
            'boolean.base': 'is_active must be a boolean.',
            'any.required': 'is_active is required.'
        }),
});
