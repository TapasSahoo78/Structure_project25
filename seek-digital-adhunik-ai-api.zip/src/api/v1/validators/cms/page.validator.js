// src/validators/category.validator.ts
import Joi from "joi";

const blockSchema = Joi.object({
    title: Joi.string().trim().max(100).required().messages({
        'string.base': 'Title must be a string.',
        'string.empty': 'Title cannot be empty.',
        'string.max': 'Title must be at most 100 characters long.',
        'any.required': 'Title is required.'
    }),
    subtitle: Joi.string().trim().max(100).allow(null).messages({
        'string.base': 'Subtitle must be a string.',
        'string.max': 'Subtitle must be at most 100 characters long.'
    }),
    content: Joi.string().trim().allow(null).messages({
        'string.base': 'Content must be a string.'
    }),
    order_number: Joi.number().allow(null).messages({
        'number.base': 'Order number must be a number.'
    }),
    status: Joi.boolean().required().messages({
        'boolean.base': 'Status must be a boolean.',
        'any.required': 'Status is required.'
    })
});

export const pageValidator = Joi.object({
    _id: Joi.string().optional(),
    title: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'title must be a string.',
            'string.empty': 'title is required.',
            'string.max': 'title cannot be more than 100 characters.',
            'any.required': 'title is required.'
        }),
    blocks: Joi.array()
        .items(blockSchema)
        .optional()
        .messages({
            'array.base': 'Blocks must be an array.',
            'array.empty': 'Blocks cannot be empty.',
            'any.required': 'Blocks are required.'
        }),
    meta_title: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'meta_title must be a string.',
            'string.empty': 'meta_title is required.',
            'string.max': 'meta_title cannot be more than 100 characters.',
            'any.required': 'meta_title is required.'
        }),
    meta_description: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'meta_description must be a string.',
            'string.empty': 'meta_description is required.',
            'string.max': 'meta_description cannot be more than 100 characters.',
            'any.required': 'meta_description is required.'
        }),
    meta_keywords: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'meta_keywords must be a string.',
            'string.empty': 'meta_keywords is required.',
            'string.max': 'meta_keywords cannot be more than 100 characters.',
            'any.required': 'meta_keywords is required.'
        }),
});
