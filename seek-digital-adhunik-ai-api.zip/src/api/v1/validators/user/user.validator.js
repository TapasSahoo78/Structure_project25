import Joi from "joi";
import { GENDER } from "../../../../constants/gender/gender";
import { CONTACT_LABEL } from "../../../../constants/contactLabel/contactLabel";

export const userValidator = Joi.object({
    roleId: Joi.string().required().messages({
        'string.base': 'Role ID must be a string.',
        'string.empty': 'Role ID is required.',
        'any.required': 'Role ID is required.'
    }),
    email: Joi.string().email().required().messages({
        'string.base': 'Email must be a string.',
        'string.email': 'Email must be a valid email address.',
        'string.empty': 'Email is required.',
        'any.required': 'Email is required.'
    }),
    first_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'First name must be a string.',
        'string.empty': 'First name is required.',
        'string.min': 'First name must be at least 1 character long.',
        'string.max': 'First name must be at most 30 characters long.',
        'any.required': 'First name is required.'
    }),
    middle_name: Joi.string().allow('').max(30).messages({
        'string.base': 'Middle name must be a string.',
        'string.max': 'Middle name must be at most 30 characters long.'
    }),
    last_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'Last name must be a string.',
        'string.empty': 'Last name is required.',
        'string.min': 'Last name must be at least 1 character long.',
        'string.max': 'Last name must be at most 30 characters long.',
        'any.required': 'Last name is required.'
    }),
    user_name: Joi.string().alphanum().min(3).max(30).required().messages({
        'string.base': 'User name must be a string.',
        'string.empty': 'User name is required.',
        'string.alphanum': 'User name must contain only alphanumeric characters.',
        'string.min': 'User name must be at least 3 characters long.',
        'string.max': 'User name must be at most 30 characters long.',
        'any.required': 'User name is required.'
    }),
    gender: Joi.string().allow('', null).valid(GENDER.male, GENDER.female, GENDER.others).optional().messages({
        'string.base': 'Gender must be a string.',
        'any.only': 'Gender must be one of the following: male, female, others.'
    }),
    address_line_1: Joi.string().max(100).required().messages({
        'string.base': 'Address line 1 must be a string.',
        'string.max': 'Address line 1 must be at most 100 characters long.',
		'any.required': '"Address line 1" is required.'
    }),
    address_line_2: Joi.string().allow('').max(100).messages({
        'string.base': 'Address line 2 must be a string.',
        'string.max': 'Address line 2 must be at most 100 characters long.'
    }),
    city: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'City must be a string.',
        'string.max': 'City must be at most 50 characters long.'
    }),
    state: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'State must be a string.',
        'string.max': 'State must be at most 50 characters long.'
    }),
    country: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'Country must be a string.',
        'string.max': 'Country must be at most 50 characters long.'
    }),
    ZIP: Joi.string().length(6).pattern(/^[0-9]+$/).optional().allow('').messages({
        'string.base': 'ZIP must be a string.',
        'string.length': 'ZIP must be exactly 6 characters long.',
        'string.pattern.base': 'ZIP must contain only numbers.'
    }),
    contact_label: Joi.string()
    .allow('', null) // Allow empty string and null
    .valid(CONTACT_LABEL.home, CONTACT_LABEL.business, CONTACT_LABEL.mail, CONTACT_LABEL.mobile, CONTACT_LABEL.other)
    .messages({
        'string.base': 'Contact label must be a string.',
        'any.only': 'Contact label must be one of the following: home, business, mail, mobile, other.'
    }),

    phone_number: Joi.alternatives().try(
        Joi.string().pattern(/^[0-9]+$/).required().messages({
            'string.base': 'Phone number must be a string.',
            'string.pattern.base': 'Phone number must contain only numbers.',
            'any.required': 'Phone number is required.'
        }),
        Joi.number().integer().required().messages({
            'number.base': 'Phone number must be a number.',
            'any.required': 'Phone number is required.'
        })
    ),
    phone_extension: Joi.alternatives().try(
        Joi.string().allow('').required().messages({
            'string.base': 'Phone extension must be a string.',
            'any.required': 'Phone extension is required.'
        }),
        Joi.number().allow('').required().messages({
            'number.base': 'Phone extension must be a number.',
            'any.required': 'Phone extension is required.'
        })
    ),
    company: Joi.string().max(100).allow('').messages({
        'string.base': 'Company must be a string.',
        'string.max': 'Company must be at most 100 characters long.'
    }),
    date_of_birth: Joi.date().optional().messages({
        'date.base': 'Date of birth must be a valid date.'
    }),
    password: Joi.string().min(6).max(100).optional().allow('').messages({
        'string.base': 'Password must be a string.',
        'string.empty': 'Password is required.',
        'string.min': 'Password must be at least 6 characters long.',
        'string.max': 'Password must be at most 100 characters long.'
    }),
	is_active: Joi.optional(),
	is_registered: Joi.optional(),
    is_disabled: Joi.optional(),
    devices_token: Joi.optional(),
    otp: Joi.optional(),
    expiresAt: Joi.optional(),
    last_login_date: Joi.optional(),
    _id: Joi.optional(),
    roleName: Joi.optional(),
});

export const adminUserValidator = Joi.object({
    roleId: Joi.optional(),
    email: Joi.string().email().required().messages({
        'string.base': 'Email must be a string.',
        'string.email': 'Email must be a valid email address.',
        'string.empty': 'Email is required.',
        'any.required': 'Email is required.'
    }),
    first_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'First name must be a string.',
        'string.empty': 'First name is required.',
        'string.min': 'First name must be at least 1 character long.',
        'string.max': 'First name must be at most 30 characters long.',
        'any.required': 'First name is required.'
    }),
    middle_name: Joi.string().allow('').max(30).messages({
        'string.base': 'Middle name must be a string.',
        'string.max': 'Middle name must be at most 30 characters long.'
    }),
    last_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'Last name must be a string.',
        'string.empty': 'Last name is required.',
        'string.min': 'Last name must be at least 1 character long.',
        'string.max': 'Last name must be at most 30 characters long.',
        'any.required': 'Last name is required.'
    }),
    user_name: Joi.string().alphanum().min(3).max(30).required().messages({
        'string.base': 'User name must be a string.',
        'string.empty': 'User name is required.',
        'string.alphanum': 'User name must contain only alphanumeric characters.',
        'string.min': 'User name must be at least 3 characters long.',
        'string.max': 'User name must be at most 30 characters long.',
        'any.required': 'User name is required.'
    }),
    gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).optional().allow('').messages({
        'string.base': 'Gender must be a string.',
        'any.only': 'Gender must be one of the following: male, female, others.'
    }),
    address_line_1: Joi.string().max(100).required().messages({
        'string.base': 'Address line 1 must be a string.',
        'string.max': 'Address line 1 must be at most 100 characters long.',
		'any.required': '"Address line 1" is required.'
    }),
    address_line_2: Joi.string().allow('').max(100).messages({
        'string.base': 'Address line 2 must be a string.',
        'string.max': 'Address line 2 must be at most 100 characters long.'
    }),
    city: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'City must be a string.',
        'string.max': 'City must be at most 50 characters long.'
    }),
    state: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'State must be a string.',
        'string.max': 'State must be at most 50 characters long.'
    }),
    country: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'Country must be a string.',
        'string.max': 'Country must be at most 50 characters long.'
    }),
    ZIP: Joi.string().length(6).pattern(/^[0-9]+$/).optional().allow('').messages({
        'string.base': 'ZIP must be a string.',
        'string.length': 'ZIP must be exactly 6 characters long.',
        'string.pattern.base': 'ZIP must contain only numbers.'
    }),
    contact_label: Joi.string()
    .allow('', null) // Allow empty string and null
    .valid(CONTACT_LABEL.home, CONTACT_LABEL.business, CONTACT_LABEL.mail, CONTACT_LABEL.mobile, CONTACT_LABEL.other)
    .messages({
        'string.base': 'Contact label must be a string.',
        'any.only': 'Contact label must be one of the following: home, business, mail, mobile, other.'
    }),

    phone_number: Joi.alternatives().try(
        Joi.string().pattern(/^[0-9]+$/).required().messages({
            'string.base': 'Phone number must be a string.',
            'string.pattern.base': 'Phone number must contain only numbers.',
            'any.required': 'Phone number is required.'
        }),
        Joi.number().integer().required().messages({
            'number.base': 'Phone number must be a number.',
            'any.required': 'Phone number is required.'
        })
    ),
    phone_extension: Joi.alternatives().try(
        Joi.string().allow('').required().messages({
            'string.base': 'Phone extension must be a string.',
            'any.required': 'Phone extension is required.'
        }),
        Joi.number().allow('').required().messages({
            'number.base': 'Phone extension must be a number.',
            'any.required': 'Phone extension is required.'
        })
    ),
    company: Joi.string().max(100).allow('').messages({
        'string.base': 'Company must be a string.',
        'string.max': 'Company must be at most 100 characters long.'
    }),
    date_of_birth: Joi.date().optional().messages({
        'date.base': 'Date of birth must be a valid date.'
    }),
    password: Joi.string().min(6).max(100).optional().allow('').messages({
        'string.base': 'Password must be a string.',
        'string.empty': 'Password is required.',
        'string.min': 'Password must be at least 6 characters long.',
        'string.max': 'Password must be at most 100 characters long.'
    }),
	is_active: Joi.optional(),
	is_registered: Joi.optional(),
    is_disabled: Joi.optional(),
    devices_token: Joi.optional(),
    otp: Joi.optional(),
    expiresAt: Joi.optional(),
    last_login_date: Joi.optional(),
    _id: Joi.optional(),
    roleName: Joi.optional(),
});

export const customerValidator = Joi.object({
    roleId: Joi.optional(),
    email: Joi.string().email().required().messages({
        'string.base': 'Email must be a string.',
        'string.email': 'Email must be a valid email address.',
        'string.empty': 'Email is required.',
        'any.required': 'Email is required.'
    }),
    first_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'First name must be a string.',
        'string.empty': 'First name is required.',
        'string.min': 'First name must be at least 1 character long.',
        'string.max': 'First name must be at most 30 characters long.',
        'any.required': 'First name is required.'
    }),
    middle_name: Joi.string().allow('').max(30).messages({
        'string.base': 'Middle name must be a string.',
        'string.max': 'Middle name must be at most 30 characters long.'
    }),
    last_name: Joi.string().min(1).max(30).required().messages({
        'string.base': 'Last name must be a string.',
        'string.empty': 'Last name is required.',
        'string.min': 'Last name must be at least 1 character long.',
        'string.max': 'Last name must be at most 30 characters long.',
        'any.required': 'Last name is required.'
    }),
    user_name: Joi.string().alphanum().min(3).max(30).required().messages({
        'string.base': 'User name must be a string.',
        'string.empty': 'User name is required.',
        'string.alphanum': 'User name must contain only alphanumeric characters.',
        'string.min': 'User name must be at least 3 characters long.',
        'string.max': 'User name must be at most 30 characters long.',
        'any.required': 'User name is required.'
    }),
    gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).optional().allow('').messages({
        'string.base': 'Gender must be a string.',
        'any.only': 'Gender must be one of the following: male, female, others.'
    }),
    address_line_1: Joi.string().max(100).required().messages({
        'string.base': 'Address line 1 must be a string.',
        'string.max': 'Address line 1 must be at most 100 characters long.',
		'any.required': '"Address line 1" is required.'
    }),
    address_line_2: Joi.string().allow('').max(100).messages({
        'string.base': 'Address line 2 must be a string.',
        'string.max': 'Address line 2 must be at most 100 characters long.'
    }),
    city: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'City must be a string.',
        'string.max': 'City must be at most 50 characters long.'
    }),
    state: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'State must be a string.',
        'string.max': 'State must be at most 50 characters long.'
    }),
    country: Joi.string().max(50).optional().allow('').messages({
        'string.base': 'Country must be a string.',
        'string.max': 'Country must be at most 50 characters long.'
    }),
    ZIP: Joi.string().length(6).pattern(/^[0-9]+$/).optional().allow('').messages({
        'string.base': 'ZIP must be a string.',
        'string.length': 'ZIP must be exactly 6 characters long.',
        'string.pattern.base': 'ZIP must contain only numbers.'
    }),
    contact_label: Joi.string()
    .allow('', null) // Allow empty string and null
    .valid(CONTACT_LABEL.home, CONTACT_LABEL.business, CONTACT_LABEL.mail, CONTACT_LABEL.mobile, CONTACT_LABEL.other)
    .messages({
        'string.base': 'Contact label must be a string.',
        'any.only': 'Contact label must be one of the following: home, business, mail, mobile, other.'
    }),

    phone_number: Joi.alternatives().try(
        Joi.string().pattern(/^[0-9]+$/).required().messages({
            'string.base': 'Phone number must be a string.',
            'string.pattern.base': 'Phone number must contain only numbers.',
            'any.required': 'Phone number is required.'
        }),
        Joi.number().integer().required().messages({
            'number.base': 'Phone number must be a number.',
            'any.required': 'Phone number is required.'
        })
    ),
    phone_extension: Joi.alternatives().try(
        Joi.string().allow('').required().messages({
            'string.base': 'Phone extension must be a string.',
            'any.required': 'Phone extension is required.'
        }),
        Joi.number().allow('').required().messages({
            'number.base': 'Phone extension must be a number.',
            'any.required': 'Phone extension is required.'
        })
    ),
    company: Joi.string().max(100).allow('').messages({
        'string.base': 'Company must be a string.',
        'string.max': 'Company must be at most 100 characters long.'
    }),
    date_of_birth: Joi.date().optional().messages({
        'date.base': 'Date of birth must be a valid date.'
    }),
    password: Joi.string().min(6).max(100).optional().allow('').messages({
        'string.base': 'Password must be a string.',
        'string.empty': 'Password is required.',
        'string.min': 'Password must be at least 6 characters long.',
        'string.max': 'Password must be at most 100 characters long.'
    }),
	is_active: Joi.optional(),
	is_registered: Joi.optional(),
    is_disabled: Joi.optional(),
    devices_token: Joi.optional(),
    otp: Joi.optional(),
    expiresAt: Joi.optional(),
    last_login_date: Joi.optional(),
    _id: Joi.optional(),
    roleName: Joi.optional(),
});
