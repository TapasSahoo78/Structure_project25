import express, { Request, Response, NextFunction } from "express";
import { StatusCodes } from "http-status-codes";
import bodyParser from "body-parser";
import cors from "cors";

const app = express();

app.use(cors());

app.use((req: Request, res: Response, next: NextFunction): any => {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, token");
	if (req.method === "OPTIONS") {
		res.header("Access-Control-Allow-Methods", "PUT, POST, GET, PATCH, DELETE");
		res.header(
			"Access-Control-Allow-Headers",
			"Origin, X-Requested-With, Content-Type, Accept, Authorization, token"
		);
		return res.status(StatusCodes.OK).json({});
	}
	next();
});

app.use(express.json({ limit: "100000kb" }));

// Middleware
app.use(bodyParser.json());

app.use("/api/v1", require("./api/v1/routes"));

app.get("/", (req, res) => {
	res.send(`<h1>Adhunik AI Management Portal Backend Connected Successful!</h1>`);
});

export default app;
