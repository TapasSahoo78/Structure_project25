export const NODE_ENV: "PROD" | "DEV" | "LOCAL" | "LOCAL_ATLAS" = "LOCAL";

export const MONGO_URI = {
	LOCAL: "mongodb://127.0.0.1:27017/adhunik_ai_management_portal",
	LOCAL_ATLAS: "",
	DEV: "mongodb://mgpsuser:MgPS%403245%40gh@3.111.66.206:27017/?authSource=mgpsDB",
	PROD: ""
};

// Local, Devlopment and Production Adhunik_AIManagement Portal URL
export const localAdhunik_AIManagementUrl = "http://localhost:3131";
export const testAdhunik_AIManagementUrl = "";
export const devAdhunik_AIManagementUrl = "";
export const prodAdhunik_AIManagementUrl = "";

export const emailLoginUrl =
	String(NODE_ENV) == "PROD"
		? `${prodAdhunik_AIManagementUrl}/`
		: String(NODE_ENV) == "DEV"
			? `${devAdhunik_AIManagementUrl}/`
			: String(NODE_ENV) == "LOCAL"
				? `${localAdhunik_AIManagementUrl}/`
				: ""; //Has to change in Production and Test Production

export const Adhunik_AI_MANAGEMENT_PORTAL_LINK = emailLoginUrl;

export const mongoDump = {
	host: String(NODE_ENV) == "PROD" ? "127.0.0.1" : "localhost",
	port: String(NODE_ENV) == "PROD" ? 27017 : 27017,
	database: "Adhunik_AI_Management_Portal",
	outputDir: String(NODE_ENV) == "PROD" ? "" : __dirname + "../../../database_backup"
};

export const STRIPE_SECRET_KEY =
	"sk_test_51NdpkRBuHqQNZg72VM5ngF17FUi5lff7whLJdPy4IlFn6ZoymSeIvnOWVqB5NfaTHat6yHTCpJIPMCYHcp0HmxUm00I84mXZRh";
