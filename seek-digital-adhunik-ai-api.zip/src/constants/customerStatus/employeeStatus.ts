export const EMPLOYEE_STATUS = {
	active: "ACTIVE",
	inactive: "INACTIVE"
};

export const SUBSCRIPTION_STATUS = {
	pending: "PENDING",
	active: "ACTIVE",
	inactive: "INACTIVE",
	cancelled: "CANCELLED"
};