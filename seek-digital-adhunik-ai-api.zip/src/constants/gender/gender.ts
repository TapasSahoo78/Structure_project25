export const GENDER = {
	male: "male",
	female: "female",
	others: "others"
};
