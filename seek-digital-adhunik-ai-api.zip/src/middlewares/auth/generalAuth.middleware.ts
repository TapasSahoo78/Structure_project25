import { Request, Response, NextFunction } from "express";
import { StatusCodes } from "http-status-codes";
import jwt from "jsonwebtoken";
import { Model } from "mongoose";
import { MESSAGE } from "../../constants/message";
import { ROLES } from "../../constants/roles/roles";
import userModel from "../../model/user.model";

export const generalAuth = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
	try {
		if (!req.headers.authorization) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		const token = req.headers.authorization.replace("Bearer ", "");

		if (!token) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		if (!process.env.JWT_KEY) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Token not found")
			});
		}
		const decoded = jwt.verify(token, process.env.JWT_KEY) as Record<string, unknown>;

		req.user = decoded; // setting a property of the request object with decoded string. It will be used to be validated against the valid user or member details
		const { _id } = req.user;
			//const filter = { _id }
		const data = await userModel.findOne({
			 _id: _id 
		});

		req.user.info = data;

		next();
	} catch (error) {
		console.log("error", error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Invalid Token!"),
			error: error,
			token: req.header("token")
		});
	}
};

export default generalAuth;
