import { model } from "mongoose";
import { IFaqSchema } from "../@types/interfaces/faq.interface";
import faqSchema from "./schemaDefiniton/faq.schema";

const faqModel = model<IFaqSchema>("faqs", faqSchema);

export default faqModel;
