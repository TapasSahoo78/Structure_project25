import { model } from "mongoose";
import { IfaqCategoryShema } from "../@types/interfaces/faqCategory.interface";
import faqCategorySchema from "./schemaDefiniton/faqCategory.schema ";

const faqCategoryModel = model<IfaqCategoryShema>("faq_categories", faqCategorySchema);

export default faqCategoryModel;
