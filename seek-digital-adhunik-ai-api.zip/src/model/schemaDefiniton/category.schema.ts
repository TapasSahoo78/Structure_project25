// src/models/Category.ts
import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { ICategory } from "../../@types/interfaces/category.interface"; // Assuming this is where your ICategory interface is defined

const categorySchema: Schema<ICategory> = new Schema<ICategory>(
	{
		name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Category name cannot be more than 100 characters"]
		},
		description: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			maxlength: [500, "Description cannot be more than 500 characters"]
		},
		icon: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true
		},
		parent_id: {
			type: Schema.Types.ObjectId,
			ref: "Category", // Refers to the same collection for subcategories
			default: null
		},
		created_date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
			default: Date.now
		},
		created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default categorySchema;
