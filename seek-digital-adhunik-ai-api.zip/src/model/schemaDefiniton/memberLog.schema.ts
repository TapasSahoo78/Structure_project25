import { Schema, VirtualTypeOptions } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IMemberLog } from "../../@types/interfaces/memberLog.interface";

const memberLogSchema: Schema<IMemberLog> = new Schema<IMemberLog>(
	{
		roleId: SCHEMA_DEFINITION_PROPERTY.requiredString,
		email: SCHEMA_DEFINITION_PROPERTY.requiredString,
		first_name: SCHEMA_DEFINITION_PROPERTY.requiredString,
		last_name: SCHEMA_DEFINITION_PROPERTY.requiredString,
		user_name: SCHEMA_DEFINITION_PROPERTY.requiredString,
		activity: SCHEMA_DEFINITION_PROPERTY.requiredString,
		status: SCHEMA_DEFINITION_PROPERTY.requiredString,
		description: SCHEMA_DEFINITION_PROPERTY.requiredString,
		activity_initiated_by: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		date: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		time: { ...SCHEMA_DEFINITION_PROPERTY.requiredDate, default: Date.now() }
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default memberLogSchema;
