import { Schema } from "mongoose";
import { ITool } from "../../@types/interfaces/tool.interface";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";

const toolSchema: Schema<ITool> = new Schema<ITool>(
    {
        categoryId: { type: Schema.Types.ObjectId, ref: "Category", required: true },
        name: { type: String, required: true, trim: true },
        overview: { type: String, required: true, trim: true },
        updates: { type: String, required: true, trim: true },
        pros: { type: [String], required: true },
        cons: { type: [String], required: true },
        pricing: { type: String, required: true },
        gallery: { type: [String], required: true }, // Array of image URLs
        faq: [
            {
                question: { type: String, required: true },
                answer: { type: String, required: true },
            },
        ],
        created_date: { 
            ...SCHEMA_DEFINITION_PROPERTY.requiredDate, 
            default: Date.now,
        },
        created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
    },
    {
        ...GENERAL_SCHEMA_OPTIONS,
        toJSON: { virtuals: true },
        toObject: { virtuals: true }
    }
);

export default toolSchema;
