import { model } from "mongoose";
import { ITool } from "../@types/interfaces/tool.interface";
import toolSchema from "./schemaDefiniton/tool.schema";

const toolModel = model<ITool>("Tool", toolSchema);

export default toolModel;
