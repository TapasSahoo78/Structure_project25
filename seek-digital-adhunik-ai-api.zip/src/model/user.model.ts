import { model } from "mongoose";
import { IUser } from "../@types/interfaces/user.interface";
import userSchema from "./schemaDefiniton/user.schema";

const userModel = model<IUser>("users", userSchema);

export default userModel;
