import { Model, FilterQuery } from "mongoose";
import bcrypt from "bcryptjs";
import jwt, { Secret } from "jsonwebtoken";
import e from "express";

export const isDuplicateGroupOwnerEmailService = async (
	groupOwnerModel: Model<any>,
	email: string
): Promise<boolean> => {
	try {
		const filter = { email };
		const emailInstance = await groupOwnerModel.findOne(filter);

		if (emailInstance) {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		throw err;
	}
};
export const isDuplicateValueCheckService = async (
	model: Model<any>,
	field: string, // Specify the field to check for duplicates
	value: string
): Promise<boolean> => {
	try {
		const filter = { [field]: value }; // Use dynamic field name
		const result = await model.findOne(filter).exec(); // Use exec() for better error handling

		return result !== null; // Return true if a duplicate is found
	} catch (err) {
		console.error("Error checking for duplicate value:", err); // Log the error for debugging
		throw new Error("Database error occurred while checking for duplicates."); // Throw a more user-friendly error
	}
};
export const isRegisteredEmailService = async (model: Model<any>, email: string): Promise<boolean> => {
	try {
		const emailInstance = await model.findOne({
			$and: [{ email }]
		});

		if (emailInstance) {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		throw err;
	}
};

export const isDuplicateUserNameService = async (
	groupOwnerModel: Model<any>,
	employeeModel: Model<any>,
	email: string
): Promise<boolean> => {
	try {
		const filter = { email };
		const groupOwnerUserNameInstance = await groupOwnerModel.findOne(filter);
		const memberUserNameInstance = await employeeModel.findOne(filter);

		if (groupOwnerUserNameInstance || memberUserNameInstance) {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		throw err;
	}
};

export const isRegisteredUsernameService = async (model: Model<any>, email: string): Promise<boolean> => {
	try {
		const usernameInstance = await model.findOne({
			$and: [{ email }, { is_registered: true }]
		});

		if (usernameInstance) {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		throw err;
	}
};

export const hashPassword = async (password: string): Promise<string> => {
	const salt = await bcrypt.genSalt(10);
	const encryptPassword = await bcrypt.hash(password, salt);

	return encryptPassword;
};

export const comparePassword = async (inputPassword: string, dbPassword: string): Promise<boolean> => {
	const compare = await bcrypt.compare(inputPassword, dbPassword);

	// console.log("Password Bcrypt Comparison", compare);

	if (compare) return true;
	else return false;
};

export const generateJWT = async (jwtPayload: Record<string, unknown>): Promise<string> => {
	const jwtToken = jwt.sign(
		{
			...jwtPayload
		},
		process.env.JWT_KEY as Secret,
		{
			expiresIn: "1y"
		}
	);

	return jwtToken;
};

export const convertCaseInsensitiveForQuery = (value: string): Record<string, unknown> => {
	try {
		return { $regex: value, $options: "i" };
	} catch (error: any) {
		throw error;
	}
};
