export const formatDataByStatus = (items: any): any => {
	try {
		const today = new Date();
		const obj: any = { active: [], upcoming: [], expired: [] };
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			const itemStartDate = new Date(item.start_date);

			if (item.end_date) {
				const itemEndDate = new Date(item.end_date);
				if (today >= itemStartDate) {
					if (today <= itemEndDate) {
						obj.active.push(item);
					} else {
						obj.expired.push(item);
					}
				} else {
					obj.upcoming.push(item);
				}
			} else {
				if (today >= itemStartDate) {
					obj.active.push(item);
				} else {
					obj.upcoming.push(item);
				}
			}
		}

		return obj;
	} catch (err) {
		throw err;
	}
};
