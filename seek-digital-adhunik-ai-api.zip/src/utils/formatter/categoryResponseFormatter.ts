// src/utils/responseFormatter.ts
import { ICategoryResponse } from '../../@types/interfaces/formatter/categoryFormatter.interface';
import { ICategory } from '../../@types/interfaces/category.interface'; // Assuming you have a category interface
import categoryModel from '../../model/category.model'; // Import the role model

export const formatCategoryResponse = async (category: ICategory): Promise<ICategoryResponse> => {
    // Fetch the role name based on roleId
    const ParentCategory = await categoryModel.findById(category.parent_id);
    const parent = ParentCategory ? ParentCategory.name : 'None'; // Default if not found
    const subcategories = await categoryModel.find({
        parent_id: category._id 
    }) as ICategory[];

    return {
        _id: category._id.toString(),
        name: category.name,
        description: category.description,
        icon: category.icon,
        parent_id: category?.parent_id?.toString() ?? null,
        parent: category.parent_id ? parent : null,
        subcategory: subcategories || [],
    };
};

export const formatCategoriesResponse = async (categorys: ICategory[]): Promise<ICategoryResponse[]> => {
    // Use Promise.all to fetch roles for all categorys concurrently
    const categoryResponses = await Promise.all(categorys.map(async (category) => {
        // Fetch the role name based on roleId
        const ParentCategory = await categoryModel.findById(category.parent_id);
        const parent = ParentCategory ? ParentCategory.name : 'None'; // Default if not found
        const subcategories = await categoryModel.find({
            parent_id: category._id 
        }) as ICategory[];

        return {
            _id: category._id.toString(),
            name: category.name,
            description: category.description,
            icon: category.icon,
            parent_id: category?.parent_id?.toString() ?? null,
            parent: category.parent_id ? parent : null,
            subcategory: subcategories || []
        };
    }));

    return categoryResponses; // Return the array of category responses
};
