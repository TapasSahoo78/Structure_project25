// src/utils/responseFormatter.ts
import { IFaqCategoryResponse } from '../../@types/interfaces/formatter/faqCategoryFormatter.interface';
import { IfaqCategoryShema } from '../../@types/interfaces/faqCategory.interface';
import { IFaqResponse } from '../../@types/interfaces/formatter/faqFormatter.interface';
import { IFaqSchema } from '../../@types/interfaces/faq.interface';
import faqCategoryModel from '../../model/faqCategory.model';

export const formatCategoryResponse = async (category: IfaqCategoryShema): Promise<IFaqCategoryResponse> => {
    return {
        _id: category._id.toString(),
        name: category.name,
        description: category.description
    };
};

export const formatCategoriesResponse = async (categorys: IfaqCategoryShema[]): Promise<IFaqCategoryResponse[]> => {
    // Use Promise.all to fetch roles for all categorys concurrently
    const categoryResponses = await Promise.all(categorys.map(async (category) => {
        return {
            _id: category._id.toString(),
            name: category.name,
            description: category.description
        };
    }));

    return categoryResponses; // Return the array of category responses
};
//Faq Response
export const formatFaqResponse = async (faq: IFaqSchema): Promise<IFaqResponse> => {
    // Fetch the role name based on roleId
    const faqCategory = await faqCategoryModel.findById(faq.faqCategoryId);
    const categoryNameName = faqCategory ? faqCategory.name : 'Unknown Category'; // Default if not found
    return {
        _id: faq._id.toString(),
        faqCategoryId: faq.faqCategoryId,
        categoryName: categoryNameName,
        question: faq.question,
        answer: faq.answer,
        is_active: faq.is_active,
        is_user: faq.is_user,
    };
};

export const formatFaqsResponse = async (faqs: IFaqSchema[]): Promise<IFaqResponse[]> => {
    // Use Promise.all to fetch roles for all faqs concurrently
    const faqResponses = await Promise.all(faqs.map(async (faq) => {

        // Fetch the role name based on roleId
        const faqCategory = await faqCategoryModel.findById(faq.faqCategoryId);
        const categoryNameName = faqCategory ? faqCategory.name : 'Unknown Category'; // Default if not found

        return {
            _id: faq._id.toString(),
            faqCategoryId: faq.faqCategoryId,
            categoryName: categoryNameName,
            question: faq.question,
            answer: faq.answer,
            is_active: faq.is_active,
            is_user: faq.is_user,
        };
    }));

    return faqResponses; // Return the array of category responses
};