import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  Platform,
  Dimensions,
} from 'react-native';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import constants from '../utils/helpers/constants';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import Button from './Button';
const WIDTH = Dimensions.get('window').width;
const HEIGHT = Dimensions.get('window').height;
export default function AddressComponent(props) {
  return (
    <Modal
      isVisible={props.isAddressModalVisible}
      backdropColor={'#000'}
      backdropOpacity={0.5}
      animationIn={'slideInUp'}
      animationOut={'slideOutDown'}
      animationInTiming={800}
      animationOutTiming={600}
      backdropTransitionOutTiming={0}
      avoidKeyboard={true}
      onBackdropPress={() => props.onBackdropPress()}
      style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
      <View style={styles.centeredView}>
        {props.headerVisible && (
          <View
            style={{
              padding: normalize(10),
              backgroundColor: COLORS.light_sky,
            }}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginHorizontal: normalize(6),
              }}>
              <View style={{width: '75%'}}>
                <Text
                  style={{
                    color: COLORS.white,
                    fontFamily: FONTS.Poppins_SemiBold,
                    fontSize: normalize(15),
                    marginBottom: normalize(3),
                  }}>
                  Location Permission is off
                </Text>
                <Text
                  style={{
                    color: COLORS.white,
                    fontFamily: FONTS.Poppins_Light,
                    fontSize: normalize(11),
                    lineHeight: normalize(16),
                  }}>
                  Granting location will ensure accurate address and hassle free
                  service
                </Text>
              </View>
              <Button
                title={'Grant'}
                height={normalize(25)}
                backgroundColor={COLORS.white}
                borderRadius={normalize(6)}
                fontSize={normalize(10)}
                width={normalize(60)}
                textColor={COLORS.blue}
                onPress={() => props.onPressGrant()}
              />
            </View>
          </View>
        )}
        <View style={styles.modalView}>
          {props.crosssButtonEnable && (
            <TouchableOpacity
              style={{
                position: 'absolute',
                right: normalize(15),
                top: normalize(5),
              }}
              onPress={() => {
                props.onBackdropPress();
                // setWorkAddressType(1);
              }}>
              <Image
                source={ICONS.remove}
                resizeMode="contain"
                style={{height: normalize(18), width: normalize(18)}}
              />
            </TouchableOpacity>
          )}
          <View
            style={{
              height: normalize(350),
              width: '100%',
              alignSelf: 'center',
              marginTop: normalize(15),
            }}>
            {/* <Text
              style={{
                paddingBottom: normalize(8),
                color: COLORS.textColor,
                fontSize: normalize(13),
                fontFamily: FONTS.Poppins_SemiBold,
                marginLeft: normalize(5),
              }}>
              {props.title}
            </Text> */}
            <GooglePlacesAutocomplete
              GooglePlacesDetailsQuery={{type: 'geocode'}}
              placeholder={props.placeholder}
              // currentLocation={true}
              minLength={3}
              // disableScroll={true}
              fetchDetails={true}
              returnKeyType={'default'}
              listViewDisplayed="auto"
              enablePoweredByContainer={false}
              renderLeftButton={() => (
                <Image
                  source={ICONS.search}
                  style={{
                    height: normalize(14),
                    width: normalize(14),
                    marginLeft: normalize(8),
                    tintColor: COLORS.textColor,
                  }}
                />
              )}
              // currentLocation={true} // Will add a 'Current location' button at the top of the predefined places list
              // currentLocationLabel="Current location"
              // nearbyPlacesAPI='GooglePlacesSearch'
              listEmptyComponent={() => (
                <View style={{flex: 1}}>
                  <Text style={{fontFamily: FONTS.Poppins_SemiBold}}>
                    No results were found
                  </Text>
                </View>
              )}
              textInputProps={{
                autoFocus: true,
                blurOnSubmit: false,
              }}
              // keyboardShouldPersistTaps="never"
              styles={{
                textInputContainer: {
                  alignItems: 'center',
                  // height: normalize(40),

                  borderWidth: 0.5,
                  borderColor: COLORS.textColor,
                  // borderColor: '#DFE2E7',
                  borderRadius: normalize(8),
                  fontFamily: FONTS.Poppins_SemiBold,
                },
                textInput: {
                  color: '#000',
                  fontSize: normalize(12),
                  height: normalize(40),
                },
                predefinedPlacesDescription: {
                  color: COLORS.textColor,
                },
              }}
              // textInputProps={{
              //   onChangeText: (text) => { console.warn(text) }
              // }}
              onPress={(data, details) => {
                console.log(details);
                console.log(data);
                let stateName = '';
                let cityName = '';
                let country = '';
                details.address_components.forEach(
                  x => {
                    if (x.types.includes('administrative_area_level_1')) {
                      stateName = x.long_name;
                    } else if (x.types.includes('locality')) {
                      cityName = x.long_name;
                    } else if (x.types.includes('country')) {
                      country = x.long_name;
                    }
                  },
                  // x.types.filter(t => t == 'administrative_area_level_1')
                  //   .length > 0,
                );
                // var cityName = details.address_components.filter(
                //   x => x.types.filter(t => t == 'locality').length > 0,
                // )[0].long_name;

                // var country = details.address_components.filter(
                //   x => x.types.filter(t => t == 'country').length > 0,
                // )[0].long_name;
                let body = {
                  city: cityName,
                  state: stateName,
                  country: country == 'India' ? 'India' : 'Dubai',
                  lat: details.geometry.location.lat,
                  lng: details.geometry.location.lng,
                  address1: details?.formatted_address,
                  address1: data.description,
                };
                console.log('body', body);
                props.onPressOk(body);

                // console.log(data?.terms[data.terms.length - 3].value);
                // console.log(data?.terms[data.terms.length - 2].value);

                // setAddressLatVal(details.geometry.location.lat);
                // setAddressLongVal(details.geometry.location.lng);
                // setAddress(data.description);
                // setCity(data?.terms[data.terms.length - 3].value);
                // setState(data?.terms[data.terms.length - 2].value);
                // setAddressModalVisible(false);
                // let arr = details?.address_components.filter(element => {
                //   return element.types.includes('postal_code');
                // });
                // console.log(data?.terms[data.terms.length - 2].value);
                // setPincode(arr?.[0]?.long_name ?? '');
              }}
              onFail={error => console.error(error)}
              query={{
                key: constants.GOOGLE_API_KEY,
                language: 'en',
                // components: `country:${countryCode}`,
              }}
            />
          </View>
          {/* <Container bg={"#2144C1"} radius={10} pv={10} align="center" width={'70%'}>
            <CText color={'#fff'}> Submit </CText>
        </Container> */}
        </View>
      </View>
    </Modal>
  );
}

AddressComponent.propTypes = {
  isAddressModalVisible: PropTypes.bool,
  title: PropTypes.string,
  placeholder: PropTypes.string,
  crosssButtonEnable: PropTypes.bool,
  onBackdropPress: PropTypes.func,
  onPressOk: PropTypes.func,
  onBackButtonPress: PropTypes.func,
  onPressGrant: PropTypes.func,
  onPressCancel: PropTypes.func,
  isCancelVisible: PropTypes.bool,
  ok_button_title: PropTypes.string,
  headerVisible: PropTypes.bool,
};

AddressComponent.defaultProps = {
  isAddressModalVisible: false,
  onPressCross: false,
  title: 'Add Location',
  placeholder: 'Search Location',
  crosssButtonEnable: true,
  onBackdropPress: () => {},
  onPressOk: () => {},
  onPressCancel: () => {},
  onPressGrant: () => {},
  isCancelVisible: true,
  ok_button_title: 'OK',
  headerVisible: false,
};

const styles = StyleSheet.create({
  icon: {
    height: normalize(15),
    width: normalize(15),
    resizeMode: 'contain',
    tintColor: COLORS.textColor,
  },
  topText: {
    fontSize: normalize(18),
    // fontFamily: FONTS.Poppins_SemiBold,
    color: COLORS.black,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  nameText: {
    fontSize: normalize(14),
    fontFamily: FONTS.Poppins_Bold,
    color: '#363D4E',
    marginTop: normalize(12),
  },
  phoneText: {
    fontSize: normalize(11),
    fontFamily: FONTS.Poppins_Regular,
    color: '#363D4E',
  },
  barStyle: {
    height: normalize(0.5),
    width: '100%',
    backgroundColor: '#ACACAC',
    marginTop: normalize(15),
    marginBottom: normalize(10),
  },
  featureView: {
    backgroundColor: '#ECECEA',
    flexDirection: 'row',
    width: '100%',
    paddingTop: normalize(12),
    paddingLeft: normalize(12),
    borderRadius: normalize(10),
    marginTop: normalize(10),
  },
  genderText: {
    fontSize: normalize(12),
    color: COLORS.black,
    fontFamily: FONTS.Poppins_SemiBold,
    marginLeft: normalize(5),
  },
  image: {
    height: normalize(150),
    width: '100%',
    borderRadius: normalize(10),
  },
  listText: {
    fontSize: normalize(11),
    fontFamily: FONTS.Poppins_Regular,
    color: COLORS.black,
    marginLeft: normalize(3),
  },
  imageView: {
    borderWidth: 1,
    height: normalize(90),
    width: normalize(90),
    borderRadius: normalize(45),
    borderColor: COLORS.textColor,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: normalize(10),
  },
  calendarButton: {
    paddingHorizontal: normalize(8),
    width: '100%',
    height: normalize(40),
    borderRadius: normalize(6),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.textColor,
    marginTop: normalize(5),
  },
  calendertitle: {
    fontSize: normalize(11),
    color: COLORS.black,
    fontFamily: FONTS.Poppins_SemiBold,
  },

  downiconStyle: {
    height: normalize(15),
    width: normalize(15),
  },
  addMoreView: {
    borderWidth: 1,
    height: normalize(80),
    width: normalize(80),
    borderRadius: normalize(10),
    borderColor: COLORS.textColor,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: normalize(10),
  },
  addicon: {
    height: normalize(25),
    width: normalize(25),
    resizeMode: 'contain',
  },
  imageicon: {
    height: normalize(15),
    width: normalize(15),
    tintColor: COLORS.textColor,
    elevation: 2,
  },
  centeredView: {
    maxHeight: Platform.OS == 'ios' ? HEIGHT / 1.9 : HEIGHT / 1.8,
    width: '100%',
    // paddingTop: normalize(10),
    // paddingHorizontal: 30,
    backgroundColor: '#fff',
    borderTopLeftRadius: normalize(10),
    borderTopEndRadius: normalize(20),
  },
  modalView: {
    paddingHorizontal: normalize(16),
    paddingTop: normalize(16),
    // margin: 20,
  },
  certImage: {
    height: normalize(80),
    width: normalize(80),
    marginRight: normalize(10),
  },
  remove: {
    position: 'absolute',
    right: -normalize(7),
    top: -normalize(5),
    backgroundColor: COLORS.white,
    padding: normalize(3),
    borderRadius: normalize(30),
    zIndex: 50,
    elevation: 6,
  },
  textInputContainer: {
    borderWidth: 1,
    borderColor: COLORS.dark_grey,
    height: normalize(40),
    borderRadius: normalize(7),
    width: '100%',
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    marginTop: normalize(10),
  },
  lefttextInputContainer: {
    borderEndWidth: 1,
    //borderWidth: 1,
    borderColor: '#30303033',
    width: '22%',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  textInputFont: {
    fontSize: normalize(11),
    fontFamily: FONTS.Poppins_SemiBold,
    color: COLORS.black,
  },
});
