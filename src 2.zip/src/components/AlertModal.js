import React, {memo} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import normalize from '../utils/helpers/normalize';
import _ from 'lodash';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import Button from './Button';

const AlertModal = props => {
  function onPressCancel() {
    if (props.onPressCancel) {
      props.onPressCancel();
    }
  }
  function onPressOk() {
    if (props.onPressOk) {
      props.onPressOk();
    }
  }
  function onBackButtonPress() {
    if (props.onBackButtonPress) {
      props.onBackButtonPress();
    }
  }
  function onBackdropPress() {
    if (props.onBackdropPress) {
      props.onBackdropPress();
    }
  }

  return (
    <Modal
      isVisible={props.visible}
      backdropColor={COLORS.black}
      backdropOpacity={0.7}
      animationIn={'fadeIn'}
      animationOut={'fadeOut'}
      animationInTiming={300}
      animationOutTiming={500}
      backdropTransitionOutTiming={0}
      onBackdropPress={() => {
        onBackdropPress();
      }}
      onBackButtonPress={() => {
        onBackButtonPress();
      }}
      style={{
        margin: 0,
        alignSelf: 'center',
        width: '90%',
      }}>
      <View
        style={{
          //height: normalize(190),
          paddingVertical: normalize(20),
          backgroundColor: COLORS.white,
          borderRadius: normalize(5),
          // alignItems: 'center',
        }}>
        <Image
          style={{
            height: normalize(75),
            width: normalize(75),
            alignSelf: 'center',
          }}
          source={ICONS.success}
        />
        <Text
          style={{
            color: COLORS.black,
            fontFamily: FONTS.Poppins_Bold,
            fontSize: normalize(14),
            textAlign: 'center',
            marginTop: normalize(10),
          }}>
          {props.title}
        </Text>
        <Text
          style={{
            color: COLORS.black,
            fontFamily: FONTS.Poppins_Medium,
            fontSize: normalize(13),
            marginTop: normalize(5),
            lineHeight: normalize(20),
            textAlign: 'center',
          }}>
          {props.message}
          {/* Are you sure want to logout? */}
        </Text>
        <View
          style={{
            alignItems: 'center',
            paddingTop: normalize(15),
            paddingBottom: normalize(0),
          }}>
          {/* {props.isCancelVisible && (
              <Button
                title={'Cancel'}
                iconVisible={false}
                onPress={() => onPressCancel()}
                width={'30%'}
                //marginTop={normalize(4)}
                backgroundColor={'transparent'}
                // borderColor={COLORS.lightGreen}
                // borderWidth={1}
                textColor={COLORS.red}
              />
            )} */}
          <TouchableOpacity
            onPress={() => onPressOk()}
            style={{
              paddingHorizontal: normalize(12),
              paddingVertical: normalize(5),
              borderWidth: 1,
              borderColor: COLORS.light_sky,
              borderRadius: normalize(5),
              marginRight: normalize(10),
            }}>
            <Text
              style={{
                color: COLORS.black,
                fontFamily: FONTS.Poppins_Medium,
                fontSize: normalize(12),
              }}>
              {props.ok_button_title}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

export default memo(AlertModal);

AlertModal.propTypes = {
  visible: PropTypes.bool,
  title: PropTypes.string,
  message: PropTypes.string,
  onBackdropPress: PropTypes.func,
  onPressOk: PropTypes.func,
  onBackButtonPress: PropTypes.func,
  onBackdropPress: PropTypes.func,
  onPressCancel: PropTypes.func,
  isCancelVisible: PropTypes.bool,
  ok_button_title: PropTypes.string,
};

AlertModal.defaultProps = {
  visible: false,
  onPressCross: false,
  title: '',
  message: '',
  onBackdropPress: () => {},
  onPressOk: () => {},
  onBackdropPress: () => {},
  onPressCancel: () => {},
  isCancelVisible: true,
  ok_button_title: 'OK',
};
