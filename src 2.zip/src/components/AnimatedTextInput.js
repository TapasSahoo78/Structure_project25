import React, {useState} from 'react';
import {TouchableOpacity, Text, View, Image, TextInput} from 'react-native';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import _ from 'lodash';
import {ms, mvs} from '../utils/helpers/metric';
export default function AnimatedTextInput({
  label,
  secureTextEntry,
  onChangeText,
  multiline,
  value,
  marginTop,
  marginBottom,
  rightIcon,
  verifyIcon,
  width,
  maxLength,
  keyboardType,
  underlineHeight,
  editable,
  numberOfLines,
  textColor,
  borderColor,
  suffixBox,
  suffixText,
  minimumHeight,
}) {
  const [visible, setVisible] = React.useState(secureTextEntry);
  const [flag, setFlag] = useState(false);
  return (
    <View
      style={{
        // justifyContent: 'center',
        marginBottom: marginBottom,
        marginTop: marginTop,
        width: width,

        //height: normalize(40),

        // height: normalize(60),
        // backgroundColor: 'red',
      }}>
      {(flag || !_.isEmpty(value)) && (
        <Text
          style={{
            color: '#707070',
            fontSize: ms(12),
            //fontFamily: FONTS.Ubuntu_Regular,
            marginLeft: ms(15),
            paddingHorizontal: ms(5),
            // marginBottom: -mvs(15),
            zIndex: 10,
            backgroundColor: COLORS?.white,
            position: 'absolute',
            top: -ms(8),
          }}>
          {label[label?.length - 1] == '*' ? label.replace('*', '') : label}
          {label[label?.length - 1] == '*' ? (
            <Text style={{color: COLORS?.red}}>*</Text>
          ) : null}
        </Text>
      )}
      <TextInput
        editable={editable}
        placeholder={!flag ? label : ''}
        placeholderTextColor={COLORS.placeholderColor}
        textAlignVertical={multiline ? 'top' : 'center'}
        autoCorrect={false}
        importantForAutofill="no"
        textContentType="none"
        // autoCorrect={false}
        autoComplete="off"
        selectTextOnFocus={false}
        // label={label}
        // // scrollEnabled={false}
        // labelColor={COLORS.lightay}
        // labelActiveColor={COLORS.lightGray}
        autoCapitalize={'none'}
        color={textColor}
        // paddingBottom={0}
        multiline={multiline}
        maxLength={maxLength}
        keyboardType={keyboardType}
        numberOfLines={numberOfLines ? numberOfLines : 1}
        // selectionColor={COLORS?.white}
        // underlineHeight={underlineHeight == 0 ? 0 : underlineHeight}
        // underlineActiveColor={
        //   underlineHeight == 0 ? COLORS.WhiteBg : COLORS.PrimaryBg
        // }
        // underlineColor={COLORS.sky}
        // fontSize={normalize(12)}
        // fontFamily={FONTS.Poppins_Medium_500}
        // labelActiveTop={-normalize(20)}
        //autoComplete="off"
        //selectTextOnFocus={false}
        secureTextEntry={visible ? true : false}
        onChangeText={onChangeText}
        value={value}
        onFocus={() => {
          setFlag(true);
        }}
        onBlur={() => {
          setFlag(false);
        }}
        style={{
          //elevation: 8,
          fontSize: ms(13),
          // borderBottomWidth: normalize(1),
          //fontFamily: FONTS.Poppins_Medium,
          //borderBottomColor: flag ? COLORS.yellow : '#75788D',
          // backgroundColor: 'red',
          // paddingHorizontal: 0,
          paddingLeft: ms(15),
          //paddingVertical: normalize(12),
          color: COLORS.dark_grey,
          borderRadius: ms(10),
          backgroundColor: COLORS.white,
          // minHeight: ms(52),
          minHeight: minimumHeight,
          borderWidth: ms(0.5),
          borderColor: borderColor,

          shadowColor: COLORS.themeColor,
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.5,
          shadowRadius: 3.84,
          // Elevation for Android
          elevation: 10,
        }}
      />
      {rightIcon && (
        <TouchableOpacity
          onPress={() => setVisible(!visible)}
          style={{position: 'absolute', right: ms(10), bottom: mvs(18)}}>
          <Image
            source={visible ? ICONS.eyeOff : ICONS.eye}
            style={{height: ms(18), width: ms(18)}}
            resizeMode="contain"
          />
        </TouchableOpacity>
      )}
      {verifyIcon && (
        <TouchableOpacity
          // onPress={() => setVisible(!visible)}
          style={{position: 'absolute', right: ms(10), bottom: mvs(18)}}>
          <Image
            source={ICONS.tick}
            style={{height: ms(18), width: ms(18)}}
            resizeMode="contain"
          />
        </TouchableOpacity>
      )}
      {suffixBox && (
        <View
          style={{
            padding: ms(10),
            borderLeftWidth: ms(1),
            position: 'absolute',
            right: ms(10),
            height: ms(50),
            borderLeftColor: borderColor,
          }}>
          <Text style={{fontFamily: FONTS?.Bold, fontSize: ms(20)}}>
            {suffixText}
          </Text>
        </View>
      )}
    </View>
  );
}

AnimatedTextInput.defaultProps = {
  label: '',
  value: '',
  secureTextEntry: false,
  multiline: false,
  marginBottom: 0,
  marginTop: normalize(20),
  rightIcon: false,
  verifyIcon: false,
  onChangeText: () => {},
  width: '100%',
  maxLength: null,
  keyboardType: 'default',
  editable: true,
  textColor: COLORS.black,
  borderColor: COLORS?.themeColor,
  suffixBox: false,
  suffixText: '',
  minimumHeight: normalize(48),
};
