import React from 'react';
import {Dimensions, Image, Text, TouchableOpacity, View} from 'react-native';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import PropTypes from 'prop-types';
import normalize from '../utils/helpers/normalize';
import {ms} from '../utils/helpers/metric';
const {height, width} = Dimensions.get('window');

const Button = props => {
  const {
    height = ms(48),
    width = '100%',
    backgroundColor = COLORS.deep_green,
    borderRadius = ms(30),
    textColor = COLORS.white,
    fontSize = ms(13),
    title = '',
    onPress = () => {},
    alignSelf = 'center',
    marginTop = 0,
    marginBottom = 0,
    marginHorizontal = 0,
    borderColor = COLORS.white,
    borderWidth = 0,
    textAlign = 'center',
    fontFamily = FONTS.Poppins_Medium,
    marginLeft = 0,
    marginRight = 0,
    activeOpacity = 0.7,
    letterSpacing = 0,
    textOpacity = 1,
    righticonVisible = false,
    disabled = false,
    lefticonVisible = false,
    lefticon = '',
    buttonStyle = {},
    leftIconStyle = {},
    textTransform = 'uppercase',
    righticon = ICONS.right,
    leftIconTintColor = COLORS.white,
    rightIconStyle = {},
    titleStyle = {},
  } = props;

  return (
    <TouchableOpacity
      disabled={disabled}
      activeOpacity={activeOpacity}
      style={[
        {
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          height: height,
          width: width,
          borderRadius: borderRadius,
          backgroundColor: backgroundColor,
          marginTop: marginTop,
          marginBottom: marginBottom,
          marginHorizontal: marginHorizontal,
          marginLeft: marginLeft,
          marginRight: marginRight,
          borderColor: borderColor,
          borderWidth: borderWidth,
          alignSelf: alignSelf,
        },
        {...buttonStyle},
      ]}
      onPress={() => {
        onPress();
      }}>
      {lefticonVisible && (
        <Image
          source={lefticon}
          resizeMode="contain"
          style={[
            {
              height: ms(15),
              width: ms(15),
              marginRight: ms(10),
              // tintColor: leftIconTintColor,
            },
            leftIconStyle,
          ]}
        />
      )}
      <Text
        numberOfLines={1}
        style={[
          {
            // flexShrink: 1,
            fontFamily: fontFamily,
            color: textColor,
            fontSize: fontSize,
            textAlign: textAlign,
            letterSpacing: letterSpacing,
            // opacity: textOpacity,
            textTransform: textTransform,
            textAlignVertical: 'center',
          },
          {...titleStyle},
        ]}>
        {title}
      </Text>
      {righticonVisible && (
        <Image
          source={righticon}
          resizeMode="contain"
          style={[
            {
              height: ms(15),
              width: ms(15),
              marginLeft: ms(10),
              //tintColor: COLORS.white,
            },
            rightIconStyle,
          ]}
        />
      )}
    </TouchableOpacity>
  );
};

export default Button;

Button.propTypes = {
  height: PropTypes.number,
  width: PropTypes.any,
  backgroundColor: PropTypes.string,
  borderRadius: PropTypes.number,
  textColor: PropTypes.string,
  fontSize: PropTypes.number,
  title: PropTypes.string,
  onPress: PropTypes.func,
  alignSelf: PropTypes.string,
  marginTop: PropTypes.number,
  marginBottom: PropTypes.number,
  marginHorizontal: PropTypes.number,
  textMarginTop: PropTypes.number,
  fontWeight: PropTypes.string,
  borderColor: PropTypes.string,
  borderWidth: PropTypes.number,
  textAlign: PropTypes.string,
  fontFamily: PropTypes.string,
  marginLeft: PropTypes.any,
  marginRight: PropTypes.any,
  activeOpacity: PropTypes.number,
  letterSpacing: PropTypes.number,
  textOpacity: PropTypes.number,
  righticonVisible: PropTypes.bool,
  disabled: PropTypes.bool,
  lefticonVisible: PropTypes.bool,
  lefticon: PropTypes.string,
  buttonStyle: PropTypes.any,
  textTransform: PropTypes.string,
  righticon: PropTypes.any,
  leftIconTintColor: PropTypes.string,
  leftIconStyle: PropTypes.any,
  rightIconStyle: PropTypes.any,
  titleStyle: PropTypes.any,
};
