import React, {memo} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import {ICONS, COLORS, FONTS} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {ms, mvs} from '../utils/helpers/metric';

const CameraDropDown = props => {
  function onPressGallery() {
    if (props.onPressGallery) {
      launchImageLibrary({
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
      })
        .then(response => {
          console.log(response);
          let imageObj = {};
          imageObj.name = response.assets[0].uri.replace(/^.*[\\\/]/, '');
          imageObj.type = response.assets[0].type;
          imageObj.uri = response.assets[0].uri;
          console.log(imageObj, response);

          props.onPressGallery(imageObj);
          props.onBackdropPress();
        })
        .catch(err => console.log(err));
    }
  }

  // function to open camera
  function onPressCamera() {
    if (props.onPressCamera) {
      launchCamera({
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
      })
        .then(response => {
          console.log(response);
          let imageObj = {};
          imageObj.name = response.assets[0].uri.replace(/^.*[\\\/]/, '');
          imageObj.type = response.assets[0].type;
          imageObj.uri = response.assets[0].uri;
          console.log(imageObj);
          props.onPressCamera(imageObj);
          props.onBackdropPress();
        })
        .catch(err => console.log(err));
    }
  }

  return (
    // <Modal
    //   isVisible={props.visible}
    //   animationIn={'slideInUp'}
    //   animationOut={'slideOutDown'}
    //   animationInTiming={800}
    //   animationOutTiming={800}
    //   backdropTransitionOutTiming={0}
    //   onBackdropPress={props.onBackdropPress}
    //   onBackButtonPress={props.onBackdropPress}
    //   style={{margin: 0}}>
    //   <View style={styles.conntainer}>
    //     <TouchableOpacity
    //       activeOpacity={1}
    //       style={styles.crossButton}
    //       onPress={props.onBackdropPress}>
    //       <Image
    //         source={ICONS.remove}
    //         resizeMode="contain"
    //         style={{height: ms(18), width: ms(18)}}
    //       />
    //     </TouchableOpacity>
    //     <TouchableOpacity
    //       activeOpacity={0.7}
    //       onPress={() => onPressCamera()}
    //       style={styles.button}>
    //       <Image
    //         source={ICONS.camera}
    //         resizeMode="contain"
    //         style={styles.icon}
    //       />
    //       <Text style={styles.buttonText}>Camera</Text>
    //     </TouchableOpacity>
    //     <TouchableOpacity
    //       activeOpacity={0.7}
    //       onPress={() => onPressGallery()}
    //       style={styles.button}>
    //       <Image
    //         source={ICONS.gallery}
    //         resizeMode="contain"
    //         style={styles.icon}
    //       />
    //       <Text style={styles.buttonText}>Gallery</Text>
    //     </TouchableOpacity>
    //   </View>
    // </Modal>
    <Modal
      isVisible={props.visible}
      backdropOpacity={0.6}
      animationIn={'slideInUp'}
      animationOut={'slideOutDown'}
      animationInTiming={800}
      animationOutTiming={500}
      backdropTransitionOutTiming={0}
      hasBackdrop={true}
      onBackdropPress={() => {
        props.onBackdropPress();
      }}
      onBackButtonPress={props.onBackdropPress}
      style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
      <View
        style={{
          maxHeight: Dimensions.get('window').height,
          width: '100%',
          //height: Dimensions.get('window').height - normalize(200),
          paddingTop: normalize(10),
          paddingHorizontal: normalize(30),
          backgroundColor: '#FFF',
          borderTopLeftRadius: normalize(20),
          borderTopRightRadius: normalize(20),
          padding: normalize(40),
        }}>
        <View
          style={{
            width: ms(63),
            height: ms(6),
            borderRadius: ms(8),
            backgroundColor: 'rgba(217, 217, 217, 1)',
            alignSelf: 'center',
            marginBottom: ms(20),
            marginTop: ms(10),
          }}
        />
        
        <View
          style={{
            width: '100%',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <Text
            style={{
              fontSize: normalize(18),
              fontFamily: FONTS.Medium,
              paddingVertical: normalize(20),
              //paddingHorizontal: normalize(20),
            }}>
            {props?.title}
          </Text>
          <TouchableOpacity
            //onPress={() => (false)}
            style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text
              style={{
                fontSize: normalize(16),
                color: COLORS.themeColor,
                fontFamily: FONTS.Regular,
              }}>
              Upload
            </Text>
            <Image
              resizeMode="contain"
              style={{
                height: normalize(17),
                width: normalize(17),
                marginLeft: normalize(5),
              }}
              source={ICONS.bluetick}
            />
          </TouchableOpacity>
        </View>

        <Text
          style={{
            fontSize: normalize(14),
            fontFamily: FONTS.Regular,
            //marginTop: normalize(35),
          }}>
          Add image here upload from gallery or click a picture
        </Text>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            marginTop: normalize(25),
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
          <TouchableOpacity
            onPress={() => onPressGallery()}
            style={{
              height: normalize(120),
              width: normalize(140),
              justifyContent: 'center',
              alignItems: 'center',
              borderWidth: 1,
              //borderColor: COLORS.border,
              borderRadius: normalize(20),
              borderStyle: 'dotted',
              borderColor: COLORS.themeColor,
              elevation: 3,
              backgroundColor: COLORS.white,
              shadowColor: COLORS.themeColor,
            }}>
            <Image
              resizeMode="contain"
              style={{height: normalize(30), width: normalize(40)}}
              source={ICONS.gallery}
            />
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: normalize(20),
              }}>
              <Image
                resizeMode="contain"
                style={{height: ms(15), width: ms(15), marginRight: ms(5)}}
                source={ICONS.plusicn}
              />
              <Text
                style={{
                  fontSize: normalize(14),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Add photo
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => onPressCamera()}
            style={{
              height: normalize(120),
              width: normalize(140),
              borderWidth: 1,
              //borderColor: COLORS.border,
              borderRadius: normalize(20),
              justifyContent: 'center',
              alignItems: 'center',
              borderStyle: 'dotted',
              borderColor: COLORS.themeColor,
              elevation: 3,
              backgroundColor: COLORS.white,
              shadowColor: COLORS.themeColor,
            }}>
            <Image
              resizeMode="contain"
              style={{height: normalize(30), width: normalize(40)}}
              source={ICONS.cam}
            />
            <Text
              style={{
                fontSize: normalize(14),
                marginTop: normalize(20),
                color: COLORS.themeColor,
                fontFamily: FONTS.Regular,
              }}>
              Camera
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

CameraDropDown.propTypes = {
  visible: PropTypes.bool,
  onBackdropPress: PropTypes.func,
  onPressCamera: PropTypes.func,
  onPressGallery: PropTypes.func,
  title: PropTypes.string,
};

CameraDropDown.defaultProps = {
  visible: false,
  title: 'Logo',
  onBackdropPress: () => {},
  onPressCamera: () => {},
  onPressGallery: () => {},
};
export default memo(CameraDropDown);

const styles = StyleSheet.create({
  conntainer: {
    height: ms(170),
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: COLORS.white,
    paddingVertical: mvs(20),
    borderTopLeftRadius: ms(15),
    borderTopRightRadius: ms(15),
  },
  button: {
    flexDirection: 'row',
    width: '80%',
    height: ms(45),
    borderRadius: ms(6),
    backgroundColor: COLORS.deep_green,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: ms(15),
  },
  icon: {
    height: ms(18),
    width: ms(18),
    tintColor: COLORS.white,
    marginRight: ms(18),
  },
  buttonText: {
    color: COLORS.white,
    fontSize: ms(14),
    fontFamily: FONTS.Poppins_SemiBold,
  },
  crossButton: {
    position: 'absolute',
    right: ms(15),
    top: -ms(12),
    height: ms(30),
    width: ms(30),
    backgroundColor: COLORS.white,
    zIndex: 10,
    borderRadius: ms(15),
    alignItems: 'center',
    justifyContent: 'center',
  },
});
