import React, {memo, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  StyleSheet,
  Keyboard,
  Dimensions,
} from 'react-native';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import normalize from '../utils/helpers/normalize';
import _ from 'lodash';
import CountryCodes from '../utils/helpers/CountryCodes.json';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
const WIDTH = Dimensions.get('window').width;
const HEIGHT = Dimensions.get('window').height;
const CountryPicker = props => {
  const [selectedName, setSelectedName] = useState(props.initialValue);
  const [modalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState('');
  const [data, setData] = useState(CountryCodes);

  function onPressItem(item) {
    if (props.onPressItem) {
      props.onPressItem(item);
      setSelectedName(item);
    }
  }

  function renderItem({item, index}) {
    return (
      <TouchableOpacity
        style={styles.itemView}
        onPress={() => {
          onPressItem(item);
          setModalVisible(false);
          Keyboard.dismiss();
        }}>
        <Text style={[styles.itemText]}>{item.flag}</Text>
        <Text style={[styles.itemText, {width: '80%'}]}>{item.dial_code}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <>
      <TouchableOpacity
        disabled={props.editable}
        onPress={() => {
          setModalVisible(true);
        }}
        style={styles.button}>
        <Text
          style={{
            fontSize: normalize(13),
            fontFamily: FONTS.Poppins_Regular,
            color: COLORS.textColor,
          }}>
          {selectedName?.flag}
        </Text>
        <Text
          style={{
            fontSize: normalize(13),
            fontFamily: FONTS.Poppins_Regular,
            color: COLORS.textColor,
          }}>
          {selectedName?.dial_code}
        </Text>
        <Image
          resizeMode="contain"
          style={{
            width: normalize(16),
            height: normalize(16),
            tintColor: COLORS.dark_grey,
          }}
          source={ICONS.dropdown}
        />
      </TouchableOpacity>
      <Modal
        isVisible={modalVisible}
        backdropColor={COLORS.black}
        backdropOpacity={0.7}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        onBackdropPress={() => {
          //setSearch('');
          setModalVisible(false);
        }}
        onBackButtonPress={() => {
          //setSearch('');
          setModalVisible(false);
        }}
        style={{
          margin: 0,
          flex: 1,
          justifyContent: 'flex-end',
        }}>
        <View style={styles.modalContainer}>
          {/* <View style={styles.textInputContainer}>
            <TextInput
              value={search}
              onChangeText={val => {
                setSearch(val);
                let filteredArray = [];
                if (val) {
                  filteredArray = CountryCodes.filter(value => {
                    const itemData = value.name
                      ? value.name.toUpperCase()
                      : ''.toUpperCase();
                    const textData = val.toUpperCase();
                    return itemData.includes(textData);
                  });
                  setData(filteredArray);
                } else {
                  setData(CountryCodes);
                }
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              style={styles.textInput}
            />
            {search != '' && (
              <TouchableOpacity
                onPress={() => {
                  setSearch('');
                  setData(CountryCodes);
                }}
                style={{position: 'absolute', right: normalize(12)}}>
                <Image
                  resizeMode="contain"
                  style={{
                    width: normalize(14),
                    height: normalize(14),
                    tintColor: COLORS.black,
                  }}
                  source={ICONS.remove}
                />
              </TouchableOpacity>
            )}
          </View> */}

          <FlatList
            data={data}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderItem}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          />
        </View>
      </Modal>
    </>
  );
};

export default memo(CountryPicker);

CountryPicker.propTypes = {
  visible: PropTypes.bool,
  onBackdropPress: PropTypes.func,
  data: PropTypes.array,
  initialValue: PropTypes.string,
  onPressItem: PropTypes.func,
  onPressPicker: PropTypes.func,
  editable: PropTypes.bool,
  opacity: PropTypes.number,
};

CountryPicker.defaultProps = {
  visible: false,
  data: [],
  initialValue: CountryCodes[0],
  editable: false,
  onBackdropPress: () => {},
  onPressItem: () => {},
  onPressPicker: () => {},
  opacity: 1,
};

const styles = StyleSheet.create({
  modalContainer: {
    maxHeight: Platform.OS == 'ios' ? HEIGHT / 1.9 : HEIGHT / 1.8,
    paddingHorizontal: normalize(20),
    width: '100%',
    backgroundColor: COLORS.white,
    paddingTop: normalize(10),
    borderTopLeftRadius: normalize(25),
    borderTopRightRadius: normalize(25),
  },
  textInputContainer: {
    marginBottom: normalize(7),
    marginTop: normalize(5),
    height: normalize(38),
    borderRadius: normalize(3),
    justifyContent: 'center',
    backgroundColor: '#cccccc',
    borderRadius: normalize(8),
  },
  textInput: {
    paddingLeft: normalize(14),
    fontFamily: FONTS.Poppins_Medium,
    textAlignVertical: 'center',
    fontSize: normalize(12),
    color: COLORS.black,
  },
  button: {
    borderEndWidth: 1,
    //borderWidth: 1,
    borderColor: '#30303033',
    width: '26%',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  itemView: {
    flexDirection: 'row',
    paddingVertical: normalize(15),
    backgroundColor: '#dddddd',
    marginBottom: normalize(8),
    borderRadius: normalize(10),
  },
  itemText: {
    fontSize: normalize(15),
    color: COLORS.black,
    fontFamily: FONTS.Poppins_Medium,
    marginLeft: normalize(12),
  },
  topCrossButton: {
    position: 'absolute',
    right: normalize(5),
    top: -normalize(14),
    height: normalize(25),
    width: normalize(25),
    justifyContent: 'center',
    alignItems: 'center',
  },
});
