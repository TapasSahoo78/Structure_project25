import {COLORS} from '../themes/Themes';

export default customAppearance = {
  // font: {
  //   family: FONTS.Inter_Medium,
  // },
  shapes: {
    borderWidth: 0.5,
  },
  // primaryButton: {
  //   shapes: {
  //     borderRadius: 20,
  //   },
  // },
  colors: {
    primary: COLORS.black,
    background: COLORS.white,
    componentBackground: COLORS.white,
    componentBorder: COLORS.black,
    componentDivider: COLORS.textColor,
    primaryText: COLORS.black,
    secondaryText: COLORS.black,
    componentText: COLORS.black,
    placeholderText: COLORS.dark_grey,
    icon: COLORS.black,
  },
};
