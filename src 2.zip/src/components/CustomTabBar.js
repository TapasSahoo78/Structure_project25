import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import {ms} from '../utils/helpers/metric';

const CustomTabBar = ({state, descriptors, navigation}) => {
  const {bottom} = useSafeAreaInsets();

  return (
    <View
      style={{
        flexDirection: 'row',
        paddingBottom: bottom,
        backgroundColor: 'white',
      }}>
      {state.routes.map((route, index) => {
        const {options} = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        React.useEffect(() => {}, []);

        return (
          <TouchableOpacity
            key={index}
            accessibilityRole="button"
            accessibilityState={isFocused ? {selected: true} : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{flex: 1, alignItems: 'center', padding: 10}}>
            <Animated.View style={[animatedStyle]}>
              <View
                style={
                  isFocused
                    ? styles.activeTabOuterCircle
                    : styles.inactiveTabOuterCircle
                }>
                <View
                  style={
                    isFocused
                      ? styles.activeTabBackground
                      : styles.inactiveTabBackground
                  }>
                  <Image
                    source={
                      index == 0
                        ? ICONS.tab1
                        : index == 1
                        ? ICONS.tab2
                        : index == 2
                        ? ICONS.tab3
                        : index == 3
                        ? ICONS.refer
                        : ICONS.tab4
                    }
                    resizeMode="contain"
                    style={[
                      styles.iconStyle,
                      {tintColor: isFocused ? COLORS.white : '#717171'},
                    ]}
                  />
                </View>
              </View>
              {isFocused ? (
                <Text
                  style={{
                    color: isFocused ? '#000' : '#222',
                    textAlign: 'center',
                  }}>
                  {label}
                </Text>
              ) : null}
            </Animated.View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};
const styles = StyleSheet.create({
  bottomBar: {
    width: ms(90),
    height: ms(5),
    backgroundColor: '#FCB143',
    position: 'absolute',
    bottom: 0,
    borderTopRightRadius: ms(4),
    borderTopLeftRadius: ms(4),
  },
  labelStyle: {
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    // paddingHorizontal: ms(5),
    // backgroundColor: 'red',
  },
  labelText: {
    fontFamily: FONTS.Inter_Medium,
    fontSize: ms(10),
    marginTop: ms(2),
  },
  iconStyle: {
    width: ms(18),
    height: ms(18),
    // tintColor: COLORS.dark_grey,
    //marginRight: ms(10),
  },
  fa: {
    //flexDirection: 'row',
    alignItems: 'center',
  },
  activeTabBackground: {
    height: ms(30),
    width: ms(30),
    backgroundColor: COLORS?.themeColor,
    borderRadius: ms(25),
    alignItems: 'center',
    justifyContent: 'center',
    // marginTop: -ms(30),
  },
  inactiveTabBackground: {},
  activeTabOuterCircle: {
    height: ms(40),
    width: ms(40),
    borderWidth: ms(1.5),
    borderColor: COLORS?.themeColor,
    borderRadius: ms(30),
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -ms(20),
    backgroundColor: COLORS?.white,
  },
  inactiveTabOuterCircle: {},
});

export default CustomTabBar;
