import React from 'react';
import {Text, TouchableOpacity, View, Image, Dimensions} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../themes/Themes';
import PropTypes from 'prop-types';
import {ms, mvs} from '../utils/helpers/metric';
import {useDispatch, useSelector} from 'react-redux';
import {goBack} from '../utils/helpers/RootNaivgation';

export default function DepthHeader(props) {
  const {
    label = '',
    searchOptionPresent = true,
    tickOptionPresent = true,
    addMoreOptionPresent = true,
    isBackPresent = false,
    editOptionPresent = false,
    downloadPresent = false,
  } = props;
  const dispatch = useDispatch();
  return (
    <View
      style={{
        width: Dimensions?.get('window')?.width,
        height: ms(50),
        backgroundColor: '#e6f2ff',
        borderBottomLeftRadius: ms(70),
        borderBottomRightRadius: ms(70),
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: ms(20),
      }}>
      {isBackPresent ? (
        <TouchableOpacity
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}
          onPress={() => {
            goBack();
          }}>
          <Image
            source={ICONS?.upArrow}
            style={{
              height: ms(15),
              width: ms(15),
              transform: [{rotate: '-90deg'}],
              tintColor: '#047FFF',
            }}
            resizeMode="contain"
          />
        </TouchableOpacity>
      ) : null}
      <Text
        style={{
          fontFamily: FONTS?.SemiBold,
          fontSize: ms(15),
          color: COLORS?.black,
          alignSelf: 'center',
        }}>
        {label}
      </Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: ms(10),
        }}>
        {searchOptionPresent ? (
          <TouchableOpacity
            onPress={() => {}}
            style={[
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                borderColor: 'rgba(0, 0, 0, 0.08)',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            <Image
              source={ICONS.search}
              style={[
                {tintColor: COLORS?.black, height: ms(15), width: ms(15)},
              ]}
            />
          </TouchableOpacity>
        ) : null}
        {tickOptionPresent ? (
          <TouchableOpacity
            onPress={() => {}}
            style={[
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                borderColor: 'rgba(0, 0, 0, 0.08)',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            <Image
              source={ICONS.tickBox}
              style={[
                {tintColor: COLORS?.black, height: ms(15), width: ms(15)},
              ]}
            />
          </TouchableOpacity>
        ) : null}
        {addMoreOptionPresent ? (
          <TouchableOpacity
            onPress={() => {
              // dispatch(logOutRequest());
              props.onPress()
            }}>
            <Image
              source={ICONS.addCircle}
              style={[{height: ms(30), width: ms(30)}]}
            />
          </TouchableOpacity>
        ) : null}
        {editOptionPresent ? (
          <TouchableOpacity
            onPress={() => {
              // dispatch(logOutRequest());
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Edit
            </Text>
          </TouchableOpacity>
        ) : null}
        {downloadPresent ? (
          <TouchableOpacity
            style={{
              height: ms(30),
              width: ms(30),
              borderRadius: ms(15),
              backgroundColor: COLORS?.themeColor,
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onPress={() => {
              // dispatch(logOutRequest());
            }}>
            <Image
              source={ICONS?.download}
              style={{height: ms(15), width: ms(15), tintColor: COLORS?.white}}
              resizeMode="contain"
            />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

DepthHeader.propTypes = {
  label: PropTypes.string,
  backButtonColor: PropTypes.string,
  logoutVisible: PropTypes.bool,
};
