import React, {memo} from 'react';
import {View, Text, Image, TouchableOpacity, Pressable} from 'react-native';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import normalize from '../utils/helpers/normalize';
import _ from 'lodash';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import Button from './Button';
import {ms, mvs} from '../utils/helpers/metric';

const DistributerMap = props => {
  function onPressCancel() {
    if (props.onPressCancel) {
      props.onPressCancel();
    }
  }

  function onCrossPress() {
    if (props.onCrossPress) {
      props.onCrossPress();
    }
  }

  return (
    <Modal
      isVisible={props.visible}
      backdropColor={COLORS.black}
      backdropOpacity={0.4}
      animationIn={'fadeIn'}
      animationOut={'fadeOut'}
      animationInTiming={300}
      animationOutTiming={300}
      backdropTransitionOutTiming={0}
      //   onBackdropPress={() => {
      //     onBackdropPress();
      //   }}
      //   onBackButtonPress={() => {
      //     onBackButtonPress();
      //   }}
      style={{
        margin: 0,
        marginRight: ms(25),
        marginBottom: mvs(30),
        alignSelf: 'flex-end',
        justifyContent: 'flex-end',
        width: '60%',
      }}>
      <Pressable onPress={() => props.onCrossPress()}>
        <Image
          source={ICONS.close}
          style={{
            height: ms(20),
            width: ms(20),
            alignSelf: 'center',
            marginBottom: mvs(20),
          }}
        />
      </Pressable>
      <View
        style={{
          //height: normalize(190),
          paddingVertical: ms(30),
          backgroundColor: COLORS.green,
          borderRadius: ms(10),
          alignItems: 'center',
        }}>
        <View
          style={{
            backgroundColor: COLORS.white,
            height: ms(50),
            width: ms(50),
            borderRadius: ms(25),
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            style={{
              height: ms(25),
              width: ms(25),
              alignSelf: 'center',
            }}
            source={ICONS.connection}
          />
        </View>
        <Text
          style={{
            color: COLORS.black,
            fontFamily: FONTS.Inter_SemiBold,
            fontSize: ms(15),
            textAlign: 'center',
            marginTop: mvs(10),
          }}>
          No distributor found
        </Text>
        <Text
          style={{
            color: COLORS.black,
            fontFamily: FONTS.Inter_Regular,
            fontSize: ms(13),
            marginTop: mvs(5),
            textAlign: 'center',
            lineHeight: mvs(19),
          }}>
          Would you like to map your{'\n'}distributor?
          {/* Are you sure want to logout? */}
        </Text>

        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => props.onPressStartMaping()}
          style={{
            paddingHorizontal: ms(30),
            paddingVertical: mvs(10),
            borderWidth: 1,
            borderColor: '#03C988',
            borderRadius: ms(20),
            backgroundColor: COLORS.white,
            marginTop: mvs(20),
          }}>
          <Text
            style={{
              color: COLORS.black,
              fontFamily: FONTS.Inter_Medium,
              fontSize: ms(11),
            }}>
            START MAPPING
          </Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

export default memo(DistributerMap);

DistributerMap.propTypes = {
  visible: PropTypes.bool,
  title: PropTypes.string,
  message: PropTypes.string,
  onPressStartMaping: PropTypes.func,
  onCrossPress: PropTypes.func,
  onPressCancel: PropTypes.func,
  isCancelVisible: PropTypes.bool,
  ok_button_title: PropTypes.string,
};

DistributerMap.defaultProps = {
  visible: false,
  onPressCross: false,
  title: '',
  message: '',
  onCrossPress: () => {},
  onPressStartMaping: () => {},
  onPressCancel: () => {},
  isCancelVisible: true,
  ok_button_title: 'OK',
};
