import React from 'react';
import {Text, TouchableOpacity, View, Image, Dimensions} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../themes/Themes';
import PropTypes from 'prop-types';
import {ms, mvs} from '../utils/helpers/metric';
import {useDispatch, useSelector} from 'react-redux';
import {goBack} from '../utils/helpers/RootNaivgation';

export default function FormHeader(props) {
  const {
    label = '',
    searchOptionPresent = true,
    tickOptionPresent = true,
    addMoreOptionPresent = true,
    isBackPresent = false,
    isSavePresent = true,
    isMinimizePresent = false,
    onSave = () => {},
  } = props;
  const dispatch = useDispatch();
  return (
    <View
      style={{
        width: Dimensions?.get('window')?.width,
        height: ms(50),
        backgroundColor: COLORS?.white,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: ms(20),
        borderTopWidth: ms(1),
        borderBottomWidth: ms(1),
        borderColor: 'rgba(229, 231, 235, 1)',
      }}>
      {isBackPresent ? (
        <TouchableOpacity
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: ms(10),
          }}
          onPress={() => {
            goBack();
          }}>
          <Image
            source={ICONS?.upArrow}
            style={{
              height: ms(15),
              width: ms(15),
              transform: [{rotate: '-90deg'}],
              tintColor: COLORS?.themeColor,
            }}
            resizeMode="contain"
          />
          <Text
            style={{
              fontFamily: FONTS?.SemiBold,
              fontSize: ms(15),
              color: COLORS?.black,
              alignSelf: 'center',
            }}>
            {label}
          </Text>
        </TouchableOpacity>
      ) : null}
      {isSavePresent ? (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: ms(10),
          }}>
          {isMinimizePresent ? (
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.minimize}
              />
              <View
                style={{
                  height: ms(44),
                  width: 1,
                  backgroundColor: '#E5E7EB',
                  marginLeft: ms(8),
                }}
              />
            </View>
          ) : null}
          <TouchableOpacity
            onPress={() => {
              onSave();
            }}>
            <Text
              style={{
                fontFamily: FONTS?.SemiBold,
                fontSize: ms(15),
                color: COLORS?.themeColor,
                alignSelf: 'center',
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      ) : null}
    </View>
  );
}

FormHeader.propTypes = {
  label: PropTypes.string,
  backButtonColor: PropTypes.string,
  logoutVisible: PropTypes.bool,
  isSavePresent: PropTypes.bool,
  isMinimizePresent: PropTypes.bool,
  onSave: PropTypes.func,
};
