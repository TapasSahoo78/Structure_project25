import {Dimensions, Linking, PermissionsAndroid} from 'react-native';
import Geolocation from '@react-native-community/geolocation';
import Geolocations from 'react-native-geolocation-service';
import Toast from '../utils/helpers/Toast';
import {useEffect} from 'react';
const {width, height} = Dimensions.get('window');

function directionMaps(
  current_lat,
  current_long,
  destinationlat,
  destinationLong,
) {
  Linking.openURL(
    `http://maps.google.com/maps?saddr=${parseFloat(current_lat)},${parseFloat(
      current_long,
    )}&daddr=${parseFloat(destinationlat)},${parseFloat(destinationLong)}
`,
  );
}

function getLocationforAndroid(destinationlat, destinationLong) {
  Geolocations.getCurrentPosition(
    position => {
      console.log(position);
      // setinitialRegion({
      //   latitude: position.coords.latitude,
      //   longitude: position.coords.longitude,
      //   // latitude: 22.572646,
      //   // longitude: 88.36389500000001,
      //   latitudeDelta: 0.0922,
      //   longitudeDelta: 0.0421,
      // });
      directionMaps(
        position.coords.latitude,
        position.coords.longitude,
        destinationlat,
        destinationLong,
      );

      // setinitalLatLong({
      //   // latitude: -33.86514,
      //   // longitude: 151.2092,
      //   latitude: position.coords.latitude,
      //   longitude: position.coords.longitude,
      // });
    },
    error => {
      console.log(error);
    },
    {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 3600000,
    },
  );
}

function getLocationForIOS(destinationlat, destinationLong) {
  Geolocation.getCurrentPosition(
    position => {
      directionMaps(
        position.coords.latitude,
        position.coords.longitude,
        destinationlat,
        destinationLong,
      );

      console.log(position);
    },
    error => {
      console.log(error);
      // if (Platform.OS != 'ios') {
      //   Toast('Getting error in GPS. Please turn on your GPS!');
      // }
      // console.log(error?.code, error?.message);
      //console.log(error);
      //setLoading(false);
      //getLocation();
      // setLoading(false);
      //setHasLocationPermission(false);
    },
    {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 3600000,
    },
  );
}
export default async function GetCurrentLocation(
  destinationlat,
  destinationLong,
) {
  try {
    if (Platform.OS == 'android') {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      );
      //console.log(granted, PermissionsAndroid.RESULTS.GRANTED);
      if (granted == PermissionsAndroid.RESULTS.GRANTED) {
        getLocationforAndroid(destinationlat, destinationLong); // location for android
      } else {
        // locAccess()
        Toast('Location permission denied!');
      }
      //setLoading(false);
      //setHasLocationPermission(false);
      //}
    } else {
      getLocationForIOS(destinationlat, destinationLong); // location for IOS
    }
  } catch (err) {
    //setLoading(false);
    console.log(err);
  }
}
