import React, { useState, useEffect } from 'react';
import {
  Text,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Pressable,
  Dimensions,
  //Modal,
  Button,
  FlatList,
  TextInput,
  Platform,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import { goBack, navigate } from '../utils/helpers/RootNaivgation';
import PropTypes from 'prop-types';
import { ms, mvs } from '../utils/helpers/metric';
import { useDispatch, useSelector } from 'react-redux';
import { logOutRequest } from '../redux/reducer/ProfileReducer';
import Modal from 'react-native-modal';
import {
  addTaxCurrencyRequest,
  getProfileRequest,
} from '../redux/reducer/ProfileReducer';
import { isTablet } from 'react-native-device-info';
import IsEmpty from '../utils/helpers/IsEmpty';

export default function Header(props) {
  useEffect(() => {
    getProfile();
  }, []);

  const { commonList } = useSelector(state => state.ProfileReducer);
  const profileDetailsRes = useSelector(
    state => state.ProfileReducer?.profileResponse,
  );
  console.log('...pro', JSON.stringify(profileDetailsRes));
  const [modalVisible, setModalVisible] = useState(false);
  const [languageModal, setLanguageModal] = useState(false);
  const [languageId, setLanguageId] = useState('profileDetailsRes');
  const [languages, setLanguages] = useState([]);
  const [searchedText, setSerachedText] = useState('');
  const {
    backVisible = true,
    onPressRightIcon1 = () => navigate('Notification'),
    onPressLeftIcon = () => navigate('AccountSettings'),
    backgroundColor = 'rgb(232, 243, 255)',
    notificationVisible = true,
    searchVisible = true,
    settingsVisible = true,
    label = '',
    onPressSettings = () => setModalVisible(true),
  } = props;
  const dispatch = useDispatch();
  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };
  const renderItemseparator = () => {
    return (
      <View
        style={{
          height: ms(1),
          width: '100%',
          marginVertical: ms(10),
          backgroundColor: COLORS.border,
        }}
      />
    );
  };
  useEffect(() => {
    setLanguages(commonList?.languageLists);
  }, [commonList]);
  const getProfile = () => {
    let payload = {};
    dispatch(getProfileRequest(payload));
  };
  const callUpdateProfile = id => {
    //let url = `clients/update-profile`
    let payload = {
      languageId: id,
    };
    dispatch(addTaxCurrencyRequest(payload));
  };

  const formatNameToInitials = name => {
    // Split the name into words
    const words = name.split(' ', 2);

    // Extract the first letter of each word and convert to uppercase
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');

    return initials;
  };

  const handleSearch = text => {
    if (text !== '') {
      setSerachedText(text);
      const filteredData = languages.filter(contact => {
        return contact?.language?.toLowerCase()?.includes(text?.toLowerCase());
      });
      setLanguages(filteredData);
    } else {
      setSerachedText('');
      setLanguages(commonList?.languageLists);
    }
  };
  return (
    <View
      style={[
        styles.main,
        {
          justifyContent: 'space-between',
          backgroundColor: backgroundColor,
          paddingTop: ms(30),
          paddingBottom: ms(30),
        },
      ]}>
      {backVisible ? (
        <TouchableOpacity
          activeOpacity={0.7}
          style={styles.back}
          onPress={() => {
            goBack();
          }}>
          <Image
            source={ICONS?.back}
            style={{ height: ms(20), width: ms(20) }}
            resizeMode="contain"
          />
          <Text style={styles.backText}>{label}</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          style={{ flexDirection: 'row' }}
          onPress={onPressLeftIcon}>
          {/* <Image
          source={ICONS.profile}
          resizeMode="contain"
          style={{
            height: ms(35),
            width: ms(35),
          }}
        /> */}
          {!IsEmpty(profileDetailsRes?.name) &&
            IsEmpty(profileDetailsRes?.profileImage) ? (
            <View
              style={{
                height: ms(32),
                width: ms(32),
                borderRadius: ms(16),
                justifyContent: 'center',
                alignItems: 'center',
                //backgroundColor: COLORS.themeColor,
                backgroundColor: '#44BBFE',
              }}>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: COLORS.white,
                }}>
                {formatNameToInitials(profileDetailsRes?.name)}
              </Text>
            </View>
          ) : !IsEmpty(profileDetailsRes?.profileImage) ? (
            <View
              style={{
                height: ms(32),
                width: ms(32),
                borderRadius: ms(16),
                justifyContent: 'center',
                alignItems: 'center',
                //backgroundColor: COLORS.themeColor,
                backgroundColor: '#44BBFE',
              }}>
              <Image
                source={{ uri: profileDetailsRes?.profileImage }}
                style={{ height: ms(32), width: ms(32), borderRadius: ms(16) }}
              />
            </View>
          ) : null}

          <View style={{ marginLeft: ms(10), justifyContent: 'center' }}>
            <Text style={{ fontSize: ms(12), fontFamily: FONTS?.Regular }}>
              Welcome Back!
            </Text>
            <Text
              style={{
                fontSize: ms(14),
                fontFamily: FONTS?.Bold,
                textTransform: 'capitalize',
                marginTop: Platform.OS == 'android' ? -ms(6) : ms(-2),
              }}>
              {profileDetailsRes?.name}
            </Text>
          </View>
        </TouchableOpacity>
      )}
      <View style={{ flexDirection: 'row', gap: ms(5) }}>
        {searchVisible ? (
          <TouchableOpacity
            onPress={() => {
              // dispatch(logOutRequest());
            }}
            style={[
              styles.headerLogoContainer,
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#dde5ea',
              },
            ]}>
            <Image
              source={ICONS.search}
              resizeMode="contain"
              style={[{ tintColor: '#344054', height: ms(16), width: ms(16) }]}
            />
          </TouchableOpacity>
        ) : null}
        {notificationVisible ? (
          <TouchableOpacity
            onPress={() => {
              // dispatch(logOutRequest());
            }}
            style={[
              styles.headerLogoContainer,
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#dde5ea',
              },
            ]}>
            <Image
              source={ICONS.notification}
              resizeMode="contain"
              style={[{ height: ms(19.2), width: ms(19.2) }]}
            />
          </TouchableOpacity>
        ) : null}
        {settingsVisible ? (
          <TouchableOpacity
            onPress={() => {
              // dispatch(logOutRequest());
              setModalVisible(true);
            }}
            style={[
              styles.headerLogoContainer,
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#dde5ea',
              },
            ]}>
            <Image
              source={ICONS.settings}
              resizeMode="contain"
              style={[
                { tintColor: modalVisible ? COLORS.themeColor : COLORS?.black, height: ms(18), width: ms(18) },
              ]}
            />
          </TouchableOpacity>
        ) : null}
      </View>

      {/* <TouchableOpacity style={styles.button} onPress={toggleModal}>
        <Text style={styles.buttonText}>Open Modal</Text>
      </TouchableOpacity> */}

      <Modal
        //animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={toggleModal}
        onBackdropPress={() => setModalVisible(false)} // For Android back button
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {/* <View
              style={{
                height: ms(40),
                width: ms(40),
                backgroundColor: COLORS?.white,
                position: 'absolute',
                top: isTablet ? -ms(40) : -ms(50),
                right: ms(0),
                borderWidth: 0.3,
                borderBottomWidth: ms(0),
                borderColor: COLORS?.themeColor,
                borderTopLeftRadius: ms(20),
                borderTopRightRadius: ms(20),
              }}>
              <Image
                source={ICONS?.settings}
                style={{
                  height: ms(20),
                  width: ms(20),
                  alignSelf: 'center',
                  tintColor: COLORS?.themeColor,
                  marginTop: ms(15),
                }}
              />
            </View> */}
            {/* <View style={{flexDirection:'row',alignItems:'center'}}>
              <Image resizeMode='contain' style={{height:ms(12),width:ms(11)}} source={ICONS.language}/>
            <Text
              onPress={() => {
                toggleModal();
                setLanguageModal(true);
              }}
              style={styles.modalText}>
              Language
            </Text>
            </View> */}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                gap: ms(10),
              }}>
              <Image
                resizeMode="contain"
                style={{ height: ms(12), width: ms(10) }}
                source={ICONS.currency}
              />
              <Text
                onPress={() => {
                  toggleModal();
                  navigate('TaxCurrency');
                }}
                style={styles.modalText}>
                Tax & Currency
              </Text>
            </View>
            <View
              style={{
                height: normalize(1),
                width: '100%',
                backgroundColor: COLORS.border,
                marginVertical: normalize(10),
              }}
            />
            {/* <View style={{flexDirection:'row',alignItems:'center'}}>
              <Image resizeMode='contain' style={{height:ms(12),width:ms(10)}} source={ICONS.security}/>
            <Text onPress={() => toggleModal()} style={styles.modalText}>
              Security
            </Text>
            </View> */}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                gap: ms(10),
              }}>
              <Image
                resizeMode="contain"
                style={{ height: ms(12), width: ms(11) }}
                source={ICONS.language}
              />
              <Text
                onPress={() => {
                  toggleModal();
                  setLanguageModal(true);
                }}
                style={styles.modalText}>
                Language
              </Text>
            </View>
            <View
              style={{
                height: normalize(1),
                width: '100%',
                backgroundColor: COLORS.border,
                marginVertical: normalize(10),
              }}
            />
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                gap: ms(10),
              }}>
              <Image
                resizeMode="contain"
                style={{ height: ms(12), width: ms(10) }}
                source={ICONS.security}
              />
              <Text onPress={() => toggleModal()} style={styles.modalText}>
                Security
              </Text>
            </View>
            {/* <View style={{flexDirection:'row',alignItems:'center'}}>
              <Image resizeMode='contain' style={{height:ms(12),width:ms(10)}} source={ICONS.currency}/>
            <Text
              onPress={() => {
                toggleModal();
                navigate('TaxCurrency');
              }}
              style={styles.modalText}>
              Tax & Currency
            </Text>
            </View> */}
          </View>
        </View>
      </Modal>
      <Modal
        isVisible={languageModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setLanguageModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.6,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setLanguageModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Language
            </Text>
          </View>

          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={searchedText}
              onChangeText={text => handleSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{ height: normalize(14), width: normalize(14) }}
              source={ICONS.search}
            />
          </View>

          <FlatList
            data={languages}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              //console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    // borderBottomWidth: normalize(0),
                    // borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    //marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    //console.log('itemaaa', item);
                    //alert(item?.id)
                    setLanguageId(item?.id);
                    callUpdateProfile(item?.id);

                    setLanguageModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS?.Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                      fontSize: ms(12),
                    }}>
                    {item?.language}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    flexDirection: 'row',
    padding: ms(15),
    height: mvs(70),
    alignItems: 'center',
    width: Dimensions?.get('window')?.width,
    marginTop: 'auto',
    //paddingTop:ms(40)
  },
  profilePic: {
    height: ms(20),
    width: ms(20),
    marginRight: ms(10),
  },
  profileView: {
    width: '100%',
    flexDirection: 'row',
    paddingVertical: mvs(20),
    backgroundColor: COLORS.light_sky,
    alignItems: 'center',
    paddingLeft: ms(15),
    borderBottomWidth: 0.5,
    borderBottomColor: COLORS.white,
    // elevation: 10,
    // shadowColor: COLORS.PrimaryBg,
    // shadowOpacity: 0.2,
    // shadowRadius: 2.0,
    // shadowOffset: {width: 3, height: 0},
  },
  crossButton: {
    position: 'absolute',
    top: normalize(10),
    right: normalize(10),
    zIndex: 10,
  },
  bottomButton: {
    marginBottom: normalize(10),
  },
  customRatingBarStyle: {
    flexDirection: 'row',
    marginTop: normalize(0),
    alignItems: 'center',
  },
  starImageStyle: {
    width: normalize(10),
    height: normalize(10),
    resizeMode: 'contain',
    marginLeft: normalize(3),
  },
  iconStyle: {
    height: normalize(20),
    width: normalize(20),
    resizeMode: 'contain',
  },
  headerLogoContainer: {
    height: ms(25),
    width: ms(21),
    marginLeft: ms(5),
  },
  headerLogo: {
    height: '100%',
    width: '100%',
    resizeMode: 'center',
  },
  backText: {
    fontFamily: FONTS?.Bold,
    fontSize: ms(15),
    color: COLORS?.white,
  },
  back: {
    // height: ms(30),
    // width: ms(30),
    // borderRadius: ms(15),
    // backgroundColor: COLORS?.white,
    // elevation: ms(5),
    // margin: ms(20),
    // alignItems: 'center',
    // justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: ms(10),
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
  },
  modalContent: {
    // width: 270,
    paddingVertical: 20,
    paddingHorizontal: ms(5),
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    // borderTopLeftRadius: 10,
    // borderBottomLeftRadius: 10,
    // borderBottomRightRadius: 10,
    //alignItems: 'center',
    position: 'absolute',
    top: 38,
    //right: isTablet ? -18 :-5,
    right: 1,
    borderWidth: 0.3,
    borderColor: COLORS.themeColor,
    width: ms(150),
    // elevation:3,
    // shadowColor:COLORS.themeColor,
    // zIndex: 1
    //shadowColor:COLORS.themeColor
  },
  modalText: {
    //marginBottom: 15,
    textAlign: 'center',
    fontSize: ms(13),
    fontFamily: FONTS.Medium,
    //marginLeft:ms(10)
  },
});

Header.propTypes = {
  label: PropTypes.string,
  type: PropTypes.string,
  title: PropTypes.string,
  rightVisible: PropTypes.bool,
  rightIcon1: PropTypes.bool,
  rightIcon2: PropTypes.bool,
  rightIcon1Img: PropTypes.string,
  rightView: PropTypes.any,
  backVisible: PropTypes.bool,
  onPressBack: PropTypes.func,
  onPressRightIcon1: PropTypes.func,
  onPressLeftIcon: PropTypes.func,
  creditAmount: PropTypes.string,
  serviceIconUri: PropTypes.any,
  backgroundColor: PropTypes.any,
  leftIconTintColor: PropTypes.string,
  backButtonColor: PropTypes.string,
  logoutVisible: PropTypes.bool,
  onPressSettings: PropTypes.func,
};
