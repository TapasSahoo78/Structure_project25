import React from 'react';
import {Dimensions, ImageBackground, View} from 'react-native';
import {COLORS, IMAGES} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import {ms} from '../utils/helpers/metric';

export default function ItemSeparator() {
  return (
    <View
      style={{
        height: ms(0.5),
        backgroundColor: '#dddddd',
        // width: '100%',
        //marginVertical: normalize(15),
        //alignSelf: 'center',
      }}
    />
  );
}
