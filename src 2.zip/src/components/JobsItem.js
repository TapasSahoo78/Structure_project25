import React from 'react';
import {
  Text,
  StyleSheet,
  TouchableOpacity,
  View,
  Linking,
  Dimensions,
  Image,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
import {goBack} from '../utils/helpers/RootNaivgation';
import PropTypes from 'prop-types';
import Button from './Button';
import Geolocation from '@react-native-community/geolocation';
import Geolocations from 'react-native-geolocation-service';
import Toast from '../utils/helpers/Toast';
const {width, height} = Dimensions.get('window');

export default function JobsItem(props) {
  function directionMaps(current_lat, current_long) {
    Linking.openURL(
      `http://maps.google.com/maps?saddr=${parseFloat(
        current_lat,
      )},${parseFloat(current_long)}&daddr=${parseFloat(
        props.destinationlat,
      )},${parseFloat(props.destinationLong)}
`,
    );
  }

  async function onPressDirection() {
    try {
      if (Platform.OS == 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        );
        //console.log(granted, PermissionsAndroid.RESULTS.GRANTED);
        if (granted == PermissionsAndroid.RESULTS.GRANTED) {
          getLocationforAndroid(); // location for android
        } else {
          // locAccess()
          Toast('Location permission denied!');
        }
        //setLoading(false);
        //setHasLocationPermission(false);
        //}
      } else {
        getLocationForIOS(); // location for IOS
      }
    } catch (err) {
      //setLoading(false);
      console.log(err);
    }
  }

  function getLocationforAndroid() {
    Geolocations.getCurrentPosition(
      position => {
        console.log(position);
        // setinitialRegion({
        //   latitude: position.coords.latitude,
        //   longitude: position.coords.longitude,
        //   // latitude: 22.572646,
        //   // longitude: 88.36389500000001,
        //   latitudeDelta: 0.0922,
        //   longitudeDelta: 0.0421,
        // });
        directionMaps(position.coords.latitude, position.coords.longitude);

        // setinitalLatLong({
        //   // latitude: -33.86514,
        //   // longitude: 151.2092,
        //   latitude: position.coords.latitude,
        //   longitude: position.coords.longitude,
        // });
      },
      error => {
        console.log(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 3600000,
      },
    );
  }

  function getLocationForIOS() {
    Geolocation.getCurrentPosition(
      position => {
        directionMaps(position.coords.latitude, position.coords.longitude);

        console.log(position);
      },
      error => {
        console.log(error);
        // if (Platform.OS != 'ios') {
        //   Toast('Getting error in GPS. Please turn on your GPS!');
        // }
        // console.log(error?.code, error?.message);
        //console.log(error);
        //setLoading(false);
        //getLocation();
        // setLoading(false);
        //setHasLocationPermission(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 3600000,
      },
    );
  }

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      disabled={props.disabled}
      onPress={() => props.onPress()}
      style={[
        styles.container,
        {
          marginRight: props.marginRight,
          marginBottom: props.marginBottom,
          width: props.width,
          backgroundColor: props.backgroundColor,
          marginTop: props.marginTop,
          ...props.containerStyle,
        },
      ]}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <Text style={[styles.topText1, {fontSize: props.timeFontSize}]}>
          {props.time}
        </Text>
        {props?.jobStatus != '' && (
          <View style={styles.timer}>
            {/* <Image source={ICONS.clock} style={styles.icon} /> */}
            <Text style={styles.timerText}>{props?.jobStatus}</Text>
          </View>
        )}
      </View>

      {props.person != '' ? (
        <Text style={[styles.topText1, {fontSize: props.personNameFontSize}]}>
          {props.person}
        </Text>
      ) : null}

      <Text style={[styles.topText2, {marginTop: normalize(5)}]}>
        {props.address}
      </Text>
      {props.credits != '' && (
        <Text style={[styles.topText2, {marginTop: normalize(10)}]}>
          {props.credits}
        </Text>
      )}
      {props.buttonVisible && (
        <View
          style={{
            flexDirection: 'row',
            marginTop: normalize(10),
            width: '80%',
          }}>
          {props.callButtonVisible && (
            <Button
              width={width * 0.3}
              lefticonVisible
              lefticon={ICONS.call}
              title={'Call Now'}
              borderWidth={1}
              borderColor={COLORS.blue}
              backgroundColor={COLORS.white}
              textColor={COLORS.textColor}
              height={normalize(32)}
              fontSize={normalize(9)}
              leftIconTintColor={null}
              marginRight={normalize(10)}
              onPress={() => Linking.openURL(`tel:${props.mobile_no}`)}
            />
          )}
          <Button
            width={width * 0.3}
            lefticonVisible
            onPress={() => onPressDirection()}
            lefticon={ICONS.navigate}
            title={'Direction'}
            borderWidth={1}
            borderColor={COLORS.blue}
            backgroundColor={COLORS.white}
            textColor={COLORS.textColor}
            height={normalize(32)}
            fontSize={normalize(9)}
            leftIconTintColor={null}
          />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingLeft: normalize(15),
    paddingVertical: normalize(15),
    //marginBottom: normalize(10),
    borderRadius: normalize(10),
  },
  topText1: {
    color: '#363D4E',
    fontFamily: FONTS.Poppins_Bold,
  },
  topText2: {
    fontSize: normalize(10),
    lineHeight: normalize(17),
    width: '90%',
    color: COLORS.textColor,
    fontFamily: FONTS.Poppins_Regular,
  },
  timer: {
    backgroundColor: COLORS.light_sky,
    paddingHorizontal: normalize(5),
    paddingVertical: normalize(2),
    alignItems: 'center',
    borderRadius: normalize(2),
  },
  icon: {
    height: normalize(12),
    width: normalize(12),
  },
  timerText: {
    //fontFamily: FONTS.Poppins_SemiBold,
    fontWeight: '700',
    color: COLORS.black,
  },
});

JobsItem.propTypes = {
  time: PropTypes.string,
  address: PropTypes.string,
  credits: PropTypes.bool,
  onPress: PropTypes.bool,
  marginBottom: PropTypes.number,
  marginRight: PropTypes.number,
  width: PropTypes.any,
  backgroundColor: PropTypes.string,
  buttonVisible: PropTypes.bool,
  marginTop: PropTypes.number,
  person: PropTypes.string,
  personNameFontSize: PropTypes.number,
  timeFontSize: PropTypes.number,
  containerStyle: PropTypes.any,
  callButtonVisible: PropTypes.bool,
  mobile_no: PropTypes.any,
  timer: PropTypes.any,
  disabled: PropTypes.bool,
  destinationlat: PropTypes.any,
  destinationLong: PropTypes.any,
  jobStatus: PropTypes.any,
};
JobsItem.defaultProps = {
  time: '',
  address: '',
  credits: '',
  timer: null,
  marginBottom: 0,
  marginRight: 0,
  width: '100%',
  backgroundColor: '#EEFFDE',
  buttonVisible: false,
  marginTop: 0,
  person: '',
  personNameFontSize: normalize(10),
  timeFontSize: normalize(12),
  callButtonVisible: true,
  mobile_no: null,
  onPress: () => {},
  containerStyle: {},
  disabled: false,
  destinationlat: null,
  destinationLong: null,
  jobStatus: '',
};
