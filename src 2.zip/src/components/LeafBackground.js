import React from 'react';
import {Image, View} from 'react-native';
import {COLORS, ICONS, IMAGES} from '../themes/Themes';
import {ms} from '../utils/helpers/metric';

export default function LeafBackground() {
  return (
    <Image
      source={ICONS.leaf}
      style={{
        height: ms(350),
        width: ms(220),
        position: 'absolute',
        bottom: 0,
        zIndex: -40,
        left: 0,
        resizeMode: 'contain',
      }}
    />
  );
}
