import React from 'react';
import {Text, TouchableOpacity, View, Image, Dimensions} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../themes/Themes';
import PropTypes from 'prop-types';
import {ms, mvs} from '../utils/helpers/metric';
import {useDispatch, useSelector} from 'react-redux';
import {navigate} from '../utils/helpers/RootNaivgation';

export default function MainHeader(props) {
  const {
    label = '',
    searchOptionPresent = true,
    tickOptionPresent = true,
    addMoreOptionPresent = true,
    isBackPresent = false,
    moreOptionPresent = () => {},
  } = props;
  const dispatch = useDispatch();
  return (
    <View
      style={{
        width: Dimensions?.get('window')?.width,
        height: ms(70),
        // backgroundColor: 'rgba(68, 187, 254, 0.4)',
        backgroundColor: '#dff4fe',
        // backgroundColor: 'rgba(68, 187, 254, 1)',
        // opacity: 0.1,
        borderBottomLeftRadius: ms(35),
        borderBottomRightRadius: ms(35),
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: ms(20),
      }}>
      {isBackPresent ? (
        <TouchableOpacity
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Image
            source={ICONS?.upArrow}
            style={{
              height: ms(15),
              width: ms(15),
              transform: [{rotate: '-90deg'}],
              tintColor: COLORS?.black,
            }}
            resizeMode="contain"
          />
        </TouchableOpacity>
      ) : null}
      <Text
        style={{
          fontFamily: FONTS?.Medium,
          fontSize: ms(18),
          color: 'rgba(52, 64, 84, 1)',
          alignSelf: 'center',
        }}>
        {label}
      </Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: ms(10),
        }}>
        {searchOptionPresent ? (
          <TouchableOpacity
            onPress={() => {}}
            style={[
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#dde5ea',
              },
            ]}>
            <Image
              source={ICONS.search}
              style={[{tintColor: '#344054', height: ms(14), width: ms(14)}]}
            />
          </TouchableOpacity>
        ) : null}
        {tickOptionPresent ? (
          <TouchableOpacity
            onPress={() => {}}
            style={[
              {
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                borderWidth: ms(0.7),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#dde5ea',
              },
            ]}>
            <Image
              source={ICONS.tickBox}
              style={[{tintColor: '#344054', height: ms(14), width: ms(14)}]}
            />
          </TouchableOpacity>
        ) : null}
        {addMoreOptionPresent ? (
          <TouchableOpacity
            onPress={() => {
              moreOptionPresent();
            }}>
            <Image
              resizeMode="contain"
              source={ICONS.addCircle}
              style={[{height: ms(30), width: ms(30)}]}
            />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

MainHeader.propTypes = {
  label: PropTypes.string,
  backButtonColor: PropTypes.string,
  logoutVisible: PropTypes.bool,
  moreOptionPresent: PropTypes.func,
};
