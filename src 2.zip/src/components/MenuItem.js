import React from 'react';
import {Text, StyleSheet, TouchableOpacity, Image, View} from 'react-native';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import normalize from '../utils/helpers/normalize';
const MenuItem = ({
  title,
  action,
  icon,
  iconHeight,
  iconWidth,
  marginBottom,
  whatsappIconVisible,
}) => {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={action}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        width: '95%',
        height: normalize(45),
        paddingLeft: normalize(15),
        paddingRight: normalize(8),
        justifyContent: 'space-between',
        backgroundColor: COLORS.white,
        marginTop: normalize(7),
        borderRadius: normalize(5),
        alignSelf: 'center',
        marginBottom: marginBottom,
        // borderBottomWidth: 0.5,
        //borderBottomColor: '#ACACAC',
      }}>
      {whatsappIconVisible && (
        <Image
          resizeMode="contain"
          style={{
            width: normalize(18),
            height: normalize(18),
            tintColor: COLORS.green,
          }}
          source={ICONS.whatsapp}
        />
      )}
      <Text
        style={{
          fontSize: normalize(12),
          fontFamily: FONTS.Poppins_SemiBold,
          color: '#363D4E',
          //marginLeft: normalize(12),
        }}>
        {title}
      </Text>
      <Image
        resizeMode="contain"
        style={{
          width: normalize(10),
          height: normalize(10),
          tintColor: '#ACACAC',
        }}
        source={ICONS.rightArrow}
      />
    </TouchableOpacity>
  );
};

export default MenuItem;
MenuItem.defaultProps = {
  title: '',
  icon: '',
  iconHeight: normalize(18),
  iconWidth: normalize(18),
  action: () => {},
  marginBottom: 0,
  whatsappIconVisible: false,
};
