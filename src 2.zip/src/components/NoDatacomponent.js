import React from 'react';
import {SafeAreaView, Text, Image, TouchableOpacity} from 'react-native';
import {ICONS, FONTS, COLORS} from '../themes/Themes';
import PropTypes from 'prop-types';
import {ms, mvs} from '../utils/helpers/metric';

export default function NoDataComponent(props) {
  const {
    message = '',
    textColor = COLORS.black,
    marginTop = ms(10),
    image = ICONS.emptyData,
    buttonText = '',
    onPressButton = () => {},
    buttonVisible = false,
  } = props;
  return (
    <SafeAreaView
      style={{
        marginTop: '20%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: COLORS.white,
        paddingVertical: mvs(40),
        borderRadius: ms(12),
        marginHorizontal: ms(15),
      }}>
      {/* {props.showImage && ( */}
      <Image
        style={{
          height: ms(150),
          width: ms(150),
          // tintColor: tintColor,
        }}
        source={image}
        resizeMode={'contain'}
      />
      {/* )} */}

      <Text
        style={{
          marginTop: marginTop,
          fontSize: ms(18),
          color: textColor,
          textAlign: 'center',
          width: '80%',
          fontFamily: FONTS.Inter_Bold,
          marginHorizontal: ms(40),
        }}>
        {message}
      </Text>

      {buttonVisible ? (
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => onPressButton()}
          style={{
            paddingHorizontal: ms(50),
            paddingVertical: mvs(10),
            borderWidth: 1,
            borderColor: '#03C988',
            borderRadius: ms(20),
            backgroundColor: COLORS.white,
            marginTop: mvs(20),
          }}>
          <Text
            style={{
              color: COLORS.black,
              fontFamily: FONTS.Inter_Medium,
              fontSize: ms(12),
            }}>
            {buttonText}
          </Text>
        </TouchableOpacity>
      ) : null}
    </SafeAreaView>
  );
}

NoDataComponent.propTypes = {
  message: PropTypes.string,
  image: PropTypes.any,
  showImage: PropTypes.bool,
  imageheight: PropTypes.number,
  imageWidth: PropTypes.number,
  tintColor: PropTypes.string,
  textColor: PropTypes.string,
  fontSize: PropTypes.number,
  marginTop: PropTypes.number,
  buttonText: PropTypes.string,
  onPressButton: PropTypes.func,
  buttonVisible: PropTypes.bool,
};
