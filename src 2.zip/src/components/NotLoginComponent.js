import {Image, SafeAreaView, StyleSheet, Text} from 'react-native';
import Button from './Button';
import normalize from '../utils/helpers/normalize';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import PropTypes from 'prop-types';
export default function NotLoginComponent(props) {
  return (
    <SafeAreaView
      style={{
        flex: 1,
        // backgroundColor: COLORS.white,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:props.marginTop
      }}>
      <Image
        source={props.image}
        style={styles.imageStyle}
        resizeMode="contain"
      />
      {props.title &&<Text style={styles.title}>{props.title}</Text>}
      {props.desc &&<Text style={styles.desc}>{props.desc}</Text>}
      <Button
        title={props.buttonTitle}
        width={'90%'}
        height={normalize(42)}
        marginTop={normalize(10)}
        letterSpacing={normalize(1)}
        onPress={() => props.onPress()}
        backgroundColor={'transparent'}
        borderColor={COLORS.light_sky}
        borderWidth={1}
        textColor={COLORS.black}
        borderRadius={normalize(8)}
      />
    </SafeAreaView>
  );
}

NotLoginComponent.propTypes = {
  image: PropTypes.any,
  title: PropTypes.string,
  desc: PropTypes.string,
  buttonTitle: PropTypes.string,
  onPress: PropTypes.func,
  marginTop:PropTypes.number
};

NotLoginComponent.defaultProps = {
  image: '',
  title: '',
  desc: '',
  buttonTitle: '',
  marginTop:0,
  onPress: () => {},
};

const styles = StyleSheet.create({
  imageStyle: {
    height: normalize(100),
    width: normalize(100),
  },
  title: {
    color: COLORS.black,
    fontSize: normalize(17),
    fontFamily: FONTS.Poppins_SemiBold,
    marginTop: normalize(15),
  },
  desc: {
    color: COLORS.textColor,
    fontSize: normalize(14),
    fontFamily: FONTS.Poppins_Regular,
    marginTop: normalize(5),
    textAlign: 'center',
    marginHorizontal: normalize(20),
    lineHeight: normalize(23),
  },
});
