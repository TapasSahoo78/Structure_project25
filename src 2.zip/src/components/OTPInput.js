import React, {useRef, useState, useEffect} from 'react';
import {View, Text, Pressable, TextInput} from 'react-native';
import normalize from '../utils/helpers/normalize';
import {COLORS, FONTS} from '../themes/Themes';
import {ms} from '../utils/helpers/metric';

const OTPInput = ({code, setCode, maximumLength, setIsPinReady, style}) => {
  const boxArray = new Array(maximumLength).fill(0);
  const inputRef = useRef();

  const [isInputBoxFocused, setIsInputBoxFocused] = useState(false);

  const handleOnPress = () => {
    setIsInputBoxFocused(true);
    inputRef.current.focus();
  };

  const handleOnBlur = () => {
    setIsInputBoxFocused(false);
  };

  useEffect(() => {
    // update pin ready status
    setIsPinReady(code.length === maximumLength);
    // clean up function
    return () => {
      setIsPinReady(false);
    };
  }, [code]);

  const boxDigit = (_, index) => {
    const emptyInput = '';
    const digit = code[index] || emptyInput;

    const isCurrentValue = index === code.length;
    const isLastValue = index === maximumLength - 1;
    const isCodeComplete = code.length === maximumLength;

    const isValueFocused = isCurrentValue || (isLastValue && isCodeComplete);

    return (
      <View
        key={index}
        style={{
          height: normalize(70),
          width: normalize(66),
          borderWidth: 0.5,
          borderColor: COLORS?.themeColor,
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: normalize(10),
          backgroundColor: COLORS?.white,
          elevation: 5,
          shadowColor: 'rgba(4, 127, 255, 0.5)',
        }}>
        <Text
          style={{
            color: 'rgba(52, 64, 84, 0.5)',
            fontSize: normalize(22),
            fontFamily: FONTS.Regular,
            top: normalize(2),
          }}>
          {digit}
        </Text>
      </View>
    );
  };

  return (
    <View
      style={[
        {
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: COLORS.backgraound,
          // paddingHorizontal: normalize(24),
        },
        style,
      ]}>
      <Pressable
        style={{
          justifyContent: 'space-evenly',
          flexDirection: 'row',
          width: '100%',
          // paddingHorizontal: ms(10),
        }}
        onPress={handleOnPress}>
        {boxArray.map(boxDigit)}
      </Pressable>

      <TextInput
        value={code}
        onChangeText={setCode}
        maxLength={maximumLength}
        keyboardType="numeric"
        ref={inputRef}
        onBlur={handleOnBlur}
        style={{
          opacity: 1,
          position: 'absolute',

          height: 0,
          width: 0,
        }}
      />
    </View>
  );
};

export default OTPInput;
