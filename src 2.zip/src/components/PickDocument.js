import DocumentPicker from 'react-native-document-picker';
import React from 'react';
import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';
import Modal from 'react-native-modal';
import PropTypes from 'prop-types';
import {ICONS, COLORS, FONTS} from '../themes/Themes';
import {ms, mvs} from '../utils/helpers/metric';
import {launchCamera} from 'react-native-image-picker';
export default function PickDocument(props) {
  const {visible, onBackdropPress, onPressCamera, onPressGallery} = props;

  function onPressCameraIcon() {
    launchCamera({
      quality: 0.5,
      maxWidth: ms(500),
      maxHeight: ms(500),
    })
      .then(response => {
        console.log(response);
        let imageObj = {};
        imageObj.name = response.assets[0].uri.replace(/^.*[\\\/]/, '');
        imageObj.type = response.assets[0].type;
        imageObj.uri = response.assets[0].uri;
        console.log(imageObj);
        onPressCamera(imageObj);
        onBackdropPress();
      })
      .catch(err => console.log(err));
  }

  async function onPressGalleryIcon() {
    try {
      const pickerResult = await DocumentPicker.pickSingle({
        type: [
          // DocumentPicker.types.pdf,
          // DocumentPicker.types.doc,
          // DocumentPicker.types.docx,
          DocumentPicker.types.images,
        ],
      });

      //console.log(pickerResult);
      console.log('pickerResult: ', pickerResult);
      let obj = {
        name: pickerResult.name,
        type: pickerResult.type,
        uri: pickerResult.uri,
      };
      onPressGallery(obj);
      onBackdropPress();
      console.log(obj);
    } catch (error) {
      console.log(error);
      // reject(error);
    }
  }
  return (
    <Modal
      isVisible={visible}
      animationIn={'slideInUp'}
      animationOut={'slideOutDown'}
      animationInTiming={800}
      animationOutTiming={800}
      backdropTransitionOutTiming={0}
      onBackdropPress={onBackdropPress}
      onBackButtonPress={onBackdropPress}
      style={{margin: 0}}>
      <View style={styles.conntainer}>
        <Text style={styles.title}>Upload Document</Text>

        <View style={{flexDirection: 'row', justifyContent: 'space-evenly'}}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onPressCameraIcon}
            style={styles.button}>
            <Image
              source={ICONS.camera}
              resizeMode="contain"
              style={styles.icon}
            />
            <Text style={styles.buttonText}>Camera</Text>
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onPressGalleryIcon}
            style={styles.button}>
            <Image
              source={ICONS.gallery}
              resizeMode="contain"
              style={styles.icon}
            />
            <Text style={styles.buttonText}>Gallery</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

PickDocument.propTypes = {
  visible: PropTypes.bool,
  onBackdropPress: PropTypes.func,
  onPressCamera: PropTypes.func,
  onPressGallery: PropTypes.func,
  cropping: PropTypes.bool,
};

const styles = StyleSheet.create({
  conntainer: {
    height: ms(130),
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: COLORS.white,
    paddingVertical: mvs(20),
    borderTopLeftRadius: ms(15),
    borderTopRightRadius: ms(15),
  },
  button: {
    flexDirection: 'row',
    width: '43%',
    height: ms(45),
    borderRadius: ms(6),
    backgroundColor: COLORS.green,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: mvs(15),
  },
  icon: {
    height: ms(18),
    width: ms(18),
    tintColor: COLORS.black,
    marginRight: ms(18),
  },

  title: {
    fontFamily: FONTS.Inter_SemiBold,
    color: COLORS.black,
    fontSize: ms(18),
    marginBottom: mvs(2),
    textAlign: 'center',
  },
  buttonText: {
    color: COLORS.black,
    fontSize: ms(14),
    fontFamily: FONTS.Inter_SemiBold,
  },
  crossButton: {
    position: 'absolute',
    right: ms(15),
    top: -mvs(12),
    height: ms(30),
    width: ms(30),
    backgroundColor: COLORS.white,
    zIndex: 10,
    borderRadius: ms(15),
    alignItems: 'center',
    justifyContent: 'center',
  },
});
