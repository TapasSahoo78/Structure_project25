import React, {useState, useEffect, memo} from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import PropTypes from 'prop-types';
import normalize from '../utils/helpers/normalize';
import Modal from 'react-native-modal';
import {COLORS, FONTS, ICONS} from '../themes/Themes';
import {ms, mvs} from '../utils/helpers/metric';
import ItemSeparator from './ItemSeparator';
const {height, width} = Dimensions.get('screen');
const Picker = props => {
  const {
    dataList = [],
    title = '',
    isWallet = false,
    modalVisible = false,
    renderData = () => {},
    onBackdropPress = null,
    backgroundColor = COLORS.white,
    maxHeight = Platform.OS == 'ios' ? height / 1.9 : height / 1.8,
    keyExtractor = () => {},
  } = props;
  return (
    <SafeAreaView>
      <Modal
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        backdropTransitionOutTiming={0}
        hideModalContentWhileAnimating={true}
        isVisible={modalVisible}
        style={{
          // width: '100%',
          // alignSelf: 'center',
          margin: 0,
        }}
        animationInTiming={800}
        animationOutTiming={1000}
        backdropOpacity={0.7}
        backdropColor={COLORS.dark_grey}
        onBackButtonPress={() => onBackdropPress()}
        onBackdropPress={() => onBackdropPress()}>
        <View
          style={[
            {
              backgroundColor: backgroundColor,
              maxHeight: isWallet == true ? height / 1.5 : maxHeight,
              paddingBottom: mvs(15),

              // paddingTop: mvs(5),
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              zIndex: 10,
              borderTopLeftRadius: ms(15),
              borderTopRightRadius: ms(15),
            },
          ]}>
          {/* <TouchableOpacity
            activeOpacity={1}
            style={styles.crossButton}
            onPress={props.onBackdropPress}>
            <Image
              source={ICONS.remove}
              resizeMode="contain"
              style={{height: ms(18), width: ms(18)}}
            />
          </TouchableOpacity> */}

          <Text
            style={{
              color: COLORS.white,
              fontFamily: FONTS.Poppins_SemiBold,
              fontSize: ms(14),
              paddingVertical: mvs(14),
              paddingHorizontal: ms(20),
              backgroundColor: COLORS.deep_blue,
              borderTopLeftRadius: ms(15),
              borderTopRightRadius: ms(15),
              // textAlign: 'center',
              textAlignVertical: 'center',
            }}>
            {title}
          </Text>

          <FlatList
            data={dataList}
            showsVerticalScrollIndicator={false}
            keyExtractor={keyExtractor}
            renderItem={renderData}
            style={{marginTop: mvs(8)}}
            // ItemSeparatorComponent={ItemSeparator}
            bounces={false}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  crossButton: {
    position: 'absolute',
    right: ms(15),
    top: -ms(12),
    height: ms(30),
    width: ms(30),
    backgroundColor: COLORS.white,
    zIndex: 10,
    borderRadius: ms(15),
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default Picker;

Picker.propTypes = {
  dataList: PropTypes.array,
  modalVisible: PropTypes.bool,
  renderData: PropTypes.func,
  onBackdropPress: PropTypes.func,
  backgroundColor: PropTypes.string,
  height: PropTypes.number,
  search: PropTypes.bool,
  keyExtractor: PropTypes.func,
  title: PropTypes.string,
  isWallet: PropTypes.bool,
};
