import {
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {mvs, ms} from '../utils/helpers/metric';
import {COLORS, ICONS} from '../themes/Themes';
import PropTypes from 'prop-types';
export default function ProductContainer(props) {
  return (
    <TouchableOpacity
      style={[
        styles.itemContainer,
        {
          marginLeft: props.index == 0 ? ms(10) : 0,
          width: props.width,
          marginRight: props.marginRight,
        },
      ]}
      activeOpacity={0.7}>
      <Text style={styles.title}>{props.title}</Text>
      <Text style={styles.desc}>{props.desc}</Text>
      {props.isNew ? (
        <View style={styles.newContainer}>
          <Text style={styles.newText}>New</Text>
        </View>
      ) : null}

      <ImageBackground
        source={props.image}
        //resizeMode="contain"
        imageStyle={{}}
        style={{
          width: '100%',
          height: ms(120),
          marginTop: mvs(8),
        }}>
        <Text
          style={{
            position: 'absolute',
            left: ms(2),
            top: mvs(4),
            //padding: mvs(10),
            fontSize: ms(10),
            color: COLORS.green,
            fontWeight: 'bold',
          }}>
          In Stock
        </Text>
        <Image
          source={
            props.bookMarked ? ICONS.bookmarkEnable : ICONS.bookmarkDisable
          }
          resizeMode="contain"
          style={{
            position: 'absolute',
            height: ms(22),
            width: ms(22),
            right: 0,
            top: mvs(2),
          }}
        />
      </ImageBackground>
      <Text style={[styles.desc, {marginTop: mvs(4)}]}>
        {props.price}{' '}
        <Text style={{fontWeight: 'normal', fontSize: ms(11)}}>(Exc VAT)</Text>
      </Text>
      {/* </View> */}
    </TouchableOpacity>
  );
}

ProductContainer.propTypes = {
  index: PropTypes.number,
  title: PropTypes.string,
  desc: PropTypes.string,
  image: PropTypes.string,
  bookMarked: PropTypes.bool,
  price: PropTypes.any,
  isNew: PropTypes.bool,
  width: PropTypes.number,
  marginRight: PropTypes.number,
};

ProductContainer.defaultProps = {
  index: 0,
  title: '',
  desc: '',
  image: '',
  bookMarked: false,
  price: 0,
  isNew: false,
  width: ms(225),
  marginRight: ms(15),
};

const styles = StyleSheet.create({
  title: {
    fontSize: ms(11),
    color: COLORS.textColor,
    marginBottom: mvs(4),
    textAlignVertical: 'center',
  },
  desc: {
    fontSize: ms(12),
    color: COLORS.dark_blue,
    fontWeight: '700',
    lineHeight: mvs(17),
    textAlignVertical: 'center',
  },
  itemContainer: {
    marginBottom: mvs(10),

    backgroundColor: COLORS.white,
    padding: mvs(12),

    borderRadius: ms(15),
    borderWidth: 0.7,
    borderColor: '#cccccc',
  },
  imageStyle: {
    width: ms(190),
    height: ms(150),
    alignItems: 'center',
    justifyContent: 'center',
  },
  newContainer: {
    height: ms(22),
    width: ms(50),
    backgroundColor: COLORS.red,
    position: 'absolute',
    top: 0,
    right: 0,
    borderTopRightRadius: ms(10),
    borderBottomLeftRadius: ms(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  newText: {marginBottom: 0, color: COLORS.white, fontSize: ms(9)},
});
