import React, {useRef, useState} from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  StyleSheet,
  Alert,
  Dimensions,
  ScrollView,
} from 'react-native';
import SignatureCanvas from 'react-native-signature-canvas';
import Modal from 'react-native-modal';
import {ms} from '../utils/helpers/metric';
import {ICONS} from '../themes/Themes';
import {FONTS} from '../themes/Themes';
const SignatureModal = ({visible, onClose, onSignatureSave}) => {
  const [signature, setSignature] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const ref = useRef();

  const handleSignature = signature => {
    console.log('Signature captured:', signature);
    setSignature(signature);
    setIsLoading(false);
    // Pass signature back to parent
    if (onSignatureSave) {
      onSignatureSave(signature);
    }
    // Auto close modal after saving (optional)
    // onClose();
  };

  const handleEmpty = () => {
    console.log('Signature is empty');
    setIsLoading(false);
    Alert.alert('Warning', 'Please provide a signature before saving.');
  };

  const handleClear = () => {
    console.log('Signature cleared');
    setSignature(null);
  };

  const handleError = error => {
    console.error('Signature pad error:', error);
    setIsLoading(false);
    Alert.alert('Error', 'Failed to process signature.');
  };

  const handleEnd = () => {
    setIsLoading(true);
    ref.current?.readSignature();
  };

  const handleSave = () => {
    if (!signature) {
      Alert.alert('Warning', 'No signature detected. Please sign first.');
      return;
    }
    if (onSignatureSave) {
      onSignatureSave(signature);
    }
    onClose(); // Close modal after saving
  };

  const handleCancel = () => {
    setSignature(null);
    onClose();
  };

  return (
    // <Modal
    //   visible={visible}
    //   //transparent={true}
    //   //animationType="slide"
    //   onRequestClose={onClose}
    //   style={{justifyContent: 'flex-end', margin: 0}}>
    //   <View
    //     style={{
    //       backgroundColor: 'white',
    //       padding: 22,
    //       //alignItems: 'center',
    //       borderTopLeftRadius: 15,
    //       borderTopRightRadius: 15,
    //       height: Dimensions.get('window').height * 0.6,
    //     }}>
    //     <View
    //       style={{
    //         width: ms(63),
    //         height: ms(6),
    //         borderRadius: ms(8),
    //         backgroundColor: 'rgba(217, 217, 217, 1)',
    //         alignSelf: 'center',
    //         marginBottom: ms(20),
    //       }}
    //     />
    //     {/* Header */}
    //     <View style={styles.header}>
    //       <Text style={styles.title}>Sign Here</Text>
    //       <TouchableOpacity onPress={handleCancel}>
    //         <Text style={styles.closeButton}>✕</Text>
    //       </TouchableOpacity>
    //     </View>

    //     {/* Preview */}
    //     <View style={styles.preview}>
    //       {signature ? (
    //         <Image
    //           resizeMode="contain"
    //           style={styles.signatureImage}
    //           source={{uri: signature}}
    //         />
    //       ) : (
    //         <Text style={styles.placeholderText}>No signature yet</Text>
    //       )}
    //     </View>

    //     {/* Signature Pad */}
    //     <View style={styles.signaturePadContainer}>
    //       <SignatureCanvas
    //         ref={ref}
    //         onEnd={handleEnd}
    //         onOK={handleSignature}
    //         onEmpty={handleEmpty}
    //         onClear={handleClear}
    //         onError={handleError}
    //         autoClear={true}
    //         descriptionText="Sign here"
    //         clearText="Clear"
    //         confirmText={isLoading ? 'Processing...' : 'Use Signature'}
    //         penColor="#000000"
    //         backgroundColor="rgba(255,255,255,0)"
    //         webStyle={`.m-signature-pad--footer { display: none; }`} // Optional: hide default footer
    //         style={styles.signatureCanvas}
    //       />
    //     </View>

    //     {/* Action Buttons */}
    //     <View style={styles.buttonRow}>
    //       <TouchableOpacity style={styles.button} onPress={handleCancel}>
    //         <Text style={styles.buttonText}>Cancel</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity
    //         style={[styles.button, styles.saveButton]}
    //         onPress={handleSave}
    //         disabled={!signature || isLoading}>
    //         <Text style={styles.buttonText}>
    //           {isLoading ? 'Saving...' : 'Save'}
    //         </Text>
    //       </TouchableOpacity>
    //     </View>
    //   </View>
    // </Modal>
    <Modal
      isVisible={visible}
      onBackdropPress={() => {
        onClose();
      }} // Close modal when tapping outside
      style={{justifyContent: 'flex-end', margin: 0}}>
      <View
        style={{
          backgroundColor: 'white',
          padding: 22,
          //alignItems: 'center',
          borderTopLeftRadius: 15,
          borderTopRightRadius: 15,
          height: Dimensions.get('window').height * 0.8,
        }}>
        <View
          style={{
            width: ms(63),
            height: ms(6),
            borderRadius: ms(8),
            backgroundColor: 'rgba(217, 217, 217, 1)',
            alignSelf: 'center',
            marginBottom: ms(20),
          }}
        />
        <TouchableOpacity
          onPress={() => onClose()}
          style={{position: 'absolute', top: 20, right: 20}}>
          <Image
            resizeMode="contain"
            style={{height: ms(20), width: ms(20)}}
            source={ICONS.crossbtn}
          />
        </TouchableOpacity>
        
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Signature
            </Text>
          </View>
          <View style={styles.preview}>
            {signature ? (
              <Image
                resizeMode="contain"
                style={styles.signatureImage}
                source={{uri: signature}}
              />
            ) : (
              <Text style={styles.placeholderText}>No signature yet</Text>
            )}
          </View>
          <View style={styles.signaturePadContainer}>
           <SignatureCanvas
             ref={ref}
             onEnd={handleEnd}
             onOK={handleSignature}
             onEmpty={handleEmpty}
             onClear={handleClear}
             onError={handleError}
             autoClear={true}
             descriptionText="Sign here"
             clearText="Clear"
             confirmText={isLoading ? 'Processing...' : 'Use Signature'}
             penColor="#000000"
             backgroundColor="rgba(255,255,255,0)"
             webStyle={`.m-signature-pad--footer { display: none; }`} // Optional: hide default footer
            style={styles.signatureCanvas}
           />
         </View>
         <View style={styles.buttonRow}>
           <TouchableOpacity style={styles.button} onPress={handleCancel}>
             <Text style={styles.buttonText}>Cancel</Text>
           </TouchableOpacity>
          <TouchableOpacity
             style={[styles.button, styles.saveButton]}
             onPress={handleSave}
             disabled={!signature || isLoading}>
             <Text style={styles.buttonText}>
               {isLoading ? 'Saving...' : 'Save'}
             </Text>
           </TouchableOpacity>
         </View>
        
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '100%',
    maxWidth: 500,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    maxHeight: '90%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  closeButton: {
    fontSize: 24,
    color: '#888',
  },
  preview: {
    width: '100%',
    height: 120,
    backgroundColor: '#F8F8F8',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#eee',
  },
  signatureImage: {
    width: '100%',
    height: '100%',
  },
  placeholderText: {
    color: '#aaa',
    fontSize: 14,
  },
  signaturePadContainer: {
    flex: 1,
    minHeight: 200,
    marginBottom: 20,
  },
  signatureCanvas: {
    flex: 1,
    backgroundColor: '#fff',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  button: {
    flex: 1,
    padding: 14,
    borderRadius: 8,
    backgroundColor: '#eee',
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#007AFF',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default SignatureModal;
