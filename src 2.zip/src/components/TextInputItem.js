import React, {memo} from 'react';
import {
  View,
  TextInput,
  Text,
  Image,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import PropTypes from 'prop-types';
import {COLORS, FONTS} from '../themes/Themes';
import {ms, mvs} from '../utils/helpers/metric';
const {width, height} = Dimensions.get('window');

export default function TextInputItem(props) {
  const {
    marginTop = mvs(10),
    maxLength = 2000000000,
    multiline = false,
    autoCapitalize = 'none',
    placeholder = '',
    placeholderTextColor = COLORS.placeholderColor,
    keyboardType = 'default',
    value = '',
    onChangeText = null,
    editable = true,
    borderColor = null,
    borderWidth = 0.3,
    letterSpacing = 0,
    fontSize = ms(12),
    textAlign = 'left',
    borderRadius = ms(5),
    fontFamily = FONTS.Regular,
    fontWeight = '400',
    backgroundColor = COLORS.white,
    width = '100%',
    height = ms(48),
    marginBottom = 0,
    leftIcon = '',
    rightIcon = '',
    isRightIconVisible = false,
    textInputLeft = ms(12),
    textColor = COLORS.black,
    returnKeyType = 'default',
    autoFocus = false,
    isrightdisabled = true,
    onPressRight = () => {},
    textInputStyle = null,
    leftIconTintColor = COLORS.black,
    textInputViewStyle = null,
    leftIconStyle = null,
    isSecure = false,
  } = props;

  return (
    <View
      style={[
        {
          flexDirection: 'row',
          height: height,
          borderRadius: borderRadius,
          backgroundColor: backgroundColor,
          borderWidth: borderWidth,
          borderColor: borderColor,
          alignItems: 'center',
          marginTop: marginTop,
          marginBottom: marginBottom,
          width: width,
          elevation: 3,
          shadowColor: 'rgba(4, 127, 255, 0.5)',
        },
        {...textInputViewStyle},
      ]}>
      {leftIcon != '' && (
        <Image
          source={leftIcon}
          resizeMode="contain"
          style={[
            {
              width: ms(20),
              height: ms(20),
              marginLeft: ms(8),
              tintColor: leftIconTintColor,
            },
            {...leftIconStyle},
          ]}
        />
      )}
      <TextInput
        style={[
          {
            width: width,
            paddingLeft: textInputLeft,
            textAlign: textAlign,
            letterSpacing: letterSpacing,
            color: textColor,
            fontFamily: fontFamily,
            fontSize: fontSize,
            height: height,

            // paddingBottom: normalize(5),
          },
          {...textInputStyle},
        ]}
        // autoComplete="off"
        autoCorrect={false}
        importantForAutofill="no"
        textContentType="none"
        selectTextOnFocus={false}
        maxLength={maxLength}
        multiline={multiline}
        autoCapitalize={autoCapitalize}
        placeholder={placeholder}
        editable={editable}
        scrollEnabled={false}
        spellCheck={false}
        placeholderTextColor={placeholderTextColor}
        keyboardType={keyboardType}
        autoFocus={autoFocus}
        value={value}
        secureTextEntry={isSecure}
        fontWeight={fontWeight}
        onChangeText={text => {
          onChangeText(text);
        }}
        returnKeyType={returnKeyType}
      />
      {isRightIconVisible && (
        <TouchableOpacity
          activeOpacity={0.7}
          disabled={isrightdisabled}
          onPress={() => onPressRight()}
          style={{
            position: 'absolute',
            right: ms(15),
            zIndex: 50,
          }}>
          <Image
            source={rightIcon}
            resizeMode="contain"
            style={{
              width: ms(20),
              height: ms(20),
              tintColor:COLORS.themeColor
            }}
          />
        </TouchableOpacity>
      )}
    </View>
    // </View>
  );
}

TextInputItem.propTypes = {
  marginLeft: PropTypes.number,
  marginTop: PropTypes.number,
  maxLength: PropTypes.number,
  isSecure: PropTypes.bool,
  multiline: PropTypes.bool,
  autoCapitalize: PropTypes.string,
  placeholder: PropTypes.string,
  placeholderTextColor: PropTypes.string,
  keyboardType: PropTypes.string,
  value: PropTypes.string,
  onChangeText: PropTypes.func,
  color: PropTypes.string,
  letterSpacing: PropTypes.number,
  fontSize: PropTypes.number,
  editable: PropTypes.bool,
  borderColor: PropTypes.string,
  fontWeight: PropTypes.any,
  textAlign: PropTypes.string,
  onPress: PropTypes.func,
  search: PropTypes.bool,
  borderRadius: PropTypes.any,
  icon: PropTypes.any,
  iconleft: PropTypes.any,
  iconright: PropTypes.any,
  fontFamily: PropTypes.any,
  backgroundColor: PropTypes.any,
  width: PropTypes.any,
  height: PropTypes.any,
  marginBottom: PropTypes.number,
  borderBottomWidth: PropTypes.number,
  leftIcon: PropTypes.any,
  rightIcon: PropTypes.any,
  isleftIconVisible: PropTypes.bool,
  isRightIconVisible: PropTypes.bool,
  textInputLeft: PropTypes.number,
  textColor: PropTypes.string,
  borderWidth: PropTypes.number,
  isleftIconVisible: PropTypes.bool,
  returnKeyType: PropTypes.string,
  autoFocus: PropTypes.bool,
  blurOnSubmit: PropTypes.bool,
  opacity: PropTypes.number,
  rightText: PropTypes.string,
  isrightdisabled: PropTypes.bool,
  onPressRight: PropTypes.func,
  title: PropTypes.string,
  textInputStyle: PropTypes.any,
  titleFontSize: PropTypes.number,
  leftIconTintColor: PropTypes.string,
  textInputViewStyle: PropTypes.any,
  leftIconStyle: PropTypes.any,
};
