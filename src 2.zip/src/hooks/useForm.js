import React from "react";

export default function useForm(val) {
    const [form, setform] = React.useState(val);
  
    const updatevalue = (val,key) => {
      
        let tmpform = {...form};
        tmpform[key] = val;
        console.log(form)
        setform(tmpform);
 
     } 
     const bulkupdate = (val) => {
      
        let tmpform =  {...form, ...val};
       
        setform(tmpform);
 
     }
  
    return [form, updatevalue,bulkupdate];
  }