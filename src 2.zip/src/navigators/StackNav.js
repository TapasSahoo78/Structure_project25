import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {navigationRef} from '../utils/helpers/RootNaivgation';
import SplashScreen from '../screens/auth/SplashScreen';

import {useSelector} from 'react-redux';
import Signup from '../screens/auth/Signup';
import Login from '../screens/auth/Login';
import ForgotPassword from '../screens/auth/ForgotPassword';
import SendOtp from '../screens/auth/SendOtp';
import ForgotPasswordOtp from '../screens/auth/ForgotPasswordOtp';
import ResetPassword from '../screens/auth/ResetPassword';
import SuccessfulPage from '../screens/auth/SuccessfulPage';
import Dashboard from '../screens/main/Dashboard';
import TabNav from './TabNav';
import Project from '../screens/main/Project';
import CreateProject from '../screens/main/CreateProject';
import AddClient from '../screens/main/AddClient';
import CreateClient from '../screens/main/CreateClient';
import AddCreditNote from '../screens/main/AddCreditNote';
import AddPurchaseOrder from '../screens/main/AddPurchaseOrder';
import AddEstimate from '../screens/main/AddEstimate';
import AddInvoice from '../screens/main/AddInvoice';
import AddAccount from '../screens/main/AddAccount';
import Subscription from '../screens/main/Subscription';
import AccountSettings from '../screens/main/AccountSettings';
import ClientDetail from '../screens/main/ClientDetail';
import ClientPaymentOption from '../screens/main/ClientPaymentOption';
import OtherItem from '../screens/main/OtherItem';
import Expence from '../screens/main/Expence';
import AddNewExpense from '../screens/main/AddNewExpense';
import PurchaseOrder from '../screens/main/PurchaseOrder';
import CreditNote from '../screens/main/CreditNote';
import Appointment from '../screens/main/Appointment';
import AddAppointment from '../screens/main/AddAppointment';
import Estimate from '../screens/main/Estimate';
import TimeEntries from '../screens/main/TimeEntries';
import AddNewTime from '../screens/main/AddNewTime';
import Reports from '../screens/main/Reports';
import HelpSupport from '../screens/main/HelpSupport';
import Refer from '../screens/main/Refer';
import AddCompanyDetails from '../screens/main/AddCompanyDetails';
import EditClient from '../screens/main/EditClient';
import TaxCurrency from '../screens/main/TaxCurrency';
import InvoiceDetails from '../screens/main/InvoiceDetails';
import {Image, View} from 'react-native';
import {ms} from '../utils/helpers/metric';
import {COLORS, ICONS} from '../themes/Themes';
import PaypalPayment from '../screens/main/PaypalPayment';
import StripePayment from '../screens/main/StripePayment';
import RazorPay from '../screens/main/RazorPay';
import CustomInvoiceDesign from '../screens/main/CustomInvoiceDesign';
import AddItem from '../screens/main/AddItem';
import AddInvoiceWithoutClient from '../screens/main/AddInvoiceWithoutClient';
import EditCompanyDetails from '../screens/main/EditCompanyDetails';
import UserRole from '../screens/main/UserRole';
import AddRoles from '../screens/main/AddRoles';
import ClientCommunication from '../screens/main/ClientCommunication';
import EditRole from '../screens/main/EditRole';
import AddRole from '../screens/main/AddRole';
import ProjectSettings from '../screens/main/ProjectSettings';
import InvoiceWebview from '../screens/main/InvoiceWebview';
import PersonalInfoUpdate from '../screens/main/PersonalInfoUpdate';
import ChangePassword from '../screens/main/ChangePassword';
import CustomInvoiceOption from '../screens/main/CustomInvoiceOption';
import UpdateItem from '../screens/main/UpdateItem';
import EditInvoice from '../screens/main/EditInvoice';
import EditAppointment from '../screens/main/EditAppointment';
import InvoiceWeb from '../screens/main/InvoiceWeb';
import AddEstimateWithoutClient from '../screens/main/AddEstimateWithoutClient';
import UpdateEstimate from '../screens/main/UpdateEstimate';
import UpdatePurchaseOrder from '../screens/main/UpdatePurchaseOrder';
import AddPurchaseOrderWithoutClient from '../screens/main/AddPurchaseOrderWithoutClient';
import PurchaseOrderDetails from '../screens/main/PurchaseOrderDetails';
import AddCreditNoteWithoutClient from '../screens/main/AddCreditNoteWithoutClient';
import UpdateCreditNote from '../screens/main/UpdateCreditNote';
import SignatureScreen from '../screens/main/SignatureScreen';
import EstimateDetails from '../screens/main/EstimateDetails';
import CreditNoteDetails from '../screens/main/CreditNoteDetails';
import UpdateExpence from '../screens/main/UpdateExpence';
import SignatureSettings from '../screens/main/SignatureSettings';

const Stack = createStackNavigator();

export default function StackNav() {
  const {token, isLoading, isFirstTimeUser, loginResponse, companyCreated} =
    useSelector(state => state.ProfileReducer);
  //console.log("login response",JSON.stringify(loginResponse))
  const linking = {
    prefixes: ['creditsin://'],
  };
  const horizontalAnimation = {
    gestureDirection: 'vertical',
    // detachPreviousScreen: false,
    cardStyleInterpolator: ({current, layouts}) => {
      return {
        cardStyle: {
          backgroundColor: 'transparent',
          transform: [
            {
              translateX: current.progress.interpolate({
                inputRange: [0, 1],
                outputRange: [layouts.screen.width, 0],
              }),
            },
          ],
        },
      };
    },
  };
  const Screens =
    token == null && isFirstTimeUser == '1'
      ? {
          Signup: Signup,
          Login: Login,
          ForgotPassword: ForgotPassword,
          SendOtp: SendOtp,
          ForgotPasswordOtp: ForgotPasswordOtp,
          ResetPassword: ResetPassword,
          SuccessfulPage: SuccessfulPage,
        }
      : token == null && isFirstTimeUser == '0'
      ? {
          Login: Login,
          Signup: Signup,
          ForgotPassword: ForgotPassword,
          SendOtp: SendOtp,
          ForgotPasswordOtp: ForgotPasswordOtp,
          ResetPassword: ResetPassword,
          SuccessfulPage: SuccessfulPage,
        }
      : companyCreated == 'true'
      ? {
          TabNav: TabNav,
          Dashboard: Dashboard,
          Project: Project,
          CreateProject: CreateProject,
          AddClient: AddClient,
          CreateClient: CreateClient,
          ClientDetail: ClientDetail,
          ClientPaymentOption: ClientPaymentOption,
          OtherItem: OtherItem,
          Expence: Expence,
          AccountSettings: AccountSettings,
          Subscription: Subscription,
          AddCreditNote: AddCreditNote,
          AddPurchaseOrder: AddPurchaseOrder,
          AddEstimate: AddEstimate,
          AddInvoice: AddInvoice,
          AddAccount: AddAccount,
          AddNewExpense: AddNewExpense,
          PurchaseOrder: PurchaseOrder,
          CreditNote: CreditNote,
          Appointment: Appointment,
          AddAppointment: AddAppointment,
          Estimate: Estimate,
          TimeEntries: TimeEntries,
          AddNewTime: AddNewTime,
          Reports: Reports,
          HelpSupport: HelpSupport,
          Refer: Refer,
          AddCompanyDetails: AddCompanyDetails,
          EditCompanyDetails: EditCompanyDetails,
          EditClient: EditClient,
          TaxCurrency: TaxCurrency,
          InvoiceDetails: InvoiceDetails,
          PaypalPayment: PaypalPayment,
          StripePayment: StripePayment,
          RazorPay: RazorPay,
          CustomInvoiceDesign: CustomInvoiceDesign,
          AddItem: AddItem,
          AddInvoiceWithoutClient: AddInvoiceWithoutClient,
          UserRole: UserRole,
          AddRoles: AddRoles,
          EditRole: EditRole,
          AddRole: AddRole,
          ClientCommunication: ClientCommunication,
          ProjectSettings: ProjectSettings,
          InvoiceWebview: InvoiceWebview,
          PersonalInfoUpdate: PersonalInfoUpdate,
          ChangePassword: ChangePassword,
          CustomInvoiceOption:CustomInvoiceOption,
          UpdateItem:UpdateItem,
          EditInvoice:EditInvoice,
          EditAppointment:EditAppointment,
          InvoiceWeb:InvoiceWeb,
          AddEstimateWithoutClient:AddEstimateWithoutClient,
          UpdateEstimate:UpdateEstimate,
          UpdatePurchaseOrder:UpdatePurchaseOrder,
          AddPurchaseOrderWithoutClient:AddPurchaseOrderWithoutClient,
          PurchaseOrderDetails:PurchaseOrderDetails,
          AddCreditNoteWithoutClient:AddCreditNoteWithoutClient,
          UpdateCreditNote:UpdateCreditNote,
          SignatureScreen:SignatureScreen,
          EstimateDetails:EstimateDetails,
          CreditNoteDetails:CreditNoteDetails,
          UpdateExpence:UpdateExpence,
          SignatureSettings:SignatureSettings
        }
      : {
          AddCompanyDetails: AddCompanyDetails,
          TabNav: TabNav,
          Dashboard: Dashboard,
          Project: Project,
          CreateProject: CreateProject,
          AddClient: AddClient,
          CreateClient: CreateClient,
          ClientDetail: ClientDetail,
          ClientPaymentOption: ClientPaymentOption,
          OtherItem: OtherItem,
          Expence: Expence,
          AccountSettings: AccountSettings,
          Subscription: Subscription,
          AddCreditNote: AddCreditNote,
          AddPurchaseOrder: AddPurchaseOrder,
          AddEstimate: AddEstimate,
          AddInvoice: AddInvoice,
          AddAccount: AddAccount,
          AddNewExpense: AddNewExpense,
          PurchaseOrder: PurchaseOrder,
          CreditNote: CreditNote,
          Appointment: Appointment,
          AddAppointment: AddAppointment,
          Estimate: Estimate,
          TimeEntries: TimeEntries,
          AddNewTime: AddNewTime,
          Reports: Reports,
          HelpSupport: HelpSupport,
          Refer: Refer,
          EditCompanyDetails: EditCompanyDetails,
          EditClient: EditClient,
          TaxCurrency: TaxCurrency,
          InvoiceDetails: InvoiceDetails,
          PaypalPayment: PaypalPayment,
          StripePayment: StripePayment,
          RazorPay: RazorPay,
          CustomInvoiceDesign: CustomInvoiceDesign,
          AddItem: AddItem,
          AddInvoiceWithoutClient: AddInvoiceWithoutClient,
          UserRole: UserRole,
          AddRoles: AddRoles,
          EditRole: EditRole,
          AddRole: AddRole,
          ClientCommunication: ClientCommunication,
          ProjectSettings: ProjectSettings,
          InvoiceWebview: InvoiceWebview,
          PersonalInfoUpdate: PersonalInfoUpdate,
          ChangePassword: ChangePassword,
          CustomInvoiceOption:CustomInvoiceOption,
          UpdateItem:UpdateItem,
          EditInvoice:EditInvoice,
          EditAppointment:EditAppointment,
          InvoiceWeb:InvoiceWeb,
          AddEstimateWithoutClient:AddEstimateWithoutClient,
          UpdateEstimate,UpdateEstimate,
          UpdatePurchaseOrder:UpdatePurchaseOrder,
          AddPurchaseOrderWithoutClient:AddPurchaseOrderWithoutClient,
          PurchaseOrderDetails:PurchaseOrderDetails,
          AddCreditNoteWithoutClient:AddCreditNoteWithoutClient,
          UpdateCreditNote:UpdateCreditNote,
          SignatureScreen:SignatureScreen,
          EstimateDetails:EstimateDetails,
          CreditNoteDetails:CreditNoteDetails,
          UpdateExpence:UpdateExpence,
          SignatureSettings:SignatureSettings
        };
  if (isLoading) {
    return <SplashScreen />;
  } else {
    return (
      <NavigationContainer ref={navigationRef} linking={linking}>
        <Stack.Navigator screenOptions={horizontalAnimation}>
          {Object.entries({
            ...Screens,
          }).map(([name, component], index) => {
            return (
              <>
                <Stack.Screen
                  key={index}
                  options={{headerShown: false, gestureEnabled: false}}
                  name={name}
                  component={component}
                />
                {/* {name == 'TabNav' ? (
                  <View
                    style={{
                      // marginTop: -ms(80),
                      backgroundColor: 'rgb(232, 243, 255)',
                      height: ms(60),
                      width: ms(60),
                      borderRadius: ms(30),
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'absolute',
                      top: -ms(50),
                    }}>
                    <View
                      style={{
                        height: ms(50),
                        width: ms(50),
                        borderRadius: ms(25),
                        backgroundColor: COLORS?.themeColor,

                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        source={ICONS.addMore}
                        resizeMode="contain"
                        style={[
                          {width: ms(28), height: ms(28)},
                          {tintColor: COLORS?.white, marginRight: ms(0)},
                        ]}
                      />
                    </View>
                  </View>
                ) : null} */}
              </>
            );
          })}
        </Stack.Navigator>
      </NavigationContainer>
    );
  }
}
