import React, { useEffect, useState } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image, Dimensions, View, Text, StyleSheet } from 'react-native';
import { COLORS, FONTS, ICONS } from '../themes/Themes';
import { ms, mvs } from '../utils/helpers/metric';
import 'react-native-gesture-handler';
import CustomTabBar from '../components/CustomTabBar';

import Dashboard from '../screens/main/Dashboard';
import Client from '../screens/main/Client';
import Invoice from '../screens/main/Invoice';
import MoreOption from '../screens/main/MoreOption';
import Estimate from '../screens/main/Estimate';
const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const Tab = createBottomTabNavigator();
import { useSelector } from 'react-redux';
import DeviceInfo from 'react-native-device-info';
export default function TabNav(props) {
  const [isTablet, setIsTablet] = useState(false);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  const profileDetailsRes = useSelector(
    state => state.ProfileReducer?.profileResponse,
  );
  const companyDeatils = profileDetailsRes?.isVerified;
  return (
    <Tab.Navigator
      initialRouteName="Dashboard"
      screenOptions={{
        tabBarItemStyle: isTablet
          ? {
            height: 70,
            flexDirection: 'column',
            alignItems: 'center',
            width: Dimensions.get('window').width,
          }
          : {},
        // lazy: false,
        // tabBarShowLabel: false,
        headerShown: false,
        tabBarHideOnKeyboard: true,

        tabBarStyle: {
          backgroundColor: COLORS.white,
          height: ms(85),
          borderTopWidth: 0,
          //paddingBottom: mvs(7),
          paddingTop: mvs(14),
          paddingVertical: ms(0),
          borderTopLeftRadius: ms(20),
          borderTopRightRadius: ms(20),

          alignItems: 'center',
          justifyContent: 'center',
          //backgroundColor:'green',
          paddingHorizontal: ms(5),
        },

        tabBarLabelStyle: {
          // marginBottom: mvs(10),
          fontFamily: FONTS.Poppins_Medium,
          textAlignVertical: 'center',
          fontSize: ms(11),
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
          marginTop: ms(5),
          //backgroundColor:'red'

          // color: '#047FFF',
        },
        tabBarShowLabel: true,
        tabBarActiveTintColor: COLORS.themeColor,
        tabBarInactiveTintColor: '#ccced4',
      }}>
      <Tab.Screen
        name="Dashboard"
        component={Dashboard}
        options={{
          title: 'Home',

          tabBarIcon: ({ focused, color, size }) => (
            <View
              style={
                focused
                  ? styles.activeTabBackground
                  : styles.inactiveTabBackground
              }>
              <Image
                source={ICONS.tab1}
                resizeMode="contain"
                style={[
                  styles.iconStyle,
                  { tintColor: focused ? '#047FFF' : '#ccced4' },
                ]}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Client"
        component={Client}
        listeners={{
          tabPress: e => {
            if (!companyDeatils) {
              e.preventDefault();
            }
          },
        }}
        options={{
          title: 'Client',
          tabBarIcon: ({ focused, color, size }) => (
            <View
              style={
                focused
                  ? styles.activeTabBackground
                  : styles.inactiveTabBackground
              }>
              <Image
                source={ICONS.tab2}
                resizeMode="contain"
                style={[
                  styles.iconStyle,
                  { tintColor: focused ? '#047FFF' : '#ccced4' },
                ]}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Invoice"
        component={Invoice}
        listeners={{
          tabPress: e => {
            if (!companyDeatils) {
              e.preventDefault();
            }
          },
        }}
        options={{
          title: 'Invoice',
          tabBarIcon: ({ focused, color, size }) => (
            <View
              style={
                focused
                  ? styles.activeTabBackground
                  : styles.inactiveTabBackground
              }>
              <Image
                source={ICONS.tab3}
                resizeMode="contain"
                style={[
                  styles.iconStyle,
                  { tintColor: focused ? '#047FFF' : '#ccced4' },
                ]}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Estimate"
        component={Estimate}
        listeners={{
          tabPress: e => {
            if (!companyDeatils) {
              e.preventDefault();
            }
          },
        }}
        options={{
          title: 'Estimate',
          tabBarIcon: ({ focused, color, size }) => (
            <View
              style={
                focused
                  ? styles.activeTabBackground
                  : styles.inactiveTabBackground
              }>
              <Image
                source={ICONS.tab4}
                resizeMode="contain"
                style={[
                  styles.iconStyle,
                  { tintColor: focused ? '#047FFF' : '#ccced4' },
                ]}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="MoreOption"
        component={MoreOption}
        listeners={{
          tabPress: e => {
            if (!companyDeatils) {
              e.preventDefault();
            }
          },
        }}
        options={{
          title: 'More',
          tabBarIcon: ({ focused, color, size }) => (
            <View
              style={
                focused
                  ? styles.activeTabBackground
                  : styles.inactiveTabBackground
              }>
              <Image
                source={ICONS.tab5}
                resizeMode="contain"
                style={[
                  styles.iconStyle,
                  { tintColor: focused ? '#047FFF' : '#ccced4' },
                ]}
              />
            </View>
          ),
        }}
      />
      {/* <Tab.Screen
        name="Dashboard41"
        component={Dashboard}
        options={{
          title: '',
          tabBarIcon: ({focused, color, size}) => (
            <View
              style={{
                // marginTop: -ms(80),
                backgroundColor: 'rgb(232, 243, 255)',
                height: ms(60),
                width: ms(60),
                borderRadius: ms(30),
                alignItems: 'center',
                justifyContent: 'center',
                position: 'absolute',
                top: -ms(50),
              }}>
              <View
                style={{
                  height: ms(50),
                  width: ms(50),
                  borderRadius: ms(25),
                  backgroundColor: COLORS?.themeColor,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  source={ICONS.addMore}
                  resizeMode="contain"
                  style={[
                    styles.iconStyle,
                    {tintColor: COLORS?.white, marginRight: ms(0)},
                  ]}
                />
              </View>
            </View>
          ),
        }}
      /> */}
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  bottomBar: {
    width: ms(90),
    height: ms(5),
    backgroundColor: '#FCB143',
    position: 'absolute',
    bottom: 0,
    borderTopRightRadius: ms(4),
    borderTopLeftRadius: ms(4),
  },
  labelStyle: {
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
  },
  labelText: {
    fontFamily: FONTS.Inter_Medium,
    fontSize: ms(10),
    marginTop: mvs(2),
  },
  iconStyle: {
    width: ms(28),
    height: ms(28),

    // tintColor: COLORS.dark_grey,
    // marginRight: ms(10),
  },
  fa: {
    //flexDirection: 'row',
    alignItems: 'center',
  },
  activeTabBackground: {
    // height: ms(50),
    // width: ms(50),
    // backgroundColor: COLORS?.themeColor,
    borderRadius: ms(25),
    alignItems: 'center',
    justifyContent: 'center',

    // width: '20%',
    // backgroundColor: '#FF0',
    // marginTop: -ms(30),
  },
  inactiveTabBackground: {
    // width: '20%',
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: '#FF0',
  },
});
