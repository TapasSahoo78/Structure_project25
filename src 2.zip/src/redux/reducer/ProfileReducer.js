import {createSlice} from '@reduxjs/toolkit';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {act} from 'react';
const initialState = {
  token: null,
  registrationResponse: null,
  isLoading: true,
  error: null,
  profile_status: '',
  loginResponse: null,
  profileResponse: null,
  loading: false,
  sendOtpResponse: null,
  getSubscriptionRes: null,
  addSubscriptionResponse: null,
  clientList: [],
  commonList: null,
  clientDetails: null,
  countryList: null,
  appointmentList: null,
  projectList: [],
  projectDetail: '',
  loginResponse: null,
  loading: false,
  //sendOtpResponse: null,
  getSubscriptionRes: null,
  addSubscriptionResponse: null,
  clientList: null,
  commonList: null,
  clientDetails: null,
  countryList: null,
  appointmentList: null,
  itemList: null,
  invoiceList: null,
  invoiceDetail: null,
  addedItem: null,
  isFirstTimeUser: '1',
  roleList: [],
  accountList: [],
  clientCommunicationDetails: null,
  projectSettingsDetail: '',
  companyCreated: 'false',
  getTemplate: '',
  getLogo: [],
  logoList: [],
  colourList: [],
  waterMarkList: [],
  headerList: [],
  invoiceTemplate: null,
  invoiceSettings: null,
  invoiceOptionSettings: null,
  previewInvoice: null,
  projectFiles: [],
  contactList: [],
  projectTime:[],
  taskList:[],
  estimateList:[],
  allTimes:[],
  purchaseOrderList:[],
  invoicePreview:null,
  poDetails:null,
  creditNoteList:[],
  customLogo:null,
  customheader:null,
  customWaterMark:null,
  estimateDetails:null,
  creditNoteDetails:null,
  clientWiseProject:[],
  expenseList:[],
  appointmentContacts:null,
  dashboardStatus:null,
  signatureDetail:null
};

const ProfileSlice = createSlice({
  name: 'Profile',
  initialState: initialState,
  reducers: {
    tokenRequest(state, action) {
      state.profile_status = action.type;
      state.isLoading = true;
    },
    tokenSuccess(state, action) {
      console.log('From Reducer: ', action?.payload);
      state.profile_status = action.type;
      state.isLoading = false;
      state.token = action?.payload?.token ?? null;
      state.isFirstTimeUser = action?.payload?.is_first_time_user ?? '1';
      state.companyCreated = action?.payload?.is_company_created;
    },
    tokenFailure(state, action) {
      state.profile_status = action.type;
      state.isLoading = false;
      state.error = action.payload;
    },
    registrationRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    registrationSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.registrationResponse = action.payload;
    },
    registrationFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    loginRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    loginSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.loginResponse = action.payload;
    },
    loginFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addBusinessDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addBusinessDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.loginResponse=action.payload
    },
    addBusinessDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getProfileRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getProfileSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.profileResponse = action.payload;
    },
    getProfileFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    sendVerificationCodeRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    sendVerificationCodeSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.sendOtpResponse = action.payload;
      //state.profileResponse = action.payload
    },
    sendVerificationCodeFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    resetPasswordRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    resetPasswordSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.profileResponse = action.payload
    },
    resetPasswordFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getSubscriptionRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getSubscriptionSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.getSubscriptionRes = action.payload;
    },
    getSubscriptionFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addSubscriptionRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addSubscriptionSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.addSubscriptionResponse = action.payload;
    },
    addSubscriptionFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addClientRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addClientSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    addClientFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getClientRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getClientSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.clientList = action.payload;
    },
    getClientFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCommonListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCommonListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.commonList = action.payload;
    },
    getCommonListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getClientDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getClientDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.clientDetails = action.payload;
    },
    getClientDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    editClientRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    editClientSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.clientDetails = action.payload
    },
    editClientFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCountryListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCountryListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.countryList = action.payload;
    },
    getCountryListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addTaxCurrencyRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addTaxCurrencySuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.countryList = action.payload
    },
    addTaxCurrencyFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addAppointmentRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addAppointmentSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.countryList = action.payload
    },
    addAppointmentFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getAppointmentListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getAppointmentListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.appointmentList = action.payload;
    },
    getAppointmentListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addItemsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addItemsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.addedItem = action?.payload;
      //state.appointmentList = action.payload
    },
    addItemsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getItemsListReqest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getItemsListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.itemList = action.payload;
    },
    getItemsListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectCreateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectCreateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    projectCreateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.projectList = action?.payload;
    },
    projectListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectDetailRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectDetailSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.projectDetail = action?.payload;
    },
    projectDetailFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectUpdateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectUpdateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    projectUpdateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    noteCreateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    noteCreateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    noteCreateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    logoutRequest(state, action) {
      state.profile_status = action.type;
    },
    logoutSuccess(state, action) {
      state.profile_status = action.type;
      state.token = null;
    },

    invoiceCreateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    invoiceCreateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.addedItem = null;
    },
    invoiceCreateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteClientRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteClientSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    deleteClientFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    invoiceListRequest(state, action) {
      console.log('REDUCER CALL');
      state.profile_status = action.type;
      state.loading = true;
    },
    invoiceListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoiceList = action?.payload;
    },
    invoiceListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    invoiceDetailRequest(state, action) {
      console.log('REDUCER CALL');
      state.profile_status = action.type;
      state.loading = true;
    },
    invoiceDetailSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoiceDetail = action?.payload;
    },
    invoiceDetailFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    invoiceDeletelRequest(state, action) {
      console.log('REDUCER CALL');
      state.profile_status = action.type;
      state.loading = true;
    },
    invoiceDeleteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    invoiceDeleteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getMyClientDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getMyClientDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.clientDetails = action.payload;
    },
    getMyClientDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    getRoleListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getRoleListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.roleList = action?.payload;
    },
    getRoleListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    addAccountRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addAccountSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    addAccountFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    accountListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    accountListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.accountList = action?.payload;
    },
    accountListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getClientCommDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getClientCommDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.clientCommunicationDetails = action?.payload;
    },
    getClientCommDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateClientCommRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateClientCommSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.clientCommunicationDetails = action?.payload;
    },
    updateClientCommFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    swtchAccountRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    swtchAccountSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    swtchAccountFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectSettingsDetailRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectSettingsDetailSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.projectSettingsDetail = action?.payload;
    },
    projectSettingsDetailFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    projectSettingsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectSettingsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    projectSettingsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    roleCreateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    roleCreateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    roleCreateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    roleDeleteRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    roleDeleteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    roleDeleteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    roleUpdateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    roleUpdateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    roleUpdateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    getInvoiceTemplateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getInvoiceTemplateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.getTemplate = action?.payload;
    },
    getInvoiceTemplateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    createLogoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    createLogoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    createLogoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    getLogoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getLogoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      // state.getLogo = action?.payload;
      state.logoList = action?.payload;
    },
    getLogoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    updateProfileRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateProfileSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
    },
    updateProfileFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getColourListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getColourListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.colourList = action.payload;
    },
    getColourListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getWaterMarkListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getWaterMarkListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.waterMarkList = action.payload;
    },
    getWaterMarkListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getHeaderListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getHeaderListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.headerList = action.payload;
    },
    getHeaderListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addInvoiceDesignRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addInvoiceDesignSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoiceTemplate = action.payload;
    },
    addInvoiceDesignFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getInvoiceSettingsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getInvoiceSettingsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoiceSettings = action.payload;
    },
    getInvoiceSettingsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateInvoiceSettingsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateInvoiceSettingsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.invoiceSettings = action.payload
    },
    updateInvoiceSettingsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getInvoiceOptionsSettingsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getInvoiceOptionsSettingsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoiceOptionSettings = action.payload;
    },
    getInvoiceOptionsSettingsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addInvoiceOptionRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addInvoiceOptionSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.invoiceOptionSettings = action.payload
    },
    addInvoiceOptionFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getPreviewInvoiceRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getPreviewInvoiceSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.previewInvoice = action.payload;
    },
    getPreviewInvoiceFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getFilesRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getFilesSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.projectFiles = action.payload;
    },
    getFilesFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addFilesRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addFilesSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.projectFiles = action.payload
    },
    addFilesFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getContactRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getContactSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.contactList = action.payload
    },
    getContactFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addContactRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addContactSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.contactList = action.payload
    },
    addContactFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getProjectTimeRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getProjectTimeSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.projectTime = action.payload
    },
    getProjectTimeFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addProjectTimeRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addProjectTimeSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.projectTime = action.payload
    },
    addProjectTimeFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getTaskListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getTaskListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.taskList = action.payload
    },
    getTaskListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addTaskRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addTaskSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    addTaskFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateItemRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateItemSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    updateItemFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteItemRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteItemSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    deleteItemFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateInvoiceRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateInvoiceSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    updateInvoiceFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteInvoiceRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteInvoiceSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    deleteInvoiceFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateAppointmentRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateAppointmentSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    updateAppointmentFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateContactRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateContactSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    updateContactFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteContactRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteContactSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    deleteContactFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateTaskRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateTaskSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    updateTaskFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteTaskRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteTaskSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    deleteTaskFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteAppointmentRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteAppointmentSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    deleteAppointmentFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addEstimateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addEstimateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.taskList = action.payload
    },
    addEstimateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getEstimateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getEstimateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.estimateList = action.payload
    },
    getEstimateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateEstimateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateEstimateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.estimateList = action.payload
    },
    updateEstimateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteEstimateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteEstimateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.estimateList = action.payload
    },
    deleteEstimateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getAllTimesRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getAllTimesSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.allTimes = action.payload
    },
    getAllTimesFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getPurchaseOrderRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getPurchaseOrderSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.purchaseOrderList = action.payload
    },
    getPurchaseOrderFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addPurchaseOrderRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addPurchaseOrderSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.purchaseOrderList = action.payload
    },
    addPurchaseOrderFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getInvoicePreviewRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getInvoicePreviewSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.invoicePreview = action.payload
    },
    getInvoicePreviewFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updatePoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updatePoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.invoicePreview = action.payload
    },
    updatePoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deletePoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deletePoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.invoicePreview = action.payload
    },
    deletePoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    getPoDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getPoDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.poDetails = action.payload
    },
    getPoDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCreditNoteListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCreditNoteListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.creditNoteList = action.payload
    },
    getCreditNoteListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addCreditNoteRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addCreditNoteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteList = action.payload
    },
    addCreditNoteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateCreditNoteRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateCreditNoteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteList = action.payload
    },
    updateCreditNoteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteCreditNoteRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteCreditNoteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteList = action.payload
    },
    deleteCreditNoteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addCustomTimeRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addCustomTimeSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteList = action.payload
    },
    addCustomTimeFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addCustomLogoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addCustomLogoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customLogo = action.payload
    },
    addCustomLogoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addCustomHeaderRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addCustomHeaderSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customheader = action.payload
    },
    addCustomHeaderFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addCustomWaterRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addCustomWaterSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customWaterMark = action.payload
    },
    addCustomWaterFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCustomLogoRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCustomLogoSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customLogo = action.payload
    },
    getCustomLogoFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCustomHeaderRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCustomHeaderSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customheader = action.payload
    },
    getCustomHeaderFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCustomWaterMarkRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCustomWaterMarkSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.customWaterMark = action.payload
    },
    getCustomWaterMarkFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    createCustomTemplateRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    createCustomTemplateSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      
    },
    createCustomTemplateFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getEstimateDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getEstimateDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.estimateDetails = action.payload
      
    },
    getEstimateDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getCreditNoteDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getCreditNoteDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.creditNoteDetails = action.payload
      
    },
    getCreditNoteDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    verifyOtpRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    verifyOtpSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteDetails = action.payload
      
    },
    verifyOtpFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    resendOtpRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    resendOtpSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteDetails = action.payload
      
    },
    resendOtpFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    projectDeleteRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    projectDeleteSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.creditNoteDetails = action.payload
      
    },
    projectDeleteFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getClientWiseProjectRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getClientWiseProjectSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.clientWiseProject = action.payload
      
    },
    getClientWiseProjectFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addNewExpenseRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addNewExpenseSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.clientWiseProject = action.payload
      
    },
    addNewExpenseFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getExpenseListRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getExpenseListSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.expenseList = action.payload
      
    },
    getExpenseListFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    deleteExpenseRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    deleteExpenseSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.expenseList = action.payload
      
    },
    deleteExpenseFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    updateExpenseRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    updateExpenseSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      //state.expenseList = action.payload
      
    },
    updateExpenseFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getAppointmentContactsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getAppointmentContactsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.appointmentContacts = action.payload
      
    },
    getAppointmentContactsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getProfileStatusRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getProfileStatusSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.dashboardStatus = action.payload
      
    },
    getProfileStatusFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    addSignatureSettingsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    addSignatureSettingsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      
      
    },
    addSignatureSettingsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
    getSignatureDetailsRequest(state, action) {
      state.profile_status = action.type;
      state.loading = true;
    },
    getSignatureDetailsSuccess(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.signatureDetail = action.payload
      
      
    },
    getSignatureDetailsFailure(state, action) {
      state.profile_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  updateProfileRequest,
  updateProfileSuccess,
  updateProfileFailure,

  getLogoRequest,
  getLogoSuccess,
  getLogoFailure,

  createLogoRequest,
  createLogoSuccess,
  createLogoFailure,

  getInvoiceTemplateRequest,
  getInvoiceTemplateSuccess,
  getInvoiceTemplateFailure,

  roleUpdateRequest,
  roleUpdateSuccess,
  roleUpdateFailure,

  roleDeleteRequest,
  roleDeleteSuccess,
  roleDeleteFailure,

  roleCreateRequest,
  roleCreateSuccess,
  roleCreateFailure,

  projectSettingsRequest,
  projectSettingsSuccess,
  projectSettingsFailure,

  projectSettingsDetailRequest,
  projectSettingsDetailSuccess,
  projectSettingsDetailFailure,

  swtchAccountRequest,
  swtchAccountSuccess,
  swtchAccountFailure,

  accountListRequest,
  accountListSuccess,
  accountListFailure,

  addAccountRequest,
  addAccountSuccess,
  addAccountFailure,

  getRoleListRequest,
  getRoleListSuccess,
  getRoleListFailure,

  invoiceDeletelRequest,
  invoiceDeleteSuccess,
  invoiceDeleteFailure,

  invoiceDetailRequest,
  invoiceDetailSuccess,
  invoiceDetailFailure,

  invoiceListRequest,
  invoiceListSuccess,
  invoiceListFailure,

  invoiceCreateRequest,
  invoiceCreateSuccess,
  invoiceCreateFailure,

  logoutRequest,
  logoutSuccess,

  noteCreateRequest,
  noteCreateSuccess,
  noteCreateFailure,

  projectUpdateRequest,
  projectUpdateSuccess,
  projectUpdateFailure,

  projectDetailRequest,
  projectDetailSuccess,
  projectDetailFailure,

  projectListRequest,
  projectListSuccess,
  projectListFailure,

  projectCreateRequest,
  projectCreateSuccess,
  projectCreateFailure,

  tokenRequest,
  tokenSuccess,
  tokenFailure,

  registrationRequest,
  registrationSuccess,
  registrationFailure,

  loginRequest,
  loginSuccess,
  loginFailure,

  addBusinessDetailsRequest,
  addBusinessDetailsSuccess,
  addBusinessDetailsFailure,

  getProfileRequest,
  getProfileSuccess,
  getProfileFailure,

  sendVerificationCodeRequest,
  sendVerificationCodeSuccess,
  sendVerificationCodeFailure,

  resetPasswordRequest,
  resetPasswordSuccess,
  resetPasswordFailure,

  getSubscriptionRequest,
  getSubscriptionSuccess,
  getSubscriptionFailure,

  addSubscriptionRequest,
  addSubscriptionSuccess,
  addSubscriptionFailure,

  addClientRequest,
  addClientSuccess,
  addClientFailure,

  getClientRequest,
  getClientSuccess,
  getClientFailure,

  getCommonListRequest,
  getCommonListSuccess,
  getCommonListFailure,

  getClientDetailsRequest,
  getClientDetailsSuccess,
  getClientDetailsFailure,

  editClientRequest,
  editClientSuccess,
  editClientFailure,

  getCountryListRequest,
  getCountryListSuccess,
  getCountryListFailure,

  addTaxCurrencyRequest,
  addTaxCurrencySuccess,
  addTaxCurrencyFailure,

  addAppointmentRequest,
  addAppointmentSuccess,
  addAppointmentFailure,

  getAppointmentListRequest,
  getAppointmentListSuccess,
  getAppointmentListFailure,

  addItemsRequest,
  addItemsSuccess,
  addItemsFailure,

  getItemsListReqest,
  getItemsListSuccess,
  getItemsListFailure,

  deleteClientRequest,
  deleteClientSuccess,
  deleteClientFailure,

  getMyClientDetailsRequest,
  getMyClientDetailsSuccess,
  getMyClientDetailsFailure,

  getClientCommDetailsRequest,
  getClientCommDetailsSuccess,
  getClientCommDetailsFailure,

  updateClientCommRequest,
  updateClientCommSuccess,
  updateClientCommFailure,

  getColourListRequest,
  getColourListSuccess,
  getColourListFailure,

  getWaterMarkListRequest,
  getWaterMarkListSuccess,
  getWaterMarkListFailure,

  getHeaderListRequest,
  getHeaderListSuccess,
  getHeaderListFailure,

  addInvoiceDesignRequest,
  addInvoiceDesignSuccess,
  addInvoiceDesignFailure,

  getInvoiceSettingsRequest,
  getInvoiceSettingsSuccess,
  getInvoiceSettingsFailure,

  updateInvoiceSettingsRequest,
  updateInvoiceSettingsSuccess,
  updateInvoiceSettingsFailure,

  getInvoiceOptionsSettingsRequest,
  getInvoiceOptionsSettingsSuccess,
  getInvoiceOptionsSettingsFailure,

  addInvoiceOptionRequest,
  addInvoiceOptionSuccess,
  addInvoiceOptionFailure,

  getPreviewInvoiceRequest,
  getPreviewInvoiceSuccess,
  getPreviewInvoiceFailure,

  getFilesRequest,
  getFilesSuccess,
  getFilesFailure,

  addFilesRequest,
  addFilesSuccess,
  addFilesFailure,

  getContactRequest,
  getContactSuccess,
  getContactFailure,

  addContactRequest,
  addContactSuccess,
  addContactFailure,

  getProjectTimeRequest,
  getProjectTimeSuccess,
  getProjectTimeFailure,

  addProjectTimeRequest,
  addProjectTimeSuccess,
  addProjectTimeFailure,

  getTaskListRequest,
  getTaskListSuccess,
  getTaskListFailure,

  addTaskRequest,
  addTaskSuccess,
  addTaskFailure,

  updateItemRequest,
  updateItemSuccess,
  updateItemFailure,

  deleteItemRequest,
  deleteItemSuccess,
  deleteItemFailure,

  updateInvoiceRequest,
  updateInvoiceSuccess,
  updateInvoiceFailure,

  deleteInvoiceRequest,
  deleteInvoiceSuccess,
  deleteInvoiceFailure,

  updateAppointmentRequest,
  updateAppointmentSuccess,
  updateAppointmentFailure,

  updateContactRequest,
  updateContactSuccess,
  updateContactFailure,

  deleteContactRequest,
  deleteContactSuccess,
  deleteContactFailure,

  updateTaskRequest,
  updateTaskSuccess,
  updateTaskFailure,

  deleteTaskRequest,
  deleteTaskSuccess,
  deleteTaskFailure,

  deleteAppointmentRequest,
  deleteAppointmentSuccess,
  deleteAppointmentFailure,

  addEstimateRequest,
  addEstimateSuccess,
  addEstimateFailure,

  getEstimateRequest,
  getEstimateSuccess,
  getEstimateFailure,

  updateEstimateRequest,
  updateEstimateSuccess,
  updateEstimateFailure,

  deleteEstimateRequest,
  deleteEstimateSuccess,
  deleteEstimateFailure,

  getAllTimesRequest,
  getAllTimesSuccess,
  getAllTimesFailure,

  getPurchaseOrderRequest,
  getPurchaseOrderSuccess,
  getPurchaseOrderFailure,

  addPurchaseOrderRequest,
  addPurchaseOrderSuccess,
  addPurchaseOrderFailure,

  getInvoicePreviewRequest,
  getInvoicePreviewSuccess,
  getInvoicePreviewFailure,

  updatePoRequest,
  updatePoSuccess,
  updatePoFailure,

  deletePoRequest,
  deletePoSuccess,
  deletePoFailure,

  getPoDetailsRequest,
  getPoDetailsSuccess,
  getPoDetailsFailure,

  getCreditNoteListRequest,
  getCreditNoteListSuccess,
  getCreditNoteListFailure,

  addCreditNoteRequest,
  addCreditNoteSuccess,
  addCreditNoteFailure,

  updateCreditNoteRequest,
  updateCreditNoteSuccess,
  updateCreditNoteFailure,

  deleteCreditNoteRequest,
  deleteCreditNoteSuccess,
  deleteCreditNoteFailure,

  addCustomTimeRequest,
  addCustomTimeSuccess,
  addCustomTimeFailure,

  addCustomLogoRequest,
  addCustomLogoSuccess,
  addCustomLogoFailure,

  addCustomHeaderRequest,
  addCustomHeaderSuccess,
  addCustomHeaderFailure,

  addCustomWaterRequest,
  addCustomWaterSuccess,
  addCustomWaterFailure,

  getCustomLogoRequest,
  getCustomLogoSuccess,
  getCustomLogoFailure,

  getCustomHeaderRequest,
  getCustomHeaderSuccess,
  getCustomHeaderFailure,

  getCustomWaterMarkRequest,
  getCustomWaterMarkSuccess,
  getCustomWaterMarkFailure,

  createCustomTemplateRequest,
  createCustomTemplateSuccess,
  createCustomTemplateFailure,

  getEstimateDetailsRequest,
  getEstimateDetailsSuccess,
  getEstimateDetailsFailure,

  getCreditNoteDetailsRequest,
  getCreditNoteDetailsSuccess,
  getCreditNoteDetailsFailure,

  verifyOtpRequest,
  verifyOtpSuccess,
  verifyOtpFailure,

  resendOtpRequest,
  resendOtpSuccess,
  resendOtpFailure,

  projectDeleteRequest,
  projectDeleteSuccess,
  projectDeleteFailure,

  getClientWiseProjectRequest,
  getClientWiseProjectSuccess,
  getClientWiseProjectFailure,

  addNewExpenseRequest,
  addNewExpenseSuccess,
  addNewExpenseFailure,

  getExpenseListRequest,
  getExpenseListSuccess,
  getExpenseListFailure,

  deleteExpenseRequest,
  deleteExpenseSuccess,
  deleteExpenseFailure,

  updateExpenseRequest,
  updateExpenseSuccess,
  updateExpenseFailure,

  getAppointmentContactsRequest,
  getAppointmentContactsSuccess,
  getAppointmentContactsFailure,

  getProfileStatusRequest,
  getProfileStatusSuccess,
  getProfileStatusFailure,

  addSignatureSettingsRequest,
  addSignatureSettingsSuccess,
  addSignatureSettingsFailure,

  getSignatureDetailsRequest,
  getSignatureDetailsSuccess,
  getSignatureDetailsFailure
  
} = ProfileSlice.actions;
export default ProfileSlice.reducer;
