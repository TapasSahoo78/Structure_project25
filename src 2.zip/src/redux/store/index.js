import {configureStore} from '@reduxjs/toolkit';
import createSagaMiddleware from 'redux-saga';
import {logger} from 'redux-logger';
import RootSaga from '../../saga/RootSaga';
import ProfileReducer from '../reducer/ProfileReducer';

let sagaMiddleware = createSagaMiddleware();

export default configureStore({
  reducer: {
    ProfileReducer: ProfileReducer,
  },
  middleware: () => {
    // WARNING: this means that _none_ of the default middleware are added!
    return [sagaMiddleware, logger];
    // or for TS users, use:
    // return new Tuple(myMiddleware)
  },
});

sagaMiddleware.run(RootSaga);
