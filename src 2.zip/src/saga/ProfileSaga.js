import {call, put, select, takeLatest} from 'redux-saga/effects';

import {
  tokenSuccess,
  tokenFailure,
  tokenRequest,
  registrationRequest,
  registrationSuccess,
  registrationFailure,
  loginRequest,
  loginSuccess,
  loginFailure,
  addBusinessDetailsRequest,
  addBusinessDetailsSuccess,
  addBusinessDetailsFailure,
  getProfileRequest,
  getProfileSuccess,
  getProfileFailure,
  sendVerificationCodeRequest,
  sendVerificationCodeSuccess,
  sendVerificationCodeFailure,
  resetPasswordRequest,
  resetPasswordSuccess,
  resetPasswordFailure,
  getSubscriptionRequest,
  getSubscriptionSuccess,
  getSubscriptionFailure,
  addSubscriptionRequest,
  addSubscriptionSuccess,
  addSubscriptionFailure,
  addClientRequest,
  addClientSuccess,
  addClientFailure,
  getClientRequest,
  getClientSuccess,
  getClientFailure,
  getCommonListRequest,
  getCommonListSuccess,
  getCommonListFailure,
  getClientDetailsRequest,
  getClientDetailsSuccess,
  getClientDetailsFailure,
  editClientRequest,
  editClientSuccess,
  editClientFailure,
  getCountryListRequest,
  getCountryListSuccess,
  getCountryListFailure,
  addTaxCurrencyRequest,
  addTaxCurrencySuccess,
  addTaxCurrencyFailure,
  addAppointmentRequest,
  addAppointmentSuccess,
  addAppointmentFailure,
  getAppointmentListRequest,
  getAppointmentListSuccess,
  getAppointmentListFailure,
  projectCreateRequest,
  projectCreateSuccess,
  projectCreateFailure,
  projectListRequest,
  projectListSuccess,
  projectListFailure,
  projectDetailRequest,
  projectDetailSuccess,
  projectDetailFailure,
  projectUpdateRequest,
  projectUpdateSuccess,
  projectUpdateFailure,
  noteCreateRequest,
  noteCreateSuccess,
  noteCreateFailure,
  addItemsRequest,
  addItemsSuccess,
  addItemsFailure,
  getItemsListReqest,
  getItemsListSuccess,
  getItemsListFailure,
  logoutRequest,
  logoutSuccess,
  invoiceCreateRequest,
  invoiceCreateSuccess,
  invoiceCreateFailure,
  invoiceListRequest,
  invoiceListSuccess,
  invoiceListFailure,
  invoiceDetailSuccess,
  invoiceDetailFailure,
  invoiceDetailRequest,
  invoiceDeletelRequest,
  invoiceDeleteSuccess,
  invoiceDeleteFailure,
  deleteClientRequest,
  getMyClientDetailsRequest,
  deleteClientSuccess,
  deleteClientFailure,
  getMyClientDetailsSuccess,
  getMyClientDetailsFailure,
  getRoleListRequest,
  getRoleListSuccess,
  getRoleListFailure,
  addAccountRequest,
  addAccountSuccess,
  addAccountFailure,
  accountListRequest,
  accountListSuccess,
  accountListFailure,
  getClientCommDetailsRequest,
  getClientCommDetailsSuccess,
  getClientCommDetailsFailure,
  updateClientCommRequest,
  updateClientCommSuccess,
  updateClientCommFailure,
  roleUpdateRequest,
  roleDeleteRequest,
  roleCreateRequest,
  projectSettingsRequest,
  projectSettingsDetailRequest,
  swtchAccountRequest,
  roleUpdateFailure,
  roleUpdateSuccess,
  roleCreateFailure,
  roleDeleteFailure,
  roleDeleteSuccess,
  roleCreateSuccess,
  projectSettingsFailure,
  projectSettingsSuccess,
  projectSettingsDetailFailure,
  projectSettingsDetailSuccess,
  swtchAccountFailure,
  swtchAccountSuccess,
  getInvoiceTemplateRequest,
  getInvoiceTemplateSuccess,
  getInvoiceTemplateFailure,
  createLogoRequest,
  createLogoSuccess,
  createLogoFailure,
  getLogoRequest,
  getLogoSuccess,
  getLogoFailure,
  updateProfileRequest,
  updateProfileSuccess,
  updateProfileFailure,
  getColourListRequest,
  getColourListSuccess,
  getColourListFailure,
  getWaterMarkListRequest,
  getWaterMarkListSuccess,
  getWaterMarkListFailure,
  getHeaderListRequest,
  getHeaderListSuccess,
  getHeaderListFailure,
  addInvoiceDesignRequest,
  addInvoiceDesignSuccess,
  addInvoiceDesignFailure,
  getInvoiceSettingsRequest,
  getInvoiceSettingsSuccess,
  getInvoiceSettingsFailure,
  updateInvoiceSettingsRequest,
  updateInvoiceSettingsSuccess,
  updateInvoiceSettingsFailure,
  getInvoiceOptionsSettingsRequest,
  getInvoiceOptionsSettingsSuccess,
  getInvoiceOptionsSettingsFailure,
  addInvoiceOptionRequest,
  addInvoiceOptionSuccess,
  addInvoiceOptionFailure,
  getPreviewInvoiceRequest,
  getPreviewInvoiceSuccess,
  getPreviewInvoiceFailure,
  getFilesRequest,
  getFilesSuccess,
  getFilesFailure,
  addFilesRequest,
  addFilesSuccess,
  addFilesFailure,
  getContactRequest,
  getContactSuccess,
  getContactFailure,
  addContactRequest,
  addContactSuccess,
  addContactFailure,
  getProjectTimeRequest,
  getProjectTimeSuccess,
  getProjectTimeFailure,
  addProjectTimeRequest,
  addProjectTimeSuccess,
  addProjectTimeFailure,
  getTaskListRequest,
  getTaskListSuccess,
  getTaskListFailure,
  addTaskRequest,
  addTaskSuccess,
  addTaskFailure,
  updateItemRequest,
  updateItemSuccess,
  updateItemFailure,
  deleteItemRequest,
  deleteItemSuccess,
  deleteItemFailure,
  updateInvoiceRequest,
  updateInvoiceSuccess,
  updateInvoiceFailure,
  deleteInvoiceRequest,
  deleteInvoiceSuccess,
  deleteInvoiceFailure,
  updateAppointmentRequest,
  updateAppointmentSuccess,
  updateAppointmentFailure,
  updateContactRequest,
  updateContactSuccess,
  updateContactFailure,
  deleteContactRequest,
  deleteContactSuccess,
  deleteContactFailure,
  updateTaskRequest,
  updateTaskSuccess,
  updateTaskFailure,
  deleteTaskRequest,
  deleteTaskSuccess,
  deleteTaskFailure,
  deleteAppointmentRequest,
  deleteAppointmentSuccess,
  deleteAppointmentFailure,
  addEstimateRequest,
  addEstimateSuccess,
  addEstimateFailure,
  getEstimateRequest,
  getEstimateSuccess,
  getEstimateFailure,
  updateEstimateRequest,
  updateEstimateSuccess,
  updateEstimateFailure,
  deleteEstimateSuccess,
  deleteEstimateFailure,
  deleteEstimateRequest,
  getAllTimesRequest,
  getAllTimesSuccess,
  getAllTimesFailure,
  getPurchaseOrderRequest,
  getPurchaseOrderSuccess,
  getPurchaseOrderFailure,
  addPurchaseOrderRequest,
  addPurchaseOrderSuccess,
  addPurchaseOrderFailure,
  getInvoicePreviewRequest,
  getInvoicePreviewSuccess,
  getInvoicePreviewFailure,
  updatePoRequest,
  updatePoSuccess,
  updatePoFailure,
  deletePoRequest,
  deletePoSuccess,
  deletePoFailure,
  getPoDetailsRequest,
  getPoDetailsSuccess,
  getPoDetailsFailure,
  getCreditNoteListRequest,
  getCreditNoteListSuccess,
  getCreditNoteListFailure,
  addCreditNoteRequest,
  addCreditNoteSuccess,
  addCreditNoteFailure,
  updateCreditNoteRequest,
  updateCreditNoteSuccess,
  updateCreditNoteFailure,
  deleteCreditNoteRequest,
  deleteCreditNoteSuccess,
  deleteCreditNoteFailure,
  addCustomTimeRequest,
  addCustomTimeSuccess,
  addCustomTimeFailure,
  addCustomLogoRequest,
  addCustomLogoSuccess,
  addCustomLogoFailure,
  addCustomHeaderRequest,
  addCustomHeaderSuccess,
  addCustomHeaderFailure,
  addCustomWaterRequest,
  addCustomWaterSuccess,
  addCustomWaterFailure,
  getCustomLogoRequest,
  getCustomLogoSuccess,
  getCustomLogoFailure,
  getCustomHeaderRequest,
  getCustomHeaderSuccess,
  getCustomHeaderFailure,
  getCustomWaterMarkRequest,
  getCustomWaterMarkSuccess,
  getCustomWaterMarkFailure,
  createCustomTemplateRequest,
  createCustomTemplateSuccess,
  createCustomTemplateFailure,
  getEstimateDetailsRequest,
  getEstimateDetailsSuccess,
  getEstimateDetailsFailure,
  getCreditNoteDetailsRequest,
  getCreditNoteDetailsSuccess,
  getCreditNoteDetailsFailure,
  verifyOtpRequest,
  verifyOtpSuccess,
  verifyOtpFailure,
  resendOtpRequest,
  resendOtpSuccess,
  resendOtpFailure,
  projectDeleteRequest,
  projectDeleteSuccess,
  projectDeleteFailure,
  getClientWiseProjectRequest,
  getClientWiseProjectSuccess,
  getClientWiseProjectFailure,
  addNewExpenseRequest,
  addNewExpenseSuccess,
  addNewExpenseFailure,
  getExpenseListRequest,
  getExpenseListSuccess,
  getExpenseListFailure,
  deleteExpenseRequest,
  deleteExpenseSuccess,
  deleteExpenseFailure,
  updateExpenseRequest,
  updateExpenseSuccess,
  updateExpenseFailure,
  getAppointmentContactsRequest,
  getAppointmentContactsSuccess,
  getAppointmentContactsFailure,
  getProfileStatusRequest,
  getProfileStatusSuccess,
  getProfileStatusFailure,
  addSignatureSettingsRequest,
  addSignatureSettingsSuccess,
  addSignatureSettingsFailure,
  getSignatureDetailsRequest,
  getSignatureDetailsSuccess,
  getSignatureDetailsFailure

} from '../redux/reducer/ProfileReducer';
import {deleteApi, getApi, postApi, putApi} from '../utils/helpers/ApiRequest';
import {goBack, navigate, replace} from '../utils/helpers/RootNaivgation';
import Toast from '../utils/helpers/Toast';
import _ from 'lodash';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {Alert} from 'react-native';
import constants from '../utils/helpers/constants';
const getItems = state => state.ProfileReducer;
export function* tokenSaga() {
  try {
    let creds = yield call(AsyncStorage.getItem, constants?.TOKEN);
    console.log('creds', creds);
    // if (JSON.parse(creds).token != null) {
    yield put(tokenSuccess(JSON.parse(creds)));
    // } else {
    //   yield put(tokenSuccess(null));
    // }
  } catch (error) {
    console.log(error);
    yield put(tokenFailure(error));
  }
}

export function* registrationRequestSaga(action) {
  // const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
  };

  try {
    let response = yield call(
      postApi,
      `clients/client-register`,
      action?.payload,
      header,
    );

    console.log('register response', response.data);
    if (response.data.status) {
      yield call(
        AsyncStorage.setItem,
        constants?.TOKEN,
        JSON.stringify({
          token: response?.data?.data?.deviceToken,
          is_first_time_user: '0',
        }),
      );
      yield put(
        tokenSuccess({
          token: response?.data?.data?.deviceToken,
          is_first_time_user: '0',
        }),
      );
      // Toast(response.data.message);
      yield put(registrationSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(registrationFailure(response.data));
    }
  } catch (error) {
    console.log(error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else {
      Toast('Something went wrong');
    }
    yield put(registrationFailure(error?.response ? error?.response : error));
  }
}

export function* loginRequestSaga(action) {
  // const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
  };

  try {
    let response = yield call(
      postApi,
      `clients/client-login`,
      action?.payload,
      header,
    );

    console.log(response);
    yield call(
      AsyncStorage.setItem,
      constants?.TOKEN,
      JSON.stringify({
        token: response?.data?.data?.deviceToken,
        is_first_time_user: '0',
        is_company_created: String(
          response?.data?.data?.user?.isCompanyCreated,
        ),
      }),
    );
    yield put(
      tokenSuccess({
        token: response?.data?.data?.deviceToken,
        is_first_time_user: '0',
        is_company_created: String(
          response?.data?.data?.user?.isCompanyCreated,
        ),
      }),
    );
    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(loginSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(loginFailure(response.data));
    }
  } catch (error) {
    console.log(error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else {
      Toast('Something went wrong');
    }
    yield put(loginFailure(error?.response ? error?.response : error));
  }
}

export function* addBusinessDetailsRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `clients/create-profile`,
      action?.payload,
      header,
    );

    console.log('response form add business', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield call(
        AsyncStorage.setItem,
        constants?.TOKEN,
        JSON.stringify({
          token: items.token,
          is_first_time_user: '0',
          is_company_created: 'true',
        }),
      );
      // yield put(
      //   tokenSuccess({
      //     token: items.token,
      //     is_first_time_user: '0',
      //     is_company_created:'true'
      //   }),
      // );
      yield put(addBusinessDetailsSuccess(response?.data?.data));
      navigate('Subscription');
    } else {
      Toast(response.data.message);
      yield put(addBusinessDetailsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      addBusinessDetailsFailure(error?.response ? error?.response : error),
    );
  }
}

export function* getProfileRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  console.log('abc', items.token);

  try {
    let response = yield call(
      postApi,
      `clients/client-profile`,
      action?.payload,
      header,
    );

    console.log('response form profile data', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      console.log('ssss', response?.data?.data);
      yield put(getProfileSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(getProfileFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      // Toast('Something went wrong');
    }
    yield put(getProfileFailure(error?.response ? error?.response : error));
  }
}
export function* sendVerificationCodeRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //token:items.token
  };

  try {
    let response = yield call(
      postApi,
      `clients/verification-code-generate`,
      action?.payload,
      header,
    );

    console.log('response form send verification', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(sendVerificationCodeSuccess(response?.data?.data));
      //navigate('ForgotPasswordOtp');
      navigate('SendOtp');
    } else {
      Toast(response.data.message);
      yield put(sendVerificationCodeFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      sendVerificationCodeFailure(error?.response ? error?.response : error),
    );
  }
}

export function* resendOtpRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //token:items.token
  };

  try {
    let response = yield call(
      postApi,
      `clients/verification-code-generate`,
      action?.payload,
      header,
    );

    console.log('response form send verification', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(resendOtpSuccess(response?.data?.data));
      //navigate('ForgotPasswordOtp');
      //navigate('SendOtp');
    } else {
      Toast(response.data.message);
      yield put(resendOtpFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      resendOtpFailure(error?.response ? error?.response : error),
    );
  }
}
export function* resetPasswordRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //token:items.token
  };

  try {
    let response = yield call(
      postApi,
      `clients/reset-password`,
      action?.payload,
      header,
    );

    console.log('response form reset password', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(resetPasswordSuccess(response?.data?.data));
      //navigate('ForgotPasswordOtp');
      navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(resetPasswordFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(resetPasswordFailure(error?.response ? error?.response : error));
  }
}
export function* getSubscriptionRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `common/get-plan-list`,
      action?.payload,
      header,
    );

    console.log('response form subscription', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getSubscriptionSuccess(response?.data?.data));
      //navigate('ForgotPasswordOtp');
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getSubscriptionFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getSubscriptionFailure(error?.response ? error?.response : error),
    );
  }
}
export function* addSubscriptionRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/buy-plan`,
      action?.payload,
      header,
    );

    console.log('response form add subscription', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(addSubscriptionSuccess(response?.data?.data));
      navigate('TabNav');
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(addSubscriptionFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      addSubscriptionFailure(error?.response ? error?.response : error),
    );
  }
}
export function* addClientRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    //contenttype: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/add-client`,
      action?.payload,
      header,
    );

    console.log('response form add client', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(addClientSuccess(response?.data?.data));
      goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(addClientFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addClientFailure(error?.response ? error?.response : error));
  }
}
export function* getClientRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, `main/clients`, action?.payload, header);

    console.log('response form get client', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getClientSuccess(response?.data?.data));

      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getClientFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getClientFailure(error?.response ? error?.response : error));
  }
}
export function* getCommonListRequestSaga() {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(getApi, `common/get-master-data`, header);

    console.log('response form get common', JSON.stringify(response.data));

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getCommonListSuccess(response?.data?.data));

      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getCommonListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCommonListFailure(error?.response ? error?.response : error));
  }
}
export function* getClientDetailsRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(getApi, action.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getClientDetailsSuccess(response?.data?.data));

      navigate('ClientDetail');
    } else {
      Toast(response.data.message);
      yield put(getClientDetailsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getClientDetailsFailure(error?.response ? error?.response : error),
    );
  }
}
export function* editClientRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    //contenttype: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      putApi,
      `main/client/${items.clientDetails.id}`,
      action?.payload,
      header,
    );

    console.log('response form edit client', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(editClientSuccess(response?.data?.data));
      goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(editClientFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      yield call(logoutRequestSaga);
      Toast('You have logged in with different devices');
    } else {
      Toast('Something went wrong');
    }
    yield put(editClientFailure(error?.response ? error?.response : error));
  }
}
export function* getCountryListRequestSaga() {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //token:items.token
  };

  try {
    let response = yield call(getApi, `get-country-list`, header);

    console.log(
      'response form get country list',
      JSON.stringify(response.data),
    );

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getCountryListSuccess(response?.data?.data));

      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getCountryListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wronggggg');
    }
    yield put(getCountryListFailure(error?.response ? error?.response : error));
  }
}
export function* addTaxCurrencyRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `clients/update-profile`,
      action?.payload,
      header,
    );

    console.log('response form add Tax and currency', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(addTaxCurrencySuccess(response?.data?.data));
      try {
        let res = yield call(postApi, `clients/client-profile`, {}, header);

        console.log('response form profile fetch', res.data);

        // Toast(response.data.message);
        if (res.data.status) {
          // Toast(response.data.message);
          console.log('ssss', res?.data?.data);
          yield put(getProfileSuccess(res?.data?.data));
        } else {
          Toast(res.data.message);
          yield put(getProfileFailure(res.data));
        }
      } catch (error) {
        console.log('Error: ', error?.response ? error?.response : error);
        if (error?.response?.status == 422) {
          Toast(error?.response?.data?.message);
        } else if (error?.response?.status == 401) {
          Toast('You have logged in with different devices');
          yield call(logoutRequestSaga);
        } else {
          Toast('Something went wrong');
        }
        yield put(getProfileFailure(error?.response ? error?.response : error));
      }

      goBack();
      //navigate("Subscription")
    } else {
      Toast(response.data.message);
      yield put(addTaxCurrencyFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else {
      Toast('Something went wrong');
    }
    yield put(addTaxCurrencyFailure(error?.response ? error?.response : error));
  }
}
export function* addAppointmentRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    //contenttype: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/add-appointment`,
      action?.payload,
      header,
    );

    console.log('response form add appointment', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(addAppointmentSuccess(response?.data?.data));
      goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(addAppointmentFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addAppointmentFailure(error?.response ? error?.response : error));
  }
}
export function* getAppointmentListRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/appointments`,
      action?.payload,
      header,
    );

    console.log('response form get appointment', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getAppointmentListSuccess(response?.data?.data));
      //goBack()
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getAppointmentListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getAppointmentListFailure(error?.response ? error?.response : error),
    );
  }
}
export function* projectCreateRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',

    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/add-project`,
      action?.payload,
      header,
    );

    console.log('response form add project', response.data);

    // Toast(response.data.message);
    if (response?.data?.status) {
      // Toast(response.data.message);
      yield put(projectCreateSuccess(response?.data?.data));
      goBack();
      //navigate('Login');
    } else {
      Toast(response?.data?.message);
      yield put(projectCreateFailure(response?.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(projectCreateFailure(error?.response ? error?.response : error));
  }
}
export function* getItemsListReqestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(postApi, `list-item`, action.payload, header);

    console.log('response form list items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getItemsListSuccess(response?.data?.data));
      //goBack()
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(getItemsListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getItemsListFailure(error?.response ? error?.response : error));
  }
}

export function* projectListRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/project-list`,
      action?.payload,
      header,
    );

    console.log('response form get project list', response.data);

    // Toast(response.data.message);
    if (response?.data?.status) {
      // Toast(response.data.message);
      yield put(projectListSuccess(response?.data?.data));
      // goBack();
      //navigate('Login');
    } else {
      Toast(response?.data?.message);
      yield put(projectListFailure(response?.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(projectListFailure(error?.response ? error?.response : error));
  }
}
export function* projectDetailRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/project-details`,
      action?.payload,
      header,
    );

    console.log('response form get project details', response.data);

    // Toast(response.data.message);
    if (response?.data?.status) {
      // Toast(response.data.message);
      yield put(projectDetailSuccess(response?.data?.data));
      // goBack();
      //navigate('Login');
    } else {
      Toast(response?.data?.message);
      yield put(projectDetailFailure(response?.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(projectDetailFailure(error?.response ? error?.response : error));
  }
}
export function* projectUpdateRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    // contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/update-project`,
      action?.payload,
      header,
    );

    console.log('response form update project', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      Toast(response.data.message);
      yield put(projectUpdateSuccess(response?.data?.data));
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(projectUpdateFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(projectUpdateFailure(error?.response ? error?.response : error));
  }
}
export function* noteCreateRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    // contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `main/update-project`,
      action?.payload,
      header,
    );

    console.log('response form update project', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      Toast(response.data.message);
      yield put(noteCreateSuccess(response?.data?.data));
      yield call(projectDetailRequestSaga, action);
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(noteCreateFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(noteCreateFailure(error?.response ? error?.response : error));
  }
}
export function* addItemsRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(postApi, `create-item`, action?.payload, header);

    console.log('response form add items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(addItemsSuccess(response?.data?.data));
      if (action?.payload?.listingRequired) navigate('OtherItem');
      //goBack()
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(addItemsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addItemsFailure(error?.response ? error?.response : error));
  }
}
export function* logoutRequestSaga() {
  try {
    // yield call(AsyncStorage.removeItem, constants?.TOKEN);
    yield call(
      AsyncStorage.setItem,
      constants?.TOKEN,
      JSON.stringify({
        token: null,
        is_first_time_user: '0',
      }),
    );
    yield put(logoutSuccess());
    navigate('Login');
  } catch (error) {
    console.log('Error: ', error);
  }
}
export function* invoiceCreateRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      `create-invoice`,
      action?.payload,
      header,
    );

    console.log('response form add items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(invoiceCreateSuccess(response?.data?.data));
      // navigate('OtherItem');
      goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(invoiceCreateFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(invoiceCreateFailure(error?.response ? error?.response : error));
  }
}
export function* invoiceListRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };
  console.log(header);
  try {
    let response = yield call(postApi, `invoice-list`, action?.payload, header);

    console.log('response form add items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(invoiceListSuccess(response?.data?.data));
      // navigate('OtherItem');
      // goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(invoiceListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(invoiceListFailure(error?.response ? error?.response : error));
  }
}
export function* invoiceDetailRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };
  console.log(header);
  try {
    let response = yield call(
      postApi,
      `invoice-details`,
      action?.payload,
      header,
    );

    console.log('response form add items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(invoiceDetailSuccess(response?.data?.data));
      // navigate('OtherItem');
      // goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(invoiceDetailFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(invoiceDetailFailure(error?.response ? error?.response : error));
  }
}
export function* invoiceDeletelRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //contenttype: 'multipart/form-data',
    token: items.token,
  };
  console.log(header);
  try {
    let response = yield call(
      postApi,
      `delete-invoice`,
      action?.payload,
      header,
    );

    console.log('response form add items', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(invoiceDeleteSuccess(response?.data?.data));
      // navigate('OtherItem');
      goBack();
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(invoiceDeleteFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(invoiceDeleteFailure(error?.response ? error?.response : error));
  }
}
export function* deleteClientRequestSaga(action) {
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    // contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      deleteApi,
      `main/client/${action.payload.id}`,
      //action?.payload,
      header,
    );

    console.log('response form delete client', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      Toast(response.data.message);
      yield put(deleteClientSuccess(response?.data?.data));
      // yield call(getClientRequestSaga);
      //navigate('Login');
    } else {
      Toast(response.data.message);
      yield put(deleteClientFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteClientFailure(error?.response ? error?.response : error));
  }
}

export function* getMyClientDetailsRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(getApi, action.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getMyClientDetailsSuccess(response?.data?.data));

      navigate('EditClient');
    } else {
      Toast(response.data.message);
      yield put(getMyClientDetailsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getMyClientDetailsFailure(error?.response ? error?.response : error),
    );
  }
}

export function* getRoleListRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'role-list', action.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      // Toast(response.data.message);
      yield put(getRoleListSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(getRoleListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getRoleListFailure(error?.response ? error?.response : error));
  }
}

export function* addAccountRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'create-account',
      action.payload,
      header,
    );

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      Toast(response.data.message);
      yield put(addAccountSuccess(response?.data?.data));
      goBack();
    } else {
      Toast(response.data.message);
      yield put(addAccountFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addAccountFailure(error?.response ? error?.response : error));
  }
}

export function* accountListRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'account-list', action.payload, header);

    console.log('response form get client details', response.data);

    if (response.data.status) {
      yield put(accountListSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(accountListFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(accountListFailure(error?.response ? error?.response : error));
  }
}

export function* getClientCommDetailsRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'clients/details-communication-settings',
      action.payload,
      header,
    );

    console.log(
      'response form get client communication details',
      response.data,
    );

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(getClientCommDetailsSuccess(response?.data?.data));
      navigate('ClientCommunication');
    } else {
      Toast(response.data.message);
      yield put(getClientCommDetailsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getClientCommDetailsFailure(error?.response ? error?.response : error),
    );
  }
}
export function* updateClientCommRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'clients/update-communication-settings',
      action.payload,
      header,
    );

    console.log(
      'response form update client communication details',
      response.data,
    );

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(updateClientCommSuccess(response?.data?.data));
      //navigate("ClientCommunication")
      goBack();
    } else {
      Toast(response.data.message);
      yield put(updateClientCommFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      updateClientCommFailure(error?.response ? error?.response : error),
    );
  }
}

export function* switchAccountRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'switch-accounts',
      action.payload,
      header,
    );

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(swtchAccountSuccess(response?.data?.data));
      yield call(
        AsyncStorage.setItem,
        constants?.TOKEN,
        JSON.stringify({
          token: response?.data?.data?.token,
          is_first_time_user: '0',
        }),
      );
      yield put(
        tokenSuccess({
          token: response?.data?.data?.token,
          is_first_time_user: '0',
        }),
      );
    } else {
      Toast(response.data.message);
      yield put(swtchAccountFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(swtchAccountFailure(error?.response ? error?.response : error));
  }
}

export function* projectSettingsDetailRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'clients/details-project-settings',
      action?.payload,
      header,
    );

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(projectSettingsDetailSuccess(response?.data?.data));
    } else {
      Toast(response.data.message);
      yield put(projectSettingsDetailFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      projectSettingsDetailFailure(error?.response ? error?.response : error),
    );
  }
}

export function* projectSettingsRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'clients/update-project-settings',
      action?.payload,
      header,
    );

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(projectSettingsSuccess(response?.data?.data));
      Toast(response.data.message);
      goBack();
    } else {
      Toast(response.data.message);
      yield put(projectSettingsFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      projectSettingsFailure(error?.response ? error?.response : error),
    );
  }
}

export function* roleCreateRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'create-role', action?.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(roleCreateSuccess(response?.data?.data));
      Toast(response.data.message);
      goBack();
    } else {
      Toast(response.data.message);
      yield put(roleCreateFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(roleCreateFailure(error?.response ? error?.response : error));
  }
}

export function* roleDeleteRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'role-delete', action?.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(roleDeleteSuccess(response?.data?.data));
      Toast(response.data.message);
      yield call(getRoleListRequestSaga, action?.payload);
    } else {
      Toast(response.data.message);
      yield put(roleDeleteFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(roleCreateFailure(error?.response ? error?.response : error));
  }
}

export function* roleUpdateRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'role-update', action?.payload, header);

    console.log('response form get client details', response.data);

    // Toast(response.data.message);
    if (response.data.status) {
      yield put(roleUpdateSuccess(response?.data?.data));
      Toast(response.data.message);
      goBack();
    } else {
      Toast(response.data.message);
      yield put(roleUpdateFailure(response.data));
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(roleUpdateFailure(error?.response ? error?.response : error));
  }
}

export function* getInvoiceTemplateRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'get-invoice', action?.payload, header);

    console.log('response form get client details', response.data);
    yield put(getInvoiceTemplateSuccess(response?.data));
    // Toast(response.data.message);
    navigate('InvoiceWebview');
    // Toast(response.data.message);
    // if (response.data.status) {
    //   yield put(getInvoiceTemplateSuccess(response?.data));
    //   Toast(response.data.message);
    //   navigate('InvoiceWebview');
    // } else {
    //   Toast(response.data.message);
    //   yield put(getInvoiceTemplateFailure(response.data));
    // }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(
      getInvoiceTemplateFailure(error?.response ? error?.response : error),
    );
  }
}

export function* createLogoRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'create-logo', action?.payload, header);

    console.log('response form get client details', response.data);
    yield put(createLogoSuccess(response?.data));
    yield call(getLogoRequestSaga);
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(createLogoFailure(error?.response ? error?.response : error));
  }
}

export function* getLogoRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'logo-list', action?.payload, header);

    console.log('response form get client details', response.data);
    yield put(getLogoSuccess(response?.data?.data));
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getLogoFailure(error?.response ? error?.response : error));
  }
}

export function* updateProfileRequestSaga(action) {
  console.log(action.payload);
  const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(
      postApi,
      'clients/update-client-profile',
      action?.payload,
      header,
    );

    console.log('response form get client details', response.data);
    Toast(response?.data?.message);
    yield put(updateProfileSuccess(response?.data?.data));
    yield call(getProfileRequestSaga, action?.payload);
    goBack();
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateProfileFailure(error?.response ? error?.response : error));
  }
}

export function* getColourListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'colour-list', action?.payload, header);

    console.log('response form Colour list', response.data);
    yield put(getColourListSuccess(response?.data?.data));
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getColourListFailure(error?.response ? error?.response : error));
  }
}

export function* getWaterMarkListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'water-mark-list', action?.payload, header);

    //console.log('response form water mark', response.data);
    yield put(getWaterMarkListSuccess(response?.data?.data));
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getWaterMarkListFailure(error?.response ? error?.response : error));
  }
}

export function* getHeaderListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'header-list', action?.payload, header);

    console.log('response form header list', response.data);
    yield put(getHeaderListSuccess(response?.data?.data));
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getHeaderListFailure(error?.response ? error?.response : error));
  }
}

export function* addInvoiceDesignRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'get-invoice', action?.payload, header);

    console.log('response from add invoice design', response.data);
    yield put(addInvoiceDesignSuccess(response?.data?.data));
    //goBack()
    navigate("InvoiceWebview")
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addInvoiceDesignFailure(error?.response ? error?.response : error));
  }
}

export function* getInvoiceSettingsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'get-invoice-setting', action?.payload, header);

    console.log('response from add invoice design', response.data);
    yield put(getInvoiceSettingsSuccess(response?.data?.data));
    //goBack()
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      //Toast(error?.response?.data?.message);
      console.log(error?.response?.data?.message)
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      //Toast('Something went wrong');
    }
    yield put(getInvoiceSettingsFailure(error?.response ? error?.response : error));
  }
}

export function* updateInvoiceSettingsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'update-invoice-setting', action?.payload, header);

    console.log('response from update invoice design', response.data);
    yield put(updateInvoiceSettingsSuccess(response?.data?.data));
    //goBack()
    navigate("InvoiceWebview")
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateInvoiceSettingsFailure(error?.response ? error?.response : error));
  }
}

// export function* addInvoiceDesignRequestSaga(action) {
  
//  const items = yield select(getItems);
//   let header = {
//     Accept: 'application/json',
//     contenttype: 'application/json',
//     token: items.token,
//   };

//   try {
//     let response = yield call(postApi, 'get-invoice', action?.payload, header);

//     console.log('response from add invoice design', response.data);
//     yield put(addInvoiceDesignSuccess(response?.data?.data));
//     goBack()
//   } catch (error) {
//     console.log('Error: ', error?.response ? error?.response : error);
//     if (error?.response?.status == 422) {
//       Toast(error?.response?.data?.message);
//     } else if (error?.response?.status == 401) {
//       Toast('You have logged in with different devices');
//       yield call(logoutRequestSaga);
//     } else {
//       Toast('Something went wrong');
//     }
//     yield put(addInvoiceDesignFailure(error?.response ? error?.response : error));
//   }
// }

export function* getInvoiceOptionsSettingsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'get-invoice-option-setting', action?.payload, header);

    console.log('response from invoice setting option', response.data);
    yield put(getInvoiceOptionsSettingsSuccess(response?.data?.data));
    //goBack()
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    }else if (error?.response?.status == 404) {
      //Toast(error?.response?.data?.message);
      
    } else {
      Toast('Something went wrong');
    }
    yield put(getInvoiceOptionsSettingsFailure(error?.response ? error?.response : error));
  }
}

export function* addInvoiceOptionRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'invoice-option-setting', action?.payload, header);

    console.log('response from invoice setting option add', response.data);
    yield put(addInvoiceOptionSuccess(response?.data?.data));
    //goBack()
    //navigate("InvoiceWebview")
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addInvoiceOptionFailure(error?.response ? error?.response : error));
  }
}

export function* getPreviewInvoiceRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'preview-invoice', action?.payload, header);

    console.log('response from invoice setting option add', response.data);
    yield put(getPreviewInvoiceSuccess(response?.data));
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getPreviewInvoiceFailure(error?.response ? error?.response : error));
  }
}

export function* getFilesRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };

  try {
    let response = yield call(postApi, 'main/get-files', action?.payload, header);

    console.log('response from get files', response.data);
    yield put(getFilesSuccess(response?.data?.data));
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getFilesFailure(error?.response ? error?.response : error));
  }
}

export function* addFilesRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  const formData = action.payload;
    // let projectId;
    // projectId = formData.get('projectId'); 

  try {
    let response = yield call(postApi, 'main/save-files', action?.payload?.body, header);

    console.log('response from add files', response.data);
    yield put(addFilesSuccess(response?.data));
    yield call(getFilesRequestSaga,{ payload: { projectId: action.payload.projectId } })
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addFilesFailure(error?.response ? error?.response : error));
  }
}

export function* getContactRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/get-contacts', action?.payload, header);

    console.log('response from get contact', response.data);
    yield put(getContactSuccess(response?.data?.data));
    
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getContactFailure(error?.response ? error?.response : error));
  }
}

export function* addContactRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/save-contact', action?.payload, header);

    console.log('response from add contact', response.data);
    yield put(addContactSuccess(response?.data?.data));
    yield call(getContactRequestSaga,{ payload: { client_id: action.payload.client_id } })
    
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addContactFailure(error?.response ? error?.response : error));
  }
}

export function* getProjectTimeRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/get-times', action?.payload, header);

    console.log('response from project time', response.data);
    yield put(getProjectTimeSuccess(response?.data?.data));
    
    
    
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getProjectTimeFailure(error?.response ? error?.response : error));
  }
}

export function* addProjectTimeRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/upsert-times', action?.payload, header);

    console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(addProjectTimeSuccess(response?.data?.data));
      yield call(getTaskListRequestSaga,{ payload: { projectId: action.payload.project_id } })
      Toast("Time added successfully")
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(addProjectTimeFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addProjectTimeFailure(error?.response ? error?.response : error));
  }
}
export function* addCustomTimeRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/upsert-times', action?.payload, header);

    console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(addCustomTimeSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{ payload: { projectId: action.payload.project_id } })
      yield call(getAllTimesRequestSaga,{payload:{id:action.payload.client_id}})
      Toast("Time added successfully")
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(addCustomTimeFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addCustomTimeFailure(error?.response ? error?.response : error));
  }
}

export function* getTaskListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/get-tasks', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(getTaskListSuccess(response?.data?.data));
    }else{
      Toast(response.data.message)
      yield put(getTaskListFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getTaskListFailure(error?.response ? error?.response : error));
  }
}

export function* addTaskRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/save-tasks', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(addTaskSuccess(response?.data?.data));
      yield call(getTaskListRequestSaga,{ payload: { projectId: action.payload.projectId } })
    }else{
      Toast(response.data.message)
      yield put(addTaskFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addTaskFailure(error?.response ? error?.response : error));
  }
}

export function* updateItemRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'update-item', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateItemSuccess(response?.data?.data));
      
      yield call(getItemsListReqestSaga,{payload:{}})
      
    }else{
      Toast(response.data.message)
      yield put(updateItemFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateItemFailure(error?.response ? error?.response : error));
  }
}

export function* deleteItemRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'delet-item', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteItemSuccess(response?.data?.data));
      
      yield call(getItemsListReqestSaga,{payload:{}})
      
    }else{
      Toast(response.data.message)
      yield put(deleteItemFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteItemFailure(error?.response ? error?.response : error));
  }
}

export function* updateInvoiceRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'update-invoice', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateInvoiceSuccess(response?.data?.data));
      
      goBack()
      
    }else{
      Toast(response.data.message)
      yield put(updateInvoiceFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateInvoiceFailure(error?.response ? error?.response : error));
  }
}

export function* deleteInvoiceRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'delete-invoice', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteInvoiceSuccess(response?.data?.data));

      yield call(invoiceListRequestSaga,{payload:{paymentStatus:"unpaid"}})
      
      
      
    }else{
      Toast(response.data.message)
      yield put(deleteInvoiceFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteInvoiceFailure(error?.response ? error?.response : error));
  }
}

export function* updateAppointmentRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/update-appointment', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateAppointmentSuccess(response?.data?.data));
      goBack()
    }else{
      Toast(response.data.message)
      yield put(updateAppointmentFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateAppointmentFailure(error?.response ? error?.response : error));
  }
}

export function* updateContactRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/update-contact', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateContactSuccess(response?.data?.data));
      yield call(getContactRequestSaga,{payload:{client_id:action.payload.client_id}})
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(updateContactFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateContactFailure(error?.response ? error?.response : error));
  }
}

export function* deleteContactRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/delete-contact', action?.payload?.body, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteContactSuccess(response?.data?.data));
      yield call(getContactRequestSaga,{payload:action.payload.cId})
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(deleteContactFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteContactFailure(error?.response ? error?.response : error));
  }
}

export function* updateTaskRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/update-task', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateTaskSuccess(response?.data?.data));
      yield call(getTaskListRequestSaga,{payload:{projectId:action.payload.projectId}})
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(updateTaskFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateTaskFailure(error?.response ? error?.response : error));
  }
}

export function* deleteTaskRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/delete-task', action?.payload?.body, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteTaskSuccess(response?.data?.data));
      yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(deleteTaskFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteTaskFailure(error?.response ? error?.response : error));
  }
}

export function* deleteAppointmentRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/delete-appointment', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteAppointmentSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      //goBack()
    }else{
      Toast(response.data.message)
      yield put(deleteAppointmentFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteAppointmentFailure(error?.response ? error?.response : error));
  }
}

export function* addEstimateRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'create-estimate', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(addEstimateSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      //goBack()
      navigate("Estimate")
    }else{
      Toast(response.data.message)
      yield put(addEstimateFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addEstimateFailure(error?.response ? error?.response : error));
  }
}

export function* getEstimateRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'estimate-list', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(getEstimateSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      //goBack()
      
    }else{
      Toast(response.data.message)
      yield put(getEstimateFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getEstimateFailure(error?.response ? error?.response : error));
  }
}

export function* updateEstimateRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'update-estimate', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(updateEstimateSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      goBack()
      
    }else{
      Toast(response.data.message)
      yield put(updateEstimateFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateEstimateFailure(error?.response ? error?.response : error));
  }
}

export function* deleteEstimateRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'delete-estimate', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(deleteEstimateSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
      yield call(getEstimateRequestSaga,{payload:{}})
      
      
      
    }else{
      Toast(response.data.message)
      yield put(deleteEstimateFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteEstimateFailure(error?.response ? error?.response : error));
  }
}

export function* getAllTimesRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'main/get-all-times', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(getAllTimesSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
     
      
      
      
    }else{
      Toast(response.data.message)
      yield put(getAllTimesFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getAllTimesFailure(error?.response ? error?.response : error));
  }
}

export function* getPurchaseOrderRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'purchase-order-list', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(getPurchaseOrderSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
     
      
      
      
    }else{
      Toast(response.data.message)
      yield put(getPurchaseOrderFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getPurchaseOrderFailure(error?.response ? error?.response : error));
  }
}

export function* addPurchaseOrderRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'create-purchase-order', action?.payload, header);

    //console.log('response from add project time', response.data);
    if(response.data.status){
      yield put(addPurchaseOrderSuccess(response?.data?.data));
      //yield call(getTaskListRequestSaga,{payload:action.payload.pId})
     
      navigate("PurchaseOrder")
      
      
    }else{
      Toast(response.data.message)
      yield put(addPurchaseOrderFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addPurchaseOrderFailure(error?.response ? error?.response : error));
  }
}

export function* getInvoicePreviewRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'invoice-preview', action?.payload, header);

    
    if(response.data){
      yield put(getInvoicePreviewSuccess(response?.data));
     
    }else{
      Toast(response.data.message)
      yield put(getInvoicePreviewFailure(response?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getInvoicePreviewFailure(error?.response ? error?.response : error));
  }
}

export function* updatePoRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'update-purchase-order', action?.payload, header);

    
    if(response.data.status){
      yield put(updatePoSuccess(response?.data?.data));
      goBack()
     
    }else{
      Toast(response.data.message)
      yield put(updatePoFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updatePoFailure(error?.response ? error?.response : error));
  }
}

export function* deletePoRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'delete-purchase-order', action?.payload, header);

    
    if(response.data.status){
      yield put(deletePoSuccess(response?.data?.data));

      yield call(getPurchaseOrderRequestSaga,{payload:{}})
      //goBack()
     
    }else{
      Toast(response.data.message)
      yield put(deletePoFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deletePoFailure(error?.response ? error?.response : error));
  }
}

export function* getPoDetailsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi, 'purchase-order-details', action?.payload, header);

    
    if(response.data.status){
      yield put(getPoDetailsSuccess(response?.data?.data));
      navigate("PurchaseOrderDetails")
      
      //goBack()
     
    }else{
      Toast(response.data.message)
      yield put(getPoDetailsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getPoDetailsFailure(error?.response ? error?.response : error));
  }
}

export function* getCreditNoteListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'credit-note-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getCreditNoteListSuccess(response?.data?.data));
      
      
      //goBack()
     
    }else{
      Toast(response.data.message)
      yield put(getCreditNoteListFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCreditNoteListFailure(error?.response ? error?.response : error));
  }
}

export function* addCreditNoteRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-credit-note', action?.payload, header);

    
    if(response.data.status){
      yield put(addCreditNoteSuccess(response?.data?.data));
      yield call(getCreditNoteListRequestSaga,{payload:{}})
      
      navigate("CreditNote")
      //goBack()
     
    }else{
      Toast(response.data.message)
      yield put(addCreditNoteFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addCreditNoteFailure(error?.response ? error?.response : error));
  }
}

export function* updateCreditNoteRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'update-credit-note', action?.payload, header);

    
    if(response.data.status){
      yield put(updateCreditNoteSuccess(response?.data?.data));
      yield call(getCreditNoteListRequestSaga,{payload:{}})
      
      
      goBack()
     
    }else{
      Toast(response.data.message)
      yield put(updateCreditNoteFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateCreditNoteFailure(error?.response ? error?.response : error));
  }
}

export function* deleteCreditNoteRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'delete-credit-note', action?.payload, header);

    
    if(response.data.status){
      yield put(deleteCreditNoteSuccess(response?.data?.data));
      yield call(getCreditNoteListRequestSaga,{payload:{}})
      
      
      
     
    }else{
      Toast(response.data.message)
      yield put(deleteCreditNoteFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteCreditNoteFailure(error?.response ? error?.response : error));
  }
}

// export function* deleteCreditNoteRequestSaga(action) {
  
//  const items = yield select(getItems);
//   let header = {
//     Accept: 'application/json',
//     contenttype: 'application/json',
//     token: items.token,
//   };
//   try {
//     let response = yield call(postApi,'delete-credit-note', action?.payload, header);

    
//     if(response.data.status){
//       yield put(deleteCreditNoteSuccess(response?.data?.data));
//       yield call(getCreditNoteListRequestSaga,{payload:{}})
      
      
      
     
//     }else{
//       Toast(response.data.message)
//       yield put(deleteCreditNoteFailure(response?.data?.data))
//     }
//   } catch (error) {
//     console.log('Error: ', error?.response ? error?.response : error);
//     if (error?.response?.status == 422) {
//       Toast(error?.response?.data?.message);
//     } else if (error?.response?.status == 401) {
//       Toast('You have logged in with different devices');
//       yield call(logoutRequestSaga);
//     } else {
//       Toast('Something went wrong');
//     }
//     yield put(deleteCreditNoteFailure(error?.response ? error?.response : error));
//   }
// }

export function* addCustomLogoRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-logo', action?.payload, header);

    
    if(response.data.status){
      yield put(addCustomLogoSuccess(response?.data?.data));
      //yield call(getCustomLogoRequestSaga,{payload:{}})
    }else{
      Toast(response.data.message)
      yield put(addCustomLogoFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addCustomLogoFailure(error?.response ? error?.response : error));
  }
}

export function* addCustomHeaderRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-header', action?.payload, header);

    
    if(response.data.status){
      yield put(addCustomHeaderSuccess(response?.data?.data));
      //yield call(getCustomHeaderRequestSaga,{payload:{}})
    }else{
      Toast(response.data.message)
      yield put(addCustomHeaderFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addCustomHeaderFailure(error?.response ? error?.response : error));
  }
}

export function* addCustomWaterRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-watermark', action?.payload, header);

    
    if(response.data.status){
      yield put(addCustomWaterSuccess(response?.data?.data));
      //yield call(getCustomWaterMarkRequestSaga,{payload:{}})
    }else{
      Toast(response.data.message)
      yield put(addCustomWaterFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addCustomWaterFailure(error?.response ? error?.response : error));
  }
}

export function* getCustomLogoRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'logo-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getCustomLogoSuccess(response?.data?.data));
    }else{
      Toast(response.data.message)
      yield put(getCustomLogoFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCustomLogoFailure(error?.response ? error?.response : error));
  }
}

export function* getCustomHeaderRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'header-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getCustomHeaderSuccess(response?.data?.data));
    }else{
      Toast(response.data.message)
      yield put(getCustomHeaderFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCustomHeaderFailure(error?.response ? error?.response : error));
  }
}

export function* getCustomWaterMarkRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'water-mark-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getCustomWaterMarkSuccess(response?.data?.data));
    }else{
      Toast(response.data.message)
      yield put(getCustomWaterMarkFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCustomWaterMarkFailure(error?.response ? error?.response : error));
  }
}

export function* createCustomTemplateRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-custom-template', action?.payload, header);

    
    if(response.data.status){
      yield put(createCustomTemplateSuccess(response?.data?.data));
    }else{
      Toast(response.data.message)
      yield put(createCustomTemplateFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(createCustomTemplateFailure(error?.response ? error?.response : error));
  }
}

export function* getEstimateDetailsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'estimate-details', action?.payload, header);

    
    if(response.data.status){
      yield put(getEstimateDetailsSuccess(response?.data?.data));
      navigate("EstimateDetails")
    }else{
      Toast(response.data.message)
      yield put(getEstimateDetailsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getEstimateDetailsFailure(error?.response ? error?.response : error));
  }
}

export function* getCreditNoteDetailsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'credit-note-details', action?.payload, header);

    
    if(response.data.status){
      yield put(getCreditNoteDetailsSuccess(response?.data?.data));
      navigate("CreditNoteDetails")
    }else{
      Toast(response.data.message)
      yield put(getCreditNoteDetailsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getCreditNoteDetailsFailure(error?.response ? error?.response : error));
  }
}

export function* verifyOtpRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    //token: items.token,
  };
  try {
    let response = yield call(postApi,'clients/verify-otp', action?.payload, header);

    
    if(response.data.status){
      yield put(verifyOtpSuccess(response?.data?.data));
      //navigate("CreditNoteDetails")
      navigate('ResetPassword',{otp:action.payload.otp});
    }else{
      Toast(response.data.message)
      yield put(verifyOtpFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(verifyOtpFailure(error?.response ? error?.response : error));
  }
}

export function* projectDeleteRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'main/delete-project', action?.payload, header);

    
    if(response.data.status){
      yield put(projectDeleteSuccess(response?.data?.data));
      yield call(projectListRequestSaga,{payload:{}})
      
    }else{
      Toast(response.data.message)
      yield put(projectDeleteFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(projectDeleteFailure(error?.response ? error?.response : error));
  }
}

export function* getClientWiseProjectRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'main/client-project-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getClientWiseProjectSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(getClientWiseProjectFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getClientWiseProjectFailure(error?.response ? error?.response : error));
  }
}

export function* addNewExpenseRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'create-expense', action?.payload, header);

    
    if(response.data.status){
      yield put(addNewExpenseSuccess(response?.data?.data));
      goBack()
      
    }else{
      Toast(response.data.message)
      yield put(addNewExpenseFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addNewExpenseFailure(error?.response ? error?.response : error));
  }
}

export function* getExpenseListRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'expense-list', action?.payload, header);

    
    if(response.data.status){
      yield put(getExpenseListSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(getExpenseListFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getExpenseListFailure(error?.response ? error?.response : error));
  }
}

export function* deleteExpenseRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'delete-expense', action?.payload, header);

    
    if(response.data.status){
      yield put(deleteExpenseSuccess(response?.data?.data));
      yield call(getExpenseListRequestSaga,{payload:{}})

     
      
    }else{
      Toast(response.data.message)
      yield put(deleteExpenseFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(deleteExpenseFailure(error?.response ? error?.response : error));
  }
}

export function* updateExpenseRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'multipart/form-data',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'expense-update', action?.payload, header);

    
    if(response.data.status){
      yield put(updateExpenseSuccess(response?.data?.data));
      goBack()
      
    }else{
      Toast(response.data.message)
      yield put(updateExpenseFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(updateExpenseFailure(error?.response ? error?.response : error));
  }
}

export function* getAppointmentContactsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'main/get-contacts-for-appointment', action?.payload, header);

    
    if(response.data.status){
      yield put(getAppointmentContactsSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(getAppointmentContactsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getAppointmentContactsFailure(error?.response ? error?.response : error));
  }
}

export function* getProfileStatusRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'dashboard', action?.payload, header);

    
    if(response.data.status){
      yield put(getProfileStatusSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(getProfileStatusFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getProfileStatusFailure(error?.response ? error?.response : error));
  }
}

export function* addSignatureSettingsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'invoice-signature-setting', action?.payload, header);

    
    if(response.data.status){
      yield put(addSignatureSettingsSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(addSignatureSettingsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(addSignatureSettingsFailure(error?.response ? error?.response : error));
  }
}

export function* getSignatureDetailsRequestSaga(action) {
  
 const items = yield select(getItems);
  let header = {
    Accept: 'application/json',
    contenttype: 'application/json',
    token: items.token,
  };
  try {
    let response = yield call(postApi,'get-invoice-signature', action?.payload, header);

    
    if(response.data.status){
      yield put(getSignatureDetailsSuccess(response?.data?.data));
     
      
    }else{
      Toast(response.data.message)
      yield put(getSignatureDetailsFailure(response?.data?.data))
    }
  } catch (error) {
    console.log('Error: ', error?.response ? error?.response : error);
    if (error?.response?.status == 422) {
      Toast(error?.response?.data?.message);
    } else if (error?.response?.status == 401) {
      Toast('You have logged in with different devices');
      yield call(logoutRequestSaga);
    } else {
      Toast('Something went wrong');
    }
    yield put(getSignatureDetailsFailure(error?.response ? error?.response : error));
  }
}


const watchFunction = [
  (function* () {
    yield takeLatest(updateProfileRequest.type, updateProfileRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getLogoRequest.type, getLogoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(createLogoRequest.type, createLogoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      getInvoiceTemplateRequest.type,
      getInvoiceTemplateRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(roleUpdateRequest.type, roleUpdateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(roleDeleteRequest.type, roleDeleteRequestSaga);
  })(),
  (function* () {
    yield takeLatest(roleCreateRequest.type, roleCreateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectSettingsRequest.type, projectSettingsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      projectSettingsDetailRequest.type,
      projectSettingsDetailRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(swtchAccountRequest.type, switchAccountRequestSaga);
  })(),
  (function* () {
    yield takeLatest(accountListRequest.type, accountListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addAccountRequest.type, addAccountRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getRoleListRequest.type, getRoleListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(invoiceDeletelRequest.type, invoiceDeletelRequestSaga);
  })(),
  (function* () {
    yield takeLatest(invoiceDetailRequest.type, invoiceDetailRequestSaga);
  })(),
  (function* () {
    yield takeLatest(invoiceListRequest.type, invoiceListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(invoiceCreateRequest.type, invoiceCreateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(logoutRequest.type, logoutRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addItemsRequest.type, addItemsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(noteCreateRequest.type, noteCreateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectUpdateRequest.type, projectUpdateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectDetailRequest.type, projectDetailRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectListRequest.type, projectListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectCreateRequest.type, projectCreateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(tokenRequest.type, tokenSaga);
  })(),
  (function* () {
    yield takeLatest(registrationRequest.type, registrationRequestSaga);
  })(),
  (function* () {
    yield takeLatest(loginRequest.type, loginRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      addBusinessDetailsRequest.type,
      addBusinessDetailsRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(getProfileRequest.type, getProfileRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      sendVerificationCodeRequest.type,
      sendVerificationCodeRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(resetPasswordRequest.type, resetPasswordRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getSubscriptionRequest.type, getSubscriptionRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addSubscriptionRequest.type, addSubscriptionRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addClientRequest.type, addClientRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getClientRequest.type, getClientRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCommonListRequest.type, getCommonListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getClientDetailsRequest.type, getClientDetailsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(editClientRequest.type, editClientRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCountryListRequest.type, getCountryListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addTaxCurrencyRequest.type, addTaxCurrencyRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addAppointmentRequest.type, addAppointmentRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      getAppointmentListRequest.type,
      getAppointmentListRequestSaga,
    );
  })(),

  (function* () {
    yield takeLatest(getItemsListReqest.type, getItemsListReqestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteClientRequest.type, deleteClientRequestSaga);
  })(),
  (function* () {
    yield takeLatest(
      getMyClientDetailsRequest.type,
      getMyClientDetailsRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(
      getClientCommDetailsRequest.type,
      getClientCommDetailsRequestSaga,
    );
  })(),
  (function* () {
    yield takeLatest(updateClientCommRequest.type, updateClientCommRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getColourListRequest.type, getColourListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getWaterMarkListRequest.type, getWaterMarkListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getHeaderListRequest.type, getHeaderListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addInvoiceDesignRequest.type, addInvoiceDesignRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getInvoiceSettingsRequest.type, getInvoiceSettingsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateInvoiceSettingsRequest.type, updateInvoiceSettingsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getInvoiceOptionsSettingsRequest.type, getInvoiceOptionsSettingsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addInvoiceOptionRequest.type, addInvoiceOptionRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getPreviewInvoiceRequest.type, getPreviewInvoiceRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getFilesRequest.type, getFilesRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addFilesRequest.type, addFilesRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getContactRequest.type, getContactRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addContactRequest.type, addContactRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getProjectTimeRequest.type, getProjectTimeRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addProjectTimeRequest.type, addProjectTimeRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getTaskListRequest.type, getTaskListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addTaskRequest.type, addTaskRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateItemRequest.type, updateItemRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteItemRequest.type, deleteItemRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateInvoiceRequest.type, updateInvoiceRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteInvoiceRequest.type, deleteInvoiceRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateAppointmentRequest.type, updateAppointmentRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateContactRequest.type, updateContactRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteContactRequest.type, deleteContactRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateTaskRequest.type, updateTaskRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteTaskRequest.type, deleteTaskRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteAppointmentRequest.type, deleteAppointmentRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addEstimateRequest.type, addEstimateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getEstimateRequest.type, getEstimateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateEstimateRequest.type, updateEstimateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteEstimateRequest.type, deleteEstimateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getAllTimesRequest.type, getAllTimesRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getPurchaseOrderRequest.type, getPurchaseOrderRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addPurchaseOrderRequest.type, addPurchaseOrderRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getInvoicePreviewRequest.type, getInvoicePreviewRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updatePoRequest.type, updatePoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deletePoRequest.type, deletePoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getPoDetailsRequest.type, getPoDetailsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCreditNoteListRequest.type, getCreditNoteListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addCreditNoteRequest.type, addCreditNoteRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateCreditNoteRequest.type, updateCreditNoteRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteCreditNoteRequest.type, deleteCreditNoteRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addCustomTimeRequest.type, addCustomTimeRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addCustomLogoRequest.type, addCustomLogoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addCustomHeaderRequest.type, addCustomHeaderRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addCustomWaterRequest.type, addCustomWaterRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCustomLogoRequest.type, getCustomLogoRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCustomHeaderRequest.type, getCustomHeaderRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCustomWaterMarkRequest.type, getCustomWaterMarkRequestSaga);
  })(),
  (function* () {
    yield takeLatest(createCustomTemplateRequest.type, createCustomTemplateRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getEstimateDetailsRequest.type, getEstimateDetailsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getCreditNoteDetailsRequest.type, getCreditNoteDetailsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(verifyOtpRequest.type, verifyOtpRequestSaga);
  })(),
  (function* () {
    yield takeLatest(resendOtpRequest.type, resendOtpRequestSaga);
  })(),
  (function* () {
    yield takeLatest(projectDeleteRequest.type, projectDeleteRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getClientWiseProjectRequest.type, getClientWiseProjectRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addNewExpenseRequest.type, addNewExpenseRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getExpenseListRequest.type, getExpenseListRequestSaga);
  })(),
  (function* () {
    yield takeLatest(deleteExpenseRequest.type, deleteExpenseRequestSaga);
  })(),
  (function* () {
    yield takeLatest(updateExpenseRequest.type, updateExpenseRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getAppointmentContactsRequest.type, getAppointmentContactsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getProfileStatusRequest.type, getProfileStatusRequestSaga);
  })(),
  (function* () {
    yield takeLatest(addSignatureSettingsRequest.type, addSignatureSettingsRequestSaga);
  })(),
  (function* () {
    yield takeLatest(getSignatureDetailsRequest.type, getSignatureDetailsRequestSaga);
  })(),
];

export default watchFunction;
