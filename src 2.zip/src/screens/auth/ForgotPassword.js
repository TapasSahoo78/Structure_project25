import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {goBack, navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import {useDispatch} from 'react-redux';
import {sendVerificationCodeRequest} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
//import Header from '../../components/Header';
import FormHeader from '../../components/FormHeader';
import TextInputItem from '../../components/TextInputItem';
//import { goBack } from '../../utils/helpers/RootNaivgation';

export default function ForgotPassword() {
  const dispatch = useDispatch();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {}, []);

  const checkValidation = () => {
    if (email == '') {
      Toast('Enter email');
    } else if (!constants.EMAIL_REGEX.test(email)) {
      Toast('Enter valid email');
    } else {
      let payload = {
        email: email,
      };
      dispatch(sendVerificationCodeRequest(payload));
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />

      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          //justifyContent: 'center',
        }}
        source={IMAGES?.newbg}>
        <View
          style={{
            alignItems: 'center',
            justifyContent: 'center',
            paddingTop: ms(40),
          }}>
          <TouchableOpacity
            onPress={() => goBack()}
            style={{position: 'absolute', top: 20, left: 0}}>
            <Image
              source={ICONS?.upArrow}
              style={{
                height: ms(15),
                width: ms(15),
                transform: [{rotate: '-90deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          <View style={{width: '60%'}}>
            <Image
              source={ICONS?.logoWithName}
              style={{height: ms(100), width: ms(150), alignSelf: 'center'}}
              resizeMode="contain"
            />
            <Text
              style={{
                fontFamily: FONTS?.Header_SemiBold,
                fontSize: ms(20),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(30),
              }}>
              Forgot Your Password?{' '}
            </Text>
            <Text
              style={{
                fontFamily: FONTS?.Italic,
                fontSize: ms(14),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(5),
              }}>
              Reset Now
            </Text>
          </View>
          <View style={{height: '60%', justifyContent: 'center'}}>
            <TextInputItem
              placeholder={'Email'}
              keyboardType={'email-address'}
              width={Dimensions?.get('window')?.width - 60}
              height={ms(50)}
              value={email}
              borderRadius={ms(10)}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setEmail(item);
              }}
            />
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                color: '#344054',
                marginTop: ms(20),
                alignSelf: 'center',
                textAlign: 'center',
                width: '70%',
              }}
              onPress={() => {
                navigate('Login');
              }}>
              Enter your email above to get password {'\n'} reset code
            </Text>
            <TouchableOpacity
              style={{
                backgroundColor: COLORS?.themeColor,
                // width: ms(150),
                width: ms(179),
                height: ms(47),
                alignSelf: 'center',
                borderRadius: ms(30),
                flexDirection: 'row',
                alignItems: 'center',
                // justifyContent: 'center',
                //padding: ms(12),
                // paddingHorizontal: ms(20),
                // paddingVertical: ms(10),
                gap: ms(20),
                marginTop: ms(60),
              }}
              onPress={() => {
                checkValidation();
                //navigate('SendOtp');
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color: COLORS?.white,
                  marginLeft: ms(35),
                }}>
                Send Code
              </Text>
              <Image
                style={{
                  height: ms(34),
                  width: ms(33),
                  position: 'absolute',
                  right: ms(7),
                }}
                source={ICONS?.next}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </View>
        {/* <Image
          source={ICONS?.logoImage}
          style={{height: ms(100), width: ms(100), position: 'absolute'}}
        /> */}
        <View
          style={{
            height: ms(61),
            width: Dimensions?.get('window')?.width,
            backgroundColor: COLORS?.themeColor,
            position: 'absolute',
            bottom: ms(0),
            borderTopLeftRadius: ms(49),
            borderTopRightRadius: ms(49),
          }}
        />
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
