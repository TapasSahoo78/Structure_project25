import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Keyboard,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import OTPInput from '../../components/OTPInput';
import {useSelector} from 'react-redux';
import { useDispatch } from 'react-redux';
import { resendOtpRequest, verifyOtpRequest } from '../../redux/reducer/ProfileReducer';

export default function ForgotPasswordOtp() {
  const dispatch = useDispatch()
  const [pin, setPin] = useState('');
   const [timer, setTimer] = useState(150); 
  const [isActive, setIsActive] = useState(true);
  const {sendOtpResponse} = useSelector(state => state.ProfileReducer);
  useEffect(() => {}, []);
  useEffect(() => {
    let interval = null;
    if (isActive && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else if (timer === 0) {
      setIsActive(false); // Stop timer
    }

    return () => clearInterval(interval);
  }, [isActive, timer]);
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' + mins : mins}:${secs < 10 ? '0' + secs : secs}`;
  };

  const handleResendOTP = () => {
    //Alert.alert('OTP Sent!', 'A new OTP has been sent to your phone.');
    let payload = {
      email:sendOtpResponse?.email
    }
    dispatch(resendOtpRequest(payload))
    setTimer(150); // Reset to 2:30
    setIsActive(true); // Restart timer
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          justifyContent: 'center',
        }}
        source={IMAGES?.colorBackground}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <View style={{width: '80%'}}>
            {/* <View
              style={{
                height: ms(100),
                width: ms(100),
                borderRadius: ms(50),
                backgroundColor: 'rgba(4, 127, 255,0.4)',
                alignSelf: 'center',
              }}
            /> */}
            <Image
              style={{height: ms(165), width: ms(168), alignSelf: 'center'}}
              source={ICONS.dancingmobile}
            />
            <Text
              style={{
                fontFamily: FONTS?.Header_SemiBold,
                fontSize: ms(20),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(50),
              }}>
              Enter Verification Code
            </Text>
            <View
              style={{
                width: '100%',
                alignItems: 'center',
                marginRight: ms(20),
                marginTop: -ms(10),
              }}>
              <OTPInput
                code={pin}
                setCode={setPin}
                maximumLength={4}
                setIsPinReady={status => {
                  if (status) {
                    Keyboard.dismiss();
                  }
                }}
                style={{marginTop: normalize(20)}}
              />
            </View>
          </View>

          <Text
            style={{
              fontFamily: FONTS?.Regular,
              fontSize: ms(14),
              color: COLORS?.black,
              marginTop: ms(40),
              width: '90%',
              textAlign: 'center',
            }}>
            We have sent an email at {'\n'}
            <Text style={{fontFamily: FONTS?.SemiBold}}>
              {sendOtpResponse?.email}
            </Text>
          </Text>
          {isActive ? <Text
            style={{
              fontFamily: FONTS.Regular,
              color: '#047FFF',
              marginVertical: ms(20),
            }}>
            Resend OTP in {formatTime(timer)}
          </Text>:<Text onPress={()=> handleResendOTP()}
            style={{
              fontFamily: FONTS.Regular,
              color: '#047FFF',
              marginVertical: ms(20),
            }}>
            Resend OTP 
          </Text>}
          
          <TouchableOpacity
            style={{
              backgroundColor: COLORS?.themeColor,
              // width: ms(150),
              width: ms(179),
              height: ms(47),
              alignSelf: 'center',
              borderRadius: ms(30),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              //padding: ms(12),
              // paddingHorizontal: ms(20),
              // paddingVertical: ms(10),
              gap: ms(20),
              marginTop: ms(40),
            }}
            onPress={() => {
              let payload = {
                email:sendOtpResponse?.email,
                otp:pin
              }
              dispatch(verifyOtpRequest(payload))
              
              
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(14),
                color: COLORS?.white,
                marginLeft: -ms(20),
              }}>
              Verify Code
            </Text>
            <Image
              style={{
                height: ms(34),
                width: ms(33),
                position: 'absolute',
                right: ms(7),
              }}
              source={ICONS?.next}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
