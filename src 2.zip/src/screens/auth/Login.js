import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms } from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import { navigate, goBack } from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import IsInternetConnected from '../../utils/helpers/IsInternetConnected';
import Toast from '../../utils/helpers/Toast';
import { useDispatch, useSelector } from 'react-redux';
import { loginRequest } from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import Modal from 'react-native-modal';
import { useFocusEffect } from '@react-navigation/native';
import TextInputItem from '../../components/TextInputItem';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

export default function Login() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const [passwordVisible, setPasswordVisible] = useState(true);
  const { loading = false, isFirstTimeUser } = useSelector(
    state => state.ProfileReducer || {},
  );

  // Correctly initialize the modal state
  const [isModalVisible, setIsModalVisible] = useState(true);

  useEffect(() => { }, []);

  useFocusEffect(
    React.useCallback(() => {
      setIsModalVisible(true);
    }, []),
  );

  const checkValidation = () => {
    checkFieldValidation();
    // IsInternetConnected()
    //   .then(() => checkFieldValidation())
    //   .catch(() => Toast("Internet connection error"));
  };

  const checkFieldValidation = () => {
    if (email === '') {
      Toast('Enter your email id');
    } else if (!constants.EMAIL_REGEX.test(email)) {
      Toast('Enter valid email');
    } else if (password === '') {
      Toast('Enter password');
    } else {
      // setIsModalVisible(false); // Correct usage of the setter function
      let payload = {
        email: email,
        password: password,
        deviceType: 1,
      };
      dispatch(loginRequest(payload));
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Loader visible={loading} />
      <MyStatusBar />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
        }}
        source={IMAGES?.colorBackground}>
        {isFirstTimeUser == 1 ? (
          <TouchableOpacity
            style={{ padding: ms(20) }}
            onPress={() => {
              goBack();
            }}>
            <Image
              source={ICONS?.upArrow}
              style={{
                height: ms(15),
                width: ms(15),
                transform: [{ rotate: '-90deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
        ) : null}
        <View
          style={{
            alignItems: 'center',
            justifyContent: 'center',
            paddingHorizontal: ms(30),
            height: Dimensions?.get('window')?.height / 2.6,
          }}>
          <Text
            style={{
              fontFamily: FONTS?.Header_SemiBold,
              fontSize: ms(26),
              color: '#344054',
              textAlign: 'center',
            }}>
            Login in to
          </Text>
          <Text
            style={{
              fontFamily: FONTS?.Header_SemiBold,
              fontSize: ms(26),
              color: COLORS?.themeColor,
              textAlign: 'center',
              marginTop: -ms(10),
            }}>
            RaiseInvoice
          </Text>

          <Text
            style={{
              fontFamily: FONTS?.Italic,
              fontSize: ms(18),
              color: '#262F3F',
              textAlign: 'center',
              marginTop: ms(20),
            }}>
            Start Invoicing
          </Text>
        </View>
        <Modal
          isVisible={isModalVisible}
          backdropOpacity={1}
          coverScreen={false}
          hasBackdrop={false}
          animationInTiming={700}
          animationOutTiming={400}
          style={{ justifyContent: 'flex-end', margin: 0 }}>
          <ImageBackground
            style={{
              height: Dimensions?.get('window')?.height / 1.6,
              width: Dimensions?.get('window')?.width,
              alignItems: 'center',
              justifyContent: 'center',
              position: 'absolute',
              bottom: ms(0),
            }}
            resizeMode="stretch"
            source={IMAGES?.loginBackground}>
            <KeyboardAwareScrollView>
              <View
                style={{
                  alignItems: 'center',
                  justifyContent: 'center',
                  paddingTop: ms(20),
                }}>
                <TextInputItem
                  placeholder={'Email Address'}
                  keyboardType={'email-address'}
                  width={Dimensions?.get('window')?.width - 65}
                  placeholderTextColor={'rgba(52, 64, 84, 0.5)'}
                  value={email}
                  borderColor={COLORS?.themeColor}
                  onChangeText={item => {
                    setEmail(item);
                  }}
                />
                <View style={{ marginTop: ms(7) }}>
                  <TextInputItem
                    placeholder={'Password'}
                    isSecure={passwordVisible}
                    keyboardType={'default'}
                    width={Dimensions?.get('window')?.width - 65}
                    placeholderTextColor={'rgba(52, 64, 84, 0.5)'}
                    value={password}
                    isRightIconVisible={true}
                    rightIcon={passwordVisible ? ICONS.eyeoff : ICONS.eye}
                    onPressRight={() => setPasswordVisible(!passwordVisible)}
                    isrightdisabled={false}
                    borderColor={COLORS?.themeColor}
                    onChangeText={item => {
                      setPassword(item);
                    }}
                    st
                  // secureTextEntry={true}
                  />
                </View>
                <Text
                  style={{
                    alignSelf: 'flex-end',
                    color: COLORS?.white,
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(10),
                    width: '100%',
                    textDecorationLine: 'underline',
                    marginVertical: ms(20),
                  }}
                  onPress={() => {
                    setIsModalVisible(false); // Correct usage of the setter function
                    navigate('ForgotPassword');
                  }}>
                  Forgot Password?
                </Text>
                <TouchableOpacity
                  style={{
                    backgroundColor: COLORS?.white,
                    borderRadius: ms(30),
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    // paddingVertical: ms(10),
                    height: ms(45),
                    width: ms(150),
                    paddingHorizontal: ms(30),
                    // gap: ms(15),
                    marginTop: ms(10),
                  }}
                  onPress={() => {
                    checkValidation();
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(16),
                      color: COLORS?.themeColor,
                    }}>
                    Login
                  </Text>
                  <Image
                    style={{
                      height: ms(30),
                      width: ms(30),
                      position: 'absolute',
                      right: ms(15),
                    }}
                    source={ICONS?.next}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: COLORS?.white,
                    marginTop: ms(30),
                    marginBottom: ms(10),
                  }}>
                  or continue with
                </Text>
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    flexDirection: 'row',
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{ height: ms(42.5), width: ms(42.5) }}
                    source={ICONS.googlelogo}
                  />
                  <Image
                    resizeMode="contain"
                    style={{
                      height: ms(42.5),
                      width: ms(42.5),
                      marginLeft: ms(15),
                    }}
                    source={ICONS.applelogo}
                  />
                  <Image
                    resizeMode="contain"
                    style={{
                      height: ms(42.5),
                      width: ms(42.5),
                      marginLeft: ms(15),
                    }}
                    source={ICONS.winlogo}
                  />
                  <Image
                    resizeMode="contain"
                    style={{
                      height: ms(42.5),
                      width: ms(42.5),
                      marginLeft: ms(15),
                    }}
                    source={ICONS.fblogo}
                  />
                </View>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: COLORS?.white,
                    marginTop: ms(20),
                  }}
                  onPress={() => {
                    if (isFirstTimeUser == 1) goBack();
                    else navigate('Signup');
                  }}>
                  Don't Have an Account?{'\t'}
                  <Text
                    style={{
                      color: COLORS?.white,
                      textDecorationLine: 'underline',
                    }}>
                    Signup
                  </Text>
                </Text>
              </View>
            </KeyboardAwareScrollView>
          </ImageBackground>
        </Modal>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
