import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import {useDispatch, useSelector} from 'react-redux';
import Toast from '../../utils/helpers/Toast';
import {resetPasswordRequest} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import TextInputItem from '../../components/TextInputItem';

export default function ResetPassword(props) {
  const dispatch = useDispatch();
  const {loading = false} = useSelector(state => state.ProfileReducer || {});
  const senOtpres = useSelector(state => state.ProfileReducer?.sendOtpResponse);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(true);
  const [cpasswordVisible, setCPasswordVisible] = useState(true);
  console.log("response from otp res",JSON.stringify(senOtpres))
  useEffect(() => {
    //alert(props.route.params.otp)
    //alert(JSON.stringify(senOtpres))
  }, []);

  const checkValidation = () => {
    if (password == '') {
      Toast('Enter password');
    } else if (confirmPassword == '') {
      Toast('Enter confirm password');
    } else if (password !== confirmPassword) {
      Toast('Password and confirm password does not match');
    } else {
      let payload = {
        email: senOtpres.email,
        otp: props.route.params.otp,
        password: password,
        confirm_password: password,
        deviceType:1
      };
      dispatch(resetPasswordRequest(payload));
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <Loader visible={loading} />
      <MyStatusBar />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          //justifyContent: 'center',
        }}
        source={IMAGES?.colorBackground}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <View style={{width: '60%'}}>
            <Image
              source={ICONS?.logoWithName}
              style={{
                height: ms(100),
                width: ms(150),
                alignSelf: 'center',
                marginTop: ms(40),
              }}
              resizeMode="contain"
            />
            <Text
              style={{
                fontFamily: FONTS?.Header_SemiBold,
                fontSize: ms(20),
                color: '#344054',
                textAlign: 'center',
                marginTop: ms(40),
              }}>
              Reset Password
            </Text>
          </View>

          {/* <TextInputItem
            placeholder={'Password'}
            keyboardType={'default'}
            secureTextEntry={true}
            width={Dimensions?.get('window')?.width - 60}
            value={password}
            borderRadius={ms(10)}
            borderColor={COLORS?.themeColor}
            borderWidth={ms(0.5)}
            onChangeText={item => {
              setPassword(item);
            }}
          /> */}
          <TextInputItem
                            placeholder={'Password'}
                            isSecure={passwordVisible}
                            keyboardType={'default'}
                            width={Dimensions?.get('window')?.width - 65}
                            placeholderTextColor={'rgba(52, 64, 84, 0.5)'}
                            value={password}
                            isRightIconVisible={true}
                            rightIcon={passwordVisible ? ICONS.eyeoff : ICONS.eye}
                            onPressRight={() => setPasswordVisible(!passwordVisible)}
                            isrightdisabled={false}
                            borderColor={COLORS?.themeColor}
                            onChangeText={item => {
                              setPassword(item);
                            }}
                            
                            // secureTextEntry={true}
                          />
          <View style={{marginTop: ms(5)}}>
            <TextInputItem
              placeholder={'Confirm Password'}
              isSecure={cpasswordVisible}
              keyboardType={'default'}
              isRightIconVisible={true}
              placeholderTextColor={'rgba(52, 64, 84, 0.5)'}
              width={Dimensions?.get('window')?.width - 65}
              value={confirmPassword}
              borderRadius={ms(10)}
              rightIcon={cpasswordVisible ? ICONS.eyeoff : ICONS.eye}
              onPressRight={() => setCPasswordVisible(!cpasswordVisible)}
              borderColor={COLORS?.themeColor}
              borderWidth={ms(0.5)}
              isrightdisabled={false}
              onChangeText={item => {
                setConfirmPassword(item);
              }}
            />
          </View>
          <TouchableOpacity
            style={{
              backgroundColor: COLORS?.themeColor,
              // width: ms(150),
              width: ms(179),
              height: ms(47),
              alignSelf: 'center',
              borderRadius: ms(30),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              //padding: ms(12),
              // paddingHorizontal: ms(20),
              // paddingVertical: ms(10),
              gap: ms(20),
              marginTop: ms(150),
            }}
            onPress={() => {
              checkValidation();
              //navigate('SuccessfulPage');
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(14),
                color: COLORS?.white,
                marginLeft: -ms(20),
              }}>
              Reset Now
            </Text>
            <Image
              style={{
                height: ms(34),
                width: ms(33),
                position: 'absolute',
                right: ms(7),
              }}
              source={ICONS?.next}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </View>
        {/* <Image
          source={ICONS?.logoImage}
          style={{height: ms(100), width: ms(100), position: 'absolute'}}
        /> */}
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
