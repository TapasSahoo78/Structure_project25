import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';


export default function SendOtp(props) {
  useEffect(() => {
    setTimeout(() => {
      navigate('ForgotPasswordOtp');
    }, 2000);
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar backgroundColor={COLORS?.white} />
      <Image
        source={ICONS?.telegramfly}
        style={{height: ms(100), width: ms(100), position: 'absolute'}}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
