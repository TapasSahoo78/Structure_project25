import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import IsInternetConnected from '../../utils/helpers/IsInternetConnected';
import Toast from '../../utils/helpers/Toast';
import {registrationRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../utils/helpers/Loader';
import TextInputItem from '../../components/TextInputItem';

export default function Signup() {
  const {loading = false} = useSelector(state => state.ProfileReducer || {});
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [terms, setTerms] = useState(true);
  const [marketing, setMarketing] = useState(true);
  const [passwordVisible, setPasswordVisible] = useState(true);
  useEffect(() => {}, []);
  const dispatch = useDispatch();

  const checkValidation = () => {
    // IsInternetConnected()
    // .then(()=> alert("hiii"))
    // .catch(()=> Toast("Internet connection error"))

    checkFieldValidation();
  };
  const checkFieldValidation = () => {
    //const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (name == '') {
      Toast('Enter your name');
    } else if (email == '') {
      Toast('Enter your email id');
    } else if (!constants.EMAIL_REGEX.test(email)) {
      Toast('Enter valid email id');
    } else if (password == '') {
      Toast('Enter your password');
    } else if (password.length < 6) {
      Toast('Enter atleast six digit password');
    } else if (!terms) {
      Toast(
        'You should mark read terms of use, privacy notice and offer details',
      );
    } else if (!marketing) {
      Toast('You should check marketing communication');
    } else {
      let payload = {
        name: name,
        email: email,
        password: password,
        deviceType: 1,
      };
      dispatch(registrationRequest(payload));
    }
  };

  const onpressOnRight = () => {
    setPasswordVisible(!passwordVisible);
  };
  return (
    <SafeAreaView style={styles.container}>
      <Loader visible={loading} />
      <MyStatusBar />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          justifyContent: 'center',
        }}
        source={IMAGES?.iconbg}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <View style={{width: '60%', paddingTop: ms(40)}}>
            <Text
              style={{
                fontFamily: FONTS?.Header_SemiBold,
                fontSize: ms(18),
                color: COLORS?.black,
                textAlign: 'center',
              }}>
              Start Your free 30 days trial with{' '}
              <Text style={{color: COLORS?.themeColor}}>RaiseInvoice</Text>
            </Text>
            <Text
              style={{
                fontFamily: FONTS?.Italic,
                fontSize: ms(12),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(3),
              }}>
              Send Invoices | Accept Payments Manage Cash Flow | Manage Projects
            </Text>
          </View>
          <View style={{marginTop: ms(10)}}>
            <TextInputItem
              placeholder={'Name'}
              keyboardType={'default'}
              width={Dimensions?.get('window')?.width - 65}
              value={name}
              borderColor={COLORS?.themeColor}
              borderRadius={ms(10)}
              height={normalize(45)}
              onChangeText={item => {
                setName(item);
              }}
            />
          </View>
          <View style={{marginVertical: ms(5)}}>
            <TextInputItem
              placeholder={'Email'}
              keyboardType={'email-address'}
              width={Dimensions?.get('window')?.width - 65}
              value={email}
              borderColor={COLORS?.themeColor}
              borderRadius={ms(10)}
              height={normalize(45)}
              onChangeText={item => {
                setEmail(item);
              }}
            />
          </View>
          {/* <TextInputItem
            placeholder={'Password'}
            isSecure={true}
            keyboardType={'default'}
            width={Dimensions?.get('window')?.width - 65}
            secureTextEntry={true}
            value={password}
            borderColor={COLORS?.themeColor}
            height={normalize(45)}
            borderRadius={ms(10)}
            onChangeText={item => {
              setPassword(item);
            }}
            isRightIconVisible={true}
            rightIcon={passwordVisible?ICONS.eyeoff:ICONS.eye}
            onPressRight={()=> setPasswordVisible(!passwordVisible)}
          /> */}
          <TextInputItem
            placeholder="Password"
            isSecure={passwordVisible}
            value={password}
            onChangeText={setPassword}
            width={Dimensions.get('window').width - 65}
            height={normalize(45)}
            borderRadius={ms(10)}
            borderColor={COLORS.themeColor}
            isRightIconVisible={true}
            rightIcon={passwordVisible ? ICONS.eyeoff : ICONS.eye}
            onPressRight={() => setPasswordVisible(!passwordVisible)}
            isrightdisabled={false} // Ensure button is enabled
          />
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'flex-start',
              marginTop: ms(10),
              gap: ms(15),
              width: Dimensions?.get('window').width - 20,
              //padding: ms(10),
              paddingVertical: ms(10),
              paddingHorizontal: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => setTerms(!terms)}
              style={{
                height: ms(23),
                width: ms(23),
                backgroundColor: terms ? COLORS?.themeColor : COLORS.white,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: ms(5),
                borderWidth: ms(1),
                borderColor: COLORS?.themeColor,
              }}>
              {terms ? (
                <Image
                  source={ICONS?.tick}
                  style={{height: ms(12), width: ms(14)}}
                  resizeMode="contain"
                />
              ) : null}
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                width: '90%',
                color: COLORS?.black,
              }}>
              I've read and agreed to the terms of use, privacy notice and offer
              details: <Text style={{color: '#13B5EA'}}>Terms of use</Text>, 
              <Text style={{color: '#13B5EA'}}>privacy notice</Text>, and 
              <Text style={{color: '#13B5EA'}}>offer details</Text>.
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'flex-start',
              gap: ms(15),
              width: Dimensions?.get('window').width - 20,
              //padding: ms(10),
              paddingHorizontal: ms(20),
              paddingVertical: ms(10),
              paddingTop: ms(0),
            }}>
            <TouchableOpacity
              onPress={() => setMarketing(!marketing)}
              style={{
                height: ms(23),
                width: ms(23),
                backgroundColor: marketing ? COLORS?.themeColor : COLORS.white,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: ms(5),
                borderWidth: ms(1),
                borderColor: COLORS.themeColor,
              }}>
              {marketing ? (
                <Image
                  source={ICONS?.tick}
                  style={{height: ms(12), width: ms(14)}}
                  resizeMode="contain"
                />
              ) : null}
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                width: '90%',
                color: COLORS?.black,
              }}>
              Please send me marketing communications
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => checkValidation()}
            style={{
              backgroundColor: COLORS?.themeColor,
              // width: ms(150),
              width: ms(160),
              height: ms(47),
              alignSelf: 'center',
              borderRadius: ms(30),
              flexDirection: 'row',
              alignItems: 'center',
              // justifyContent: 'center',
              //padding: ms(12),
              // paddingHorizontal: ms(20),
              // paddingVertical: ms(10),
              gap: ms(20),
              marginTop: ms(60),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(14),
                color: COLORS?.white,
                marginLeft: ms(35),
              }}>
              Signup
            </Text>
            <Image
              style={{
                height: ms(34),
                width: ms(33),
                position: 'absolute',
                right: ms(7),
              }}
              source={ICONS?.next}
              resizeMode="contain"
            />
          </TouchableOpacity>
          <Text
            style={{
              fontFamily: FONTS?.Regular,
              fontSize: ms(14),
              color: COLORS?.textColor,
              marginTop: ms(40),
              marginBottom: ms(20),
            }}>
            or continue with
          </Text>
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              flexDirection: 'row',
            }}>
            <Image
              resizeMode="contain"
              style={{height: ms(42.5), width: ms(42.5)}}
              source={ICONS.googlelogo}
            />
            <Image
              resizeMode="contain"
              style={{height: ms(42.5), width: ms(42.5), marginLeft: ms(15)}}
              source={ICONS.applelogo}
            />
            <Image
              resizeMode="contain"
              style={{height: ms(42.5), width: ms(42.5), marginLeft: ms(15)}}
              source={ICONS.winlogo}
            />
            <Image
              resizeMode="contain"
              style={{height: ms(42.5), width: ms(42.5), marginLeft: ms(15)}}
              source={ICONS.fblogo}
            />
          </View>
          <View style={{paddingTop: ms(5)}}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(14),
                color: COLORS?.black,
                marginTop: ms(15),
              }}
              onPress={() => {
                navigate('Login');
              }}>
              Already Have an Account?{' '}
              <Text
                style={{
                  color: COLORS?.themeColor,
                  textDecorationLine: 'underline',
                }}>
                Signin
              </Text>
            </Text>
          </View>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
