import React, {useEffect} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';

export default function SplashScreen() {
  useEffect(() => {}, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          backgroundColor: COLORS?.themeColor,
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Image
          source={ICONS?.flashpage}
          style={{height: '100%', width: '100%'}}
          //resizeMode="contain"
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
