import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms} from '../../utils/helpers/metric';
import normalize from '../../utils/helpers/normalize';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';

export default function SuccessfulPage() {
  const [confirmPassword, setConfirmPassword] = useState('');
  const [password, setPassword] = useState('');
  useEffect(() => {}, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          justifyContent: 'center',
        }}
        source={IMAGES?.colorBackground}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <View style={{width: '60%'}}>
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(18),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(30),
              }}>
              You have successfully changed the password
            </Text>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(11),
                color: COLORS?.black,
                textAlign: 'center',
                marginTop: ms(10),
              }}
              onPress={() => {
                navigate('TabNav');
              }}>
              Start Invoicing Now
            </Text>
          </View>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
