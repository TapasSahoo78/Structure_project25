import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import DeviceInfo from 'react-native-device-info';
import {
  accountListRequest,
  getClientCommDetailsRequest,
  logoutRequest,
  swtchAccountRequest,
} from '../../redux/reducer/ProfileReducer';
import {useFocusEffect} from '@react-navigation/native';
import IsEmpty from '../../utils/helpers/IsEmpty';

export default function AccountSettings() {
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('');
  const [switchAccountModal, setSwitchAccountModal] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const dispatch = useDispatch();
  const profileDetailsRes = useSelector(
    state => state.ProfileReducer?.profileResponse,
  );
  const {accountList} = useSelector(state => state.ProfileReducer);

  const [selectedUser, setSelectedUser] = useState('');
  const [verification, setVerification] = useState(false);
  useEffect(() => {}, []);

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };
  useFocusEffect(
    useCallback(() => {
      dispatch(accountListRequest());
    }, []),
  );
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  const paymentMethod = [
    {
      id: 100,
      method: 'Card Payment',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.card,
    },
    {
      id: 101,
      method: 'Bank Transfers',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.bank,
    },
    {
      id: 102,
      method: 'Paypal',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.paypal,
    },
  ];

  const formatNameToInitials = name => {
    // Split the name into words
    const words = name.split(' ');

    // Extract the first letter of each word and convert to uppercase
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');

    return initials;
  };

  const createTwoButtonAlert = () => {
    Alert.alert('Logout', 'Do you really want to logout from the app?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {
        text: 'Yes',
        onPress: () => {
          dispatch(logoutRequest());
          // dispatch(deleteClientRequest(payload));
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Account & Settings'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          isSavePresent={false}
        />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            paddingTop: ms(20),
            paddingBottom: ms(30),
            //backgroundColor: 'rgba(4, 127, 255, 0.1)',
            //backgroundColor: ' rgba(4, 127, 255, 0.1)',
            backgroundColor: '#e6f2ff',

            borderBottomLeftRadius: ms(65),
            borderBottomRightRadius: ms(65),
            alignItems: 'center',
          }}>
          {/* <Image 
                    style={{ 
                        height: ms(54), 
                        width: ms(54), 
                        resizeMode: 'contain', 
                        overflow: 'hidden' 
                        }} 
                        source={IMAGES.profile} 
                        /> */}
          {!IsEmpty(profileDetailsRes?.name) &&
          IsEmpty(profileDetailsRes?.profileImage) ? (
            <View
              style={{
                height: ms(54),
                width: ms(54),
                borderRadius: ms(27),
                justifyContent: 'center',
                alignItems: 'center',
                //backgroundColor: COLORS.themeColor,
                backgroundColor: '#44BBFE',
              }}>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: COLORS.white,
                }}>
                {formatNameToInitials(profileDetailsRes?.name)}
              </Text>
            </View>
          ) : !IsEmpty(profileDetailsRes?.profileImage) ? (
            <View
              style={{
                height: ms(54),
                width: ms(54),
                borderRadius: ms(27),
                justifyContent: 'center',
                alignItems: 'center',
                //backgroundColor: COLORS.themeColor,
                backgroundColor: '#44BBFE',
              }}>
              <Image
                source={{uri: profileDetailsRes?.profileImage}}
                style={{height: ms(54), width: ms(54), borderRadius: ms(27)}}
              />
            </View>
          ) : null}
          <Text
            style={{
              textTransform: 'capitalize',
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              color: '#344054',
              marginTop: ms(8),
            }}>
            {profileDetailsRes?.name}
          </Text>
          <Text
            style={{
              fontSize: ms(12),
              fontFamily: FONTS.Regular,
              textTransform: 'capitalize',
              marginTop: ms(-5),
              color: '#344054',
            }}>
            {profileDetailsRes?.userCompany?.companyName}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => navigate('Subscription')}
          style={{
            height: ms(40),
            width: ms(270),
            backgroundColor: COLORS.themeColor,
            marginTop: isTablet ? -17 : -14,
            alignSelf: 'center',
            borderRadius: ms(20),
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontFamily: FONTS.Regular,
              fontSize: ms(14),
              color: COLORS.white,
            }}>
            Upgrade Plan
          </Text>
        </TouchableOpacity>
        <View style={{flex: 1, padding: ms(20)}}>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Account
            </Text>
          </View>

          <View style={{marginTop: ms(10), marginLeft: ms(10)}}>
            <Text
              style={{
                fontSize: ms(12),
                color: 'rgba(52, 64, 84, 1)',
                fontFamily: FONTS.Regular,
              }}>
              Account ID
            </Text>
            <Text
              style={{
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              {profileDetailsRes?.uuid?.split('-')[0].toUpperCase()}
            </Text>
          </View>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
              //marginLeft:ms(10)
            }}
          />

          <TouchableOpacity
            onPress={() => navigate('Subscription')}
            style={{
              marginTop: ms(0),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingRight: ms(10),
              marginLeft: ms(10),
            }}>
            <View>
              <Text
                style={{
                  fontSize: ms(12),
                  color: 'rgba(52, 64, 84, 1)',
                  fontFamily: FONTS.Regular,
                }}>
                Manage Subscription
              </Text>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: 'rgba(52, 64, 84, 1)',
                }}>
                {profileDetailsRes?.planDetails?.name}
              </Text>
            </View>
            <View
              style={{
                height: ms(20),
                width: ms(20),
                borderRadius: ms(10),
                backgroundColor: `rgba(68, 187, 254, 1)`,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                style={{height: 10, width: 10, resizeMode: 'contain'}}
                source={ICONS.rightarrow}
              />
            </View>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />

          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginLeft: ms(10),
              paddingVertical: ms(8),
            }}
            onPress={() => {
              setSwitchAccountModal(true);
              // navigate('AddAccount');
            }}>
            <Image
              source={ICONS.switchacc}
              style={{height: ms(18), width: ms(13)}}
              resizeMode="contain"
            />
            <Text
              style={{
                marginLeft: ms(10),
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              Switch or Add Account
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />

          <TouchableOpacity
            onPress={() => navigate('UserRole')}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginLeft: ms(10),
              paddingVertical: ms(8),
            }}>
            <Image
              source={ICONS.switchacc}
              style={{height: ms(18), width: ms(13), resizeMode: 'contain'}}
            />
            <Text
              style={{
                marginLeft: ms(10),
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              User Roles Management
            </Text>
          </TouchableOpacity>
          {/* <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(10),
              //marginLeft:ms(10)
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Details
            </Text>
          </View> */}
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              //marginTop: ms(10),
              marginLeft: ms(10),
              paddingVertical: ms(10),
              marginBottom: ms(10),
            }}
            onPress={() => {
              navigate('PersonalInfoUpdate');
            }}>
            <Image
              source={ICONS.switchacc}
              style={{height: ms(18), width: ms(13), resizeMode: 'contain'}}
            />
            <Text
              style={{
                marginLeft: ms(10),
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              Personal Info
            </Text>
          </TouchableOpacity>
          {/* <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          /> */}
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              //marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Company
            </Text>
          </View>

          <TouchableOpacity
            onPress={() => navigate('EditCompanyDetails')}
            style={{
              marginTop: ms(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingRight: ms(10),
              marginLeft: ms(10),
            }}>
            <View>
              <Text
                style={{
                  fontSize: ms(12),
                  color: ' rgba(52, 64, 84, 1)',
                  fontFamily: FONTS.Regular,
                }}>
                Company Info
              </Text>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: 'rgba(52, 64, 84, 1)',
                }}>
                Details & Reviews
              </Text>
            </View>
            <View
              style={{
                height: ms(20),
                width: ms(20),
                borderRadius: ms(10),
                backgroundColor: `rgba(68, 187, 254, 1)`,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                style={{height: 10, width: 10, resizeMode: 'contain'}}
                source={ICONS.rightarrow}
              />
            </View>
          </TouchableOpacity>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Settings
            </Text>
          </View>
          <TouchableOpacity
            style={{marginLeft: ms(10), paddingVertical: ms(5)}}
            onPress={() => navigate('CustomInvoiceDesign')}>
            <Text
              style={{
                marginTop: ms(10),
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              Customize Invoice
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <TouchableOpacity
            style={{marginLeft: ms(10),paddingVertical:ms(5)}}
            onPress={() => navigate('CustomInvoiceOption')}>
            <Text
              style={{
                //marginTop: ms(10),
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                color: 'rgba(52, 64, 84, 1)',
              }}>
              Customize Invoice Options
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <Text
            onPress={() => navigate('ClientPaymentOption')}
            style={{
              marginTop: ms(0),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              paddingVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Client Payment Options
          </Text>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <Text
            onPress={() => {
              let payload = {};
              dispatch(getClientCommDetailsRequest(payload));
              //navigate("ClientCommunication")
            }}
            style={{
              marginTop: ms(0),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              paddingVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Client Communication
          </Text>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <Text
            onPress={() => navigate('ProjectSettings')}
            style={{
              marginTop: ms(0),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              marginVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Project Settings
          </Text>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <Text
            onPress={() => navigate('SignatureSettings')}
            style={{
              marginTop: ms(0),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              marginVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Signature
          </Text>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(10),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Tax
            </Text>
          </View>
          <Text
            onPress={() => navigate('TaxCurrency')}
            style={{
              marginTop: ms(10),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              paddingVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Tax Setting & Currency
          </Text>

          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(10),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Security
            </Text>
          </View>
          <Text
            style={{
              marginTop: ms(10),
              fontSize: ms(14),
              fontFamily: FONTS.Medium,
              marginLeft: ms(10),
              paddingVertical: ms(5),
              color: 'rgba(52, 64, 84, 1)',
            }}>
            Trusted Devices
          </Text>

          <View
            style={{
              width: '100%',
              marginVertical: ms(10),
              height: ms(1),
              backgroundColor: '#E5E7EB',
            }}
          />

          <View
            style={{
              //marginTop: ms(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingRight: ms(10),
              marginLeft: ms(10),
            }}>
            <View>
              <Text
                style={{
                  fontSize: ms(10),
                  color: '#344054',
                  fontFamily: FONTS.Regular,
                }}>
                Two Factor Authentication
              </Text>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: 'rgba(52, 64, 84, 1)',
                }}>
                Verify its you when you log in
              </Text>
            </View>
            <TouchableOpacity onPress={() => setVerification(!verification)}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(32)}}
                source={verification ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>
          <Text
            style={{
              fontSize: ms(10),
              color: '#344054',
              fontFamily: FONTS.Regular,
              marginTop: ms(10),
              marginLeft: ms(10),
            }}>
            Two-factor authentication is required for this account.{'\n'}Other
            team members will also need to verify when{'\n'}logging in .{' '}
            <Text
              style={{
                color: COLORS.themeColor,
                textDecorationLine: 'underline',
              }}>
              Learn More
            </Text>
          </Text>
          <View
            style={{
              width: '100%',
              marginVertical: ms(20),
              height: ms(1),
              backgroundColor: '#E5E7EB',
            }}
          />

          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              //marginTop: ms(25),
              marginLeft: ms(10),
            }}
            onPress={() => {
              createTwoButtonAlert();
              //dispatch(logoutRequest());
            }}>
            <Image
              style={{height: ms(18), width: ms(18), resizeMode: 'contain'}}
              source={ICONS.logout}
            />
            <Text
              style={{
                fontSize: ms(14),
                fontFamily: FONTS.Medium,
                marginLeft: ms(5),
                color: 'rgba(52, 64, 84, 1)',
              }}>
              Logout
            </Text>
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              marginVertical: ms(20),
              height: ms(1),
              backgroundColor: '#E5E7EB',
            }}
          />
          <View
            style={{
              // marginTop: ms(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingRight: ms(10),
              marginLeft: ms(10),
            }}>
            <View>
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  color: 'rgba(52, 64, 84, 1)',
                }}>
                Do Not Sell My Personal Information
              </Text>
            </View>

            <View
              style={{
                height: ms(20),
                width: ms(20),
                borderRadius: ms(10),
                backgroundColor: `rgba(68, 187, 254, 1)`,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                style={{height: 10, width: 10, resizeMode: 'contain'}}
                source={ICONS.rightarrow}
              />
            </View>
          </View>
          <View
            style={{
              width: '100%',
              marginVertical: ms(20),
              height: ms(1),
              backgroundColor: '#E5E7EB',
            }}
          />
          <Image
            style={{
              height: ms(59),
              width: ms(151),
              resizeMode: 'contain',
              alignSelf: 'center',
              marginTop: ms(50),
            }}
            source={ICONS.accicn}
          />
        </View>
        <View
          style={{
            paddingVertical: ms(20),
            backgroundColor: 'rgba(4, 127, 255, 0.1)',
            borderTopLeftRadius: ms(70),
            borderTopRightRadius: ms(70),
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontSize: ms(14),
              fontFamily: FONTS.Regular,
              color: COLORS.themeColor,
            }}>
            Open Source License
          </Text>
          <Text
            style={{
              fontSize: ms(14),
              fontFamily: FONTS.Regular,
              color: COLORS.themeColor,
            }}>
            Terms of Service | Privacy Policy
          </Text>
        </View>
      </ScrollView>
      <Modal
        isVisible={switchAccountModal}
        onBackdropPress={() => {
          setSwitchAccountModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: ms(37),
            borderTopRightRadius: ms(37),
            height: Dimensions.get('window').height * 0.6,
            // minHeight: ms(200),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{marginBottom: ms(100)}}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontFamily: FONTS?.SemiBold,
                  fontSize: ms(16),
                  color: 'rgba(52, 64, 84, 1)',
                  marginLeft: ms(5),
                }}>
                Add or Switch Account
              </Text>
              <TouchableOpacity
                onPress={() => {
                  dispatch(
                    swtchAccountRequest({
                      id: selectedUser?.id,
                      deviceType: 1,
                    }),
                  );
                  setSwitchAccountModal(false);
                }}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                  }}>
                  Switch
                </Text>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(17),
                    width: ms(17),
                    marginLeft: ms(5),
                    borderRadius: ms(9),
                  }}
                  source={ICONS.bluetick}
                />
              </TouchableOpacity>
            </View>
            <View>
              <FlatList
                data={accountList}
                renderItem={({item, index}) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        // alignItems: 'center',
                        gap: ms(10),
                        paddingBottom: ms(5),
                        marginTop: ms(15),
                        borderBottomWidth: ms(0.5),
                        borderBottomColor: '#DFDFDF',
                      }}
                      onPress={() => {
                        setSelectedUser(item);
                      }}>
                      <Image
                        source={
                          item?.id == selectedUser?.id ||
                          (selectedUser == '' && index == 0)
                            ? ICONS?.radioEnable
                            : ICONS?.radioDisable
                        }
                        style={{
                          height: ms(20),
                          width: ms(20),
                          tintColor:
                            item?.id == selectedUser?.id ||
                            (selectedUser == '' && index == 0)
                              ? '#44BBFE'
                              : '#D9D9D9',
                        }}
                        resizeMode="contain"
                      />
                      <View>
                        <Text
                          style={{
                            fontFamily: FONTS?.Medium,
                            fontSize: ms(14),
                            color: 'rgba(52, 64, 84, 1)',
                          }}>
                          {item?.name}
                        </Text>
                        <Text
                          style={{
                            marginTop: -ms(5),
                            fontFamily: FONTS?.Regular,
                            fontSize: ms(14),
                          }}>
                          {item?.email}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </ScrollView>
          <TouchableOpacity
            style={{
              width: '100%',
              position: 'absolute',
              bottom: ms(10),
              borderWidth: ms(0.3),
              borderColor: COLORS?.themeColor,
              borderRadius: ms(10),
              padding: ms(10),
              alignSelf: 'center',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
            }}
            onPress={() => {
              navigate('AddAccount');
              setSwitchAccountModal(false);
            }}>
            <Image
              resizeMode="contain"
              style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
              source={ICONS.plusicn}
            />
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Add Account
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
