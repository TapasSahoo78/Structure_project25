import React, { useCallback, useEffect, useState, useRef } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Linking,
  Alert,
  TextInput,
  RefreshControl,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import { navigate } from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { useFocusEffect } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Modal from 'react-native-modal';
import {
  noteCreateRequest,
  projectDetailRequest,
  projectUpdateRequest,
  getFilesRequest,
  addFilesRequest,
  getContactRequest,
  addContactRequest,
  getProjectTimeRequest,
  addProjectTimeRequest,
  getTaskListRequest,
  addTaskRequest,
  updateContactRequest,
  deleteContactRequest,
  updateTaskRequest,
  deleteTaskRequest,
} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import DatePicker from 'react-native-date-picker';
import Toast from '../../utils/helpers/Toast';
import DeviceInfo, { isTablet } from 'react-native-device-info';
import CameraDropDown from '../../components/CameraDropDown';
import { pick, types } from '@react-native-documents/picker';
import constants from '../../utils/helpers/constants';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
export default function AddClient(props) {
  const [myDoc, setMydoc] = useState('');
  const [imageObject, setImageObject] = useState('');
  const [cameraModal, setCameraModal] = useState(false);
  const [option, setOption] = useState(props.route.params.status == "view" ? 'File' : "Details");
  const [toggleButtonFlag, setToggleButtonFlag] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [projectLocation, setProjectLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const dispatch = useDispatch();
  const [startDateModalOpen, setStartDateModalOpen] = useState(false);
  const [endDateModalOpen, setEndDateModalOpen] = useState(false);
  const { projectDetail, projectFiles, contactList, loading, taskList } =
    useSelector(state => state.ProfileReducer);
  const [note, setNote] = useState('');
  const [isBottomButtonVisible, setIsBottomButtonVisible] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [taskName, setTaskName] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [dateFlag, setDateFlag] = useState('');
  const [taskStartDate, setTaskStartDate] = useState('');
  const [taskEndDate, setTaskEndDate] = useState('');
  const [priority, setPriority] = useState('');
  const [isButtonPressed, setIsButtonPressed] = useState(false);
  const [contactId, setContactId] = useState('');
  const activeProjects = [
    {
      name: 'Project 1',
      contact_name: 'Akash Mishra',
      date: '2024-11-01',
    },
  ];
  const [priorityModal, setPriorityModal] = useState(false);
  const [addModal, setAddModal] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactAddress, setContactAddress] = useState('');
  const priorityList = [
    {
      id: 100,
      name: 'high',
    },
    {
      id: 101,
      name: 'medium',
    },
    {
      id: 102,
      name: 'low',
    },
  ];

  const [startTime, setStartTime] = useState(0); // base time in seconds
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const intervalRef = useRef(null);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [description, setDescription] = useState('');
  const [addButton, setAddButton] = useState(false);
  const [timeId, setTimeId] = useState('');

  const [addtaskModal, setAddTaskModal] = useState(false);
  const [timerModal, setTimerModal] = useState(false);
  const [taskId, setTaskId] = useState('');
  const [timeNote, setTimeNote] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [editContactModal, setEditContactModal] = useState(false);
  const [updateTaskId, setUpdateTaskId] = useState('');
  const [updateTaskModal, setUpdateTaskModal] = useState(false);

  const tabData = [
    { key: 'File', label: 'Files' },
    { key: 'Details', label: 'Details' },
    { key: 'Contacts', label: 'Contacts' },
    { key: 'Notes', label: 'Notes' },
    { key: 'Task', label: 'Task' },
    //{key: 'Time', label: 'Time'},
  ];
  const formatNameToInitials = name => {
    // Split the name into words
    const words = name.split(' ');

    // Extract the first letter of each word and convert to uppercase
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');

    return initials;
  };
  useFocusEffect(
    useCallback(() => {
      //alert(JSON.stringify(props?.route?.params?.item))
      let payload = {
        client_id: props?.route?.params?.item?.client_id,
        projectId: props?.route?.params?.item?.id,
      };
      console.log(payload);
      dispatch(projectDetailRequest(payload));
      let myData = {
        projectId: props?.route?.params?.item?.id,
      };
      let myPayload = {
        client_id: props?.route?.params?.item?.client_id,
      }
      dispatch(getFilesRequest(myData));
      dispatch(getContactRequest(myPayload));
      dispatch(getTaskListRequest(myData));
      let timepayload = {
        client_id: props?.route?.params?.item?.client_id,
        project_id: props?.route?.params?.item?.id,
      };


      //dispatch(getProjectTimeRequest(timepayload));
    }, []),
  );
  function isEmpty(item) {
    if (item == '' || item == null || item == undefined) return true;
    return false;
  }
  useEffect(() => {
    if (!isEmpty(projectDetail) && !loading) {
      setProjectName(projectDetail?.enrichedProject?.project_name);
      setProjectDescription(projectDetail?.enrichedProject?.project_desc);
      setProjectLocation(projectDetail?.enrichedProject?.project_location);
      setStartDate(projectDetail?.enrichedProject?.start_date);
      setEndDate(projectDetail?.enrichedProject?.end_date);
      setNote(projectDetail?.enrichedProject?.notes);

      //setTaskName(projectDetail?.enrichedProject?.taskName);
      //setTaskDescription(projectDetail?.enrichedProject?.taskDescription);
      //setTaskStartDate(projectDetail?.enrichedProject?.taskStartDate);
      //setTaskEndDate(projectDetail?.enrichedProject?.taskEndDate);
      //setPriority(projectDetail?.enrichedProject?.taskPriority);
      //setContactName(projectDetail?.enrichedProject?.client?.name);
    }
  }, [projectDetail]);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  const sumTimeDifferences = (projectTimes) => {
    if (!Array.isArray(projectTimes) || projectTimes.length === 0) {
      return '00:00:00';
    }

    const totalSeconds = projectTimes.reduce((sum, item) => {
      if (!item?.timeDifference) return sum;

      const parts = item.timeDifference.split(':');
      const hours = parseInt(parts[0], 10) || 0;
      const minutes = parseInt(parts[1], 10) || 0;
      const seconds = parseInt(parts[2], 10) || 0;

      return sum + (hours * 3600) + (minutes * 60) + seconds;
    }, 0);

    // Convert total seconds back to HH:MM:SS
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');

    return `${hours}:${minutes}:${seconds}`;
  };
  const renderItemseparator = () => {
    return (
      <View
        style={{
          height: ms(1),
          width: Dimensions.get('window').width,
          marginLeft: ms(-20),
          marginVertical: ms(5),
          backgroundColor: COLORS.border,
        }}
      />
    );
  };

  const formatTime = seconds => {
    // const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    // const secs = (seconds % 60).toString().padStart(2, '0');
    // return `${mins}:${secs}`;
    const hrs = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, '0'); // 3600 sec = 1 hour
    const mins = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${hrs}:${mins}:${secs}`;
  };
  // useEffect(() => {
  //       setStartTime(120);
  //       setElapsedTime(120);
  //       setTimerActive(true);
  //   }, []);
  // useEffect(() => {
  //   if (projectTime.length == 0) {
  //     setElapsedTime(0);
  //     setAddButton(true);
  //   } else if (projectTime[0]?.end_time) {
  //     const [hourss, minutess, secondss] = projectTime[0]?.timeDifference
  //       ?.split(':')
  //       .map(Number);
  //     const totalSeconds = hourss * 3600 + minutess * 60 + secondss;
  //     setElapsedTime(totalSeconds);
  //     setTimerActive(false);
  //     setDescription(projectTime[0]?.notes);
  //     setAddButton(false);
  //   } else {
  //     setTimeId(projectTime[0]?.id);
  //     setAddButton(false);
  //     const [hours, minutes, seconds] = projectTime[0]?.timeDifference
  //       ?.split(':')
  //       .map(Number);
  //     const totalSeconds = hours * 3600 + minutes * 60 + seconds;
  //     setElapsedTime(totalSeconds);
  //     setTimerActive(true);
  //     setDescription(projectTime[0]?.notes);
  //   }
  // }, [projectTime]);
  useEffect(() => {
    if (timerActive) {
      intervalRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerActive]);

  const openTimer = item => {
    // let myData = {
    //     projectId: props?.route?.params?.item?.id,
    //   };
    // dispatch(getTaskListRequest(myData));

    setTaskId(item?.id);
    if (item.projectTimes.length == 0) {
      setElapsedTime(0);
      setAddButton(true);
    } else if (item.projectTimes[0]?.end_time) {
      const [hourss, minutess, secondss] = item.projectTimes[0]?.timeDifference
        ?.split(':')
        .map(Number);
      const totalSeconds = hourss * 3600 + minutess * 60 + secondss;
      setElapsedTime(totalSeconds);
      setTimerActive(false);
      setDescription(item.projectTimes[0]?.notes);
      setAddButton(false);
    } else {
      setTimeId(item.projectTimes[0]?.id);
      setAddButton(false);
      const [hours, minutes, seconds] = item.projectTimes[0]?.timeDifference
        ?.split(':')
        .map(Number);
      const totalSeconds = hours * 3600 + minutes * 60 + seconds;
      setElapsedTime(totalSeconds);

      setTimerActive(true);
      setDescription(item.projectTimes[0]?.notes);
    }
    setTimerModal(true);
  };

  const stopTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setTimerActive(false);
    Alert.alert('Timer Stopped', `Final time: ${formatTime(elapsedTime)}`);
  };

  const _onRefresh = () => {
    setRefreshing(true);

    // Your refresh logic here (API call, data fetching, etc.)
    let myData = {
      projectId: props?.route?.params?.item?.id,
    };
    dispatch(getTaskListRequest(myData));
    console.log('hiii');

    setRefreshing(false);
    // setTimeout(() => {
    //   // Example: fetch new data
    //   // fetchDataFromAPI();
    //   let myData = {
    //     projectId: props?.route?.params?.item?.id,
    //   };
    //   dispatch(getTaskListRequest(myData));

    //   setRefreshing(false);
    // }, 2000); // Simulate network request
  };

  const updateTask = item => {
    console.log('task to be updated', item);
    setUpdateTaskId(item?.id);
    setTaskName(item?.taskName);
    setTaskDescription(item?.taskDescription);
    setPriority(item?.taskPriority);
    setTaskStartDate(new Date(item?.taskStartDate));
    setTaskEndDate(new Date(item?.taskEndDate));
    setUpdateTaskModal(true);
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      {startDateModalOpen ? (
        <DatePicker
          modal
          mode={'date'}
          open={true}
          date={
            dateFlag == 'task'
              ? taskStartDate
                ? new Date(moment(taskStartDate)?.format('YYYY-MM-DD'))
                : new Date()
              : endDate
                ? new Date(moment(endDate)?.format('YYYY-MM-DD'))
                : new Date()
          }
          minimumDate={new Date()}
          onConfirm={date => {
            console.log('date', date);
            if (dateFlag == 'task') {
              setTaskStartDate(date);
            } else {
              setStartDate(date);
            }

            setStartDateModalOpen(false);
          }}
          onCancel={() => {
            setStartDateModalOpen(false);
          }}
        />
      ) : null}
      {endDateModalOpen ? (
        <DatePicker
          modal
          mode={'date'}
          open={true}
          date={
            dateFlag == 'task'
              ? taskEndDate
                ? new Date(moment(taskEndDate)?.format('YYYY-MM-DD'))
                : new Date()
              : endDate
                ? new Date(moment(endDate)?.format('YYYY-MM-DD'))
                : new Date()
          }
          minimumDate={new Date()}
          onConfirm={date => {
            console.log('date', date);
            if (dateFlag == 'task') {
              setTaskEndDate(date);
            } else {
              setEndDate(date);
            }

            setEndDateModalOpen(false);
          }}
          onCancel={() => {
            setEndDateModalOpen(false);
          }}
        />
      ) : null}
      <View
        style={{
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={''}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <KeyboardAwareScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={_onRefresh} />
        }
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}
        onScrollAnimationEnd={() => { }}>
        <View style={{ flex: 1, padding: ms(20) }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              paddingHorizontal: ms(35),
              paddingBottom: ms(10),
              borderBottomWidth: ms(1.5),
              borderBottomColor: '#E5E7EB',
              width: Dimensions.get('window').width,
              marginLeft: ms(-20),
            }}>
            <View>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.black,
                }}>
                {projectDetail?.enrichedProject?.project_name}
              </Text>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                  color: COLORS?.black,
                  textTransform: 'capitalize',
                }}>
                {projectDetail?.enrichedProject?.client?.name}
              </Text>
            </View>
            <Text
              style={{
                fontFamily: FONTS?.ExtraLight,
                fontSize: ms(12),
                color: COLORS?.black,
              }}>
              {moment(new Date())?.format('Do MMM, YYYY')}
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              paddingHorizontal: ms(10),
              borderBottomWidth: ms(1.5),
              paddingTop: ms(10),
              borderBottomColor: '#E5E7EB',
              width: Dimensions.get('window').width,
              marginLeft: ms(-20),
            }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {tabData.map(tab => (
                <TouchableOpacity
                  key={tab.key}
                  style={{
                    paddingBottom: ms(10),
                    borderBottomWidth: option === tab.key ? ms(1.2) : ms(0),
                    //width: ms(70), // fixed width or use % if preferred
                    paddingHorizontal: isTablet ? ms(25) : ms(15),
                    borderBottomColor: COLORS?.themeColor,
                  }}
                  onPress={() => {
                    if (tab.key == 'Time') {
                      //navigate("AddNewTime")
                      setOption(tab.key);
                    } else {
                      setOption(tab.key);
                    }
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: option === tab.key ? '#344054' : '#344054BF',
                      textAlign: 'center',
                    }}>
                    {tab.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
          {option == 'File' ? (
            <View>
              {projectFiles.length > 0 ? (
                <FlatList
                  data={projectFiles}
                  numColumns={2}
                  contentContainerStyle={{
                    //alignSelf: 'center',
                    //paddingLeft: ms(10),
                    marginTop: ms(20),
                  }}
                  renderItem={({ item }) => {
                    let pdfflag;
                    if (item.fileName.split('.').pop() == 'pdf') {
                      pdfflag = true;
                    } else {
                      pdfflag = false;
                    }
                    return (
                      <TouchableOpacity
                        onPress={() => {
                          //Linking.openURL(constants.IMAGE_URL+"/"+item?.fileName)
                          Linking.openURL(item?.url);
                          console.log(item?.url);
                        }}
                        style={{
                          width: Dimensions.get('window').width / 2 - ms(30),
                          borderWidth: ms(1),
                          borderColor: COLORS.border,
                          height: ms(100),
                          margin: ms(5),
                          alignItems: 'center',
                          justifyContent: 'center',
                          padding: ms(10),
                          borderRadius: ms(10),
                        }}>
                        <Image
                          resizeMode="contain"
                          style={{ height: ms(30), width: ms(30) }}
                          source={pdfflag ? ICONS.pdf : ICONS.imgicn}
                        />
                        <Text
                          numberOfLines={2}
                          multiline={true}
                          style={{
                            fontSize: ms(10),
                            fontFamily: FONTS.Regular,
                            marginTop: ms(10),
                            textAlign: 'center',
                            color: COLORS.themeColor,
                          }}>
                          {constants.BASE_URL}/{item?.fileName}
                        </Text>
                      </TouchableOpacity>
                    );
                  }}
                />
              ) : null}
            </View>
          ) : null}
          {option == 'Details' ? (
            <View style={{ alignItems: 'center' }}>
              <AnimatedTextInput
                label={'Project Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={projectName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setProjectName(item);
                }}
              />
              <AnimatedTextInput
                label={'Project Description'}
                keyboardType={'default'}
                multiline={true}
                numberOfLines={10}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={projectDescription}
                minimumHeight={ms(100)}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setProjectDescription(item);
                }}
              />
              <View>
                <AnimatedTextInput
                  label={'Project location'}
                  keyboardType={'default'}
                  width={
                    isTablet
                      ? Dimensions?.get('window')?.width - 70
                      : Dimensions?.get('window')?.width - 50
                  }
                  value={projectLocation}
                  minimumHeight={ms(45)}
                  multiline={true}
                  numberOfLines={6}
                  borderColor={COLORS?.themeColor}
                  onChangeText={item => {
                    setProjectLocation(item);
                  }}
                />
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(28),
                    width: ms(16.2),
                    position: 'absolute',
                    right: ms(12),
                    top: isTablet ? ms(35) : ms(28),
                  }}
                  source={ICONS?.location}
                />
              </View>
              <TouchableOpacity
                style={{
                  // padding: ms(8),
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('detail');
                  setStartDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {startDate
                    ? moment(startDate)?.format('Do MMM, YYYY')
                    : 'Start Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
              {/* <AnimatedTextInput
                label={'Start Date'}
                keyboardType={'default'}
                width={Dimensions?.get('window')?.width - 50}
                value={startDate}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setStartDate(item);
                }}
              /> */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('detail');
                  setEndDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {endDate
                    ? moment(endDate)?.format('Do MMM, YYYY')
                    : 'End Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(20),
                  paddingVertical: ms(8),
                  backgroundColor: COLORS?.themeColor,
                  marginTop: ms(30),
                  alignSelf: 'center',
                  width: ms(150),
                  borderRadius: ms(20),
                }}
                onPress={() => {
                  if (projectName == '') {
                    Toast('Project name is required');
                  } else if (projectDescription == '') {
                    Toast('Project description is required');
                  } else if (projectLocation == '') {
                    Toast('Project location is required');
                  } else {
                    dispatch(
                      projectUpdateRequest({
                        client_id: projectDetail?.enrichedProject?.client_id,
                        projectId: projectDetail?.enrichedProject?.id,
                        project_name: projectName,
                        project_desc: projectDescription,
                        start_date: startDate
                          ? moment(new Date(startDate))?.format('YYYY-MM-DD')
                          : null,
                        end_date: endDate
                          ? moment(new Date(endDate))?.format('YYYY-MM-DD')
                          : null,
                        status: '1',
                      }),
                    );
                  }
                }}>
                <Text
                  style={{
                    color: COLORS?.white,
                    textAlign: 'center',
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(15),
                  }}>
                  Save
                </Text>
              </TouchableOpacity>
            </View>
          ) : null}
          {option == 'Contacts' ? (
            <View>
              <View style={{
                height: ms(40),
                borderRadius: ms(5),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                paddingHorizontal: ms(10), marginTop: ms(20), justifyContent: 'center'
              }}>
                <Text style={{
                  fontSize: ms(14),
                  color: COLORS.themeColor,
                  fontWeight: '600',
                }}>Primary Contact</Text>

              </View>
              <View
                style={{
                  padding: ms(10),
                  borderWidth: ms(0.3),
                  borderColor: COLORS?.themeColor,
                  marginTop: ms(10),
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  gap: ms(20),
                  elevation: 3,
                  backgroundColor: COLORS.white,
                  shadowColor: COLORS.themeColor,
                  //height: ms(100),
                  alignItems: 'center',
                  marginTop: ms(20),

                }}>
                <View
                  style={{
                    height: ms(50),
                    width: ms(50),
                    backgroundColor: '#44BBFE',
                    borderRadius: ms(25),
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text
                    style={{
                      textAlign: 'center',
                      color: COLORS?.white,
                      fontFamily: FONTS?.Bold,
                      fontSize: ms(15),
                      textTransform: 'uppercase',
                    }}>
                    {formatNameToInitials(contactList[0]?.contact_name)}
                    {/* {item?.contact_name?.split?.(' ', 2)?.[0]?.[0] +
                            item?.contact_name.split?.(' ', 2)?.[1]?.[0]} */}
                  </Text>
                </View>
                <View style={{ width: '70%' }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.SemiBold,
                      fontSize: ms(12),
                      color: COLORS?.black,
                      textTransform: 'capitalize',
                    }}>
                    {contactList[0]?.contact_name}
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      gap: ms(10),
                      alignItems: 'center',
                    }}>
                    <Image
                      source={ICONS?.mail}
                      style={{ height: ms(12), width: ms(12) }}
                      resizeMode="contain"
                    />
                    <Text style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                      //textTransform: 'capitalize',
                    }}>{contactList[0]?.contact_email}</Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      gap: ms(10),
                      alignItems: 'center',
                    }}>
                    <Image
                      source={ICONS?.call}
                      style={{ height: ms(12), width: ms(12) }}
                    // resizeMode="contain"
                    />
                    <Text style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                      //textTransform: 'capitalize',
                    }}>{contactList[0]?.contact_phone}</Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      gap: ms(10),
                      alignItems: 'center',
                    }}>
                    <Image
                      source={ICONS?.pinloc}
                      style={{ height: ms(12), width: ms(12) }}
                    // resizeMode="contain"
                    />
                    <Text style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                      //textTransform: 'capitalize',
                      flex: 1
                    }}>{contactList[0]?.address}</Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      gap: ms(10),
                      alignItems: 'center',
                    }}>
                    <Image
                      source={ICONS?.alarm}
                      style={{ height: ms(12), width: ms(12) }}
                      resizeMode="contain"
                      tintColor={COLORS.black}
                    />
                    <Text style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                      //textTransform: 'capitalize',
                      flex: 1
                    }}>Updated on - {moment(contactList[0]?.updatedAt).format("LL")}</Text>
                  </View>
                </View>

              </View>
              {contactList.length > 1 ? <View><View style={{
                height: ms(40),
                borderRadius: ms(5),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                paddingHorizontal: ms(10), marginTop: ms(20), justifyContent: 'center'
              }}>
                <Text style={{
                  fontSize: ms(14),
                  color: COLORS.themeColor,
                  fontWeight: '600',
                }}>Secondary Contact</Text>

              </View>
                <FlatList
                  data={contactList}
                  contentContainerStyle={{
                    paddingBottom: ms(20),
                  }}
                  renderItem={({ item, index }) => {
                    return (
                      index !== 0 ?
                        <View
                          style={{
                            padding: ms(10),
                            borderWidth: ms(0.3),
                            borderColor: COLORS?.themeColor,
                            marginTop: ms(10),
                            borderRadius: ms(6),
                            flexDirection: 'row',
                            gap: ms(20),
                            elevation: 3,
                            backgroundColor: COLORS.white,
                            shadowColor: COLORS.themeColor,
                            //height: ms(100),
                            alignItems: 'center',
                            marginTop: ms(20),

                          }}>



                          <View
                            style={{
                              height: ms(50),
                              width: ms(50),
                              backgroundColor: '#44BBFE',
                              borderRadius: ms(25),
                              alignItems: 'center',
                              justifyContent: 'center',
                              //marginVertical:ms(20)
                            }}>
                            <Text
                              style={{
                                textAlign: 'center',
                                color: COLORS?.white,
                                fontFamily: FONTS?.Bold,
                                fontSize: ms(15),
                                textTransform: 'uppercase',
                              }}>
                              {formatNameToInitials(item?.contact_name)}
                              {/* {item?.contact_name?.split?.(' ', 2)?.[0]?.[0] +
                            item?.contact_name.split?.(' ', 2)?.[1]?.[0]} */}
                            </Text>
                          </View>
                          <View style={{ width: '70%' }}>
                            <Text
                              style={{
                                fontFamily: FONTS?.SemiBold,
                                fontSize: ms(12),
                                color: COLORS?.black,
                                textTransform: 'capitalize',
                              }}>
                              {item?.contact_name}
                            </Text>
                            <View
                              style={{
                                flexDirection: 'row',
                                gap: ms(10),
                                alignItems: 'center',
                              }}>
                              <Image
                                source={ICONS?.mail}
                                style={{ height: ms(12), width: ms(12) }}
                                resizeMode="contain"
                              />
                              <Text style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(12),
                                color: COLORS?.black,
                                //textTransform: 'capitalize',
                              }}>{item?.contact_email}</Text>
                            </View>
                            <View
                              style={{
                                flexDirection: 'row',
                                gap: ms(10),
                                alignItems: 'center',
                              }}>
                              <Image
                                source={ICONS?.call}
                                style={{ height: ms(12), width: ms(12) }}
                              // resizeMode="contain"
                              />
                              <Text style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(12),
                                color: COLORS?.black,
                                //textTransform: 'capitalize',
                              }}>{item?.contact_phone}</Text>
                            </View>
                            <View
                              style={{
                                flexDirection: 'row',
                                gap: ms(10),
                                alignItems: 'center',
                              }}>
                              <Image
                                source={ICONS?.pinloc}
                                style={{ height: ms(12), width: ms(12) }}
                              // resizeMode="contain"
                              />
                              <Text style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(12),
                                color: COLORS?.black,
                                //textTransform: 'capitalize',
                                flex: 1
                              }}>{item?.address}</Text>
                            </View>
                            <View
                              style={{
                                flexDirection: 'row',
                                gap: ms(10),
                                alignItems: 'center',
                              }}>
                              <Image
                                source={ICONS?.alarm}
                                style={{ height: ms(12), width: ms(12) }}
                                resizeMode="contain"
                                tintColor={COLORS.black}
                              />
                              <Text style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(12),
                                color: COLORS?.black,
                                //textTransform: 'capitalize',
                                flex: 1
                              }}>Updated on - {moment(item?.updatedAt).format("LL")}</Text>
                            </View>
                          </View>

                          <View
                            style={{
                              flexDirection: 'row',
                              alignItems: 'center',
                              width: '30%',
                              justifyContent: 'flex-end',
                              alignSelf: 'flex-start',
                              //backgroundColor:'red',
                              //marginTop:ms(20),
                              flex: 1
                            }}>
                            <TouchableOpacity
                              onPress={() => {
                                setContactName(item?.contact_name);
                                setContactEmail(item?.contact_email);
                                setContactPhone(item?.contact_phone);
                                setContactAddress(item?.address);
                                setContactId(item?.id);
                                setEditContactModal(true);
                              }}
                              style={{ padding: ms(10) }}>
                              <Image
                                source={ICONS.editicn}
                                resizeMode="contain"
                                style={{ height: ms(15), width: ms(15) }}
                              />
                            </TouchableOpacity>
                            <TouchableOpacity
                              onPress={() => {
                                Alert.alert(
                                  'Confirmation',
                                  'Are you sure you want to delete?',
                                  [
                                    {
                                      text: 'Cancel',
                                      onPress: () =>
                                        console.log('Cancel Pressed'),
                                      style: 'cancel', // On iOS, this marks the button as a 'cancel' button
                                    },
                                    {
                                      text: 'OK',
                                      onPress: () => {
                                        let payload = {
                                          body: {
                                            id: item?.id,
                                          },
                                          pId: {
                                            projectId:
                                              props?.route?.params?.item?.id,
                                          },
                                          cid: {
                                            client_id: props?.route?.params?.item?.client_id,
                                          }
                                        };
                                        dispatch(deleteContactRequest(payload));
                                      },
                                    },
                                  ],
                                );
                              }}>
                              <Image
                                source={ICONS.delete}
                                resizeMode="contain"
                                style={{ height: ms(15), width: ms(15) }}
                              />
                            </TouchableOpacity>
                          </View>

                        </View> : null
                    );
                  }}
                />

              </View> : null}

              <View style={{ marginTop: ms(30) }}>
                <TouchableOpacity
                  style={{
                    paddingHorizontal: ms(20),
                    paddingVertical: ms(8),
                    backgroundColor: COLORS?.themeColor,

                    alignSelf: 'center',
                    width: ms(150),
                    borderRadius: ms(20),
                    marginBottom: ms(20),
                  }}
                  onPress={() => {
                    setAddModal(true);
                  }}>
                  <Text
                    style={{
                      color: COLORS?.white,
                      textAlign: 'center',
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(15),
                    }}>
                    Add More
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
          {option == 'Notes' ? (
            <View style={{ alignItems: 'center' }}>
              {/* <FlatList
                showsVerticalScrollIndicator={false}
                data={projectDetail?.projectNotes}
                style={{height: Dimensions?.get('window')?.height / 1.8}}
                renderItem={({item, index}) => {
                  return (
                    <View
                      style={{
                        paddingVertical: ms(5),
                        borderBottomWidth: ms(0.5),
                        borderBottomColor: '#DEDEDE',
                      }}>
                      <Text
                        style={{
                          textAlign: 'left',
                          fontSize: ms(11),
                          fontFamily: FONTS?.Regular,
                          color: COLORS?.black,
                        }}>
                        {item?.note}
                      </Text>
                      <Text
                        style={{
                          textAlign: 'right',
                          fontSize: ms(8),
                          fontFamily: FONTS?.Italic,
                          color: COLORS?.black,
                        }}>
                        {moment(item?.createdAt)?.format('Do MMM, YYYY')}
                      </Text>
                    </View>
                  );
                }}
              /> */}
              <AnimatedTextInput
                label={'Note'}
                keyboardType={'default'}
                multiline={true}
                numberOfLines={6}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={note}
                minimumHeight={ms(100)}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setNote(item);
                }}
              />
              <View style={{ marginTop: ms(30) }}>
                <TouchableOpacity
                  style={{
                    paddingHorizontal: ms(20),
                    paddingVertical: ms(8),
                    backgroundColor: COLORS?.themeColor,

                    alignSelf: 'center',
                    width: ms(150),
                    borderRadius: ms(20),
                    marginBottom: ms(20),
                  }}
                  onPress={() => {
                    if (note == '') {
                      Toast('Note is required');
                    } else {
                      dispatch(
                        noteCreateRequest({
                          notes: note,
                          client_id: projectDetail?.enrichedProject?.client_id,
                          projectId: projectDetail?.enrichedProject?.id,
                        }),
                      );
                      setNote('');
                    }
                  }}>
                  <Text
                    style={{
                      color: COLORS?.white,
                      textAlign: 'center',
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(15),
                    }}>
                    Save
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
          {option == 'Task' ? (
            <View style={{ alignItems: 'center' }}>
              {taskList?.length > 0 ? (
                <FlatList
                  data={taskList}
                  //style={{paddingHorizontal: ms(20), marginTop: ms(20)}}
                  contentContainerStyle={{
                    alignItems: 'center',
                    marginTop: ms(20),
                  }}
                  renderItem={({ item, index }) => {
                    return (
                      <View
                        style={{
                          padding: ms(10),
                          backgroundColor: COLORS?.white,
                          borderRadius: ms(10),
                          marginBottom: ms(10),
                          borderWidth: ms(0.6),
                          borderColor: COLORS.border,
                          //flexDirection: 'row',
                          //justifyContent: 'space-between',
                          width: isTablet
                            ? Dimensions?.get('window')?.width - 70
                            : Dimensions?.get('window')?.width - 50,
                          elevation: 5,
                          shadowColor: 'rgba(4, 127, 255, 0.2)',
                        }}>
                        <View
                          style={{
                            height: ms(40),
                            borderRadius: ms(5),
                            backgroundColor: 'rgba(4, 127, 255, 0.1)',
                            paddingHorizontal: ms(10),
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: COLORS.themeColor,
                              fontWeight: '600',
                            }}>
                            {moment(item.taskStartDate).format('ll')}
                          </Text>
                          <TouchableOpacity
                            onPress={() => {
                              navigate('AddNewTime', { item: item });
                              //openTimer(item)
                            }}
                            style={{
                              flexDirection: 'row',
                              alignItems: 'center',
                            }}>
                            <Image
                              style={{
                                height: ms(18),
                                width: ms(16),
                                resizeMode: 'contain',
                              }}
                              source={ICONS.alarm}
                            />
                            <Text
                              style={{
                                fontSize: ms(14),
                                color: COLORS.themeColor,
                                fontWeight: '400',
                                marginLeft: ms(5),
                              }}>
                              {item.projectTimes.length > 0
                                ? sumTimeDifferences(item.projectTimes)
                                : '00:00:00'}
                            </Text>
                          </TouchableOpacity>
                        </View>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                            width: '100%',
                            justifyContent: 'space-between',
                          }}>
                          <View style={{ paddingLeft: ms(10) }}>
                            <Text
                              style={{
                                fontFamily: FONTS?.Medium,
                                fontSize: ms(13),
                                color: COLORS?.black,
                                marginTop: ms(10),
                              }}>
                              {item?.taskName}
                              <Text style={{ fontFamily: FONTS?.Light }}>
                                {'\n'}
                                {item?.taskDescription}
                              </Text>
                            </Text>
                          </View>
                          <View
                            style={{
                              flexDirection: 'row',
                              alignItems: 'center',
                              width: '30%',

                              justifyContent: 'flex-end',
                              //alignSelf: 'flex-start',
                            }}>
                            <TouchableOpacity
                              onPress={() => updateTask(item)}
                              style={{ padding: ms(5) }}>
                              <Image
                                resizeMode="contain"
                                style={{ height: ms(15), width: ms(15) }}
                                source={ICONS.editicn}
                              />
                            </TouchableOpacity>
                            <TouchableOpacity
                              onPress={() => {
                                Alert.alert(
                                  'Confirmation',
                                  'Are you sure you want to delete task?',
                                  [
                                    {
                                      text: 'Cancel',
                                      onPress: () =>
                                        console.log('Cancel Pressed'),
                                      style: 'cancel', // On iOS, this marks the button as a 'cancel' button
                                    },
                                    {
                                      text: 'OK',
                                      onPress: () => {
                                        let payload = {
                                          body: {
                                            id: item?.id,
                                          },
                                          pId: {
                                            projectId:
                                              props?.route?.params?.item?.id,
                                          },
                                        };
                                        dispatch(deleteTaskRequest(payload));
                                      },
                                    },
                                  ],
                                );
                              }}
                              style={{ padding: ms(5) }}>
                              <Image
                                resizeMode="contain"
                                style={{ height: ms(15), width: ms(15) }}
                                source={ICONS.delete}
                              />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    );
                  }}
                />
              ) : null}

              <View style={{ marginTop: ms(30) }}>
                <TouchableOpacity
                  style={{
                    paddingHorizontal: ms(20),
                    paddingVertical: ms(8),
                    backgroundColor: COLORS?.themeColor,

                    alignSelf: 'center',
                    width: ms(150),
                    borderRadius: ms(20),
                    marginBottom: ms(20),
                  }}
                  onPress={() => {
                    setAddTaskModal(true);
                  }}>
                  <Text
                    style={{
                      color: COLORS?.white,
                      textAlign: 'center',
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(15),
                    }}>
                    Add Task
                  </Text>
                </TouchableOpacity>
              </View>
              {/* <AnimatedTextInput
                label={'Task Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setTaskName(item);
                }}
              />
              <AnimatedTextInput
                label={'Task Description'}
                keyboardType={'default'}
                multiline={true}
                numberOfLines={10}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskDescription}
                minimumHeight={ms(100)}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setTaskDescription(item);
                }}
              />
              <TouchableOpacity
                style={{
                  // padding: ms(8),
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setPriorityModal(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {priority ? priority : 'Priority'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(14),
                    width: ms(5),
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '180deg'}],
                  }}
                  source={ICONS?.arrow}
                />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={{
                  // padding: ms(8),
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setStartDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskStartDate
                    ? moment(taskStartDate)?.format('Do MMM, YYYY')
                    : 'Start Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(18), width: ms(16.2)}}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setEndDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskEndDate
                    ? moment(taskEndDate)?.format('Do MMM, YYYY')
                    : 'End Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(18), width: ms(16.2)}}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(20),
                  paddingVertical: ms(8),
                  backgroundColor: COLORS?.themeColor,
                  marginTop: ms(30),
                  alignSelf: 'center',
                  width: ms(150),
                  borderRadius: ms(20),
                }}
                onPress={() => {
                  if (taskName == '') {
                    Toast('Task name is required');
                  } else if (taskDescription == '') {
                    Toast('Task Description is required');
                  } else {
                    dispatch(
                      projectUpdateRequest({
                        client_id: projectDetail?.enrichedProject?.client_id,
                        projectId: projectDetail?.enrichedProject?.id,
                        taskName: taskName,
                        taskDescription: taskDescription,
                        taskStartDate: taskStartDate
                          ? moment(new Date(taskStartDate))?.format(
                              'YYYY-MM-DD',
                            )
                          : null,
                        taskEndDate: taskEndDate
                          ? moment(new Date(taskEndDate))?.format('YYYY-MM-DD')
                          : null,
                        taskPriority: priority ? priority : 'low',
                        //status: '1',
                      }),
                    );
                  }
                }}>
                <Text
                  style={{
                    color: COLORS?.white,
                    textAlign: 'center',
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(15),
                  }}>
                  Save
                </Text>
              </TouchableOpacity> */}
            </View>
          ) : null}
          {/* {option == 'Time' ? (
            <View style={{flex: 1, marginTop: ms(20)}}>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(14),
                    color: COLORS?.themeColor,
                  }}>
                  Time
                </Text>
              </TouchableOpacity>

              <View
                style={{
                  paddingVertical: ms(20),
                  marginVertical: ms(20),
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text style={{fontSize: ms(14), color: COLORS.gray}}>
                  Started at
                </Text>
                <Text style={{fontSize: ms(52), color: COLORS.black}}>
                  {formatTime(elapsedTime)}
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: ms(20),
                  }}>
                  <TouchableOpacity
                    style={{
                      height: ms(48),
                      width: ms(48),
                      borderRadius: ms(24),
                      borderWidth: 1,
                      borderColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(13), width: ms(12)}}
                      source={ICONS.delete}
                    />
                  </TouchableOpacity>
                  {timerActive ? (
                    <TouchableOpacity
                      onPress={() => {
                        if (intervalRef.current) {
                          clearInterval(intervalRef.current);
                          intervalRef.current = null;
                        }

                        setTimerActive(false);
                        let payload = {
                          id: timeId,
                          client_id: props?.route?.params?.item?.client_id,
                          project_id: props?.route?.params?.item?.id,
                          notes: projectTime[0].note,
                          start_time: '00:00:00',
                          end_time: String(formatTime(elapsedTime)),
                        };
                        dispatch(addProjectTimeRequest(payload));
                        setTimerActive(false);
                      }}
                      style={{
                        height: ms(48),
                        width: ms(48),
                        borderRadius: ms(24),
                        borderWidth: 1,
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: COLORS.themeColor,
                        marginLeft: ms(10),
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{height: ms(14), width: ms(8)}}
                        source={ICONS.pause}
                      />
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      onPress={() => setTimerActive(true)}
                      style={{
                        height: ms(48),
                        width: ms(48),
                        borderRadius: ms(24),
                        borderWidth: 1,
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: COLORS.themeColor,
                        marginLeft: ms(10),
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{height: ms(14), width: ms(8)}}
                        source={ICONS.play}
                      />
                    </TouchableOpacity>
                  )}

                  <TouchableOpacity
                    style={{
                      height: ms(48),
                      width: ms(48),
                      borderRadius: ms(24),
                      borderWidth: 1,
                      borderColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginLeft: ms(10),
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(13), width: ms(15.2)}}
                      source={ICONS.resume}
                    />
                  </TouchableOpacity>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginTop: ms(20),
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Bold,
                    fontSize: ms(14),
                    color: COLORS?.themeColor,
                  }}>
                  Note
                </Text>
              </TouchableOpacity>

              <TextInput
                style={{
                  height: ms(100),
                  borderWidth: ms(0.5),
                  padding: 10,
                  borderRadius: 10,
                  textAlignVertical: 'top',
                  borderColor: COLORS.themeColor,
                  marginTop: ms(20),
                  elevation: ms(5),
                  backgroundColor: COLORS?.white,
                  shadowColor: COLORS.themeColor,
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                }}
                multiline={true} // Enable multi-line input
                numberOfLines={4} // Set the number of lines to display
                onChangeText={text => setDescription(text)} // Update state on text change
                value={description} // Controlled input
                placeholder="Description" // Placeholder text
                textAlignVertical="top" // Align text to the top
              />
              {addButton ? (
                <View style={{marginTop: ms(30)}}>
                  <TouchableOpacity
                    style={{
                      paddingHorizontal: ms(20),
                      paddingVertical: ms(8),
                      backgroundColor: COLORS?.themeColor,

                      alignSelf: 'center',
                      width: ms(150),
                      borderRadius: ms(20),
                      marginBottom: ms(20),
                    }}
                    onPress={() => {
                      if (description == '') {
                        Toast('Enter notes');
                      } else {
                        let payload = {
                          id: '',
                          client_id: props?.route?.params?.item?.client_id,
                          project_id: props?.route?.params?.item?.id,
                          notes: description,
                          start_time: '00:00:00',
                          end_time: '',
                        };
                        dispatch(addProjectTimeRequest(payload));
                      }
                    }}>
                    <Text
                      style={{
                        color: COLORS?.white,
                        textAlign: 'center',
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(15),
                      }}>
                      Save
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : null}
            </View>
          ) : null} */}
        </View>
      </KeyboardAwareScrollView>
      {option == 'File' ? (
        <TouchableOpacity
          style={{
            height: ms(50),
            width: ms(50),
            borderRadius: ms(25),
            backgroundColor: COLORS?.themeColor,
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(20),
            right: ms(20),
            zIndex: 10,
          }}
          onPress={() => {
            setToggleButtonFlag(!toggleButtonFlag);
          }}>
          {!toggleButtonFlag ? (
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[styles.iconStyle, { tintColor: COLORS?.white }]}
            />
          ) : (
            <Image
              source={ICONS?.addMore}
              //style={[styles.iconStyle, {height: ms(50), width: ms(50),transform: [{ rotate: '45deg' }],}]}
              style={[
                styles.iconStyle,
                {
                  tintColor: COLORS?.white,
                  borderRadius: ms(10),
                  transform: [{ rotate: '45deg' }],
                },
              ]}
            />
          )}
        </TouchableOpacity>
      ) : null}
      {toggleButtonFlag ? (
        <View
          style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0, 0.5)',
            height: Dimensions?.get('window')?.height,
            width: Dimensions?.get('window')?.width,
            position: 'absolute',
          }}>
          <View
            style={{
              position: 'absolute',
              backgroundColor: COLORS?.white,
              width: ms(150),
              padding: ms(10),
              bottom: ms(80),
              right: ms(10),
              borderRadius: ms(8),
            }}>
            <TouchableOpacity
              onPress={() => {
                setToggleButtonFlag(!toggleButtonFlag);
                setCameraModal(true);
              }}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Photo
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Estimate
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Invoice
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={async () => {
                setToggleButtonFlag(!toggleButtonFlag);
                try {
                  const [result] = await pick({
                    mode: 'open',
                    type: [types.pdf],
                    allowMultiSelection: false,
                  });
                  console.log('result on open file pdf', result);
                  setMydoc(result);
                  if (result) {
                    const formData = new FormData();
                    formData.append('document', result);
                    formData.append(
                      'client_id',
                      props?.route?.params?.item?.client_id,
                    );
                    formData.append(
                      'projectId',
                      props?.route?.params?.item?.id,
                    );
                    //dispatch(addFilesRequest(formData))
                    dispatch(
                      addFilesRequest({
                        body: formData,
                        projectId: props?.route?.params?.item?.id,
                      }),
                    );
                  }

                  //call api
                } catch (err) {
                  // see error handling
                }
              }}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                PDF
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </View>
      ) : null}
      <CameraDropDown
        visible={cameraModal}
        onBackdropPress={() => {
          setCameraModal(false);
        }}
        onPressCamera={item => {
          console.log('images: ', item);
          setImageObject(item);
          if (item) {
            const formData = new FormData();
            formData.append('document', item);
            formData.append('client_id', props?.route?.params?.item?.client_id);
            formData.append('projectId', props?.route?.params?.item?.id);
            dispatch(
              addFilesRequest({
                body: formData,
                projectId: props?.route?.params?.item?.id,
              }),
            );
            // dispatch(addFilesRequest({
            //   projectId: props?.route?.params?.item?.id,
            //   formData: formData
            // }))
          }
          //storeImage(item);
        }}
        onPressGallery={item => {
          console.log('images: ', item);
          setImageObject(item);
          //storeImage(item);
          if (item) {
            const formData = new FormData();
            formData.append('document', item);
            formData.append('client_id', props?.route?.params?.item?.client_id);
            formData.append('projectId', props?.route?.params?.item?.id);
            //dispatch(addFilesRequest(formData))
            dispatch(
              addFilesRequest({
                body: formData,
                projectId: props?.route?.params?.item?.id,
              }),
            );
            // dispatch(addFilesRequest({
            //   project: project_id,
            //   formData: formData
            // }))
          }
        }}
      />
      <Modal
        isVisible={priorityModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setPriorityModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.6,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <TouchableOpacity
            onPress={() => {
              setPriorityModal(false);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select priority.
            </Text>
          </View>

          <FlatList
            data={priorityList}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0),
                    borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                    //width:Dimensions.get('window').width,
                    //marginLeft:ms(-20)
                  }}
                  onPress={() => {
                    //console.log('itemaaa', item);
                    //alert(item?.id)
                    setPriority(item?.name);
                    //callUpdateProfile(item?.id);

                    setPriorityModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS.Fredoka_Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                    }}>
                    {item?.name}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <Modal
        isVisible={addModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        avoidKeyboard={true}
        onBackdropPress={() => {
          setAddModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.65,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(25),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <TouchableOpacity
            onPress={() => {
              setAddModal(false);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>

          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Add contact
            </Text>
          </View>
          <View style={{ alignSelf: 'center' }}>
            <AnimatedTextInput
              label={'Contact Name'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactName}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              //editable={false}

              onChangeText={item => {
                setContactName(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Email'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactEmail}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              onChangeText={item => {
                setContactEmail(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Phone'}
              keyboardType={'numeric'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactPhone}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              maxLength={10}
              onChangeText={item => {
                setContactPhone(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Address'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactAddress}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              onChangeText={item => {
                setContactAddress(item);
              }}
            />
          </View>

          <View style={{ marginTop: ms(30) }}>
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,

                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
                marginBottom: ms(20),
              }}
              onPress={() => {
                if (isButtonPressed) return;
                if (contactEmail == '') {
                  Toast('Enter contact email');
                } else if (!constants.EMAIL_REGEX.test(contactEmail)) {
                  Toast('Enter valid email');
                } else if (contactPhone == '') {
                  Toast('Enter contact phone');
                } else if (contactAddress == '') {
                  Toast('Enter contact address');
                } else {
                  setIsButtonPressed(true);
                  try {
                    let payload = {
                      contact_name: contactName,
                      contact_email: contactEmail,
                      contact_phone: contactPhone,
                      address: contactAddress,
                      client_id: props?.route?.params?.item?.client_id,
                      projectId: props?.route?.params?.item?.id,
                    };
                    dispatch(addContactRequest(payload));
                    setAddModal(false);
                    setContactName('');
                    setContactEmail('');
                    setContactAddress('');
                    setContactPhone('');
                  } catch (error) {
                  } finally {
                    setIsButtonPressed(false);
                  }
                }
              }}
              disabled={isButtonPressed}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        isVisible={addtaskModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        avoidKeyboard={true}
        onBackdropPress={() => {
          setAddTaskModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        {/* ScrollView wraps only the modal content */}
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.6,
            width: '100%',
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
          }}>
          <TouchableOpacity
            onPress={() => {
              setAddTaskModal(false);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />

          <KeyboardAwareScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingTop: normalize(10),
              paddingHorizontal: normalize(25),
              paddingBottom: normalize(40), // Ensure padding at the bottom
            }}>
            {/* Handle bar */}

            {/* Title */}
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontSize: normalize(18),
                  fontFamily: FONTS.Medium,
                  paddingVertical: normalize(5),
                }}>
                Add Task
              </Text>
            </View>

            {/* Task Name Input */}
            <View style={{ alignSelf: 'center' }}>
              <AnimatedTextInput
                label={'Task Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setTaskName(item);
                }}
              />

              {/* Task Description Input */}
              <AnimatedTextInput
                label={'Task Description'}
                keyboardType={'default'}
                multiline={true}
                numberOfLines={10}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskDescription}
                minimumHeight={ms(100)}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setTaskDescription(item);
                }}
              />

              {/* Priority Selector */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setPriorityModal(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {priority ? priority : 'Priority'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(14),
                    width: ms(5),
                    tintColor: COLORS.themeColor,
                    transform: [{ rotate: '180deg' }],
                  }}
                  source={ICONS?.arrow}
                />
              </TouchableOpacity>

              {/* Start Date */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setStartDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskStartDate
                    ? moment(taskStartDate)?.format('Do MMM, YYYY')
                    : 'Start Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>

              {/* End Date */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setEndDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskEndDate
                    ? moment(taskEndDate)?.format('Do MMM, YYYY')
                    : 'End Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
            </View>

            {/* Save Button */}
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                marginTop: ms(30),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                if (taskName === '') {
                  Toast('Task name is required');
                } else if (taskDescription === '') {
                  Toast('Task description is required');
                } else if (priority === '') {
                  Toast('Select task priority');
                } else if (taskStartDate === '') {
                  Toast('Select task start date');
                } else if (taskEndDate === '') {
                  Toast('Select task end date');
                } else {
                  setAddTaskModal(false);
                  dispatch(
                    addTaskRequest({
                      client_id: projectDetail?.enrichedProject?.client_id,
                      projectId: projectDetail?.enrichedProject?.id,
                      taskName: taskName,
                      taskDescription: taskDescription,
                      taskStartDate: taskStartDate
                        ? moment(new Date(taskStartDate)).format('YYYY-MM-DD')
                        : null,
                      taskEndDate: taskEndDate
                        ? moment(new Date(taskEndDate)).format('YYYY-MM-DD')
                        : null,
                      taskPriority: priority || 'low',
                    }),
                  );
                  // Optionally close modal after save
                  // setAddTaskModal(false);
                }
                setTaskName('');
                setTaskDescription('');
                setTaskStartDate('');
                setTaskEndDate('');
                setPriority('');
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </KeyboardAwareScrollView>
          <Modal
            isVisible={priorityModal}
            backdropOpacity={0.6}
            animationIn={'slideInUp'}
            animationOut={'slideOutDown'}
            animationInTiming={800}
            animationOutTiming={500}
            backdropTransitionOutTiming={0}
            hasBackdrop={true}
            onBackdropPress={() => {
              setPriorityModal(false);
            }}
            style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
            <View
              style={{
                maxHeight: Dimensions.get('window').height * 0.6,
                width: '100%',
                //height: Dimensions.get('window').height - normalize(200),
                paddingTop: normalize(10),
                paddingHorizontal: normalize(30),
                backgroundColor: '#FFF',
                borderTopLeftRadius: normalize(20),
                borderTopRightRadius: normalize(20),
                padding: normalize(40),
              }}>
              <TouchableOpacity
                onPress={() => {
                  setPriorityModal(false);
                }}
                style={{ position: 'absolute', top: 20, right: 20 }}>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(20), width: ms(20) }}
                  source={ICONS.crossbtn}
                />
              </TouchableOpacity>
              <View
                style={{
                  width: ms(63),
                  height: ms(6),
                  borderRadius: ms(8),
                  backgroundColor: 'rgba(217, 217, 217, 1)',
                  alignSelf: 'center',
                  marginBottom: ms(20),
                  marginTop: ms(10),
                }}
              />
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontSize: normalize(18),
                    fontFamily: FONTS.Medium,
                    paddingVertical: normalize(20),
                    //paddingHorizontal: normalize(20),
                  }}>
                  Select priority.
                </Text>
              </View>

              <FlatList
                data={priorityList}
                //style={{maxHeight: Dimensions.get('window').height / 3}}
                showsVerticalScrollIndicator={false}
                ItemSeparatorComponent={renderItemseparator}
                ListEmptyComponent={
                  <View style={{ alignItems: 'center' }}>
                    <Text style={{ color: COLORS?.orange }}>No data found.</Text>
                  </View>
                }
                renderItem={({ item, index }) => {
                  console.log('www', item);

                  return (
                    <TouchableOpacity
                      style={{
                        borderBottomWidth: normalize(0),
                        borderBottomColor: COLORS.dark_grey,
                        padding: normalize(10),
                        //backgroundColor: '#EBF4F6',
                        marginTop: normalize(5),
                        borderRadius: normalize(5),
                        flexDirection: 'row',
                        alignItems: 'center',
                        //width:Dimensions.get('window').width,
                        //marginLeft:ms(-20)
                      }}
                      onPress={() => {
                        //console.log('itemaaa', item);
                        //alert(item?.id)
                        setPriority(item?.name);
                        //callUpdateProfile(item?.id);

                        setPriorityModal(false);
                      }}>
                      <Text
                        style={{
                          color: '#000',
                          fontFamily: FONTS.Fredoka_Regular,
                          textTransform: 'capitalize',
                          marginLeft: normalize(10),
                        }}>
                        {item?.name}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </Modal>
        </View>
      </Modal>
      <Modal
        isVisible={updateTaskModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        avoidKeyboard={true}
        onBackdropPress={() => {
          setUpdateTaskModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        {/* ScrollView wraps only the modal content */}
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.6,
            width: '100%',
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
          }}>
          <TouchableOpacity
            onPress={() => {
              setUpdateTaskModal(false);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />

          <KeyboardAwareScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingTop: normalize(10),
              paddingHorizontal: normalize(25),
              paddingBottom: normalize(40), // Ensure padding at the bottom
            }}>
            {/* Handle bar */}

            {/* Title */}
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontSize: normalize(18),
                  fontFamily: FONTS.Medium,
                  paddingVertical: normalize(5),
                }}>
                Update Task
              </Text>
            </View>

            {/* Task Name Input */}
            <View style={{ alignSelf: 'center' }}>
              <AnimatedTextInput
                label={'Task Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setTaskName(item);
                }}
              />

              {/* Task Description Input */}
              <AnimatedTextInput
                label={'Task Description'}
                keyboardType={'default'}
                multiline={true}
                numberOfLines={10}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={taskDescription}
                minimumHeight={ms(100)}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setTaskDescription(item);
                }}
              />

              {/* Priority Selector */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setPriorityModal(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {priority ? priority : 'Priority'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(14),
                    width: ms(5),
                    tintColor: COLORS.themeColor,
                    transform: [{ rotate: '180deg' }],
                  }}
                  source={ICONS?.arrow}
                />
              </TouchableOpacity>

              {/* Start Date */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setStartDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskStartDate
                    ? moment(taskStartDate)?.format('Do MMM, YYYY')
                    : 'Start Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>

              {/* End Date */}
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(10),
                  borderWidth: ms(0.5),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(6),
                  marginTop: ms(10),
                  width: isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50,
                  backgroundColor: COLORS?.white,
                  height: ms(45),
                  alignItems: 'center',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
                onPress={() => {
                  setDateFlag('task');
                  setEndDateModalOpen(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: 'rgba(52, 64, 84, 0.5)',
                  }}>
                  {taskEndDate
                    ? moment(taskEndDate)?.format('Do MMM, YYYY')
                    : 'End Date'}
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(18), width: ms(16.2) }}
                  source={ICONS?.calendar}
                />
              </TouchableOpacity>
            </View>

            {/* Save Button */}
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                marginTop: ms(30),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                setUpdateTaskModal(false);
                dispatch(
                  updateTaskRequest({
                    id: updateTaskId,
                    client_id: projectDetail?.enrichedProject?.client_id,
                    projectId: projectDetail?.enrichedProject?.id,
                    taskName: taskName,
                    taskDescription: taskDescription,
                    taskStartDate: taskStartDate
                      ? moment(new Date(taskStartDate)).format('YYYY-MM-DD')
                      : null,
                    taskEndDate: taskEndDate
                      ? moment(new Date(taskEndDate)).format('YYYY-MM-DD')
                      : null,
                    taskPriority: priority || 'low',
                  }),
                );

                setTaskName('');
                setTaskDescription('');
                setTaskStartDate('');
                setTaskEndDate('');
                setPriority('');
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </KeyboardAwareScrollView>
          <Modal
            isVisible={priorityModal}
            backdropOpacity={0.6}
            animationIn={'slideInUp'}
            animationOut={'slideOutDown'}
            animationInTiming={800}
            animationOutTiming={500}
            backdropTransitionOutTiming={0}
            hasBackdrop={true}
            onBackdropPress={() => {
              setPriorityModal(false);
            }}
            style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
            <View
              style={{
                maxHeight: Dimensions.get('window').height * 0.6,
                width: '100%',
                //height: Dimensions.get('window').height - normalize(200),
                paddingTop: normalize(10),
                paddingHorizontal: normalize(30),
                backgroundColor: '#FFF',
                borderTopLeftRadius: normalize(20),
                borderTopRightRadius: normalize(20),
                padding: normalize(40),
              }}>
              <TouchableOpacity
                onPress={() => {
                  setPriorityModal(false);
                }}
                style={{ position: 'absolute', top: 20, right: 20 }}>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(20), width: ms(20) }}
                  source={ICONS.crossbtn}
                />
              </TouchableOpacity>
              <View
                style={{
                  width: ms(63),
                  height: ms(6),
                  borderRadius: ms(8),
                  backgroundColor: 'rgba(217, 217, 217, 1)',
                  alignSelf: 'center',
                  marginBottom: ms(20),
                  marginTop: ms(10),
                }}
              />
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontSize: normalize(18),
                    fontFamily: FONTS.Medium,
                    paddingVertical: normalize(20),
                    //paddingHorizontal: normalize(20),
                  }}>
                  Select priority.
                </Text>
              </View>

              <FlatList
                data={priorityList}
                //style={{maxHeight: Dimensions.get('window').height / 3}}
                showsVerticalScrollIndicator={false}
                ItemSeparatorComponent={renderItemseparator}
                ListEmptyComponent={
                  <View style={{ alignItems: 'center' }}>
                    <Text style={{ color: COLORS?.orange }}>No data found.</Text>
                  </View>
                }
                renderItem={({ item, index }) => {
                  console.log('www', item);

                  return (
                    <TouchableOpacity
                      style={{
                        borderBottomWidth: normalize(0),
                        borderBottomColor: COLORS.dark_grey,
                        padding: normalize(10),
                        //backgroundColor: '#EBF4F6',
                        marginTop: normalize(5),
                        borderRadius: normalize(5),
                        flexDirection: 'row',
                        alignItems: 'center',
                        //width:Dimensions.get('window').width,
                        //marginLeft:ms(-20)
                      }}
                      onPress={() => {
                        //console.log('itemaaa', item);
                        //alert(item?.id)
                        setPriority(item?.name);
                        //callUpdateProfile(item?.id);

                        setPriorityModal(false);
                      }}>
                      <Text
                        style={{
                          color: '#000',
                          fontFamily: FONTS.Fredoka_Regular,
                          textTransform: 'capitalize',
                          marginLeft: normalize(10),
                        }}>
                        {item?.name}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </Modal>
        </View>
      </Modal>

      <Modal
        isVisible={timerModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          let myData = {
            projectId: props?.route?.params?.item?.id,
          };
          dispatch(getTaskListRequest(myData));

          setTimerModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        {/* ScrollView wraps only the modal content */}
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.6,
            width: '100%',
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingTop: normalize(10),
              paddingHorizontal: normalize(25),
              paddingBottom: normalize(40), // Ensure padding at the bottom
            }}>
            <View style={{ flex: 1, marginTop: ms(20) }}>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(14),
                    color: COLORS?.themeColor,
                  }}>
                  Time
                </Text>
              </TouchableOpacity>

              <View
                style={{
                  paddingVertical: ms(20),
                  marginVertical: ms(20),
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text style={{ fontSize: ms(14), color: COLORS.gray }}>
                  Started at
                </Text>
                <Text style={{ fontSize: ms(52), color: COLORS.black }}>
                  {formatTime(elapsedTime)}
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: ms(20),
                  }}>
                  <TouchableOpacity
                    style={{
                      height: ms(48),
                      width: ms(48),
                      borderRadius: ms(24),
                      borderWidth: 1,
                      borderColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{ height: ms(13), width: ms(12) }}
                      source={ICONS.delete}
                    />
                  </TouchableOpacity>
                  {timerActive ? (
                    <TouchableOpacity
                      onPress={() => {
                        if (intervalRef.current) {
                          clearInterval(intervalRef.current);
                          intervalRef.current = null;
                        }

                        setTimerActive(false);
                        let payload = {
                          id: timeId,
                          client_id: props?.route?.params?.item?.client_id,
                          project_id: props?.route?.params?.item?.id,
                          notes: description,
                          start_time: '00:00:00',
                          end_time: String(formatTime(elapsedTime)),
                          task_id: taskId,
                        };
                        dispatch(addProjectTimeRequest(payload));
                        //setTimerActive(false);
                        setTimerModal(false);
                      }}
                      style={{
                        height: ms(48),
                        width: ms(48),
                        borderRadius: ms(24),
                        borderWidth: 1,
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: COLORS.themeColor,
                        marginLeft: ms(10),
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{ height: ms(14), width: ms(8) }}
                        source={ICONS.pause}
                      />
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      onPress={() => setTimerActive(true)}
                      style={{
                        height: ms(48),
                        width: ms(48),
                        borderRadius: ms(24),
                        borderWidth: 1,
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: COLORS.themeColor,
                        marginLeft: ms(10),
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{ height: ms(14), width: ms(8) }}
                        source={ICONS.play}
                      />
                    </TouchableOpacity>
                  )}

                  <TouchableOpacity
                    style={{
                      height: ms(48),
                      width: ms(48),
                      borderRadius: ms(24),
                      borderWidth: 1,
                      borderColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginLeft: ms(10),
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{ height: ms(13), width: ms(15.2) }}
                      source={ICONS.resume}
                    />
                  </TouchableOpacity>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginTop: ms(20),
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Bold,
                    fontSize: ms(14),
                    color: COLORS?.themeColor,
                  }}>
                  Note
                </Text>
              </TouchableOpacity>

              <TextInput
                style={{
                  height: ms(100),
                  borderWidth: ms(0.5),
                  padding: 10,
                  borderRadius: 10,
                  textAlignVertical: 'top',
                  borderColor: COLORS.themeColor,
                  marginTop: ms(20),
                  elevation: ms(5),
                  backgroundColor: COLORS?.white,
                  shadowColor: COLORS.themeColor,
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                }}
                multiline={true} // Enable multi-line input
                numberOfLines={4} // Set the number of lines to display
                onChangeText={text => setDescription(text)} // Update state on text change
                value={description} // Controlled input
                placeholder="Description" // Placeholder text
                textAlignVertical="top" // Align text to the top
              />
              {addButton ? (
                <View style={{ marginTop: ms(30) }}>
                  <TouchableOpacity
                    style={{
                      paddingHorizontal: ms(20),
                      paddingVertical: ms(8),
                      backgroundColor: COLORS?.themeColor,

                      alignSelf: 'center',
                      width: ms(150),
                      borderRadius: ms(20),
                      marginBottom: ms(20),
                    }}
                    onPress={() => {
                      if (description == '') {
                        Toast('Enter notes');
                      } else {
                        let payload = {
                          id: '',
                          client_id: props?.route?.params?.item?.client_id,
                          project_id: props?.route?.params?.item?.id,
                          notes: description,
                          start_time: '00:00:00',
                          end_time: '',
                          task_id: taskId,
                        };
                        dispatch(addProjectTimeRequest(payload));
                        setTimerModal(false);
                      }
                    }}>
                    <Text
                      style={{
                        color: COLORS?.white,
                        textAlign: 'center',
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(15),
                      }}>
                      Save
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : null}
            </View>
          </ScrollView>
        </View>
      </Modal>

      <Modal
        isVisible={editContactModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        avoidKeyboard={true}
        onBackdropPress={() => {
          setContactName('');
          setContactEmail('');
          setContactAddress('');
          setContactPhone('');
          setEditContactModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.65,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(25),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <TouchableOpacity
            onPress={() => {
              setContactName('');
              setContactEmail('');
              setContactAddress('');
              setContactPhone('');
              setEditContactModal(false);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>

          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Edit contact
            </Text>
          </View>
          <View style={{ alignSelf: 'center' }}>
            <AnimatedTextInput
              label={'Contact Name'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactName}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              //editable={false}

              onChangeText={item => {
                setContactName(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Email'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactEmail}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              onChangeText={item => {
                setContactEmail(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Phone'}
              keyboardType={'numeric'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactPhone}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              onChangeText={item => {
                setContactPhone(item);
              }}
            />
            <AnimatedTextInput
              label={'Contact Address'}
              keyboardType={'default'}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={contactAddress}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              onChangeText={item => {
                setContactAddress(item);
              }}
            />
          </View>

          <View style={{ marginTop: ms(30) }}>
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,

                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
                marginBottom: ms(20),
              }}
              onPress={() => {
                setIsButtonPressed(true);
                console.log(JSON.stringify());
                try {
                  let payload = {
                    contact_name: contactName,
                    contact_email: contactEmail,
                    contact_phone: contactPhone,
                    address: contactAddress,
                    client_id: props?.route?.params?.item?.client_id,
                    projectId: props?.route?.params?.item?.id,
                    id: contactId,
                  };
                  dispatch(updateContactRequest(payload));
                  setEditContactModal(false);
                  setContactName('');
                  setContactEmail('');
                  setContactAddress('');
                  setContactPhone('');
                } catch (error) {
                } finally {
                  setIsButtonPressed(false);
                }
              }}
              disabled={isButtonPressed}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
