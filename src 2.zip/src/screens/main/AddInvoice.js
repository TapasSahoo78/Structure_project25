import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {TextInput} from 'react-native-gesture-handler';
import Toast from '../../utils/helpers/Toast';
import {useDispatch, useSelector} from 'react-redux';
import {
  addCustomTimeRequest,
  addItemsRequest,
  addProjectTimeRequest,
  getAllTimesRequest,
  getCommonListRequest,
  getExpenseListRequest,
  getInvoiceOptionsSettingsRequest,
  getInvoiceSettingsRequest,
  getItemsListReqest,
  invoiceCreateRequest,
  invoiceListRequest,
} from '../../redux/reducer/ProfileReducer';
import moment from 'moment';
import DatePicker from 'react-native-date-picker';
import DeviceInfo from 'react-native-device-info';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import constants from '../../utils/helpers/constants';
import Loader from '../../utils/helpers/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useFocusEffect} from '@react-navigation/native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

export default function AddInvoice() {
  const dispatch = useDispatch();
  const [isTablet, setIsTablet] = useState(false);

  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('');
  const [rate, setRate] = useState('');
  const [quantity, setQuantity] = useState('');
  const [tax, setTax] = useState('');
  const [days, setDays] = useState('');
  const [billContent, setBillContent] = useState(true);
  const [itemContent, setItemContent] = useState(true);
  const [moreContent, setMoreContent] = useState(true);
  const [methodContent, setMethodContent] = useState(true);
  const [instructionContent, setInstructionContent] = useState(true);

  const [selectedItems, setSelectedItems] = useState([]);
  const [selectedItemsss, setSelectedItemsss] = useState([]);
  const [termContent, setTermContent] = useState(false);
  const {
    clientDetails,
    addedItem,
    itemList,
    invoiceList,
    appointmentList,
    allTimes,
    loading,
    invoiceOptionSettings,
    invoiceSettings,
    expenseList,
    commonList,
  } = useSelector(state => state.ProfileReducer);
  console.log('client detailsssss', JSON.stringify(clientDetails));
  const [openItemList, setOpenItemList] = useState(false);
  const [discountModal, setDiscountModal] = useState(false);
  const [selectedDiscount, setSelectedDiscount] = useState('Flat');
  const [addedItems, setAddedItems] = useState([]);
  const [openEditModal, setOpenEditModal] = useState(false);
  const [editIndex, setEditIndex] = useState('');
  const [allTotal, setAllTotal] = useState(0);
  const [totalDiscount, setTotalDiscount] = useState(0);
  const [totalAm, setTotalAm] = useState(0);
  const [selectedDate, setSlectedDate] = useState('');
  const [openStart, setOpenStart] = useState(false);
  const [dueDate, setDueDate] = useState('Select due date');
  const [termsModal, setTermsModal] = useState(false);
  const [grandTax, setGrandTax] = useState(0);
  const [openCustom, setOpenCustom] = useState(false);
  const [selectedDateNew, setSelectedDateNew] = useState('');
  const [dueDateNew, setDueDateNew] = useState();
  const [newTerm, setNewterm] = useState('');
  const [openInstruction, setOpenInstruction] = useState(false);
  const [paymentInstruction, setPaymentInstruction] = useState('');
  const [openNote, setOpenNote] = useState(false);
  const [invoiceNote, setInvoiceNote] = useState('');
  const [camModal, setCamModal] = useState(false);
  const [logoImg, setLogoImg] = useState([]);
  const [appointModal, setAppointModal] = useState(false);
  const [selectedItemss, setSelectedItemss] = useState([]);
  const [appointmentListNew, setAppointmentListNew] = useState([]);
  const [timeModal, setTimeModal] = useState(false);
  const [allTimerList, setAllTimerList] = useState([]);
  const [customTimeModal, setCustomTimeModal] = useState(false);
  const [openStartTime, setOpenStartTime] = useState(false);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [customTimeNote, setCustomTimeNote] = useState('');
  const [selectedStartTime, setSelectedStartTime] = useState('');
  const [selectedEndtime, setSelectedEndtime] = useState('');
  const [totalNewDiscount, setTotalNewDiscount] = useState('');
  // const [selectedStartTime, setSelectedStartTime] = useState(
  //   moment().format('hh:mma'),
  // );
  // const [selectedEndtime, setSelectedEndtime] = useState(
  //   moment().format('hh:mma'),
  // );
  const [openEndTime, setOpenEndTime] = useState(false);
  const [depositModal, setDepositModal] = useState(false);
  const [depositPercentage, setDepositPercentage] = useState(0);
  const [calculatedAmount, setCalculatedAmount] = useState('');
  const [depositType, setDepositType] = useState('Percentage');
  const [openDepositDueDate, setOpenDepositDueDate] = useState(false);
  const [depositDueDate, setDepositDueDate] = useState('');
  const [itemCode, setItemCode] = useState('');
  const [editDiscountModal, setEditDiscountModal] = useState(false);
  const [disType, setDisType] = useState('flat');
  const [editedDiscount, setEditedDiscount] = useState('');
  const [selectedExpenses, setSelectedExpenses] = useState([]);
  const [expenseModal, setExpenseModal] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState('');
  const [unitModal, setUnitModal] = useState(false);
  const TERMS_OPTIONS = [
    {value: '', label: 'None', days: 0},
    {value: '1', label: 'Custom', days: 0},
    {value: '2', label: 'Next Day', days: 1},
    {value: '3', label: '2 Days', days: 2},
    {value: '4', label: '3 Days', days: 3},
    {value: '5', label: '4 Days', days: 4},
    {value: '6', label: '5 Days', days: 5},
    {value: '7', label: '10 Days', days: 10},
    {value: '8', label: '30 Days', days: 30},
    {value: '9', label: '90 Days', days: 90},
    {value: '10', label: '180 Days', days: 180},
    {value: '11', label: '365 Days', days: 365},
  ];
  const discountPercentage = [
    {
      id: 100,
      name: 'Flat',
    },
    {
      id: 101,
      name: 'Percentage',
    },
  ];

  const flattenedExpenses = expenseList?.flatMap(category => category.expenses);

  useFocusEffect(
    useCallback(() => {
      let payload = {}
      dispatch(getClientRequest(payload));
      dispatch(getInvoiceSettingsRequest());
      dispatch(getInvoiceOptionsSettingsRequest());
      dispatch(getExpenseListRequest());
      dispatch(getCommonListRequest());
    }, []),
  );

  useEffect(() => {
    dispatch(getAllTimesRequest({id: clientDetails?.id}));
  }, [clientDetails]);

  useEffect(() => {
    const result = groupByTaskIdWithTotalTime(allTimes);
    console.log('after sorting time list', JSON.stringify(result));
    setAllTimerList(result);
  }, [allTimes]);

  useEffect(() => {
    if (totalAm > 0 && calculatedAmount !== 0) {
      if (calculatedAmount > totalAm) {
        Toast('Deposit amount can not be greater than total amount');
      }
    }
  }, [calculatedAmount]);

  useEffect(() => {
    setCalculatedAmount(0);
  }, [addedItems]);

  function groupByTaskIdWithTotalTime(data) {
    const grouped = data.reduce((acc, item) => {
      const key = item.task_id;

      // Initialize group if not exists
      if (!acc[key]) {
        acc[key] = {
          task_id: key,
          task_name: item.task_name || item.client_name,
          task_description: item.task_description,
          totalTimeInSeconds: 0,
          notes: item.notes,
        };
      }

      // Parse timeDifference (HH:MM:SS)
      const [h, m, s] = item.timeDifference.split(':').map(Number);
      const seconds = h * 3600 + m * 60 + (s || 0);
      acc[key].totalTimeInSeconds += seconds;

      return acc;
    }, {});

    // Convert seconds back to HH:MM:SS and return as array
    return Object.values(grouped).map(group => {
      const total = group.totalTimeInSeconds;
      const hours = Math.floor(total / 3600)
        .toString()
        .padStart(2, '0');
      const minutes = Math.floor((total % 3600) / 60)
        .toString()
        .padStart(2, '0');
      const seconds = (total % 60).toString().padStart(2, '0');

      return {
        ...group,
        totalTime: `${hours}:${minutes}:${seconds}`,
        // Optional: remove totalTimeInSeconds if not needed
        // totalTimeInSeconds: undefined
      };
    });
  }

  const renderImageItem = ({item, index}) => (
        <View style={styles.imageItemWrapper}>
          <View style={styles.imageContainer}>
            <Image source={{uri: item}} style={styles.image} resizeMode="cover" />
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => removeImage(index)}
              hitSlop={{top: 10, bottom: 10, left: 10, right: 10}} // Increases touch area
            >
              <Image
                resizeMode="contain"
                style={styles.deleteIcon}
                source={ICONS.crossbtn}
              />
            </TouchableOpacity>
          </View>
        </View>
      );

  const removeImage = index => {
    setLogoImg(prev => prev.filter((_, i) => i !== index));
  };
  useEffect(() => {
    const newarr = appointmentList
      .flatMap(item =>
        item.appointments.map(app => ({
          id: app.id,
          name: app.client?.name, // Safe access in case client is missing
          description: app.notes,
          rate: '',
          quantity: '',
          gstChecked: false,
          gstValue: '',
          discountChecked: false,
          discountType: '',
          discountValue: '',
        })),
      )
      .filter(item => item.id != null);
    console.log('appointment list new', JSON.stringify(newarr));
    setAppointmentListNew(newarr);
  }, [appointmentList]);

  useEffect(() => {
    // Set current date in dd/mm/yyyy format on mount
    const today = moment().format('YYYY-MM-DD');
    setSlectedDate(today);
    setDueDate(today);
  }, []);

  useEffect(() => {
    let payload = {};
    dispatch(getItemsListReqest(payload));
    //dispatch(getClientRequest(payload));
    dispatch(invoiceListRequest(payload));
  }, []);

  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useEffect(() => {
    let payload = {};
    dispatch(getItemsListReqest(payload));
  }, []);

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  const paymentMethod = [
    {
      id: 100,
      method: 'Card Payment',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.card,
    },
    {
      id: 101,
      method: 'Bank Transfers',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.bank,
    },
    {
      id: 102,
      method: 'Paypal',
      description: '',
      img: ICONS.paypal,
    },
  ];

  const renderPayment = ({item, index}) => {
    let isSelected = item.id == selectedPayment;
    return (
      <View
        style={{
          flex: 1,
          padding: 20,
          backgroundColor: COLORS.white,
          borderWidth: 0.2,
          borderColor: COLORS.themeColor,
          borderRadius: ms(10),
          elevation: 5,
          shadowColor: 'rgba(4, 127, 255, 0.2)',
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <View
            style={{
              padding: 10,
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(5),
            }}>
            <Image
              style={{height: ms(30), width: ms(30), resizeMode: 'contain'}}
              source={item.img}
            />
          </View>
          <View>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  color: COLORS.textColor,
                  marginLeft: ms(15),
                  fontSize: ms(14),
                }}>
                {item.method}
              </Text>
              <Image
                source={ICONS.knowmore}
                style={{
                  height: ms(11),
                  width: ms(11),
                  resizeMode: 'contain',
                  marginLeft: ms(5),
                }}
              />
            </View>
            {item.description ? (
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  color: COLORS.gray,
                  marginLeft: ms(15),
                  fontSize: ms(12),
                }}>
                {item.description}
              </Text>
            ) : null}
          </View>

          <TouchableOpacity
            style={{position: 'absolute', top: 20, right: 10}}
            onPress={() => {
              if (selectedPayment == item.id) {
                setSelectedPayment('');
              } else {
                setSelectedPayment(item.id);
              }
            }}>
            {isSelected ? (
              <Image
                source={ICONS.switch}
                style={{height: ms(20), width: ms(32)}}
                resizeMode="contain"
              />
            ) : (
              <Image
                source={ICONS.switchoff}
                style={{height: ms(20), width: ms(32)}}
                resizeMode="contain"
              />
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const ItemSeparator = () => {
    return <View style={{height: ms(1), marginVertical: ms(5)}} />;
  };

  const findItemsss = () => {
    // Step 1: Filter selected items from itemList
    const temp = allTimerList.filter(item =>
      selectedItemsss.includes(item.task_id),
    );
    console.log('after selectionn', JSON.stringify(temp));

    // Step 2: Transform the selected items into the desired format
    const myObj = temp.map(item => ({
      id: item.task_id,
      item_name: item.task_name,
      item_Description: item.notes + '( ' + item.totalTime + ' )',
      rate: '',
      qty: '',
      tax: '',
      discount: '', // consider setting a default or pulling from item
      discountType: '', // same as above
      days: '',
      subtotal: '',
      productTotal: '',
    }));

    console.log('transformed items', JSON.stringify(myObj));

    // Step 3: Update addedItems array in a single state update

    //setAddedItems(prev => [...prev, ...myObj]);
    setAddedItems(prev => {
      const existingIds = new Set(prev.map(item => item.id));
      const existingNames = new Set(prev.map(item => item.item_name));

      const newItems = myObj.filter(
        item => !existingIds.has(item.id) && !existingNames.has(item.item_name),
      );

      return [...prev, ...newItems];
    });

    // Step 4: Clear selected items
    setSelectedItemsss([]);
    setTimeModal(false);
    //setModalVisible(false);
  };
  const checkValidation = () => {
    let subtotal;
    let discount;
    if (itemName == '') {
      Toast('Enter item name');
    } else if (itemDescription == '') {
      Toast('Enter item description');
    } else if (rate == '') {
      Toast('Enter rate');
    } else if (quantity == '') {
      Toast('Enter quantity');
    } else if (tax == '') {
      Toast('Enter tax');
    } else {
      if (selectedDiscount == 'Flat') {
        subtotal = Number(quantity) * Number(rate) - Number(days);
        discount = Number(days);
      } else if (selectedDiscount == 'Percentage') {
        discount = Number(quantity) * Number(rate) * (Number(days) / 100);
        subtotal = Number(quantity) * Number(rate) - discount;
      } else {
        subtotal = Number(quantity) * Number(rate);
        discount = 0;
      }
      let payload = {
        id: '',
        item_name: itemName,
        item_Description: itemDescription,
        rate: rate,
        qty: quantity,
        tax: tax,
        days: days,
        discountType: selectedDiscount,
        subtotal: subtotal,
        discount: discount,
        productTotal: quantity * rate,
        itemCode: itemCode || '',
        unitTypes: selectedUnit,
      };
      setAddedItems([...addedItems, payload]);
      // dispatch(addItemsRequest(payload));
      setModalVisible(false);
      setItemName('');
      setItemDescription('');
      setRate('');
      setQuantity('');
      setTax('');
      setDays('');
      setSelectedUnit('');
      //setSelectedDiscount('Flat');
    }
  };
  // useEffect(() => {
  //   console.log('added items', JSON.stringify(addedItems));
  //   if (addedItems.length > 0) {
  //     let grand_total = 0;
  //     let grand_discount = 0;
  //     let totalTax = 0;
  //     for (const item of addedItems) {
  //       if(item?.qty !== "" && item?.rate == ""){
  //         grand_total += Number(item.qty) * Number(item.rate);
  //       grand_discount += Number(item.discount);
  //       totalTax +=
  //         Number(item.qty) * Number(item.rate) * (Number(item.tax) / 100);

  //       }else{
  //         grand_total += 0
  //       grand_discount += 0
  //       totalTax +=0

  //       }

  //     }

  //     setAllTotal(grand_total);
  //     setTotalDiscount(grand_discount);
  //     let totall = grand_total - grand_discount;
  //     setTotalAm(totall);
  //     setGrandTax(totalTax);
  //   }else{
  //     setAllTotal(0);
  //     setTotalDiscount(0);
  //     //let totall = grand_total - grand_discount;
  //     setTotalAm(0);
  //     setGrandTax(0)

  //   }
  // }, [addedItems]);
  const checkValidationForAddInvoice = async () => {
    let autosaveStatus = await AsyncStorage.getItem('autosave');
    let items_arr = addedItems.map((item, index) => {
      let obj = {
        id: item.id,
        name: item.item_name,
        description: item.item_Description,
        rate: item.rate,
        quantity: item.qty,
        gstChecked: false,
        gstValue: item.tax,
        discountChecked: false,
        discountType: item.discountType,
        discountValue: item.days,
        code: item.itemCode || '',
        unitTypes: item?.unitTypes || '',
      };
      return obj;
    });

    // console.log('submit items', JSON.stringify(items_arr));
    // console.log('client details', JSON.stringify(clientDetails));
    // console.log('due date', dueDateNew, 'date', selectedDateNew);

    let client_Detail = {
      id: clientDetails?.id,
      uuid: clientDetails?.uuid,
      name: clientDetails?.name,
      email: clientDetails.email,
      phone: clientDetails?.phone,
      isActive: clientDetails?.isActive,
      isVerified: clientDetails?.isVerified,
      createdAt: clientDetails?.createdAt,
      updatedAt: clientDetails?.updatedAt,
    };

    let invSttngs = {
      id: invoiceSettings?.id || null,
      templateName: invoiceSettings?.name || '',
      logoId: invoiceSettings?.logoDetails?.id || '',
      logoImage: invoiceSettings?.logoDetails?.logoImage || '',
      logoSize: invoiceSettings?.logoSize || 'medium',
      logoPosition: invoiceSettings?.logoPosition || 'center',
      colourId: invoiceSettings?.colourDetails?.id || '',
      colourCode: invoiceSettings?.colourDetails?.colourCode || '',
      customColour: invoiceSettings?.colourDetails?.colourCode || '',
      headerId: invoiceSettings?.headerDetails?.id || '',
      headerImg: invoiceSettings?.headerDetails?.headerImg || '',
      waterMarkId: invoiceSettings?.waterMarkDetails?.id || '',
      waterMarkImg: invoiceSettings?.waterMarkDetails?.waterMarkImg || '',
    };

    let invOp = {
      id: invoiceOptionSettings?.id || null,
      shippingDetails: invoiceOptionSettings?.shippingDetails || false,
      due_date: invoiceOptionSettings?.due_date || false,
      payment_terms: invoiceOptionSettings?.payment_terms || false,
      itemCode: invoiceOptionSettings?.itemCode || false,
      quantityAndRate: invoiceOptionSettings?.quantityAndRate || false,
      pTax: invoiceOptionSettings?.pTax || false,
      tax_amounts: invoiceOptionSettings?.tax_amounts || false,
      includeSignatureLine:
        invoiceOptionSettings?.includeSignatureLine || false,
      invoicePrifix: invoiceOptionSettings?.invoicePrifix || '',
    };

    let payload = {
      invoiceNumber: invoiceList.length + 1,
      client_id: client_Detail,
      items: items_arr,
      date: moment(selectedDateNew).format('YYYY-MM-DD[T]HH:mm:ss[Z]'),
      term: newTerm,
      // term:{
      //   dueDate:moment(dueDateNew).format('YYYY-MM-DD[T]HH:mm:ss[Z]')
      // },
      dueDate: moment(dueDateNew).format('YYYY-MM-DD[T]HH:mm:ss[Z]'),
      subTotal: allTotal,
      discount: totalDiscount,
      total: totalAm,
      paid: 0,
      balance: totalAm,
      paymentStatus: 'unpaid',
      //logo: logoImg,
      attachments: logoImg,
      autosaveEnabled: autosaveStatus == 'enabled' ? true : false,
      customInvoice: invSttngs,
      customInvoiceOption: invOp,
      comment: invoiceNote,
    };

    let depositObj = {};

    if (calculatedAmount !== 0) {
      if (depositType == 'Percentage') {
        depositObj.type = 'percent';
        depositObj.percentage = depositPercentage;
        depositObj.amount = calculatedAmount;
        depositObj.dueDate = depositDueDate;
        depositObj.addToFuture = false;
        depositObj.paid = 0;
      } else if (depositType == 'Fix') {
        depositObj.type = 'fix';
        //depositObj.percentage = depositPercentage
        depositObj.amount = calculatedAmount;
        depositObj.dueDate = depositDueDate;
        depositObj.addToFuture = false;
        depositObj.paid = 0;
      }
      payload.deposit = depositObj;
    }
    if (Number(totalAm) == 0) {
      Toast('Total amount can not be 0 ');
    } else {
      dispatch(invoiceCreateRequest(payload));
    }

    //dispatch(invoiceCreateRequest(payload));
  };

  useEffect(() => {
    console.log('added items', JSON.stringify(addedItems));

    if (addedItems.length > 0) {
      let grand_total = 0;
      let grand_discount = 0;
      let totalTax = 0;

      for (const item of addedItems) {
        // Check if qty and rate are present and can be converted to numbers
        const qty = Number(item.qty);
        const rate = Number(item.rate);

        // Only include items with valid qty and rate
        if (
          item.qty !== '' &&
          item.rate !== '' &&
          !isNaN(qty) &&
          !isNaN(rate)
        ) {
          const itemTotal = qty * rate;
          const discount = Number(item.discount) || 0;
          const taxPercent = Number(item.tax) || 0;

          grand_total += itemTotal;
          grand_discount += discount;
          //totalTax += itemTotal * (taxPercent / 100);
          totalTax += parseFloat((itemTotal * (taxPercent / 100)).toFixed(2));
        }
        // Else: skip invalid/incomplete items
      }

      setAllTotal(grand_total);
      setTotalDiscount(parseFloat(grand_discount).toFixed(2));
      setTotalAm(grand_total - grand_discount);
      setGrandTax(totalTax);
    } else {
      setAllTotal(0);
      setTotalDiscount(0);
      setTotalAm(0);
      setGrandTax(0);
    }
  }, [addedItems]);
  function isEmpty(item) {
    if (item == null || item == '' || item == undefined) return true;
    return false;
  }
  const renderItemseparator = () => {
    return (
      <View
        style={{
          height: ms(1),
          width: '100%',
          marginVertical: ms(10),
          backgroundColor: COLORS.border,
        }}
      />
    );
  };
  const editHandle = (item, index) => {
    let disCountType;
    if (item.disCountType == '') {
      setSelectedDiscount('Flat');
    } else {
      setSelectedDiscount(item.discountType);
    }
    setItemName(item.item_name);
    setItemDescription(item.item_Description);
    setRate(item.rate);
    setQuantity(item.qty);
    setTax(item.tax);
    setDays(String(item.days));
    setEditIndex(Number(index));
    if (invoiceOptionSettings?.itemCode) {
      setItemCode(item.itemCode);
    }
    if (item?.unitTypes) {
      setSelectedUnit(item?.unitTypes);
    } else {
      setSelectedUnit('');
    }

    setOpenEditModal(true);
  };

  const editItem = () => {
    //alert(editIndex)
    let subtotal;
    let discount;
    let temp = addedItems.map((item, index) => {
      if (index == editIndex) {
        if (selectedDiscount == 'Flat') {
          subtotal = Number(quantity) * Number(rate) - Number(days);
          discount = Number(days);
        } else if (selectedDiscount == 'Percentage') {
          discount = Number(quantity) * Number(rate) * (Number(days) / 100);
          subtotal = Number(quantity) * Number(rate) - discount;
        } else {
          subtotal = Number(quantity) * Number(rate);
          discount = 0;
        }
        let payload = {
          id: item.id,
          item_name: itemName,
          item_Description: itemDescription,
          rate: rate,
          qty: quantity,
          tax: tax,
          discount: days,
          discountType: selectedDiscount,
          subtotal: subtotal,
          discount: discount,
          days: days,
          productTotal: quantity * rate,
          itemCode: itemCode || '',
          unitTypes: selectedUnit,
        };
        return payload;
      } else {
        return item;
      }
    });
    setAddedItems(temp);
    setOpenEditModal(false);

    setItemName('');
    setItemDescription('');
    setRate('');
    setQuantity('');
    setTax('');
    setDays('');
    setSelectedUnit('');
  };

  const findItems = () => {
    // Step 1: Filter selected items from itemList
    const temp = itemList.filter(item => selectedItems.includes(item.uuid));
    console.log('after selection', JSON.stringify(temp));

    // Step 2: Transform the selected items into the desired format
    const myObj = temp.map(item => ({
      id: item.id,
      item_name: item.item_name,
      item_Description: item.item_Description,
      rate: String(item.rate),
      qty: String(item.qty),
      tax: String(item.tax),
      discount: 0, // consider setting a default or pulling from item
      discountType: '', // same as above
      days: String(0),
      subtotal: Number(item.qty) * Number(item.rate),
      productTotal: Number(item.qty) * Number(item.rate),
    }));

    console.log('transformed items', JSON.stringify(myObj));

    // Step 3: Update addedItems array in a single state update

    //setAddedItems(prev => [...prev, ...myObj]);
    setAddedItems(prev => {
      const existingIds = new Set(prev.map(item => item.id));
      const existingNames = new Set(prev.map(item => item.item_name)); // all current IDs

      const newItems = myObj.filter(
        item => !existingIds.has(item.id) && !existingNames.has(item.item_name),
      ); // ✅ filter used here

      return [...prev, ...newItems];
    });

    // Step 4: Clear selected items
    setSelectedItems([]);
    setOpenItemList(false);
    setTimeout(() => {
      setModalVisible(false);
    }, 1000);
  };

  const findExpense = () => {
    // Step 1: Filter selected items from itemList
    const temp = flattenedExpenses.filter(item =>
      selectedExpenses.includes(item.id),
    );
    console.log('after selection', JSON.stringify(temp));

    // Step 2: Transform the selected items into the desired format
    const myObj = temp.map(item => ({
      id: item.id,
      item_name: item.merchant,
      item_Description: item.description,
      rate: String(item.rate),
      qty: String(1),
      tax: String(item.tax),
      discount: 0, // consider setting a default or pulling from item
      discountType: '', // same as above
      days: String(0),
      subtotal: Number(1) * Number(item.rate),
      productTotal: Number(1) * Number(item.rate),
    }));

    console.log('transformed items', JSON.stringify(myObj));

    // Step 3: Update addedItems array in a single state update

    //setAddedItems(prev => [...prev, ...myObj]);
    setAddedItems(prev => {
      const existingIds = new Set(prev.map(item => item.id));
      const existingNames = new Set(prev.map(item => item.item_name)); // all current IDs

      const newItems = myObj.filter(
        item => !existingIds.has(item.id) && !existingNames.has(item.item_name),
      ); // ✅ filter used here

      return [...prev, ...newItems];
    });

    // Step 4: Clear selected items
    //setSelectedItems([]);
    setSelectedExpenses([]);
    //setOpenItemList(false);
    setExpenseModal(false);
  };

  const findItemss = () => {
    // Step 1: Filter selected items from itemList
    const temp = appointmentListNew.filter(item =>
      selectedItemss.includes(item.id),
    );
    console.log('after selectionn', JSON.stringify(temp));

    // Step 2: Transform the selected items into the desired format
    const myObj = temp.map(item => ({
      id: item.id,
      item_name: item.name,
      item_Description: item.description,
      rate: '',
      qty: '',
      tax: '',
      discount: '', // consider setting a default or pulling from item
      discountType: '', // same as above
      days: '',
      subtotal: '',
      productTotal: '',
    }));

    console.log('transformed items', JSON.stringify(myObj));

    // Step 3: Update addedItems array in a single state update

    //setAddedItems(prev => [...prev, ...myObj]);
    setAddedItems(prev => {
      const existingIds = new Set(prev.map(item => item.id));
      const existingNames = new Set(prev.map(item => item.item_name));

      const newItems = myObj.filter(
        item => !existingIds.has(item.id) && !existingNames.has(item.item_name),
      );

      return [...prev, ...newItems];
    });

    // Step 4: Clear selected items
    setSelectedItemss([]);
    setAppointModal(false);
    //setModalVisible(false);
  };

  const handleDelete = (item, itemIndex) => {
    Alert.alert('Delete', 'Are you sure you want to delete this item?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel', // 'cancel' style is typically for the dismissive button
      },
      {
        text: 'OK',
        onPress: () => {
          let temp = addedItems.filter((item, index) => {
            return index !== itemIndex;
          });
          setAddedItems(temp);
        },
      },
    ]);
    //alert(itemIndex)
  };

  const calculateDuedate = item => {
    //alert(selectedDate)
    if (item.label == 'Custom') {
      setOpenCustom(true);
      setNewterm(item.value);
    } else {
      setNewterm(item.value);
      const futureDate = moment(selectedDate).add(item?.days, 'days').toDate();
      console.log('select due date', moment(futureDate).format('YYYY-MM-DD'));
      setDueDate(moment(futureDate).format('YYYY-MM-DD'));
      setDueDateNew(futureDate);
    }
  };

  const onPressGallery = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Image picker cancelled or failed:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          // Create image object with Base64
          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(), // fallback to last part of URI
            type: asset.type, // e.g., 'image/jpeg'
            uri: asset.uri,
            size: asset.fileSize,
            base64: `data:${asset.type};base64,${asset.base64}`, // Full data URL
          };

          console.log('Image with Base64:', imageObj);
          //setLogoImg(imageObj.base64);
          setLogoImg(prev => [...prev, imageObj.base64]);

          // Pass to parent component

          setCamModal(false); // Close modal
        }
      },
    );
  };

  const onPressCamera = () => {
    launchCamera(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Camera cancelled or error:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(),
            type: asset.type,
            uri: asset.uri,
            size: asset.fileSize,
            base64: `data:${asset.type};base64,${asset.base64}`, // Ready for upload or display
          };

          console.log('Photo with Base64:', imageObj);

          //setLogoImg(imageObj.base64);
          setLogoImg(prev => [...prev, imageObj.base64]);
          setCamModal(false);
        }
      },
    );
  };
  const getCustomItems = () => {
    console.log('start time', startTime, 'end time', endTime);
    const start = moment(startTime);
    const end = moment(endTime);
    const duration = moment.duration(end.diff(start));
    const hours = Math.floor(duration.asHours());
    const minutes = duration.minutes();
    const seconds = duration.seconds();
    const formattedTime = `${String(hours).padStart(2, '0')}:${String(
      minutes,
    ).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    console.log(formattedTime);
    let payload = {
      id: '',
      item_name: clientDetails?.name,
      item_Description: customTimeNote + '( ' + formattedTime + ' )',
      rate: '',
      qty: '',
      tax: '',
      discount: '', // consider setting a default or pulling from item
      discountType: '', // same as above
      days: '',
      subtotal: '',
      productTotal: '',
    };
    setAddedItems([...addedItems, payload]);
    setCustomTimeModal(false);
    let payloadd = {
      id: null,
      project_id: null,
      client_id: clientDetails.id,
      task_id: getRandomNumber(70, 300),
      start_time: moment(start).format('HH:mm'),
      end_time: moment(end).format('HH:mm'),
      notes: customTimeNote,
    };
    dispatch(addCustomTimeRequest(payloadd));
  };
  function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(1),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add Invoice'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={() => checkValidationForAddInvoice()}
        />
      </View>
      <DatePicker
        modal
        //mode={'date'}
        open={openStart}
        date={new Date()}
        onConfirm={date => {
          //setStartDate(date);
          setSelectedDateNew(date);
          setSlectedDate(moment(date).format('YYYY-MM-DD'));
          console.log(date);
          setOpenStart(false);
        }}
        onCancel={() => {
          setOpenStart(false);
        }}
      />
      <DatePicker
        modal
        //mode={'date'}
        open={openDepositDueDate}
        date={new Date()}
        onConfirm={date => {
          //setStartDate(date);
          //setSelectedDateNew(date);
          setDepositDueDate(moment(date).format('DD-MM-YYYY'));
          console.log(date);
          setOpenDepositDueDate(false);
        }}
        onCancel={() => {
          setOpenDepositDueDate(false);
        }}
      />

      <DatePicker
        modal
        //mode={'date'}
        open={openCustom}
        date={new Date()}
        onConfirm={date => {
          //setStartDate(date);
          setDueDateNew(date);
          setDueDate(moment(date).format('YYYY-MM-DD'));
          console.log(date);
          setOpenCustom(false);
        }}
        onCancel={() => {
          setOpenCustom(false);
        }}
      />

      <DatePicker
        modal
        mode={'time'}
        open={openStartTime}
        date={new Date()}
        onConfirm={time => {
          //setStartDate(date);
          //setSelectedDateNew(date);
          //setSlectedDate(moment(date).format('YYYY-MM-DD'));
          console.log('start time', time);
          setSelectedStartTime(moment(time).format('hh:mma'));
          setStartTime(time);
          setOpenStartTime(false);
        }}
        onCancel={() => {
          setOpenStartTime(false);
        }}
      />
      <DatePicker
        modal
        mode={'time'}
        open={openEndTime}
        date={new Date()}
        onConfirm={time => {
          //setStartDate(date);
          //setSelectedDateNew(date);
          //setSlectedDate(moment(date).format('YYYY-MM-DD'));
          console.log('start time', time);
          setEndTime(time);
          setSelectedEndtime(moment(time).format('hh:mma'));
          setOpenEndTime(false);
        }}
        onCancel={() => {
          setOpenEndTime(false);
        }}
      />

      <KeyboardAwareScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <TouchableOpacity
            onPress={() => setBillContent(!billContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: '#047FFF',
              }}>
              Bill To
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: billContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {billContent ? (
            <View style={{flex: 1, paddingVertical: ms(10)}}>
              <View
                style={{
                  backgroundColor: COLORS.backgraound,
                  borderRadius: ms(10),
                  borderWidth: 0.6,
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  padding: ms(15),
                  // height: ms(45),
                  elevation: 2,
                  shadowColor: COLORS?.themeColor,
                  //backgroundColor: COLORS?.white,
                }}>
                <TouchableOpacity
                  style={{position: 'absolute', top: 15, right: 15}}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(16), width: ms(16)}}
                    source={ICONS.crossbtn}
                  />
                </TouchableOpacity>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <View
                    style={{
                      height: ms(80),
                      width: ms(80),
                      borderRadius: ms(40),
                      backgroundColor: '#44BBFE',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    {clientDetails?.profileImage ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(80),
                          width: ms(80),
                          borderRadius: ms(40),
                        }}
                        source={{
                          uri:
                            constants.IMAGE_URL + clientDetails?.profileImage,
                        }}
                      />
                    ) : (
                      <Text
                        style={{
                          fontFamily: FONTS?.Bold,
                          fontSize: ms(18),
                          color: COLORS?.white,
                        }}>
                        {!isEmpty(
                          clientDetails?.name?.split?.(' ', 2)?.[0]?.[0],
                        )
                          ? clientDetails?.name?.split?.(' ', 2)?.[0]?.[0]
                          : '' +
                            !isEmpty(
                              clientDetails?.name?.split?.(' ', 2)?.[1]?.[0],
                            )
                          ? clientDetails?.name?.split?.(' ', 2)?.[1]?.[0]
                          : ''}
                      </Text>
                    )}
                  </View>
                  <View style={{paddingLeft: ms(13), width: '70%'}}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(16),
                        color: '#344054',
                      }}>
                      {clientDetails?.name}
                    </Text>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <Image
                        style={{
                          height: ms(12),
                          width: ms(15),
                          resizeMode: 'contain',
                        }}
                        source={ICONS.mail}
                      />
                      <Text
                        style={{
                          fontFamily: FONTS?.Regular,
                          fontSize: ms(12),
                          color: '#344054',
                          marginLeft: ms(5),
                        }}>
                        {clientDetails?.email}
                      </Text>
                    </View>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <Image
                        style={{
                          height: ms(15),
                          width: ms(15),
                          resizeMode: 'contain',
                        }}
                        source={ICONS.call}
                      />
                      <Text
                        style={{
                          fontFamily: FONTS?.Regular,
                          fontSize: ms(12),
                          color: '#344054',
                          marginLeft: ms(5),
                        }}>
                        {clientDetails?.phone}
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: 'row',
                        gap: ms(10),
                        alignItems: 'center',
                      }}>
                      <Image
                        source={ICONS?.pinloc}
                        style={{height: ms(12), width: ms(12)}}
                        // resizeMode="contain"
                      />
                      <Text
                        style={{
                          fontFamily: FONTS?.Regular,
                          fontSize: ms(12),
                          color: '#344054',
                          marginLeft: ms(5),
                        }}>
                        {clientDetails?.address}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          ) : null}
          <TouchableOpacity
            onPress={() => setItemContent(!itemContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(10),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Items
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: itemContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {itemContent ? (
            addedItems.length > 0 ? (
              <View>
                <FlatList
                  data={addedItems}
                  renderItem={({item, index}) => {
                    return (
                      <View
                        //onPress={() => editHandle(item, index)}
                        style={[
                          {
                            padding: ms(10),
                            backgroundColor: COLORS.white,
                            borderWidth: ms(0.5),
                            borderColor: '#DEDEDE',
                            borderRadius: ms(6),
                            marginVertical: ms(10),
                          },
                        ]}>
                        <View
                          style={{
                            backgroundColor: 'rgba(4, 127, 255, 0.1)',
                            padding: ms(10),
                            borderRadius: ms(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                            gap: ms(10),
                          }}>
                          {/* Checkbox or Indicator */}

                          <Text
                            style={{
                              fontFamily: FONTS.Medium,
                              fontSize: ms(12),
                              color: COLORS.themeColor,
                            }}>
                            {item.item_name}
                          </Text>
                        </View>

                        {/* Price Row */}
                        <View
                          style={{
                            padding: ms(10),
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              fontFamily: FONTS.Medium,
                              fontSize: ms(13),
                              color: COLORS.black,
                            }}>
                            ${Number(item.productTotal)} {'\n\n'}{' '}
                            {item.item_Description}
                          </Text>
                          <View style={{}}>
                            <TouchableOpacity
                              onPress={() => editHandle(item, index)}>
                              <Image
                                resizeMode="contain"
                                style={{height: ms(15), width: ms(15)}}
                                source={ICONS.editicn}
                              />
                            </TouchableOpacity>
                            <TouchableOpacity
                              onPress={() => handleDelete(item, index)}>
                              <Image
                                resizeMode="contain"
                                style={{
                                  height: ms(15),
                                  width: ms(15),
                                  marginTop: ms(20),
                                }}
                                source={ICONS.delete}
                              />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    );
                  }}
                />
              </View>
            ) : null
          ) : null}

          <View>
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.6),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                height: ms(45),
                elevation: 5,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}
              onPress={() => setModalVisible(true)}>
              <TouchableOpacity
                onPress={() => setModalVisible(true)}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                {/* <View
                             style={{
                               height: ms(15),
                               width: ms(15),
                               borderRadius: ms(5),
                               backgroundColor: COLORS.themeColor,
                               justifyContent: 'center',
                               alignItems: 'center',
                             }}>
                             <Text
                               style={{
                                 fontSize: ms(10),
                                 fontWeight: '800',
                                 color: COLORS.white,
                               }}>
                               +
                             </Text>
                           </View> */}
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontFamily: FONTS.Regular,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                    marginLeft: ms(5),
                  }}>
                  Add Items
                </Text>
              </TouchableOpacity>
            </TouchableOpacity>
          </View>
          <View>
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.6),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                height: ms(45),
                elevation: 5,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}
              onPress={() => setAppointModal(true)}>
              <View
                //onPress={() => setAppointModal(true)}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontFamily: FONTS.Regular,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                    marginLeft: ms(5),
                  }}>
                  Add Appointments
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View>
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.6),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                height: ms(45),
                elevation: 5,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}
              onPress={() => setTimeModal(true)}>
              <View
                //onPress={() => setTimeModal(true)}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontFamily: FONTS.Regular,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                    marginLeft: ms(5),
                  }}>
                  Add Time
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View>
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.6),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                height: ms(45),
                elevation: 5,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}
              onPress={() => {
                if (clientDetails.id) {
                  //setTimeModal(true);
                  setExpenseModal(true);
                } else {
                  Toast('Select client');
                }
              }}>
              <View
                //onPress={() => setTimeModal(true)}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontFamily: FONTS.Regular,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                    marginLeft: ms(5),
                  }}>
                  Add Expense
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View
            style={{
              width: Dimensions.get('window').width,
              height: ms(1.5),
              backgroundColor: COLORS.border,
              marginVertical: ms(20),
              marginLeft: ms(-20),
            }}
          />

          <View style={{paddingHorizontal: ms(10)}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(13),
                  color: '#344054',
                }}>
                Sub Total
              </Text>
              <Text style={{fontFamily: FONTS.Medium, fontSize: ms(13)}}>
                ${allTotal}
              </Text>
            </View>
          </View>
          <View
            style={{
              width: '100%',
              height: ms(0.7),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View style={{marginTop: ms(10), paddingHorizontal: ms(10)}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(13),
                  color: '#344054',
                }}>
                Tax
              </Text>
              <Text style={{fontFamily: FONTS.Medium, fontSize: ms(13)}}>
                ${grandTax}
              </Text>
            </View>
          </View>
          <View
            style={{
              width: '100%',
              height: ms(0.7),
              backgroundColor: COLORS.border,
              marginTop: ms(20),
            }}
          />
          {/* <TouchableOpacity
                                   style={{
                                     padding: ms(8),
                                     borderWidth: ms(0.6),
                                     marginTop: ms(10),
                                     borderRadius: ms(10),
                                     borderColor: COLORS?.themeColor,
                                     justifyContent: 'center',
                                     alignItems: 'center',
                                     height: ms(45),
                                     elevation: 3,
                                     shadowColor: COLORS.themeColor,
                                     backgroundColor: COLORS.white,
                                   }}>
                                   <View style={{flexDirection: 'row', alignItems: 'center'}}>
                                     
                                     <Image
                                       resizeMode="contain"
                                       style={{height: ms(15), width: ms(15)}}
                                       source={ICONS.plusicn}
                                     />
                                     <Text
                                       style={{
                                         fontFamily: FONTS.Regular,
                                         fontSize: ms(14),
                                         color: COLORS.themeColor,
                                         marginLeft: ms(5),
                                       }}>
                                       Add discount
                                     </Text>
                                   </View>
                                 </TouchableOpacity> */}
          <View style={{marginTop: ms(10), paddingHorizontal: ms(10)}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(13),
                  color: '#344054',
                }}>
                Discount
              </Text>

              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                {allTotal == 0 ? null : (
                  <TouchableOpacity onPress={() => setEditDiscountModal(true)}>
                    <Image
                      resizeMode="contain"
                      source={ICONS.editicn}
                      style={{height: ms(15), width: ms(15)}}
                    />
                  </TouchableOpacity>
                )}

                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    marginLeft: ms(5),
                    fontSize: ms(13),
                  }}>
                  ${totalDiscount}
                </Text>
              </View>
            </View>
          </View>
          <View
            style={{
              width: '100%',
              height: ms(0.7),
              backgroundColor: COLORS.border,
              marginTop: ms(20),
            }}
          />
          <View style={{marginTop: ms(10), paddingHorizontal: ms(10)}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(13),
                  color: '#344054',
                }}>
                Total
              </Text>
              <Text style={{fontFamily: FONTS.Medium, fontSize: ms(13)}}>
                ${totalAm}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => setTermContent(!termContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              //elevation:2,
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Payment Term
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: termContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {termContent ? (
            <View>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  borderWidth: ms(0.6),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: ms(12),

                  height: ms(45),
                  elevation: 5,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  marginTop: ms(20),
                }}
                onPress={() => {
                  //setClientModal(true);
                  setOpenStart(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(13),
                    color: COLORS?.themeColor,
                  }}>
                  Date: {selectedDate}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(14),
                    transform: [{rotate: '180deg'}],
                  }}
                  resizeMode="contain"
                  tintColor={COLORS.themeColor}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  padding: ms(10),
                  borderWidth: ms(0.6),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: ms(12),

                  height: ms(45),
                  elevation: 5,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  marginTop: ms(20),
                }}
                onPress={() => {
                  setTermsModal(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(13),
                    color: COLORS?.themeColor,
                  }}>
                  Due date: {dueDate}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(14),
                    transform: [{rotate: '180deg'}],
                  }}
                  resizeMode="contain"
                  tintColor={COLORS.themeColor}
                />
              </TouchableOpacity>
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => setMethodContent(!methodContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              //elevation:2,
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Payment Methods
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: methodContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {methodContent ? (
            <View style={{paddingTop: ms(20)}}>
              <FlatList
                data={paymentMethod}
                renderItem={renderPayment}
                ItemSeparatorComponent={ItemSeparator}
              />
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => setInstructionContent(!instructionContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Payment Instruction
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: instructionContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {instructionContent ? (
            <View style={{marginTop: ms(10)}}>
              <TouchableOpacity
                onPress={() => setOpenInstruction(true)}
                style={{
                  padding: ms(8),
                  borderWidth: ms(0.6),
                  marginTop: ms(10),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  height: ms(45),
                  elevation: 2,
                  shadowColor: COLORS?.themeColor,
                  backgroundColor: COLORS?.white,
                }}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(15), width: ms(15)}}
                    source={ICONS.plusicn}
                  />
                  <Text
                    style={{
                      fontFamily: FONTS.Regular,
                      fontSize: ms(14),
                      color: COLORS.themeColor,
                      marginLeft: ms(5),
                    }}>
                    Add Payment Instruction
                  </Text>
                </View>
              </TouchableOpacity>
              {openInstruction ? (
                <View style={{alignSelf: 'center'}}>
                  <AnimatedTextInput
                    label={'Payment instruction'}
                    //keyboardType={'numeric'}
                    minimumHeight={ms(45)}
                    width={
                      isTablet
                        ? Dimensions?.get('window')?.width - 70
                        : Dimensions?.get('window')?.width - 50
                    }
                    value={paymentInstruction}
                    borderColor={COLORS?.themeColor}
                    multiline={true}
                    numberOfLines={5}
                    onChangeText={item => {
                      setPaymentInstruction(item);
                    }}
                  />
                </View>
              ) : null}

              <TouchableOpacity
                onPress={() => {
                  if (addedItems.length == 0) {
                    Toast('Select item');
                  } else {
                    setDepositModal(true);
                  }
                }}
                style={{
                  padding: ms(8),
                  borderWidth: ms(0.6),
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  height: ms(45),
                  elevation: 2,
                  shadowColor: COLORS?.themeColor,
                  backgroundColor: COLORS?.white,
                }}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(15), width: ms(15)}}
                    source={ICONS.plusicn}
                  />
                  <Text
                    style={{
                      fontFamily: FONTS.Regular,
                      fontSize: ms(14),
                      color: COLORS.themeColor,
                      marginLeft: ms(5),
                    }}>
                    Add Deposit Request
                  </Text>
                </View>
              </TouchableOpacity>
              {calculatedAmount !== 0 ? (
                <View
                  onPress={() => {
                    if (addedItems.length == 0) {
                      Toast('Select item');
                    } else {
                      setDepositModal(true);
                    }
                  }}
                  style={{
                    padding: ms(8),
                    borderWidth: ms(0.6),
                    marginTop: ms(15),
                    borderRadius: ms(10),
                    borderColor: COLORS?.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: ms(45),
                    elevation: 2,
                    shadowColor: COLORS?.themeColor,
                    backgroundColor: COLORS?.white,
                  }}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        color: COLORS.themeColor,
                        marginLeft: ms(5),
                      }}>
                      Deposit amount : ${calculatedAmount}
                    </Text>
                  </View>
                </View>
              ) : null}
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => setMoreContent(!moreContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Others
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: moreContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {/* {moreContent ? (
            <View
              style={{
                padding: ms(25),
                width: '40%',
                backgroundColor: COLORS.white,
                borderRadius: 15,
                borderStyle: 'dotted',
                borderColor: COLORS.themeColor,
                borderWidth: 1,
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: ms(20),
                marginBottom: ms(0),
                elevation: 3,
                shadowColor: COLORS.themeColor,
              }}>
              {logoImg ? (
                <TouchableOpacity
                  style={{alignSelf: 'flex-end'}}
                  onPress={() => setLogoImg('')}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(15), width: ms(15)}}
                    source={ICONS.crossbtn}
                  />
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity onPress={() => setCamModal(true)}>
                <Image
                  source={logoImg ? {uri: logoImg} : ICONS.pic}
                  style={{width: ms(40), height: ms(30), resizeMode: 'cover'}}
                />
              </TouchableOpacity>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(10),
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontFamily: FONTS.Regular,
                    fontSize: ms(14),
                    color: COLORS.themeColor,
                    marginLeft: ms(5),
                    marginTop: ms(5),
                  }}>
                  Add photos
                </Text>
              </View>
            </View>
          ) : null} */}
          {moreContent ? (
            <View
                                      style={{
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        marginTop: ms(15),
                                      }}>
                                      <View
                                        style={{
                                          // paddingTop: ms(25),
                                          paddingRight: ms(5),
                                          //width: '35%',
                                          backgroundColor: COLORS.white,
                                          //borderRadius: 15,
                                          //borderStyle: 'dotted',
                                          //borderColor: COLORS.themeColor,
                                          //borderWidth: 1,
                                          justifyContent: 'center',
                                          alignItems: 'center',
                                          //marginTop: ms(20),
                                          marginBottom: ms(0),
                                          //elevation: 3,
                                          //shadowColor: COLORS.themeColor,
                                        }}>
                                        <TouchableOpacity
                                          onPress={() => setCamModal(true)}
                                          style={{
                                            padding: ms(10),
                                            borderRadius: ms(10),
                                            borderWidth: ms(0.6),
                                            borderColor: COLORS.themeColor,
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            borderStyle: 'dotted',
                                            elevation: 2,
                                            backgroundColor: 'white',
                                            shadowColor: COLORS.themeColor,
                                          }}>
                                          <View>
                                            <Image
                                              source={ICONS.attachment}
                                              style={{
                                                width: ms(25),
                                                height: ms(20),
                                                resizeMode: 'cover',
                                              }}
                                            />
                                          </View>
                                          <View
                                            style={{
                                              flexDirection: 'row',
                                              alignItems: 'center',
                                              marginTop: ms(5),
                                            }}>
                                            <Image
                                              resizeMode="contain"
                                              style={{height: ms(15), width: ms(15)}}
                                              source={ICONS.plusicn}
                                            />
                                            <Text
                                              style={{
                                                fontFamily: FONTS.Regular,
                                                fontSize: ms(12),
                                                color: COLORS.themeColor,
                                                marginLeft: ms(5),
                                                //marginTop: ms(5),
                                              }}>
                                              Photo
                                            </Text>
                                          </View>
                                        </TouchableOpacity>
                                      </View>
                                      {logoImg.length > 0 ? (
                                        <FlatList
                                          data={logoImg}
                                          horizontal={true}
                                          renderItem={renderImageItem}
                                          showsHorizontalScrollIndicator={false}
                                        />
                                      ) : null}
                                    </View>
          ) : null}
          {/* <TouchableOpacity
            onPress={() => setOpenNote(true)}
            style={{
              padding: ms(8),
              borderWidth: ms(0.6),
              marginTop: ms(0),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              justifyContent: 'center',
              alignItems: 'center',
              height: ms(45),
              elevation: 2,
              shadowColor: COLORS?.themeColor,
              backgroundColor: COLORS?.white,
              // marginBottom: ms(50),
            }}>
            <View
              style={{flexDirection: 'row', alignItems: 'center', gap: ms(5)}}>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15)}}
                source={ICONS.plusicn}
              />
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(14),
                  color: COLORS.themeColor,
                  //marginLeft: ms(5),
                }}>
                Add note
              </Text>
            </View>
          </TouchableOpacity> */}

          <View style={{alignSelf: 'center', marginBottom: ms(30)}}>
            <AnimatedTextInput
              label={'Note'}
              //keyboardType={'numeric'}
              minimumHeight={ms(70)}
              multiline={true}
              numberOfLines={6}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={invoiceNote}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setInvoiceNote(item);
              }}
            />
          </View>

          <View
            style={{
              width: '100%',
              backgroundColor: COLORS.white,
              // paddingTop: ms(10),
              // position: 'absolute',
              // bottom: 0,
              padding: ms(5),
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                // position: 'absolute',
                // bottom: ms(10),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                // checkValidation();
                checkValidationForAddInvoice();
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAwareScrollView>

      {/* <Modal
        isVisible={clientModal}
        onBackdropPress={() => {
          setClientModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Add Client
              </Text>
              <TouchableOpacity
                onPress={() => {
                  navigate('CreateClient');
                  setClientModal(false);
                }}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Add
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15), marginLeft: ms(5)}}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>
            <View>
              <FlatList
                data={clientList}
                renderItem={({item, index}) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: ms(10),
                        marginBottom: mvs(10),
                        borderBottomWidth: ms(0.6),
                        borderBottomColor: 'rgba(229, 231, 235, 1)',
                        paddingBottom: ms(5),
                      }}
                      onPress={() => {
                        setClientData(item);
                        setClientModal(false);
                      }}>
                      {item?.profileImage ? (
                        <Image
                          source={{uri: item?.profileImage}}
                          style={{
                            height: ms(30),
                            width: ms(30),
                            borderRadius: ms(15),
                          }}
                          //resizeMode="contain"
                        />
                      ) : (
                        <View
                          style={{
                            height: ms(30),
                            width: ms(30),
                            borderRadius: ms(15),
                            backgroundColor: 'rgba(217, 217, 217, 1)',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Text
                            style={{
                              fontSize: ms(14),
                              fontFamily: FONTS.Regular,
                            }}>
                            {item?.name?.[0]}
                          </Text>
                        </View>
                      )}
                      <View>
                        <Text
                          style={{fontSize: ms(14), fontFamily: FONTS.Regular}}>
                          {item?.name}
                        </Text>
                        <Text
                          style={{fontSize: ms(14), fontFamily: FONTS.Regular}}>
                          {item?.email}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                ListEmptyComponent={() => {
                  return (
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={{
                          height: ms(100),
                          width: ms(100),
                          alignSelf: 'center',
                        }}
                        source={ICONS.noclient}
                        resizeMode="contain"
                      />
                      <Text
                        style={{
                          textAlign: 'center',
                          fontSize: ms(12),
                          fontFamily: FONTS.Medium,
                          marginTop: ms(10),
                          color: COLORS.themeColor,
                        }}>
                        No client found
                      </Text>
                    </View>
                  );
                }}
              />
            </View>
          </ScrollView>
        </View>
      </Modal> */}
      <Modal
        isVisible={isModalVisible}
        avoidKeyboard={true}
        onBackdropPress={toggleModal} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
            // height: Dimensions.get('window').height - 200,
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(30),
            }}
          />
          <TouchableOpacity
            onPress={() => setModalVisible(false)}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Add Item
              </Text>
              <TouchableOpacity
                onPress={() => checkValidation()}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Save
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.7),
                borderColor: COLORS?.themeColor,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                borderRadius: ms(10),
                marginTop: ms(20),
              }}
              onPress={() => {
                setOpenItemList(true);
                let payload = {};
                dispatch(getItemsListReqest(payload));
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: COLORS?.themeColor,
                  textAlign: 'center',
                  width: '100%',
                }}>
                Choose Multiple
              </Text>
            </TouchableOpacity>
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: ms(10),
                width: isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50,
                flexDirection: 'row',
                gap: ms(5),
              }}>
              <View
                style={{
                  height: ms(1),
                  width: ms(50),
                  backgroundColor: 'rgba(4, 127, 255, 0.25)',
                }}
              />
              <Text
                style={{
                  textAlign: 'center',
                  color: '#344054',
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                }}>
                OR
              </Text>
              <View
                style={{
                  height: ms(1),
                  width: ms(50),
                  backgroundColor: 'rgba(4, 127, 255, 0.25)',
                }}
              />
            </View>

            <AnimatedTextInput
              label={'Item Name'}
              //keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={itemName}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemName(item);
              }}
            />
            {invoiceOptionSettings?.itemCode ? (
              <AnimatedTextInput
                label={'Item Code'}
                //keyboardType={'numeric'}
                minimumHeight={ms(45)}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={itemCode}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setItemCode(item);
                }}
              />
            ) : null}
            <AnimatedTextInput
              label={'Item Description'}
              // maxLength={200}
              multiline={true}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              minimumHeight={ms(150)}
              value={itemDescription}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemDescription(item);
              }}
            />
            <AnimatedTextInput
              label={'Rate'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={rate}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setRate(item);
              }}
            />
            <TouchableOpacity
              onPress={() => setUnitModal(true)}
              style={{
                paddingHorizontal: ms(15),
                borderWidth: ms(0.5),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                flexDirection: 'row',
                width: isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50,
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: ms(5),
                height: ms(45),
                elevation: 2,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  color:
                    selectedUnit == ''
                      ? COLORS.placeholderColor
                      : COLORS.dark_grey,
                }}>
                {selectedUnit ? selectedUnit : ' Unit type'}
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(12),
                  transform: [{rotate: '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <AnimatedTextInput
              label={'Qty'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={quantity}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setQuantity(item);
              }}
            />

            <TouchableOpacity
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                More Details
              </Text>
              <Image
                resizeMode="contain"
                source={ICONS.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  marginLeft: ms(10),
                  tintColor: COLORS.themeColor,
                  transform: [{rotate: '180deg'}],
                }}
              />
            </TouchableOpacity>
            <AnimatedTextInput
              label={'Tax'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={tax}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setTax(item);
              }}
            />

            
            <View
              style={{
                height: ms(45),
                width: isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50,
                borderWidth: 0.7,
                borderColor: COLORS.themeColor,
                borderRadius: ms(10),
                marginTop: ms(20),
                paddingHorizontal: ms(10),
                //alignItems:'center'
                marginBottom: ms(20),
                justifyContent: 'center',
              }}>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <TextInput
                  style={{
                    width: '70%',
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: '#707070',
                  }}
                  onChangeText={text => setDays(text)}
                  value={days}
                  placeholder="Discount"
                  keyboardType="numeric"
                  placeholderTextColor={COLORS.placeholderColor}
                />

                <View
                  style={{
                    width: ms(1),
                    height: '100%',
                    backgroundColor: COLORS.themeColor,
                  }}
                />
                <TouchableOpacity
                  onPress={() => setDiscountModal(true)}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    width: '30%',
                    justifyContent: 'center',
                  }}>
                  <Text>
                    {selectedDiscount == 'Percentage' ? '%' : selectedDiscount}
                  </Text>
                  <Image
                    resizeMode="contain"
                    source={ICONS.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      marginLeft: ms(10),
                      tintColor: COLORS.themeColor,
                      transform: [{rotate: '180deg'}],
                    }}
                  />
                </TouchableOpacity>
              </View>
            </View>

            
          </KeyboardAwareScrollView>
          <Modal
            isVisible={openItemList}
            onBackdropPress={() => {
              setOpenItemList(false);
            }} // Close modal when tapping outside
            style={{justifyContent: 'flex-end', margin: 0}}>
            <View
              style={{
                backgroundColor: 'white',
                padding: 22,
                //alignItems: 'center',
                borderTopLeftRadius: 15,
                borderTopRightRadius: 15,
                height: Dimensions.get('window').height * 0.6,
              }}>
              {/* <FlatList data={itemList} renderItem={({item, index}) => {
                         return(
                           <TouchableOpacity
                                   
                                   style={{
                                     padding: ms(10),
                                     // paddingBottom: ms(0),
                                     backgroundColor: COLORS?.white,
                                     borderWidth: ms(0.5),
                                     borderColor: '#DEDEDE',
                                     borderRadius: ms(6),
                                     marginVertical: ms(10),
                                     // elevation: 10,
                                   }}>
                                   <View
                                     style={{
                                       backgroundColor: 'rgba(4, 127, 255, 0.1)',
                                       padding: ms(10),
                                       borderRadius: ms(6),
                                       flexDirection: 'row',
                                       alignItems: 'center',
                                       gap: ms(10),
                                     }}>
                                     <Image
                                       source={ICONS?.digital_marketing}
                                       style={{height: ms(10), width: ms(10)}}
                                       resizeMode="contain"
                                     />
                                     <Text
                                       style={{
                                         fontFamily: FONTS?.Medium,
                                         fontSize: ms(12),
                                         color: COLORS?.themeColor,
                                       }}>
                                       {item?.item_name}
                                     </Text>
                                   </View>
                                   <View style={{padding: 10,flexDirection:'row',justifyContent:'space-between'}}>
                                     <Text
                                       style={{
                                         fontFamily: FONTS?.Medium,
                                         fontSize: ms(13),
                                         color: COLORS?.black,
                                       }}>
                                       ${Number(item?.rate) * Number(item?.qty)}
                                     </Text>
                                     
                                   </View>
                                   <View style={{padding: 10}}>
                                     <Text
                                       style={{
                                         fontFamily: FONTS?.Regular,
                                         fontSize: ms(13),
                                         color: COLORS?.black,
                                       }}>
                                       {item?.item_Description}
                                     </Text>
                                   </View>
                                 </TouchableOpacity>
                         )
                       }} /> */}
              <View
                style={{
                  flexDirection: 'row',
                  widt: '100%',
                  alignItems: 'center',
                  marginBottom: 12,
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    //textAlign: 'center',
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                  }}>
                  Add Item
                </Text>
                <TouchableOpacity
                  onPress={() => findItems()}
                  style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text
                    style={{
                      fontStyle: FONTS.Medium,
                      fontSize: ms(18),
                      color: COLORS.themeColor,
                    }}>
                    Add
                  </Text>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                    source={ICONS.plusicn}
                  />
                </TouchableOpacity>
              </View>
              <FlatList
                data={itemList}
                keyExtractor={item => item.uuid?.toString()} // or item.id
                renderItem={({item, index}) => {
                  const isSelected = selectedItems.includes(item.uuid);

                  const toggleSelection = () => {
                    if (isSelected) {
                      setSelectedItems(prev =>
                        prev.filter(id => id !== item.uuid),
                      );
                    } else {
                      setSelectedItems(prev => [...prev, item.uuid]);
                    }
                  };

                  return (
                    <TouchableOpacity
                      style={[
                        {
                          padding: ms(10),
                          backgroundColor: COLORS.white,
                          borderWidth: ms(0.5),
                          borderColor: '#DEDEDE',
                          borderRadius: ms(6),
                          marginVertical: ms(10),
                        },
                        isSelected && {
                          borderColor: COLORS.themeColor,
                          borderWidth: ms(1.5),
                          backgroundColor: 'rgba(4, 127, 255, 0.05)',
                        },
                      ]}
                      onPress={toggleSelection}>
                      {/* Header Row */}
                      <View
                        style={{
                          backgroundColor: 'rgba(4, 127, 255, 0.1)',
                          padding: ms(10),
                          borderRadius: ms(6),
                          flexDirection: 'row',
                          alignItems: 'center',
                          gap: ms(10),
                        }}>
                        {/* Checkbox or Indicator */}
                        <View
                          style={{
                            height: ms(16),
                            width: ms(16),
                            borderRadius: ms(4),
                            borderWidth: ms(1),
                            borderColor: isSelected
                              ? COLORS.themeColor
                              : '#ccc',
                            backgroundColor: isSelected
                              ? COLORS.themeColor
                              : 'transparent',
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}>
                          {isSelected && (
                            <Image
                              source={ICONS.tick} // Use a checkmark icon
                              style={{
                                height: ms(10),
                                width: ms(10),
                                tintColor: 'white',
                              }}
                              resizeMode="contain"
                            />
                          )}
                        </View>

                        <Text
                          style={{
                            fontFamily: FONTS.Medium,
                            fontSize: ms(12),
                            color: COLORS.themeColor,
                          }}>
                          {item.item_name}
                        </Text>
                      </View>

                      {/* Price Row */}
                      <View
                        style={{
                          padding: ms(10),
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                        }}>
                        <Text
                          style={{
                            fontFamily: FONTS.Medium,
                            fontSize: ms(13),
                            color: COLORS.black,
                          }}>
                          ${Number(item.rate) * Number(item.qty)}
                        </Text>
                      </View>

                      {/* Description */}
                      <View style={{padding: ms(10)}}>
                        <Text
                          style={{
                            fontFamily: FONTS.Regular,
                            fontSize: ms(13),
                            color: COLORS.black,
                          }}>
                          {item.item_Description}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </Modal>
          <Modal
            isVisible={unitModal}
            backdropOpacity={0.6}
            animationIn={'slideInUp'}
            animationOut={'slideOutDown'}
            animationInTiming={800}
            animationOutTiming={500}
            backdropTransitionOutTiming={0}
            hasBackdrop={true}
            onBackdropPress={() => {
              setUnitModal(false);
            }}
            style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
            <View
              style={{
                // maxHeight: Dimensions.get('window').height,
                width: '100%',
                height: Dimensions.get('window').height * 0.6,
                paddingTop: normalize(10),
                paddingHorizontal: normalize(30),
                backgroundColor: '#FFF',
                borderTopLeftRadius: normalize(20),
                borderTopRightRadius: normalize(20),
                padding: normalize(40),
              }}>
              <View
                style={{
                  width: ms(63),
                  height: ms(6),
                  borderRadius: ms(8),
                  backgroundColor: 'rgba(217, 217, 217, 1)',
                  alignSelf: 'center',
                  marginBottom: ms(20),
                  marginTop: ms(10),
                }}
              />
              <TouchableOpacity
                onPress={() => setUnitModal(false)}
                style={{position: 'absolute', top: 20, right: 20}}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(20)}}
                  source={ICONS.crossbtn}
                />
              </TouchableOpacity>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontSize: normalize(18),
                    fontFamily: FONTS.Medium,
                    paddingVertical: normalize(20),
                    //paddingHorizontal: normalize(20),
                  }}>
                  Unit type
                </Text>
                <TouchableOpacity
                  onPress={() => setUnitModal(false)}
                  style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text
                    style={{
                      fontSize: normalize(16),
                      color: COLORS.themeColor,
                      fontFamily: FONTS.Regular,
                    }}>
                    Apply
                  </Text>
                  <Image
                    resizeMode="contain"
                    style={{
                      height: normalize(17),
                      width: normalize(17),
                      marginLeft: normalize(5),
                    }}
                    source={ICONS.bluetick}
                  />
                </TouchableOpacity>
              </View>

              <FlatList
                data={commonList?.productUnitTypes}
                //style={{maxHeight: Dimensions.get('window').height / 3}}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                  <View style={{alignItems: 'center'}}>
                    <Text style={{color: COLORS?.orange}}>No data found.</Text>
                  </View>
                }
                renderItem={({item, index}) => {
                  console.log('www', item);
                  let selected = item.value == selectedUnit;
                  return (
                    <TouchableOpacity
                      style={{
                        borderBottomWidth: normalize(0),
                        borderBottomColor: COLORS.dark_grey,
                        padding: normalize(10),
                        //backgroundColor: '#EBF4F6',
                        marginTop: normalize(5),
                        borderRadius: normalize(5),
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}
                      onPress={() => {
                        console.log('itemaaa', item);
                        setSelectedUnit(item?.value);
                        //setSelectedUnitShow(item?.title);

                        setUnitModal(false);

                        //setSelectCountryCategory(item?.name);
                      }}>
                      <View
                        style={{
                          height: normalize(22),
                          width: normalize(22),
                          borderWidth: 1,
                          borderRadius: normalize(11),
                          borderColor: COLORS.themeColor,
                          justifyContent: 'center',
                          alignItems: 'center',
                        }}>
                        {selected ? (
                          <View
                            style={{
                              height: normalize(15),
                              width: normalize(15),
                              borderRadius: normalize(7.5),
                              backgroundColor: COLORS.themeColor,
                            }}
                          />
                        ) : null}
                      </View>
                      <Text
                        style={{
                          color: '#000',
                          fontFamily: FONTS.Fredoka_Regular,
                          textTransform: 'capitalize',
                          marginLeft: normalize(10),
                        }}>
                        {item?.title}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </Modal>
        </View>
      </Modal>

      <Modal
        isVisible={discountModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setDiscountModal(false);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.4,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setDiscountModal(false)}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Discount
            </Text>
          </View>

          <FlatList
            data={discountPercentage}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: COLORS?.orange}}>No data found.</Text>
              </View>
            }
            renderItem={({item, index}) => {
              //console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    // borderBottomWidth: normalize(0),
                    // borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    //marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    if (item.name == 'Percentage') {
                      setSelectedDiscount('Percentage');
                    } else {
                      setSelectedDiscount(item.name);
                    }
                    setDiscountModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS?.Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                      fontSize: ms(12),
                    }}>
                    {item?.name}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      <Modal
        isVisible={openEditModal}
        onBackdropPress={() => {
          setItemName('');
          setItemDescription('');
          setRate('');
          setQuantity('');
          setTax('');
          setDays('');
          setOpenEditModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
            // height: Dimensions.get('window').height - 200,
          }}>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Update Item
              </Text>
              <TouchableOpacity
                onPress={() => editItem()}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Update
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>

            <AnimatedTextInput
              label={'Item Name'}
              //keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={itemName}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemName(item);
              }}
            />
            {invoiceOptionSettings?.itemCode ? (
              <AnimatedTextInput
                label={'Item Code'}
                //keyboardType={'numeric'}
                minimumHeight={ms(45)}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={itemCode}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setItemCode(item);
                }}
              />
            ) : null}
            <AnimatedTextInput
              label={'Item Description'}
              // maxLength={200}
              multiline={true}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              minimumHeight={ms(150)}
              value={itemDescription}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemDescription(item);
              }}
            />
            <AnimatedTextInput
              label={'Rate'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={rate}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setRate(item);
              }}
            />
            <TouchableOpacity
              onPress={() => setUnitModal(true)}
              style={{
                paddingHorizontal: ms(15),
                borderWidth: ms(0.5),
                marginTop: ms(15),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                flexDirection: 'row',
                width: isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50,
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: ms(5),
                height: ms(45),
                elevation: 2,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
              }}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  color:
                    selectedUnit == ''
                      ? COLORS.placeholderColor
                      : COLORS.dark_grey,
                }}>
                {selectedUnit ? selectedUnit : ' Unit type'}
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(12),
                  transform: [{rotate: '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <AnimatedTextInput
              label={'Qty'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={quantity}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setQuantity(item);
              }}
            />

            <TouchableOpacity
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                More Details
              </Text>
              <Image
                resizeMode="contain"
                source={ICONS.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  marginLeft: ms(10),
                  tintColor: COLORS.themeColor,
                  transform: [{rotate: '180deg'}],
                }}
              />
            </TouchableOpacity>
            <AnimatedTextInput
              label={'Tax'}
              keyboardType={'numeric'}
              minimumHeight={ms(45)}
              width={
                isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50
              }
              value={tax}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setTax(item);
              }}
            />

            <View
              style={{
                height: ms(45),
                width: isTablet
                  ? Dimensions?.get('window')?.width - 70
                  : Dimensions?.get('window')?.width - 50,
                borderWidth: 0.7,
                borderColor: COLORS.themeColor,
                borderRadius: ms(10),
                marginTop: ms(20),
                paddingHorizontal: ms(10),
                marginBottom: ms(20),
                //alignItems:'center'
                justifyContent: 'center',
              }}>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <TextInput
                  style={{
                    width: '70%',
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: '#707070',
                  }}
                  onChangeText={text => setDays(text)}
                  value={days}
                  placeholder="Discount"
                  keyboardType="numeric"
                />

                <View
                  style={{
                    width: ms(1),
                    height: '100%',
                    backgroundColor: COLORS.themeColor,
                  }}
                />
                <TouchableOpacity
                  onPress={() => setDiscountModal(true)}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    width: '30%',
                    justifyContent: 'center',
                  }}>
                  <Text>
                    {selectedDiscount == 'Percentage' ? '%' : selectedDiscount}
                  </Text>
                  <Image
                    resizeMode="contain"
                    source={ICONS.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      marginLeft: ms(10),
                      tintColor: COLORS.themeColor,
                      transform: [{rotate: '180deg'}],
                    }}
                  />
                </TouchableOpacity>
              </View>
            </View>

            {/* <View
                       style={{
                         alignItems: 'center',
                         justifyContent: 'center',
                         marginTop: ms(10),
                         width: isTablet
                           ? Dimensions?.get('window')?.width - 70
                           : Dimensions?.get('window')?.width - 50,
                         flexDirection: 'row',
                         gap: ms(5),
                       }}>
                       <View
                         style={{
                           height: ms(1),
                           width: ms(50),
                           backgroundColor: 'rgba(4, 127, 255, 0.25)',
                         }}
                       />
                       <Text
                         style={{
                           textAlign: 'center',
                           color: '#344054',
                           fontFamily: FONTS?.Regular,
                           fontSize: ms(10),
                         }}>
                         OR
                       </Text>
                       <View
                         style={{
                           height: ms(1),
                           width: ms(50),
                           backgroundColor: 'rgba(4, 127, 255, 0.25)',
                         }}
                       />
                     </View> */}
          </KeyboardAwareScrollView>
        </View>
        <Modal
          isVisible={unitModal}
          backdropOpacity={0.6}
          animationIn={'slideInUp'}
          animationOut={'slideOutDown'}
          animationInTiming={800}
          animationOutTiming={500}
          backdropTransitionOutTiming={0}
          hasBackdrop={true}
          onBackdropPress={() => {
            setUnitModal(false);
          }}
          style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
          <View
            style={{
              // maxHeight: Dimensions.get('window').height,
              width: '100%',
              height: Dimensions.get('window').height * 0.6,
              paddingTop: normalize(10),
              paddingHorizontal: normalize(30),
              backgroundColor: '#FFF',
              borderTopLeftRadius: normalize(20),
              borderTopRightRadius: normalize(20),
              padding: normalize(40),
            }}>
            <View
              style={{
                width: ms(63),
                height: ms(6),
                borderRadius: ms(8),
                backgroundColor: 'rgba(217, 217, 217, 1)',
                alignSelf: 'center',
                marginBottom: ms(20),
                marginTop: ms(10),
              }}
            />
            <TouchableOpacity
              onPress={() => setUnitModal(false)}
              style={{position: 'absolute', top: 20, right: 20}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(20)}}
                source={ICONS.crossbtn}
              />
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontSize: normalize(18),
                  fontFamily: FONTS.Medium,
                  paddingVertical: normalize(20),
                  //paddingHorizontal: normalize(20),
                }}>
                Unit type
              </Text>
              <TouchableOpacity
                onPress={() => setUnitModal(false)}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontSize: normalize(16),
                    color: COLORS.themeColor,
                    fontFamily: FONTS.Regular,
                  }}>
                  Apply
                </Text>
                <Image
                  resizeMode="contain"
                  style={{
                    height: normalize(17),
                    width: normalize(17),
                    marginLeft: normalize(5),
                  }}
                  source={ICONS.bluetick}
                />
              </TouchableOpacity>
            </View>

            <FlatList
              data={commonList?.productUnitTypes}
              //style={{maxHeight: Dimensions.get('window').height / 3}}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <View style={{alignItems: 'center'}}>
                  <Text style={{color: COLORS?.orange}}>No data found.</Text>
                </View>
              }
              renderItem={({item, index}) => {
                console.log('www', item);
                let selected = item.value == selectedUnit;
                return (
                  <TouchableOpacity
                    style={{
                      borderBottomWidth: normalize(0),
                      borderBottomColor: COLORS.dark_grey,
                      padding: normalize(10),
                      //backgroundColor: '#EBF4F6',
                      marginTop: normalize(5),
                      borderRadius: normalize(5),
                      flexDirection: 'row',
                      alignItems: 'center',
                    }}
                    onPress={() => {
                      console.log('itemaaa', item);
                      setSelectedUnit(item?.value);
                      //setSelectedUnitShow(item?.title);

                      setUnitModal(false);

                      //setSelectCountryCategory(item?.name);
                    }}>
                    <View
                      style={{
                        height: normalize(22),
                        width: normalize(22),
                        borderWidth: 1,
                        borderRadius: normalize(11),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {selected ? (
                        <View
                          style={{
                            height: normalize(15),
                            width: normalize(15),
                            borderRadius: normalize(7.5),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </View>
                    <Text
                      style={{
                        color: '#000',
                        fontFamily: FONTS.Fredoka_Regular,
                        textTransform: 'capitalize',
                        marginLeft: normalize(10),
                      }}>
                      {item?.title}
                    </Text>
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </Modal>
      </Modal>

      <Modal
        isVisible={termsModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setTermsModal(false);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.4,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setTermsModal(false)}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Terms
            </Text>
          </View>

          <FlatList
            data={TERMS_OPTIONS}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: COLORS?.orange}}>No data found.</Text>
              </View>
            }
            renderItem={({item, index}) => {
              //console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    // borderBottomWidth: normalize(0),
                    // borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    //marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    calculateDuedate(item);
                    setTermsModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS?.Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                      fontSize: ms(12),
                    }}>
                    {item?.label}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      <Modal
        isVisible={camModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setCamModal(false);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <TouchableOpacity
            onPress={() => setCamModal(false)}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Open gallery
            </Text>
            <TouchableOpacity
              //onPress={() => (false)}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontSize: normalize(16),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Upload
              </Text>
              <Image
                resizeMode="contain"
                style={{
                  height: normalize(17),
                  width: normalize(17),
                  marginLeft: normalize(5),
                }}
                source={ICONS.bluetick}
              />
            </TouchableOpacity>
          </View>

          <Text
            style={{
              fontSize: normalize(14),
              fontFamily: FONTS.Regular,
              //marginTop: normalize(35),
            }}>
            Add image here upload from gallery or click a picture
          </Text>
          <View
            style={{
              flexDirection: 'row',
              width: '100%',
              marginTop: normalize(25),
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() => onPressGallery()}
              style={{
                height: normalize(120),
                width: normalize(140),
                justifyContent: 'center',
                alignItems: 'center',
                borderWidth: 1,
                //borderColor: COLORS.border,
                borderRadius: normalize(20),
                borderStyle: 'dotted',
                borderColor: COLORS.themeColor,
                elevation: 3,
                backgroundColor: COLORS.white,
                shadowColor: COLORS.themeColor,
              }}>
              <Image
                resizeMode="contain"
                style={{height: normalize(30), width: normalize(40)}}
                source={ICONS.gallery}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: normalize(20),
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15), marginRight: ms(5)}}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontSize: normalize(14),
                    color: COLORS.themeColor,
                    fontFamily: FONTS.Regular,
                  }}>
                  Add photo
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => onPressCamera()}
              style={{
                height: normalize(120),
                width: normalize(140),
                borderWidth: 1,
                //borderColor: COLORS.border,
                borderRadius: normalize(20),
                justifyContent: 'center',
                alignItems: 'center',
                borderStyle: 'dotted',
                borderColor: COLORS.themeColor,
                elevation: 3,
                backgroundColor: COLORS.white,
                shadowColor: COLORS.themeColor,
              }}>
              <Image
                resizeMode="contain"
                style={{height: normalize(30), width: normalize(40)}}
                source={ICONS.cam}
              />
              <Text
                style={{
                  fontSize: normalize(14),
                  marginTop: normalize(20),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Camera
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        isVisible={appointModal}
        onBackdropPress={() => {
          setAppointModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
            <View
                        style={{
                          width: ms(63),
                          height: ms(6),
                          borderRadius: ms(8),
                          backgroundColor: 'rgba(217, 217, 217, 1)',
                          alignSelf: 'center',
                          marginBottom: ms(30),
                        }}
                      />
                      <TouchableOpacity
                        onPress={() => setAppointModal(false)}
                        style={{position: 'absolute', top: 20, right: 20}}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(20), width: ms(20)}}
                          source={ICONS.crossbtn}
                        />
                      </TouchableOpacity>
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Add Appointment
            </Text>
            <TouchableOpacity
              onPress={() => {
                if (appointmentListNew.length > 0) {
                  findItemss();
                } else {
                  setTimeout(() => {
                    navigate('AddAppointment');
                  }, 500);
                }
              }}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>
          <FlatList
            data={appointmentListNew}
            keyExtractor={item => item.id?.toString()} // or item.id
            renderItem={({item, index}) => {
              const isSelected = selectedItemss.includes(item.id);

              const toggleSelection = () => {
                if (isSelected) {
                  setSelectedItemss(prev => prev.filter(id => id !== item.id));
                } else {
                  setSelectedItemss(prev => [...prev, item.id]);
                }
              };

              return (
                <TouchableOpacity
                  style={[
                    {
                      padding: ms(10),
                      backgroundColor: COLORS.white,
                      borderWidth: ms(0.5),
                      borderColor: '#DEDEDE',
                      borderRadius: ms(6),
                      marginVertical: ms(10),
                    },
                    isSelected && {
                      borderColor: COLORS.themeColor,
                      borderWidth: ms(1.5),
                      backgroundColor: 'rgba(4, 127, 255, 0.05)',
                    },
                  ]}
                  onPress={toggleSelection}>
                  {/* Header Row */}
                  <View
                    style={{
                      backgroundColor: 'rgba(4, 127, 255, 0.1)',
                      padding: ms(10),
                      borderRadius: ms(6),
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    {/* Checkbox or Indicator */}
                    <View
                      style={{
                        height: ms(16),
                        width: ms(16),
                        borderRadius: ms(4),
                        borderWidth: ms(1),
                        borderColor: isSelected ? COLORS.themeColor : '#ccc',
                        backgroundColor: isSelected
                          ? COLORS.themeColor
                          : 'transparent',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {isSelected && (
                        <Image
                          source={ICONS.tick} // Use a checkmark icon
                          style={{
                            height: ms(10),
                            width: ms(10),
                            tintColor: 'white',
                          }}
                          resizeMode="contain"
                        />
                      )}
                    </View>

                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                      }}>
                      {item.name}
                    </Text>
                  </View>

                  {/* Description */}
                  <View style={{padding: ms(10)}}>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(13),
                        color: COLORS.black,
                      }}>
                      {item.description}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      <Modal
        isVisible={timeModal}
        onBackdropPress={() => {
          setTimeModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
            <View
                        style={{
                          width: ms(63),
                          height: ms(6),
                          borderRadius: ms(8),
                          backgroundColor: 'rgba(217, 217, 217, 1)',
                          alignSelf: 'center',
                          marginBottom: ms(30),
                        }}
                      />
                      <TouchableOpacity
                        onPress={() => setTimeModal(false)}
                        style={{position: 'absolute', top: 20, right: 20}}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(20), width: ms(20)}}
                          source={ICONS.crossbtn}
                        />
                      </TouchableOpacity>
            
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Select Time
            </Text>
            <TouchableOpacity
              onPress={() => findItemsss()}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>
          <View style={{alignSelf: 'center', paddingVertical: ms(10)}}>
            <TouchableOpacity
              onPress={() => {
                if (clientDetails?.id) {
                  setTimeModal(false);
                  setTimeout(() => {
                    setCustomTimeModal(true);
                  }, 1000);
                } else {
                  Toast('Select client');
                }
              }}
              style={{
                height: ms(45),
                width: ms(200),
                backgroundColor: COLORS.themeColor,
                borderRadius: ms(25),
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  fontSize: ms(14),
                  color: COLORS.white,
                }}>
                Add Custom Time
              </Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={allTimerList}
            keyExtractor={item => item.id?.toString()} // or item.id
            renderItem={({item, index}) => {
              const isSelected = selectedItemsss.includes(item.task_id);

              const toggleSelection = () => {
                if (isSelected) {
                  setSelectedItemsss(prev =>
                    prev.filter(task_id => task_id !== item.task_id),
                  );
                } else {
                  setSelectedItemsss(prev => [...prev, item.task_id]);
                }
              };

              return (
                <TouchableOpacity
                  style={[
                    {
                      padding: ms(10),
                      backgroundColor: COLORS.white,
                      borderWidth: ms(0.5),
                      borderColor: '#DEDEDE',
                      borderRadius: ms(6),
                      marginVertical: ms(10),
                    },
                    isSelected && {
                      borderColor: COLORS.themeColor,
                      borderWidth: ms(1.5),
                      backgroundColor: 'rgba(4, 127, 255, 0.05)',
                    },
                  ]}
                  onPress={toggleSelection}>
                  {/* Header Row */}
                  <View
                    style={{
                      backgroundColor: 'rgba(4, 127, 255, 0.1)',
                      padding: ms(10),
                      borderRadius: ms(6),
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    {/* Checkbox or Indicator */}
                    <View
                      style={{
                        height: ms(16),
                        width: ms(16),
                        borderRadius: ms(4),
                        borderWidth: ms(1),
                        borderColor: isSelected ? COLORS.themeColor : '#ccc',
                        backgroundColor: isSelected
                          ? COLORS.themeColor
                          : 'transparent',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {isSelected && (
                        <Image
                          source={ICONS.tick} // Use a checkmark icon
                          style={{
                            height: ms(10),
                            width: ms(10),
                            tintColor: 'white',
                          }}
                          resizeMode="contain"
                        />
                      )}
                    </View>

                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                      }}>
                      {item.task_name}
                    </Text>
                  </View>

                  {/* Description */}
                  <View style={{padding: ms(10)}}>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(13),
                        color: COLORS.black,
                      }}>
                      {item.notes} {item.totalTime}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      <Modal
        isVisible={customTimeModal}
        onBackdropPress={() => {
          setCustomTimeModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Add Custom Time
            </Text>
            <TouchableOpacity
              onPress={() => {
                if (startTime == '') {
                  Toast('Select start time');
                } else if (endTime == '') {
                  Toast('Select end time');
                } else if (customTimeNote == '') {
                  Toast('Add note');
                } else {
                  getCustomItems();
                }
              }}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              width: '100%',
              marginTop: ms(20),
              height: ms(45),
              alignSelf: 'center',
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: ms(0.6),
              borderColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              borderRadius: ms(10),
              elevation: 2,
              shadowColor: COLORS.themeColor,
            }}>
            <Text style={{fontFamily: FONTS.Medium, fontSize: ms(16)}}>
              {clientDetails?.name}
            </Text>
          </View>
          <AnimatedTextInput
            label={'Note'}
            //keyboardType={'numeric'}
            minimumHeight={ms(70)}
            multiline={true}
            numberOfLines={6}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={customTimeNote}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setCustomTimeNote(item);
            }}
          />

          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.6),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: ms(12),

              height: ms(45),
              elevation: 5,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
              marginTop: ms(20),
            }}
            onPress={() => {
              //setClientModal(true);
              setOpenStartTime(true);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(13),
                color: COLORS?.themeColor,
              }}>
              Start time: {selectedStartTime}
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: '180deg'}],
              }}
              resizeMode="contain"
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.6),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: ms(12),

              height: ms(45),
              elevation: 5,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
              marginTop: ms(20),
            }}
            onPress={() => {
              //setClientModal(true);
              setOpenEndTime(true);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(13),
                color: COLORS?.themeColor,
              }}>
              End time: {selectedEndtime}
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: '180deg'}],
              }}
              resizeMode="contain"
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
        </View>
      </Modal>

      <Modal
        isVisible={depositModal}
        onBackdropPress={() => {
          setDepositModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Add Deposit Request
            </Text>
            <TouchableOpacity
              onPress={() => {
                if (calculatedAmount == 0) {
                  Toast('Add deposit amount');
                } else if (depositDueDate == '') {
                  Toast('Select due date');
                } else {
                  setDepositModal(false);
                }
              }}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>

          <Text
            style={{
              marginTop: ms(20),
              fontFamily: FONTS.Medium,
              fontSize: ms(16),
            }}>
            Invoice total: ${totalAm}
          </Text>

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => {
                setCalculatedAmount(0);

                setDepositPercentage(0);
                setDepositType('Percentage');
              }}
              style={{
                height: ms(45),
                width: ms(120),
                borderRadius: ms(10),
                borderWidth: ms(0.6),
                borderColor: COLORS.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor:
                  depositType == 'Percentage'
                    ? COLORS.themeColor
                    : COLORS.white,
              }}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(14),
                  color:
                    depositType == 'Percentage' ? COLORS.white : COLORS.black,
                }}>
                Percentage(%)
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                setDepositType('Fix');
                setCalculatedAmount(0);

                setDepositPercentage(0);
              }}
              style={{
                height: ms(45),
                width: ms(120),
                borderRadius: ms(10),
                borderWidth: ms(0.6),
                borderColor: COLORS.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: ms(10),
                backgroundColor:
                  depositType == 'Fix' ? COLORS.themeColor : COLORS.white,
              }}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(14),
                  color: depositType == 'Fix' ? COLORS.white : COLORS.black,
                }}>
                Fix($)
              </Text>
            </TouchableOpacity>
          </View>
          {depositType == 'Percentage' ? (
            <View>
              <AnimatedTextInput
                label={'Deposit Percentage'}
                //keyboardType={'numeric'}
                minimumHeight={ms(45)}
                //multiline={true}
                //numberOfLines={6}
                keyboardType={'numeric'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={depositPercentage}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setDepositPercentage(item);
                }}
              />
              <TouchableOpacity
                onPress={() => {
                  let calAm =
                    (Number(totalAm) * Number(depositPercentage)) / 100;
                  setCalculatedAmount(calAm);
                }}
                style={{
                  height: ms(45),
                  width: ms(120),
                  borderRadius: ms(10),
                  borderWidth: ms(0.6),
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginHorizontal: ms(10),
                  alignSelf: 'center',
                  marginTop: ms(20),
                  backgroundColor: COLORS.themeColor,
                }}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(14),
                    color: COLORS.white,
                  }}>
                  Calculate
                </Text>
              </TouchableOpacity>
              {calculatedAmount ? (
                <Text
                  style={{
                    marginTop: ms(20),
                    fontFamily: FONTS.Medium,
                    fontSize: ms(16),
                  }}>
                  Deposit amount : {calculatedAmount}
                </Text>
              ) : null}

              <TouchableOpacity
                style={{
                  padding: ms(10),
                  borderWidth: ms(0.6),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: ms(12),

                  height: ms(45),
                  elevation: 5,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  marginTop: ms(20),
                }}
                onPress={() => {
                  //setClientModal(true);
                  setOpenDepositDueDate(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(13),
                    color: COLORS?.themeColor,
                  }}>
                  Due date: {depositDueDate}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(14),
                    transform: [{rotate: '180deg'}],
                  }}
                  resizeMode="contain"
                  tintColor={COLORS.themeColor}
                />
              </TouchableOpacity>
            </View>
          ) : (
            <View>
              <AnimatedTextInput
                label={'Deposit amount'}
                //keyboardType={'numeric'}
                minimumHeight={ms(45)}
                //multiline={true}
                //numberOfLines={6}
                keyboardType={'numeric'}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={calculatedAmount}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setCalculatedAmount(item);
                }}
              />

              {calculatedAmount ? (
                <Text
                  style={{
                    marginTop: ms(20),
                    fontFamily: FONTS.Medium,
                    fontSize: ms(16),
                  }}>
                  Deposit amount : {calculatedAmount}
                </Text>
              ) : null}

              <TouchableOpacity
                style={{
                  padding: ms(10),
                  borderWidth: ms(0.6),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: ms(12),

                  height: ms(45),
                  elevation: 5,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  marginTop: ms(20),
                }}
                onPress={() => {
                  //setClientModal(true);
                  setOpenDepositDueDate(true);
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(13),
                    color: COLORS?.themeColor,
                  }}>
                  Due date: {depositDueDate}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(14),
                    transform: [{rotate: '180deg'}],
                  }}
                  resizeMode="contain"
                  tintColor={COLORS.themeColor}
                />
              </TouchableOpacity>
            </View>
          )}
        </View>
      </Modal>
      <Modal
        isVisible={editDiscountModal}
        onBackdropPress={() => {
          setEditDiscountModal(false);
          setEditedDiscount('');
          setDisType('flat');
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Select Discount
            </Text>
            <TouchableOpacity
              onPress={() => {
                if (editedDiscount == '') {
                  Toast('Enter discount');
                } else {
                  if (disType == 'flat') {
                    setTotalDiscount(parseFloat(editedDiscount).toFixed(2));
                    setTotalAm(
                      Number(allTotal) - parseFloat(editedDiscount).toFixed(2),
                    );
                  } else {
                    setTotalDiscount(parseFloat(totalNewDiscount).toFixed(2));
                    setTotalAm(
                      Number(allTotal) -
                        parseFloat(totalNewDiscount).toFixed(2),
                    );
                  }
                  setEditDiscountModal(false);
                  setEditedDiscount('');
                  setDisType('flat');
                }
              }}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Update
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>
          <Text
            style={{
              alignSelf: 'center',
              fontFamily: FONTS.Medium,
              fontSize: ms(16),
              marginVertical: ms(10),
            }}>
            Total Value : ${allTotal}
          </Text>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <TouchableOpacity
                onPress={() => setDisType('flat')}
                style={{
                  height: ms(20),
                  width: ms(20),
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: ms(0.6),
                  borderRadius: ms(5),
                  borderColor: COLORS.themeColor,
                  backgroundColor:
                    disType == 'flat' ? COLORS.themeColor : COLORS.white,
                }}>
                {disType == 'flat' ? (
                  <Image
                    resizeMode="contain"
                    style={{height: ms(10), width: ms(10)}}
                    source={ICONS.tick}
                  />
                ) : null}
              </TouchableOpacity>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(14),
                  marginLeft: ms(10),
                }}>
                Flat
              </Text>
            </View>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <TouchableOpacity
                onPress={() => setDisType('percentage')}
                style={{
                  height: ms(20),
                  width: ms(20),
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: ms(0.6),
                  borderRadius: ms(5),
                  borderColor: COLORS.themeColor,
                  backgroundColor:
                    disType == 'percentage' ? COLORS.themeColor : COLORS.white,
                }}>
                {disType == 'percentage' ? (
                  <Image
                    resizeMode="contain"
                    style={{height: ms(10), width: ms(10)}}
                    source={ICONS.tick}
                  />
                ) : null}
              </TouchableOpacity>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(14),
                  marginLeft: ms(10),
                }}>
                Percentage(%)
              </Text>
            </View>
          </View>

          <AnimatedTextInput
            label={'Discount'}
            keyboardType={'numeric'}
            minimumHeight={ms(45)}
            multiline={true}
            numberOfLines={6}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={editedDiscount}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setEditedDiscount(item);
            }}
          />
          {disType == 'percentage' ? (
            <TouchableOpacity
              onPress={() => {
                if (editedDiscount == '') {
                  Toast('Enter discount value');
                } else {
                  let newDiscount =
                    Number(allTotal) * (Number(editedDiscount) / 100);
                  setTotalNewDiscount(newDiscount);
                }
              }}
              style={{
                width: '40%',
                alignSelf: 'center',
                height: ms(40),
                borderRadius: ms(20),
                backgroundColor: COLORS.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  color: COLORS.white,
                  fontSize: ms(14),
                }}>
                Calculate
              </Text>
            </TouchableOpacity>
          ) : null}
          {disType == 'percentage' ? (
            totalNewDiscount !== '' ? (
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  fontSize: ms(16),
                  alignSelf: 'center',
                  marginTop: ms(20),
                }}>
                Total Discount :{totalNewDiscount}{' '}
              </Text>
            ) : null
          ) : editedDiscount !== '' ? (
            <Text
              style={{
                fontFamily: FONTS.Medium,
                fontSize: ms(16),
                alignSelf: 'center',
                marginTop: ms(20),
              }}>
              Total Discount :{editedDiscount}{' '}
            </Text>
          ) : null}

          {/* <TouchableOpacity
                    onPress={() => {
                      if (editedDiscount == '') {
                        Toast('Enter discount');
                      } else {
                        if (disType == 'flat') {
                          setTotalDiscount(parseFloat(editedDiscount).toFixed(2));
                          setTotalAm(
                            Number(allTotal) - parseFloat(editedDiscount).toFixed(2),
                          );
                        } else {
                          setTotalDiscount(parseFloat(totalNewDiscount).toFixed(2));
                          setTotalAm(
                            Number(allTotal) -
                              parseFloat(totalNewDiscount).toFixed(2),
                          );
                        }
                        setEditDiscountModal(false);
                        setEditedDiscount("")
                        setDisType("flat")
                      }
                    }}
                    style={{
                      width: '40%',
                      alignSelf: 'center',
                      height: ms(40),
                      borderRadius: ms(20),
                      backgroundColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        color: COLORS.white,
                        fontSize: ms(14),
                      }}>
                      Update
                    </Text>
                  </TouchableOpacity> */}
        </View>
      </Modal>
      <Modal
        isVisible={expenseModal}
        onBackdropPress={() => {
          setExpenseModal(false);
        }} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
            <View
                        style={{
                          width: ms(63),
                          height: ms(6),
                          borderRadius: ms(8),
                          backgroundColor: 'rgba(217, 217, 217, 1)',
                          alignSelf: 'center',
                          marginBottom: ms(30),
                        }}
                      />
                      <TouchableOpacity
                        onPress={() => setExpenseModal(false)}
                        style={{position: 'absolute', top: 20, right: 20}}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(20), width: ms(20)}}
                          source={ICONS.crossbtn}
                        />
                      </TouchableOpacity>
          <View
            style={{
              flexDirection: 'row',
              widt: '100%',
              alignItems: 'center',
              marginBottom: 12,
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Add Expense
            </Text>
            <TouchableOpacity
              onPress={() => {
                if (expenseList?.length > 0) {
                  if (selectedExpenses.length > 0) {
                    findExpense();
                  } else {
                    Toast('Select expense');
                  }
                } else {
                  setExpenseModal(false);
                  navigate('AddNewExpense');
                }
              }}
              style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{height: ms(15), widt: ms(15), marginLeft: ms(5)}}
                source={ICONS.plusicn}
              />
            </TouchableOpacity>
          </View>
          <FlatList
            data={flattenedExpenses}
            keyExtractor={item => item.id?.toString()} // or item.id
            renderItem={({item, index}) => {
              const isSelected = selectedExpenses.includes(item.id);

              const toggleSelection = () => {
                if (isSelected) {
                  setSelectedExpenses(prev =>
                    prev.filter(id => id !== item.id),
                  );
                } else {
                  setSelectedExpenses(prev => [...prev, item.id]);
                }
              };

              return (
                <TouchableOpacity
                  style={[
                    {
                      padding: ms(10),
                      backgroundColor: COLORS.white,
                      borderWidth: ms(0.5),
                      borderColor: '#DEDEDE',
                      borderRadius: ms(6),
                      marginVertical: ms(10),
                    },
                    isSelected && {
                      borderColor: COLORS.themeColor,
                      borderWidth: ms(1.5),
                      backgroundColor: 'rgba(4, 127, 255, 0.05)',
                    },
                  ]}
                  onPress={toggleSelection}>
                  {/* Header Row */}
                  <View
                    style={{
                      backgroundColor: 'rgba(4, 127, 255, 0.1)',
                      padding: ms(10),
                      borderRadius: ms(6),
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    {/* Checkbox or Indicator */}
                    <View
                      style={{
                        height: ms(16),
                        width: ms(16),
                        borderRadius: ms(4),
                        borderWidth: ms(1),
                        borderColor: isSelected ? COLORS.themeColor : '#ccc',
                        backgroundColor: isSelected
                          ? COLORS.themeColor
                          : 'transparent',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {isSelected && (
                        <Image
                          source={ICONS.tick} // Use a checkmark icon
                          style={{
                            height: ms(10),
                            width: ms(10),
                            tintColor: 'white',
                          }}
                          resizeMode="contain"
                        />
                      )}
                    </View>

                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                      }}>
                      {item.merchant}
                    </Text>
                  </View>

                  {/* Price Row */}
                  <View
                    style={{
                      padding: ms(10),
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(13),
                        color: COLORS.black,
                      }}>
                      ${Number(item?.rate) * Number(1)}
                    </Text>
                  </View>

                  {/* Description */}
                  <View style={{padding: ms(10)}}>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(13),
                        color: COLORS.black,
                      }}>
                      {item.description}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
  imageContainer: {
    width: ms(60),
    height: ms(60),
    position: 'relative',
    //marginHorizontal:ms(8)// Ensures absolute children are positioned relative to this
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: ms(8), // Optional: adds rounded corners
  },
  deleteButton: {
    position: 'absolute',
    top: -ms(8), // Slightly above the image
    right: -ms(10), // Slightly outside the right edge
    backgroundColor: 'white', // Optional: improves visibility
    borderRadius: ms(10),
    padding: ms(2), // Optional: adds breathing room around icon
    elevation: 2, // Android shadow
    shadowColor: '#000', // iOS shadow
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.2,
    shadowRadius: 2,
    //zIndex:2
    //justifyContent:'center',
    //alignItems:'center'
  },
  deleteIcon: {
    height: ms(15),
    width: ms(15),
    tintColor: COLORS.themeColor, // Optional: makes cross more visible
  },
  imageItemWrapper: {
    // This wrapper prevents clipping on Android
    padding: ms(8), // Gives space for the delete button to appear
    margin: ms(2),
    //backgroundColor:'red'  // Optional: spacing between items
  },
});
