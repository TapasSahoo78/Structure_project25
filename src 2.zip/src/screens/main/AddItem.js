import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { goBack } from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import { navigate } from '../../utils/helpers/RootNaivgation';
import { TextInput } from 'react-native-gesture-handler';
import Toast from '../../utils/helpers/Toast';
import { useDispatch, useSelector } from 'react-redux';

import {
  addItemsRequest,
  getCommonListRequest,
  invoiceCreateRequest,
} from '../../redux/reducer/ProfileReducer';
import moment from 'moment';
import DeviceInfo, { isTablet } from 'react-native-device-info';
import Loader from '../../utils/helpers/Loader';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

export default function AddItem() {
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('');
  const [rate, setRate] = useState('');
  const [quantity, setQuantity] = useState('');
  const [tax, setTax] = useState(0);
  const [days, setDays] = useState('');
  const [billContent, setBillContent] = useState(true);
  const [itemContent, setItemContent] = useState(true);
  const [moreContent, setMoreContent] = useState(true);
  const [methodContent, setMethodContent] = useState(true);
  const [instructionContent, setInstructionContent] = useState(true);
  const [moreDetailOpen, setMoreDetailOpen] = useState(true);
  const [isTablet, setIsTablet] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [discountModal, setDiscountModal] = useState(false);
  const [selectedDiscount, setSelectedDiscount] = useState('Flat');
  const [selectedUnit,setSelectedUnit] = useState("")
  const [selectedUnitShow,setSelectedUnitShow] = useState("")
  const [unitModal,setUnitModal] = useState(false)
  const { clientDetails, addedItem, commonList,loading } = useSelector(state => state.ProfileReducer);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  

  useEffect(()=> {
    dispatch(getCommonListRequest());
  },[])

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  const paymentMethod = [
    {
      id: 100,
      method: 'Card Payment',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.card,
    },
    {
      id: 101,
      method: 'Bank Transfers',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.bank,
    },
    {
      id: 102,
      method: 'Paypal',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.paypal,
    },
  ];

  const renderPayment = ({ item, index }) => {
    let isSelected = item.id == selectedPayment;
    return (
      <View
        style={{
          flex: 1,
          padding: 20,
          backgroundColor: COLORS.white,
          borderWidth: 1,
          borderColor: COLORS.border,
          borderRadius: ms(10),
        }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View
            style={{
              padding: 10,
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(5),
            }}>
            <Image
              style={{ height: ms(30), width: ms(30), resizeMode: 'contain' }}
              source={item.img}
            />
          </View>
          <View>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  color: COLORS.textColor,
                  marginLeft: ms(15),
                  fontSize: ms(14),
                }}>
                {item.method}
              </Text>
              <Image
                source={ICONS.knowmore}
                style={{
                  height: ms(11),
                  width: ms(11),
                  resizeMode: 'contain',
                  marginLeft: ms(5),
                }}
              />
            </View>
            <Text
              style={{
                fontFamily: FONTS.Regular,
                color: COLORS.gray,
                marginLeft: ms(15),
                fontSize: ms(12),
              }}>
              {item.description}
            </Text>
          </View>

          <TouchableOpacity
            style={{ position: 'absolute', top: 1, right: 10 }}
            onPress={() => {
              if (selectedPayment == item.id) {
                setSelectedPayment('');
              } else {
                setSelectedPayment(item.id);
              }
            }}>
            {isSelected ? (
              <Image
                source={ICONS.switch}
                style={{ height: ms(20), width: ms(32), resizeMode: 'contain' }}
              />
            ) : (
              <Image
                source={ICONS.switchoff}
                style={{ height: ms(20), width: ms(32), resizeMode: 'contain' }}
              />
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const ItemSeparator = () => {
    return <View style={{ height: ms(1), marginVertical: ms(5) }} />;
  };
  const checkValidation = () => {
    if (isSaving) return;
    if (itemName == '') {
      Toast('Enter item name');
    } else if (itemDescription == '') {
      Toast('Enter item description');
    }else if (rate == '') {
      Toast('Enter rate');
    }else if (quantity == '') {
      Toast('Enter quantity');
    } else {
      setIsSaving(true);
      let payload = {
        item_name: itemName,
        item_Description: itemDescription,
        rate: rate,
        qty: quantity,
        tax: tax,
        days: days,
        listingRequired: false,
        unitTypes:selectedUnit 
      };
      dispatch(addItemsRequest(payload));
      setModalVisible(false);

      setTimeout(() => {
        setIsSaving(false);
        goBack()
      }, 1000)
    }
  };

  const renderItemseparator = () => {
    return (
      <View
        style={{
          height: ms(1),
          width: '100%',
          marginVertical: ms(10),
          backgroundColor: COLORS.border,
        }}
      />
    );
  };

  function isEmpty(item) {
    if (item == null || item == '' || item == undefined) return true;
    return false;
  }

  const discountPercentage = [
    {
      id: 100,
      name: 'Flat',
    },
    {
      id: 101,
      name: 'Percentage',
    },
  ];
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add Item'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={()=>  checkValidation()}
        />
      </View>

      <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
        <View style={{ alignItems: 'center' }}>
          <AnimatedTextInput
            label={'Item Name'}
            //keyboardType={'numeric'}
            value={itemName}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            minimumHeight={ms(45)}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setItemName(item);
            }}
          />
          <AnimatedTextInput
            label={'Item Description'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            // maxLength={200}
            multiline={true}
            numberOfLines={10}
            minimumHeight={ms(100)}
            value={itemDescription}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setItemDescription(item);
            }}
          />
          <AnimatedTextInput
            label={'Rate'}
            keyboardType={'numeric'}
            minimumHeight={ms(45)}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={rate}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setRate(item);
            }}
          />

          <TouchableOpacity
                          onPress={() => setUnitModal(true)}
                          style={{
                            paddingHorizontal: ms(15),
                            borderWidth: ms(0.5),
                            marginTop: ms(15),
                            borderRadius: ms(10),
                            borderColor: COLORS?.themeColor,
                            flexDirection: 'row',
                            width: isTablet
                              ? Dimensions.get('window').width - 70
                              : Dimensions.get('window').width - 50,
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: ms(5),
                            height: ms(45),
                            elevation: 2,
                            backgroundColor: 'white',
                            shadowColor: COLORS.themeColor,
                          }}>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color:
                                selectedUnit == ''
                                  ? COLORS.placeholderColor
                                  : COLORS.dark_grey,
                            }}>
                              {selectedUnitShow?selectedUnitShow:' Unit type'}
                           
                          </Text>
                          <Image
                            source={ICONS?.arrow}
                            style={{
                              height: ms(5),
                              width: ms(12),
                              transform: [{ rotate: '180deg' }],
                              tintColor: COLORS?.themeColor,
                            }}
                            resizeMode="contain"
                          />
                        </TouchableOpacity>
          <AnimatedTextInput
            label={'Qty'}
            keyboardType={'numeric'}
            minimumHeight={ms(45)}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={quantity}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setQuantity(item);
            }}
          />



          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}
            onPress={() => {
              setMoreDetailOpen(!moreDetailOpen);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              More Details
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{ rotate: moreDetailOpen ? '180deg' : '0deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {moreDetailOpen ? (
            <View>
              <AnimatedTextInput
                label={'Tax'}
                keyboardType={'numeric'}
                minimumHeight={ms(45)}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 45
                }
                value={tax}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setTax(item);
                }}
              />

              {/* <View
                style={{
                  height: ms(45),
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  borderWidth: 0.5,
                  borderColor: COLORS.themeColor,
                  borderRadius: ms(10),
                  marginTop: ms(20),
                  paddingHorizontal: ms(10),
                  //alignItems:'center'
                  justifyContent: 'center',
                  height: ms(45),
                  elevation: 3,
                  backgroundColor: COLORS.white,
                  shadowColor: COLORS.themeColor,
                }}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <TextInput
                    style={{
                      width: '70%',
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: '#707070',
                    }}
                    placeholderTextColor={COLORS?.placeholderColor}
                    onChangeText={text => setDays(text)}
                    value={days}
                    placeholder="Discount"
                    keyboardType="numeric"
                  />

                  <View
                    style={{
                      width: 1,
                      height: '100%',
                      backgroundColor: COLORS.border,
                    }}
                  />
                  <TouchableOpacity onPress={() => setDiscountModal(true)} style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text>{selectedDiscount == "Percentage" ? "%":selectedDiscount}</Text>
                    <Image
                      resizeMode="contain"
                      source={ICONS.arrow}
                      style={{
                        height: ms(5),
                        width: ms(14),
                        marginLeft: ms(10),
                        tintColor: COLORS.themeColor,
                        transform: [{rotate: '180deg'}],
                      }}
                    />
                  </TouchableOpacity>
                </View>
              </View> */}
            </View>
          ) : null}
          <View
            style={{
              width: '100%',
              backgroundColor: COLORS.white,
              // paddingTop: ms(10),
              // position: 'absolute',
              // bottom: 0,
              padding: ms(5),
              marginTop: ms(30),
            }}>
            <TouchableOpacity
              disabled={isSaving}
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                // position: 'absolute',
                // bottom: ms(10),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                checkValidation();
                //checkValidationForAddInvoice();
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAwareScrollView>

      <Modal
        isVisible={discountModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setDiscountModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.4,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setDiscountModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Discount
            </Text>
          </View>

          <FlatList
            data={discountPercentage}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              //console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    // borderBottomWidth: normalize(0),
                    // borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    //marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    if (item.name == 'Percentage') {
                      setSelectedDiscount('Percentage');
                    } else {
                      setSelectedDiscount(item.name);
                    }
                    setDiscountModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS?.Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                      fontSize: ms(12),
                    }}>
                    {item?.name}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      <Modal
              isVisible={unitModal}
              backdropOpacity={0.6}
              animationIn={'slideInUp'}
              animationOut={'slideOutDown'}
              animationInTiming={800}
              animationOutTiming={500}
              backdropTransitionOutTiming={0}
              hasBackdrop={true}
              onBackdropPress={() => {
                setUnitModal(false);
              }}
              style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
              <View
                style={{
                  // maxHeight: Dimensions.get('window').height,
                  width: '100%',
                  height: Dimensions.get('window').height * 0.6,
                  paddingTop: normalize(10),
                  paddingHorizontal: normalize(30),
                  backgroundColor: '#FFF',
                  borderTopLeftRadius: normalize(20),
                  borderTopRightRadius: normalize(20),
                  padding: normalize(40),
                }}>
                <View
                  style={{
                    width: ms(63),
                    height: ms(6),
                    borderRadius: ms(8),
                    backgroundColor: 'rgba(217, 217, 217, 1)',
                    alignSelf: 'center',
                    marginBottom: ms(20),
                    marginTop: ms(10),
                  }}
                />
                 <TouchableOpacity
            onPress={() => setUnitModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{
                      fontSize: normalize(18),
                      fontFamily: FONTS.Medium,
                      paddingVertical: normalize(20),
                      //paddingHorizontal: normalize(20),
                    }}>
                    Unit type
                  </Text>
                  <TouchableOpacity
                    onPress={() => setUnitModal(false)}
                    style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text
                      style={{
                        fontSize: normalize(16),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                      }}>
                      Apply
                    </Text>
                    <Image
                      resizeMode="contain"
                      style={{
                        height: normalize(17),
                        width: normalize(17),
                        marginLeft: normalize(5),
                      }}
                      source={ICONS.bluetick}
                    />
                  </TouchableOpacity>
                </View>
      
                <FlatList
                  data={commonList?.productUnitTypes}
                  //style={{maxHeight: Dimensions.get('window').height / 3}}
                  showsVerticalScrollIndicator={false}
                  ListEmptyComponent={
                    <View style={{ alignItems: 'center' }}>
                      <Text style={{ color: COLORS?.orange }}>No data found.</Text>
                    </View>
                  }
                  renderItem={({ item, index }) => {
                    console.log('www', item);
                    let selected = item.value == selectedUnit;
                    return (
                      <TouchableOpacity
                        style={{
                          borderBottomWidth: normalize(0),
                          borderBottomColor: COLORS.dark_grey,
                          padding: normalize(10),
                          //backgroundColor: '#EBF4F6',
                          marginTop: normalize(5),
                          borderRadius: normalize(5),
                          flexDirection: 'row',
                          alignItems: 'center',
                        }}
                        onPress={() => {
                          console.log('itemaaa', item);
                          setSelectedUnit(item?.value);
                          setSelectedUnitShow(item?.title);
      
                          setUnitModal(false);
      
                          //setSelectCountryCategory(item?.name);
                        }}>
                        <View
                          style={{
                            height: normalize(22),
                            width: normalize(22),
                            borderWidth: 1,
                            borderRadius: normalize(11),
                            borderColor: COLORS.themeColor,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}>
                          {selected ? (
                            <View
                              style={{
                                height: normalize(15),
                                width: normalize(15),
                                borderRadius: normalize(7.5),
                                backgroundColor: COLORS.themeColor,
                              }}
                            />
                          ) : null}
                        </View>
                        <Text
                          style={{
                            color: '#000',
                            fontFamily: FONTS.Fredoka_Regular,
                            textTransform: 'capitalize',
                            marginLeft: normalize(10),
                          }}>
                          {item?.title}
                        </Text>
                      </TouchableOpacity>
                    );
                  }}
                />
                
              </View>
            </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
    paddingHorizontal: ms(20),
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
