import React, {useEffect, useState, useRef, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack, navigate} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {useFocusEffect} from '@react-navigation/native';
import { addProjectTimeRequest } from '../../redux/reducer/ProfileReducer';
import { useDispatch } from 'react-redux';
import Toast from '../../utils/helpers/Toast';

export default function AddNewTime(props) {
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [description, setDescription] = useState('');

  const [startTime, setStartTime] = useState(0); // base time in seconds
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const intervalRef = useRef(null);
  const [addButton, setAddButton] = useState(false);
  const [timeId, setTimeId] = useState('');

  useEffect(() => {
    if (timerActive) {
      intervalRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerActive]);
  const stopTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setTimerActive(false);
    Alert.alert('Timer Stopped', `Final time: ${formatTime(elapsedTime)}`);
  };

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };
  const formatTime = seconds => {
    // const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    // const secs = (seconds % 60).toString().padStart(2, '0');
    // return `${mins}:${secs}`;
    const hrs = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, '0'); // 3600 sec = 1 hour
    const mins = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${hrs}:${mins}:${secs}`;
  };
  useFocusEffect(
    useCallback(() => {
      console.log('from prev', JSON.stringify(props?.route?.params?.item));
      //setProjectId(props?.route?.params?.item?.project_id);
      //setClientId(props?.route?.params?.item?.client_id);
      //setTaskId(props?.route?.params?.item?.id);
      if (props?.route?.params?.item.projectTimes.length == 0) {
        setElapsedTime(0);
        setAddButton(true);
      } else if (props?.route?.params?.item?.projectTimes?.at(-1)?.end_time) {
        // const [hourss, minutess, secondss] =
        //   props?.route?.params?.item.projectTimes[0]?.timeDifference
        //     ?.split(':')
        //     .map(Number);
        // const totalSeconds = hourss * 3600 + minutess * 60 + secondss;
        // setElapsedTime(totalSeconds);
        // setTimerActive(false);
        // setDescription(props?.route?.params?.item?.projectTimes[0]?.notes);
        // setAddButton(false);
         setElapsedTime(0);
        setAddButton(true);
      } else {
        setTimeId(props?.route?.params?.item?.projectTimes?.at(-1)?.id);
        setAddButton(false);
        const [hours, minutes, seconds] =
          props?.route?.params?.item?.projectTimes?.at(-1)?.timeDifference
            ?.split(':')
            .map(Number);
        const totalSeconds = hours * 3600 + minutes * 60 + seconds;
        setElapsedTime(totalSeconds);

        setTimerActive(true);
        setDescription(props?.route?.params?.item?.projectTimes?.at(-1)?.notes);
      }
    }, []),
  );
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add New Time Track'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          isMinimizePresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, marginTop: ms(20),paddingHorizontal:ms(15)}}>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Time
            </Text>
          </TouchableOpacity>

          <View
            style={{
              paddingVertical: ms(20),
              marginVertical: ms(20),
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Text style={{fontSize: ms(14), color: COLORS.gray}}>
              Started at
            </Text>
            <Text style={{fontSize: ms(52), color: COLORS.black}}>
              {formatTime(elapsedTime)}
            </Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: ms(20),
              }}>
              <TouchableOpacity
                style={{
                  height: ms(48),
                  width: ms(48),
                  borderRadius: ms(24),
                  borderWidth: 1,
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(13), width: ms(12)}}
                  source={ICONS.delete}
                />
              </TouchableOpacity>
              {timerActive ? (
                <TouchableOpacity
                  onPress={() => {

                    if (intervalRef.current) {
                      clearInterval(intervalRef.current);
                      intervalRef.current = null;
                    }

                    setTimerActive(false);
                    let payload = {
                      id: timeId,
                      client_id: props?.route?.params?.item?.client_id,
                      project_id: props?.route?.params?.item?.project_id,
                      notes: description,
                      start_time: '00:00:00',
                      end_time: String(formatTime(elapsedTime)),
                      task_id: props?.route?.params?.item?.id,
                    };
                    dispatch(addProjectTimeRequest(payload));
                    //setTimerActive(false);
                    //goBack()
                    
                  }}
                  style={{
                    height: ms(48),
                    width: ms(48),
                    borderRadius: ms(24),
                    borderWidth: 1,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: COLORS.themeColor,
                    marginLeft: ms(10),
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(14), width: ms(8)}}
                    source={ICONS.pause}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => setTimerActive(true)}
                  style={{
                    height: ms(48),
                    width: ms(48),
                    borderRadius: ms(24),
                    borderWidth: 1,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: COLORS.themeColor,
                    marginLeft: ms(10),
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(14), width: ms(8)}}
                    source={ICONS.play}
                  />
                </TouchableOpacity>
              )}

              <TouchableOpacity
                style={{
                  height: ms(48),
                  width: ms(48),
                  borderRadius: ms(24),
                  borderWidth: 1,
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: ms(10),
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(13), width: ms(15.2)}}
                  source={ICONS.resume}
                />
              </TouchableOpacity>
            </View>
            {/* <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: ms(20),
              }}>
              <TouchableOpacity
                style={{
                  height: ms(48),
                  width: ms(48),
                  borderRadius: ms(24),
                  borderWidth: 1,
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(13), width: ms(12)}}
                  source={ICONS.delete}
                />
              </TouchableOpacity>
              {timerActive ? (
                <TouchableOpacity
                  onPress={() => {

                    if (intervalRef.current) {
                      clearInterval(intervalRef.current);
                      intervalRef.current = null;
                    }

                    setTimerActive(false);
                    let payload = {
                      id: timeId,
                      client_id: props?.route?.params?.item?.client_id,
                      project_id: props?.route?.params?.item?.project_id,
                      notes: description,
                      start_time: '00:00:00',
                      end_time: String(formatTime(elapsedTime)),
                      task_id: props?.route?.params?.item?.id,
                    };
                    dispatch(addProjectTimeRequest(payload));
                    //setTimerActive(false);
                    
                  }}
                  style={{
                    height: ms(48),
                    width: ms(48),
                    borderRadius: ms(24),
                    borderWidth: 1,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: COLORS.themeColor,
                    marginLeft: ms(10),
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(14), width: ms(8)}}
                    source={ICONS.pause}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => setTimerActive(true)}
                  style={{
                    height: ms(48),
                    width: ms(48),
                    borderRadius: ms(24),
                    borderWidth: 1,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: COLORS.themeColor,
                    marginLeft: ms(10),
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(14), width: ms(8)}}
                    source={ICONS.play}
                  />
                </TouchableOpacity>
              )}

              <TouchableOpacity
                style={{
                  height: ms(48),
                  width: ms(48),
                  borderRadius: ms(24),
                  borderWidth: 1,
                  borderColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: ms(10),
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(13), width: ms(15.2)}}
                  source={ICONS.resume}
                />
              </TouchableOpacity>
            </View> */}
          </View>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Note
            </Text>
          </TouchableOpacity>

          <TextInput
            style={{
              height: ms(100),
              borderWidth: ms(0.5),
              padding: 10,
              borderRadius: 10,
              textAlignVertical: 'top',
              borderColor: COLORS.themeColor,
              marginTop: ms(20),
              elevation: ms(5),
              backgroundColor: COLORS?.white,
              shadowColor: COLORS.themeColor,
              fontFamily: FONTS?.Regular,
              fontSize: ms(12),
            }}
            multiline={true} // Enable multi-line input
            numberOfLines={4} // Set the number of lines to display
            onChangeText={text => setDescription(text)} // Update state on text change
            value={description} // Controlled input
            placeholder="Description" // Placeholder text
            textAlignVertical="top" // Align text to the top
          />
          {addButton ? (
            <View style={{marginTop: ms(30)}}>
              <TouchableOpacity
                style={{
                  paddingHorizontal: ms(20),
                  paddingVertical: ms(8),
                  backgroundColor: COLORS?.themeColor,

                  alignSelf: 'center',
                  width: ms(150),
                  borderRadius: ms(20),
                  marginBottom: ms(20),
                }}
                onPress={() => {
                  if (description == '') {
                    Toast('Enter notes');
                  } else {
                    let payload = {
                      id: '',
                      client_id: props?.route?.params?.item?.client_id,
                      project_id: props?.route?.params?.item?.project_id,
                      notes: description,
                      start_time: '00:00:00',
                      end_time: '',
                      task_id: props?.route?.params?.item?.id,
                    };
                    dispatch(addProjectTimeRequest(payload));
                    
                  }
                }}>
                <Text
                  style={{
                    color: COLORS?.white,
                    textAlign: 'center',
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(15),
                  }}>
                  Save
                </Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      </ScrollView>
      {/* <TouchableOpacity
        style={{
          paddingHorizontal: ms(20),
          paddingVertical: ms(8),
          backgroundColor: COLORS?.themeColor,
          position: 'absolute',
          bottom: ms(10),
          alignSelf: 'center',
          width: ms(150),
          borderRadius: ms(20),
        }}
        onPress={() => {
          //navigate("AddPurchaseOrder")
          goBack();
        }}>
        <Text
          style={{
            color: COLORS?.white,
            textAlign: 'center',
            fontFamily: FONTS?.Medium,
            fontSize: ms(15),
          }}>
          Save
        </Text>
      </TouchableOpacity> */}

      <Modal
        isVisible={isModalVisible}
        onBackdropPress={toggleModal} // Close modal when tapping outside
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Text
              style={{
                marginBottom: 12,
                //textAlign: 'center',
                fontStyle: FONTS.Medium,
                fontSize: ms(18),
              }}>
              Add Item
            </Text>
            <AnimatedTextInput
              label={'Item Name'}
              //keyboardType={'numeric'}
              value={itemName}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemName(item);
              }}
            />
            <AnimatedTextInput
              label={'Item Description'}
              //maxLength={ms(60)}
              value={itemDescription}
              borderColor={COLORS?.themeColor}
              onChangeText={item => {
                setItemDescription(item);
              }}
            />
          </ScrollView>
          <TouchableOpacity
            style={{
              marginTop: 20,
              width: '90%',
              alignSelf: 'center',
              borderWidth: 1,
              borderRadius: 10,
              borderColor: COLORS.border,
              height: ms(56),
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Text
              style={{
                fontStyle: FONTS.ExtraBold,
                color: COLORS.gray,
                fontSize: ms(12),
              }}>
              Search
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
