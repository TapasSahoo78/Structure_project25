import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';

export default function AddRoles() {

    const [roles, setRoles] = useState([
        {
          id: 100,
          title: 'Service Management',
          category: [
            { id: 1001, name: 'View', isSelected: false },
            { id: 1002, name: 'Add', isSelected: false },
            { id: 1003, name: 'Edit', isSelected: false },
            { id: 1004, name: 'Delete', isSelected: false },
          ],
        },
        {
          id: 101,
          title: 'Page',
          category: [
            { id: 2001, name: 'View', isSelected: false },
            { id: 2002, name: 'Add', isSelected: false },
            { id: 2003, name: 'Edit', isSelected: false },
            { id: 2004, name: 'Delete', isSelected: false },
          ],
        },
        {
          id: 102,
          title: 'Media Management',
          category: [
            { id: 3001, name: 'View', isSelected: false },
            { id: 3002, name: 'Add', isSelected: false },
            { id: 3003, name: 'Edit', isSelected: false },
            { id: 3004, name: 'Delete', isSelected: false },
          ],
        },
      ]);

    const renderItem = ({ item }) => (
        <TouchableOpacity
          style={styles.itemContainer}
          onPress={() => toggleSelection(item.roleId, item.id)}
        >
          <Text style={[styles.itemText, item.isSelected && styles.selectedText]}>
            {item.name} ({item.roleTitle})
          </Text>
        </TouchableOpacity>
        );

        const toggleSelection = (roleId, categoryId) => {
            setRoles(prevRoles =>
              prevRoles.map(role => {
                if (role.id === roleId) {
                  return {
                    ...role,
                    category: role.category.map(cat =>
                      cat.id === categoryId ? { ...cat, isSelected: !cat.isSelected } : cat
                    ),
                  };
                }
                return role;
              })
            );
          };

          const getFlatData = () => {
            let flatList = [];
            roles.forEach(role => {
              role.category.forEach(cat => {
                flatList.push({
                  ...cat,
                  roleId: role.id,
                  roleTitle: role.title,
                });
              });
            });
            return flatList;
          };
  
 
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add User Role'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          isSavePresent={false}
        />
      </View>
      <View style={{flex: 1, padding: ms(20),width:'100%'}}>
        <TouchableOpacity
          style={{
            padding: ms(10),
            backgroundColor: 'rgba(4, 127, 255, 0.1)',
            borderRadius: ms(6),
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <Text
            style={{
              fontFamily: FONTS?.Bold,
              fontSize: ms(14),
              color: COLORS?.themeColor,
            }}>
            User Permissions
          </Text>
        </TouchableOpacity>
        <FlatList
        data={getFlatData()}
        keyExtractor={item => item.id.toString()}
        renderItem={renderItem}
      />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    //justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },

  containerr: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  itemContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  itemText: {
    fontSize: 16,
    color: 'black',
  },
  selectedText: {
    color: 'green',
  },
});
