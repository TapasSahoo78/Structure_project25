import React, {useEffect, useState, useCallback, useRef} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useDispatch} from 'react-redux';
import {useSelector} from 'react-redux';
import {
  deleteAppointmentRequest,
  getAppointmentListRequest,
} from '../../redux/reducer/ProfileReducer';
import {useFocusEffect} from '@react-navigation/native';
import Loader from '../../utils/helpers/Loader';
//import moment from 'moment';
export default function Appointment() {
  const flatListRef = useRef(null);
  const {appointmentList, loading} = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [isEnabled, setIsEnabled] = useState(false);
  const [status, setStatus] = useState('unbilled');
  const [selectedId, setSelectedId] = useState(100);

  const [selectedAppointment, setSelectedAppointment] = useState('');
  const [currentYear, setCurrentYear] = useState(moment().year());
  // useEffect(() => {
  //   let payload = {
  //     month: 1,
  //   };
  //   dispatch(getAppointmentListRequest(payload));
  // }, []);

  useFocusEffect(
    useCallback(() => {
      const today = moment();
      const isCurrentYear = currentYear === today.year();
      const currentMonth = isCurrentYear ? today.month() + 1 : 1;

      //const currentMonth = moment().month() + 1;
      let payload = {
        month: currentMonth,
        year: currentYear,
      };
      dispatch(getAppointmentListRequest(payload));
      setSelectedId(currentMonth);

      const index = months.findIndex(month => month.id === currentMonth);

      if (index !== -1 && flatListRef.current) {
        // Delay slightly to ensure rendering completes
        setTimeout(() => {
          flatListRef.current?.scrollToIndex({
            index,
            animated: true,
            viewPosition: 0.5, // center the item
          });
        }, 100);
      }
    }, [dispatch, currentYear]),
  );

  useEffect(() => {
    if (
      appointmentList &&
      Array.isArray(appointmentList) &&
      appointmentList.length > 0
    ) {
      const week_noo = getCurrentWeekOfMonth();
      const today = moment();
      //alert(week_noo)
      const dayTwoDigits = today.format('DD');
      const dayno = Number(dayTwoDigits) / 7;
      //alert(Number(dayno))
      // Get the item at index (week_no - 1), since index starts at 0
      let day_no;
      if (dayno % 7 == 0) {
        day_no = dayno - 1;
      } else {
        day_no = dayno;
      }
      const currentWeekItem = appointmentList[Math.floor(day_no)];
      //alert(JSON.stringify(currentWeekItem))
      if (currentWeekItem) {
        const currentMonth = moment().month() + 1;
        if (selectedId == currentMonth) {
          setSelectedAppointment(currentWeekItem);
        } else {
          setSelectedAppointment('');
        }
      } else {
        setSelectedAppointment(''); // Fallback
      }
    }
  }, [appointmentList]);

  const getCurrentWeekOfMonth = () => {
    const today = moment();
    const startOfMonth = today.clone().startOf('month');
    const firstDayOfWeek = startOfMonth.weekday(); // 0 (Sun) to 6 (Sat)

    // Calculate how many days from start of month to the first Sunday (or locale start of week)
    const offset = firstDayOfWeek;

    // Week number in the month
    const weekNumber = Math.ceil((today.date() + offset) / 7);

    return weekNumber;
  };

  const months = [
    {
      id: 1,
      name: 'January',
      value: 1,
    },
    {
      id: 2,
      name: 'February',
      value: 2,
    },
    {
      id: 3,
      name: 'March',
      value: 3,
    },
    {
      id: 4,
      name: 'April',
      value: 4,
    },
    {
      id: 5,
      name: 'May',
      value: 5,
    },
    {
      id: 6,
      name: 'June',
      value: 6,
    },
    {
      id: 7,
      name: 'July',
      value: 7,
    },
    {
      id: 8,
      name: 'August',
      value: 8,
    },
    {
      id: 9,
      name: 'September',
      value: 9,
    },
    {
      id: 10,
      name: 'October',
      value: 10,
    },
    {
      id: 11,
      name: 'November',
      value: 11,
    },
    {
      id: 12,
      name: 'December',
      value: 12,
    },
  ];
  const renderMonths = ({item, index}) => {
    let isSelected = item.id == selectedId;
    return (
      <TouchableOpacity
        onPress={() => {
          setSelectedId(item.id);
          let payload = {
            month: item.value,
            year: currentYear,
          };
          dispatch(getAppointmentListRequest(payload));
        }}
        style={{
          height: ms(40),
          justifyContent: 'center',
          alignItems: 'center',
          paddingHorizontal: ms(10),
          borderBottomWidth: isSelected ? 2 : 1,
          borderBottomColor: isSelected ? COLORS.themeColor : COLORS.border,
        }}>
        <Text
          style={{
            color: '#344054',
            fontSize: ms(16),
            fontFamily: FONTS.Regular,
            color: isSelected ? '#344054' : '#344054BF',
          }}>
          {item.name}
        </Text>
      </TouchableOpacity>
    );
  };
  const appointments = [
    {
      id: 100,
      title: '1 Oct - 7 Oct',
      appo: [
        {
          id: 1000,
          name: 'Akash Misra',
          time: '01:00 P.M - 03:00 P.M',
          place: 'kolkata',
          day: 1,
          month: 'Oct',
        },
      ],
    },
    {
      id: 101,
      title: '8 Oct - 14 Oct',
      appo: [
        {
          id: 1001,
          name: 'Akash Misra',
          time: '01:00 P.M - 03:00 P.M',
          place: 'kolkata',
          day: 3,
          month: 'Oct',
        },
      ],
    },
  ];
  const renderEmptyComponent = () => {
    return (
      <View style={{alignSelf: 'center', marginVertical: ms(20)}}>
        <Text
          style={{
            fontFamily: FONTS?.Regular,
            fontSize: ms(12),
            color: COLORS?.black,
          }}>
          No appointment found
        </Text>
      </View>
    );
  };
  const renderAppointment = ({item, index}) => {
    let is_selected = item.range == selectedAppointment.range;
    return (
      <View>
        <TouchableOpacity
          onPress={() =>
            selectedAppointment.range == item.range
              ? setSelectedAppointment('')
              : setSelectedAppointment(item)
          }
          style={{
            height: ms(40),
            borderWidth: ms(0.8),
            borderColor: COLORS.border,
            borderRadius: ms(10),
            marginTop: ms(20),
            paddingHorizontal: ms(12),
            alignItems: 'center',
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginBottom: ms(5),
            elevation: 2,
            backgroundColor: COLORS?.white,
            shadowColor: 'rgba(4, 127, 255, 0.2)',
          }}>
          {item?.appointments?.length > 0 ? (
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                height: ms(20),
                width: ms(20),
                borderRadius: ms(10),
                position: 'absolute',
                top: -10,
                left: 0,
                backgroundColor: COLORS.themeColor,
              }}>
              <Text
                style={{
                  fontSize: ms(12),
                  color: COLORS.white,
                  fontFamily: FONTS.SemiBold,
                }}>
                {item?.appointments.length}
              </Text>
            </View>
          ) : null}

          <Text
            style={{
              fontFamily: FONTS.Regular,
              color: COLORS.themeColor,
              fontSize: ms(12),
            }}>
            {item.range}
          </Text>
          <Image
            source={ICONS.arrow}
            style={{
              height: ms(5),
              width: ms(14),
              resizeMode: 'contain',
              transform: [{rotate: is_selected ? '0deg' : '180deg'}],
              tintColor: COLORS?.themeColor,
            }}
          />
        </TouchableOpacity>
        {is_selected ? (
          <FlatList
            data={item?.appointments}
            renderItem={renderAppoData}
            ListEmptyComponent={renderEmptyComponent}
          />
        ) : null}
      </View>
    );
  };

  // const renderAppoData = ({item, index}) => {

  //   return (
  //     <View
  //       style={{
  //         height: ms(100),
  //         borderWidth: ms(0.8),
  //         borderColor: COLORS.border,
  //         borderRadius: ms(10),
  //         marginTop: ms(5),
  //         paddingHorizontal: ms(12),
  //         alignItems: 'center',
  //         flexDirection: 'row',
  //         //justifyContent:'space-between',
  //         marginBottom: ms(5),
  //         elevation: 2,
  //         backgroundColor: COLORS?.white,
  //         shadowColor: 'rgba(4, 127, 255, 0.2)',
  //       }}>

  //       <View
  //         style={{
  //           height: ms(68),
  //           width: ms(68),
  //           borderRadius: ms(5),
  //           justifyContent: 'center',
  //           alignItems: 'center',
  //           backgroundColor: 'rgba(4, 127, 255, 0.1)',
  //         }}>
  //         <Text style={{fontSize: ms(30), color: COLORS.themeColor}}>
  //           {moment(item.start_date).utc().date()}
  //         </Text>
  //         <Text style={{fontSize: 12, color: COLORS.themeColor}}>
  //           {moment(item.start_date).utc().format('MMM')}
  //         </Text>
  //       </View>
  //       <View style={{paddingLeft: ms(10)}}>
  //         <Text style={{fontSize: ms(14), fontFamily: FONTS.Medium}}>
  //           {item?.client?.name}
  //         </Text>
  //         <Text style={{fontSize: ms(12), fontFamily: FONTS.Regular}}>
  //           {item.start_time} - {item?.end_time}
  //         </Text>
  //         <Text
  //           style={{
  //             fontSize: ms(12),
  //             fontFamily: FONTS.Regular,
  //             marginTop: ms(5),
  //             width: '60%',
  //           }}>
  //           {item.location}
  //         </Text>
  //       </View>
  //       <View style={{alignItems:'flex-end'}}>
  //           <View style={{flexDirection:'row',alignItems:'center'}}>
  //             <TouchableOpacity onPress={()=> navigate("EditAppointment",{item:item})} style={{padding:ms(5)}}>
  //               <Image resizeMode='contain' source={ICONS.editicn} style={{height:ms(15),width:ms(15)}}/>
  //             </TouchableOpacity>
  //             <TouchableOpacity style={{padding:ms(5)}}>
  //               <Image resizeMode='contain' source={ICONS.delete} style={{height:ms(15),width:ms(15)}}/>
  //             </TouchableOpacity>

  //           </View>

  //         </View>
  //     </View>
  //   );
  // };

  const renderAppoData = ({item, index}) => {
    return (
      <View
        style={{
          //height: ms(100),
          borderWidth: ms(0.8),
          borderColor: COLORS.border,
          borderRadius: ms(10),
          marginTop: ms(5),
          paddingHorizontal: ms(12),
          paddingVertical:ms(12),
          flexDirection: 'row', // Already set
          alignItems: 'center',
          justifyContent: 'space-between', // Helps distribute items
          marginBottom: ms(5),
          elevation: 2,
          backgroundColor: COLORS.white,
          shadowColor: 'rgba(4, 127, 255, 0.2)',
          // Optional: Add padding instead of fixed height
        }}>
        {/* Left: Date Circle */}
        <View
          style={{
            height: ms(68),
            width: ms(68),
            borderRadius: ms(5),
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(4, 127, 255, 0.1)',
          }}>
          <Text style={{fontSize: ms(30), color: COLORS.themeColor}}>
            {moment(item.start_date).utc().date()}
          </Text>
          <Text style={{fontSize: ms(12), color: COLORS.themeColor}}>
            {moment(item.start_date).utc().format('MMM')}
          </Text>
        </View>

        {/* Middle: Info (Flexible) */}
        <View style={{flex: 1, paddingLeft: ms(10), justifyContent: 'center'}}>
          <View style={{flexDirection: 'row', alignItems: 'center',paddingVertical:ms(5)}}>
            {item.contacts.map((itemm, index) => {
              return <Text key={index}>{itemm.contact_name},</Text>;
            })}
          </View>
          {/* <Text
            style={{fontSize: ms(14), fontFamily: FONTS.Medium}}
            numberOfLines={1}>
            {item?.client?.name}
          </Text> */}
          <Text style={{fontSize: ms(12), fontFamily: FONTS.Regular}}>
            {item.start_time} - {item.end_time}
          </Text>
          <Text
            style={{
              fontSize: ms(12),
              fontFamily: FONTS.Regular,
              marginTop: ms(5),
            }}
            numberOfLines={1}>
            {item.location}
          </Text>
        </View>

        {/* Right: Edit & Delete Icons */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginLeft: ms(10), // Optional spacing
          }}>
          {/* Edit Icon */}
          <TouchableOpacity
            onPress={() => navigate('EditAppointment', {item})}
            style={{
              padding: ms(8), // Larger touchable area
            }}>
            <Image
              source={ICONS.editicn}
              style={{
                height: ms(16),
                width: ms(16),
                tintColor: COLORS.themeColor, // Optional: colorize icon
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {/* Delete Icon */}
          <TouchableOpacity
            onPress={() => {
              let payload = {
                id: item?.id,
              };
              //alert(JSON.stringify(item))
              dispatch(deleteAppointmentRequest(payload));
              setTimeout(() => {
                const today = moment();
                const isCurrentYear = currentYear === today.year();
                const currentMonth = isCurrentYear ? today.month() + 1 : 1;

                //const currentMonth = moment().month() + 1;
                let payload = {
                  month: currentMonth,
                  year: currentYear,
                };
                dispatch(getAppointmentListRequest(payload));
                setSelectedId(currentMonth);

                const index = months.findIndex(
                  month => month.id === currentMonth,
                );

                if (index !== -1 && flatListRef.current) {
                  // Delay slightly to ensure rendering completes
                  setTimeout(() => {
                    flatListRef.current?.scrollToIndex({
                      index,
                      animated: true,
                      viewPosition: 0.5, // center the item
                    });
                  }, 100);
                }
              }, 1000);
            }} // Add actual delete handler
            style={{
              padding: ms(8),
            }}>
            <Image
              source={ICONS.delete}
              style={{
                height: ms(16),
                width: ms(16),
                //tintColor: COLORS.red, // Make it red for clarity
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: COLORS?.white,
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Appointments'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <View style={{alignItems: 'center', paddingVertical: ms(5)}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <TouchableOpacity
                style={{marginRight: ms(5)}}
                onPress={() => setCurrentYear(currentYear - 1)}>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(20),
                    width: ms(20),
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '270deg'}],
                  }}
                  source={ICONS.scrollup}
                />
              </TouchableOpacity>
              <Text style={{fontSize: ms(16), fontFamily: FONTS.SemiBold}}>
                {String(currentYear)}
              </Text>
              <TouchableOpacity
                style={{marginLeft: ms(5)}}
                onPress={() => setCurrentYear(currentYear + 1)}>
                <Image
                  resizeMode="contain"
                  style={{
                    height: ms(20),
                    width: ms(20),
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '90deg'}],
                  }}
                  source={ICONS.scrollup}
                />
              </TouchableOpacity>
            </View>
          </View>
          <>
            <FlatList
              ref={flatListRef}
              data={months}
              renderItem={renderMonths}
              style={{
                elevation: 2,
                backgroundColor: COLORS?.white,
                width: Dimensions?.get('window')?.width,
                marginLeft: ms(-20),
              }}
              horizontal
              showsHorizontalScrollIndicator={false}
              getItemLayout={(data, index) => ({
                length: ms(80), // Approximate width of each item
                offset: ms(80) * index,
                index,
              })}
            />

            <FlatList data={appointmentList} renderItem={renderAppointment} />
          </>
        </View>
      </ScrollView>
      {/* <TouchableOpacity
        onPress={() => navigate('AddAppointment')}
        style={{
          position: 'absolute',
          bottom: ms(60),
          right: ms(10),
          //height:
        }}>
        <Image
          source={ICONS.addMore}
          resizeMode="contain"
          style={[styles.iconStyle, {tintColor: COLORS?.themeColor}]}
        />
      </TouchableOpacity> */}
      <TouchableOpacity
        onPress={() => navigate('AddAppointment')}
        style={{
          //marginTop: -ms(80),
          //backgroundColor: 'rgb(232, 243, 255)',
          height: ms(70),
          width: ms(70),
          borderRadius: ms(35),
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(30),
          zIndex: 1,
          right: 0,
          borderColor: COLORS.border,
          //borderWidth: 2,
        }}>
        <View
          style={{
            height: ms(50),
            width: ms(50),
            borderRadius: ms(25),
            backgroundColor: COLORS?.themeColor,

            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            source={ICONS.addMore}
            resizeMode="contain"
            style={[
              styles.iconStyle,
              {tintColor: COLORS?.white, marginRight: ms(0)},
            ]}
          />
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
