import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {
  addAccountRequest,
  getRoleListRequest,
  updateProfileRequest,
} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';
import CameraDropDown from '../../components/CameraDropDown';

export default function ChangePassword() {
  const {roleList, loading, profileResponse} = useSelector(
    state => state.ProfileReducer,
  );
  const [name, setName] = useState(profileResponse?.name);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState(
    profileResponse?.phone == null ? '' : profileResponse?.phone,
  );
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('');
  const [roleModal, setRoleModal] = useState(false);
  const dispatch = useDispatch();
  const [imageObject, setImageObject] = useState('');
  const [cameraModal, setCameraModal] = useState(false);
  useEffect(() => {
    dispatch(getRoleListRequest());
    console.log(name);
  }, []);
  const formatNameToInitials = name => {
    // Split the name into words
    const words = name.split(' ');

    // Extract the first letter of each word and convert to uppercase
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');

    return initials;
  };
  function ChangePassword() {
    if (password == '') {
      Toast('Existing password is required');
    } else if (newPassword == '') {
      Toast('New password is required');
    } else if (confirmPassword == '') {
      Toast('Confirm password is required');
    } else if (confirmPassword != newPassword) {
      Toast('New password and confirm password should same');
    } else {
      console.log('Update profile is calling');
      let formData = new FormData();
      formData?.append('current_password', password);
      formData?.append('password', newPassword);
      // goBack();
      dispatch(updateProfileRequest(formData));
    }
  }
  function isEmpty(item) {
    if (item == '' || item == null || item == undefined) return true;
    return false;
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />

      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Change Password'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={() => {
            ChangePassword();
          }}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(50),
            alignItems: 'center',
          }}>
          <AnimatedTextInput
            label={'Old Password'}
            //keyboardType={'email-address'}
            secureTextEntry={true}
            width={Dimensions?.get('window')?.width - 50}
            value={password}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setPassword(item);
            }}
          />

          <AnimatedTextInput
            label={'New Password'}
            // keyboardType={'numeric'}
            secureTextEntry={true}
            width={Dimensions?.get('window')?.width - 50}
            value={newPassword}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setNewPassword(item);
            }}
          />

          <AnimatedTextInput
            label={'Confirm Password'}
            // keyboardType={'numeric'}
            secureTextEntry={true}
            width={Dimensions?.get('window')?.width - 50}
            value={confirmPassword}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setConfirmPassword(item);
            }}
          />
        </View>
        <TouchableOpacity
          style={{
            paddingHorizontal: ms(20),
            paddingVertical: ms(8),
            backgroundColor: COLORS?.themeColor,
            marginTop: ms(20),
            alignSelf: 'center',
            width: ms(150),
            borderRadius: ms(20),
          }}
          onPress={() => {
            ChangePassword();
          }}>
          <Text
            style={{
              color: COLORS?.white,
              textAlign: 'center',
              fontFamily: FONTS?.Medium,
              fontSize: ms(15),
            }}>
            Save
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
