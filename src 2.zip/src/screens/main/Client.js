import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import Header from '../../components/Header';
import MainHeader from '../../components/MainHeader';
import {
  getClientRequest,
  getClientDetailsRequest,
  deleteClientRequest,
  getMyClientDetailsRequest,
} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../utils/helpers/Loader';
import {useFocusEffect} from '@react-navigation/native';
import {Modal} from 'react-native';
//import { Menu, MenuOption, MenuOptions, MenuTrigger } from '@react-native-menu/menu';
//import MenuItem from '../../components/MenuItem';

export default function Client() {
  const dispatch = useDispatch();
  const {loading = false} = useSelector(state => state.ProfileReducer || {});
  const {clientList} = useSelector(state => state.ProfileReducer);
  const [menuVisible, setMenuVisible] = useState(false);
  const [setupStep, setSetupStep] = useState(false);
  const [menuOptionDisplay, setMenuOptionDisplay] = useState(false);
  const [selectedClient, setSelectedClient] = useState('');
  const clientListt = [
    {
      thumbnail: 'A',
      array: [
        {
          name: 'Akash Misra',
          email: 'akashmisra@gmail.com',
        },
        {
          name: 'Akash Misra',
          email: 'akashmisra@gmail.com',
        },
        {
          name: 'Akash Misra',
          email: 'akashmisra@gmail.com',
        },
        {
          name: 'Akash Misra',
          email: 'akashmisra@gmail.com',
        },
      ],
    },
    {
      thumbnail: 'B',
      array: [
        {
          name: 'Bikash Misra',
          email: 'bikashmisra@gmail.com',
        },
        {
          name: 'Bikash Misra',
          email: 'bikashmisra@gmail.com',
        },
        {
          name: 'Bikash Misra',
          email: 'bikashmisra@gmail.com',
        },
        {
          name: 'Bikash Misra',
          email: 'bikashmisra@gmail.com',
        },
      ],
    },
  ];
  useEffect(() => {
    //getClient()
  }, []);
  const [transformedClientList, setTransformedClientList] = useState([]);
  const transformData = data => {
    // Group clients by thumbnail
    const groupedData = data.reduce((acc, client) => {
      const thumbnail = client.name.charAt(0).toUpperCase();
      let group = acc.find(item => item.thumbnail === thumbnail);

      if (!group) {
        group = {thumbnail, array: []};
        acc.push(group);
      }

      group.array.push({
        name: client.name,
        email: client.email,
        id: client.id,
        profileImage: client.profileImage,
      });

      return acc;
    }, []);

    // Sort groups by thumbnail
    groupedData.sort((a, b) => a.thumbnail.localeCompare(b.thumbnail));

    // Sort clients within each group by name
    groupedData.forEach(group => {
      group.array.sort((a, b) => a.name.localeCompare(b.name));
    });

    return groupedData;
  };
  const toggleModal = () => {
    setMenuVisible(!menuVisible);
  };
  useEffect(() => {

    if (clientList && clientList.length > 0) {
      const transformedData = transformData(clientList);
      setTransformedClientList(transformedData);
    }
    else{
      setTransformedClientList([]);
    }
  }, [clientList]);
  useFocusEffect(
    useCallback(() => {
      // This function will be called when the screen is focused
      setSelectedClient('');
      // Call your function here
      getClient();
    }, []),
  );
  const getClient = () => {
    let payload = {};
    dispatch(getClientRequest(payload));
  };
  const getClientDetails = item => {
    let payload = `main/client/${item.id}`;
    dispatch(getClientDetailsRequest(payload));
  };

  const getMyClient = item => {
    let payload = `main/client/${item.id}`;
    dispatch(getMyClientDetailsRequest(payload));
  };

  const createTwoButtonAlert = id => {
    Alert.alert('Delete', 'Do you want to delete this client?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: () => {
          let payload = {
            id: id,
          };
          dispatch(deleteClientRequest(payload));
          setTimeout(() => {
            getClient();
          }, 2000);
        },
      },
    ]);
  };
  const getInitials = name => {
    if (!name) return '';

    const nameParts = name.split(' ');
    const firstNameInitial = nameParts[0]?.charAt(0).toUpperCase() || '';
    const lastNameInitial = nameParts[1]?.charAt(0).toUpperCase() || '';

    return firstNameInitial + lastNameInitial;
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View style={{backgroundColor: '#f8fdff'}}>
        <MainHeader
          label={'Clients'}
          moreOptionPresent={item => {
            console.log('scdsfvdgvf');
            navigate('CreateClient');
          }}
        />
        <View
          style={{
            paddingHorizontal: ms(30),
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            //marginVertical: ms(10),
            //marginTop:ms(10),
            borderBottomWidth: 1,
            //marginBottom:ms(20)
            //paddingBottom:ms(20),
            borderBottomColor: '#E5E7EB',
            //backgroundColor:'#E5E7EB',
            paddingVertical: ms(25),
            backgroundColor: '#f8fdff',
          }}>
          <View
            style={{flexDirection: 'row', alignItems: 'center', gap: ms(10)}}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: '#344054',
              }}>
              Sort by name
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                tintColor: COLORS?.themeColor,
                transform: [{rotate: '180deg'}],
              }}
              resizeMode="contain"
            />
          </View>
          <Image
            source={ICONS?.sort}
            style={{height: ms(15), width: ms(15)}}
            resizeMode="contain"
          />
        </View>
      </View>
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          // justifyContent: 'center',
          flex: 1,
        }}
        source={IMAGES?.colorBackground}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          {transformedClientList.length == 0 ? (
            <View style={{marginTop: ms(0)}}>
              <Image
                resizeMode="contain"
                style={{
                  height: ms(300),
                  width: ms(300),
                  alignSelf: 'center',
                }}
                source={ICONS.noclient}
              />
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Regular,
                  alignSelf: 'center',
                  color: '#344054',
                  textAlign: 'center',
                  marginTop: ms(20),
                }}>
                No Clients Added Yet
              </Text>
              <TouchableOpacity
                onPress={() => navigate('CreateClient')}
                style={{
                  paddingVertical: ms(10),
                  width: '60%',
                  borderRadius: ms(20),
                  backgroundColor: COLORS.themeColor,
                  alignItems: 'center',
                  alignSelf: 'center',
                  justifyContent: 'center',
                  marginTop: ms(20),
                }}>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    color: COLORS.white,
                    fontSize: ms(14),
                  }}>
                  Add New Client
                </Text>
              </TouchableOpacity>
            </View>
          ) : null}
          <View
            style={{flex: 1, marginBottom: ms(75), paddingHorizontal: ms(18)}}>
            {transformedClientList?.map((parntItem, parentIndex) => {
              return (
                <View
                  style={{marginTop: ms(5), position: 'relative', zIndex: 0}}>
                  <Text
                    style={{
                      textAlign: 'right',
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(13),
                      color: '#344054',
                      paddingRight: ms(10),
                      // marginLeft: -ms(20),
                    }}>
                    {parntItem?.thumbnail}
                  </Text>
                  <FlatList
                    data={parntItem?.array}
                    style={{
                      backgroundColor: COLORS?.white,
                      borderRadius: ms(10),
                      padding: ms(10),
                      elevation: ms(5),
                      shadowColor: 'rgba(4, 127, 255, 0.2)',
                      // marginTop: ms(5),
                    }}
                    renderItem={({item, index}) => {
                      return (
                        <View
                          //onPress={() => getClientDetails(item)}
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            borderBottomWidth:
                              index != parntItem?.array?.length - 1
                                ? ms(0.7)
                                : ms(0),
                            borderBottomColor:
                              index != parntItem?.array?.length - 1
                                ? '#E5E7EB'
                                : COLORS.white,
                            paddingVertical: ms(10),
                            paddingHorizontal: ms(10),

                            //marginBottom:ms(10)
                          }}>
                          <View
                            style={{
                              flexDirection: 'row',
                              alignItems: 'center',
                              gap: ms(10),
                            }}>
                            {item.profileImage ? (
                              <Image
                                resizeMode="cover"
                                style={{
                                  height: ms(40),
                                  width: ms(40),
                                  borderRadius: ms(20),
                                  overflow: 'hidden',
                                }}
                                source={{uri: item.profileImage}}
                              />
                            ) : (
                              <View
                                style={{
                                  height: ms(40),
                                  width: ms(40),
                                  borderRadius: ms(20),
                                  backgroundColor: '#E5E7EB',
                                  //backgroundColor: 'red',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: ms(12),
                                    fontFamily: FONTS.Medium,
                                    color: COLORS.themeColor,
                                  }}>
                                  {getInitials(item.name)}
                                </Text>
                              </View>
                            )}

                            <TouchableOpacity
                              onPress={() => getClientDetails(item)}>
                              <Text
                                style={{
                                  fontFamily: FONTS?.Medium,
                                  fontSize: ms(12),
                                  color: '#344054',
                                }}>
                                {item?.name}
                              </Text>
                              <Text
                                style={{
                                  fontFamily: FONTS?.Light,
                                  fontSize: ms(10),
                                  color: 'rgba(52, 64, 84, 1)',
                                  // marginTop: -ms(5),
                                }}>
                                {item?.email}
                              </Text>
                            </TouchableOpacity>
                          </View>
                          {menuOptionDisplay &&
                          selectedClient?.id == item?.id ? (
                            <View
                              style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                              }}>
                              <TouchableOpacity
                                onPress={() => getMyClient(item)}>
                                <Image
                                  source={ICONS?.editicn}
                                  style={{height: ms(15), width: ms(15)}}
                                  resizeMode="contain"
                                />
                              </TouchableOpacity>
                              <TouchableOpacity
                                onPress={() => createTwoButtonAlert(item?.id)}>
                                <Image
                                  source={ICONS?.delicn}
                                  style={{
                                    height: ms(14),
                                    width: ms(12.44),
                                    marginLeft: ms(15),
                                  }}
                                  resizeMode="contain"
                                />
                              </TouchableOpacity>
                            </View>
                          ) : null}
                          {selectedClient?.id != item?.id ? (
                            <TouchableOpacity
                              style={{
                                position: 'absolute',
                                top: ms(17),
                                right: ms(0),
                                // borderWidth: ms(0.2),
                                padding: ms(10),
                              }}
                              onPress={() => {
                                setMenuOptionDisplay(true);
                                setSelectedClient(item);
                              }}>
                              <Image
                                resizeMode="contain"
                                style={{height: ms(3.68), width: ms(14)}}
                                source={ICONS.moreInfo}
                              />
                            </TouchableOpacity>
                          ) : null}
                          {/* {menuOptionDisplay &&
                          selectedClient?.id == item?.id ? (
                            <View
                              style={{
                                position: 'absolute',
                                zIndex: 100,
                                // height: ms(50),
                                top: ms(8),
                                right: ms(30),
                                // width: ms(80)
                                backgroundColor: COLORS?.white,
                                borderWidth: ms(0.3),
                                borderColor: 'rgba(4, 127, 255, 0.5)',
                                borderRadius: ms(5),
                                padding: ms(5),
                                paddingHorizontal: ms(8),
                                // elevation: 5,
                              }}>
                              <TouchableOpacity
                                style={{
                                  flexDirection: 'row',
                                  gap: ms(3),
                                  alignItems: 'center',
                                }}
                                onPress={() => getMyClient(item)}>
                                <Image
                                  source={ICONS?.editicn}
                                  style={{height: ms(10), width: ms(10)}}
                                  resizeMode="contain"
                                />
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Medium,
                                    fontSize: ms(9),
                                    color: COLORS?.themeColor,
                                  }}>
                                  Edit
                                </Text>
                              </TouchableOpacity>
                              <TouchableOpacity
                                style={{
                                  flexDirection: 'row',
                                  gap: ms(3),
                                  alignItems: 'center',
                                  marginTop: ms(2),
                                }}
                                onPress={() => createTwoButtonAlert(item?.id)}>
                                <Image
                                  source={ICONS?.delicn}
                                  style={{
                                    height: ms(10),
                                    width: ms(10),
                                  }}
                                  resizeMode="contain"
                                />
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Medium,
                                    fontSize: ms(9),
                                    color: COLORS?.themeColor,
                                  }}>
                                  Delete
                                </Text>
                              </TouchableOpacity>
                            </View>
                          ) : null} */}
                        </View>
                      );
                    }}
                  />
                </View>
              );
            })}
            {/* <FlatList
              data={transformedClientList}
              style={{paddingHorizontal: ms(18)}}
              renderItem={({item, index}) => {
                var parentArray = item;
                return (
                  <View style={{marginTop: ms(5)}}>
                    <Text
                      style={{
                        textAlign: 'right',
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(13),
                        color: '#344054',
                        paddingRight: ms(10),
                      }}>
                      {item?.thumbnail}
                    </Text>
                    <FlatList
                      data={item?.array}
                      style={{
                        backgroundColor: COLORS?.white,
                        borderRadius: ms(10),
                        padding: ms(10),
                        elevation: ms(5),
                        shadowColor: 'rgba(4, 127, 255, 0.2)',
                      }}
                      renderItem={({item, index}) => {
                        return (
                          <View
                            style={{
                              flexDirection: 'row',
                              justifyContent: 'space-between',
                              borderBottomWidth:
                                index != parentArray?.array?.length - 1
                                  ? ms(0.7)
                                  : ms(0),
                              borderBottomColor:
                                index != parentArray?.array?.length - 1
                                  ? '#E5E7EB'
                                  : COLORS.white,
                              paddingVertical: ms(10),
                              paddingHorizontal: ms(10),
                            }}>
                            <View
                              style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                gap: ms(10),
                              }}>
                              {item.profileImage ? (
                                <Image
                                  resizeMode="cover"
                                  style={{
                                    height: ms(40),
                                    width: ms(40),
                                    borderRadius: ms(20),
                                    overflow: 'hidden',
                                  }}
                                  source={{uri: item.profileImage}}
                                />
                              ) : (
                                <View
                                  style={{
                                    height: ms(40),
                                    width: ms(40),
                                    borderRadius: ms(20),
                                    backgroundColor: '#E5E7EB',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: ms(12),
                                      fontFamily: FONTS.Medium,
                                      color: COLORS.themeColor,
                                    }}>
                                    {getInitials(item.name)}
                                  </Text>
                                </View>
                              )}

                              <TouchableOpacity
                                onPress={() => getClientDetails(item)}>
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Medium,
                                    fontSize: ms(12),
                                    color: '#344054',
                                  }}>
                                  {item?.name}
                                </Text>
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Light,
                                    fontSize: ms(10),
                                    color: 'rgba(52, 64, 84, 1)',
                                  }}>
                                  {item?.email}
                                </Text>
                              </TouchableOpacity>
                            </View>
                            <TouchableOpacity
                              style={{
                                position: 'absolute',
                                top: ms(27),
                                right: ms(10),
                              }}>
                              <Image
                                resizeMode="contain"
                                style={{height: ms(3.68), width: ms(14)}}
                                source={ICONS.moreInfo}
                              />
                            </TouchableOpacity>
                            {index == 2 ? (
                              <View
                                style={{
                                  position: 'absolute',
                                  zIndex: 100,
                                  height: ms(100),
                                  top: ms(15),
                                  width: ms(50),
                                  backgroundColor: COLORS?.white,
                                  elevation: 5,
                                }}></View>
                            ) : null}
                            
                          </View>
                        );
                      }}
                    />
                  </View>
                );
              }}
            /> */}
          </View>
        </ScrollView>
        <TouchableOpacity
        onPress={()=> navigate('CreateClient')}
          style={{
            //marginTop: -ms(80),
           // backgroundColor: 'rgb(232, 243, 255)',
            height: ms(70),
            width: ms(70),
            borderRadius: ms(35),
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(2),
            zIndex: 1,
            right: 10,
            borderColor: COLORS.border,
            //borderWidth: 2,
          }}>
          <View
            style={{
              height: ms(50),
              width: ms(50),
              borderRadius: ms(25),
              backgroundColor: COLORS?.themeColor,

              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[
                styles.iconStyle,
                {tintColor: COLORS?.white, marginRight: ms(0)},
              ]}
            />
          </View>
        </TouchableOpacity>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fdff',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
    // tintColor: COLORS.dark_grey,
    marginRight: ms(10),
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

    //backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
  },
  modalContent: {
    // width: 270,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    //marginBottom: 15,
    textAlign: 'center',
    fontSize: normalize(16),
    fontFamily: FONTS.Bold,
  },
});
