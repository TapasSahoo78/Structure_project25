import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {useSelector, useDispatch} from 'react-redux';
import {updateClientCommRequest} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo, {isTablet} from 'react-native-device-info';
export default function ClientCommunication() {
  const dispatch = useDispatch();
  const {clientCommunicationDetails, loading} = useSelector(
    state => state.ProfileReducer,
  );

  const [sameEmail, setSameEmail] = useState(
    clientCommunicationDetails?.sameEmail,
  );
  const [paymentReminder, setPaymentReminder] = useState(
    clientCommunicationDetails?.paymentReminder,
  );
  const [message, setMessage] = useState(
    clientCommunicationDetails?.message !== null
      ? clientCommunicationDetails?.message
      : '',
  );
  const [emailCC, setEmailCC] = useState(
    clientCommunicationDetails?.cc !== null
      ? clientCommunicationDetails?.cc
      : '',
  );
  const [emailBcc, setEmailBcc] = useState(
    clientCommunicationDetails?.bcc !== null
      ? clientCommunicationDetails?.bcc
      : '',
  );
  const [reminderThree, setReminderthree] = useState(
    clientCommunicationDetails?.day3BeforeDueDate,
  );
  const [reminderDueDate, setReminderDuedate] = useState(
    clientCommunicationDetails?.dueDate,
  );
  const [afterThree, setAfterThree] = useState(
    clientCommunicationDetails?.day3AfterDueDate,
  );
  const [afterSeven, setAfterSeven] = useState(
    clientCommunicationDetails?.day7AfterDueDate,
  );
  const [paymentNotification, setPaymentNotification] = useState(
    clientCommunicationDetails?.paymentNotification,
  );
  const [paymentReceipt, setPaymentReceipt] = useState(
    clientCommunicationDetails?.paymentReceipt,
  );
  const [emailComm, setEmailComm] = useState(clientCommunicationDetails?.email);
  const [businessResource, setBusinessResource] = useState(
    clientCommunicationDetails?.businessResource,
  );
  const [invoiceFundamental, setInvoiceFundamental] = useState(
    clientCommunicationDetails?.invoice2go,
  );
  const [productUpdate, setProductUpdate] = useState(
    clientCommunicationDetails?.productUpdate,
  );
  const [specialOffer, setSpecialOffer] = useState(
    clientCommunicationDetails?.specialOffer,
  );

  const callAddCommunicationApi = () => {
    let payload = {
      id: clientCommunicationDetails?.id,
      sameEmail: sameEmail,
      paymentReminder: paymentReminder,
      message: message,
      cc: emailCC,
      bcc: emailBcc,
      day3BeforeDueDate: paymentReminder ? reminderThree : false,
      dueDate: paymentReminder ? reminderDueDate : false,
      day3AfterDueDate: paymentReminder ? afterThree : false,
      day7AfterDueDate: paymentReminder ? afterSeven : false,
      paymentNotification: paymentNotification,
      paymentReceipt: paymentReceipt,
      email: emailComm,
      businessResource: businessResource,
      invoice2go: invoiceFundamental,
      productUpdate: productUpdate,
      specialOffer: specialOffer,
    };
    dispatch(updateClientCommRequest(payload));
  };
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Client Communication'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20), alignItems: 'center'}}>
          <View
            style={{
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              padding: ms(10),
              borderRadius: ms(6),
              width: '100%',
              //marginTop: ms(10),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Email Messages
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: ms(20),
              paddingHorizontal: ms(15),
            }}>
            <Text
              style={{
                fontSize: ms(12),
                fontFamily: FONTS.Regular,
                color: COLORS.placeholderColor,
                width: '89%',
              }}>
              Use the same email message {'\n'}for all document types
            </Text>
            {sameEmail ? (
              <TouchableOpacity onPress={() => setSameEmail(!sameEmail)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => setSameEmail(!sameEmail)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <AnimatedTextInput
            label={'Message'}
            keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={message}
            borderColor={COLORS?.themeColor}
            minimumHeight={100}
            multiline={true}
            onChangeText={item => {
              setMessage(item);
            }}
          />
          <AnimatedTextInput
            label={'Email CC'}
            keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={emailCC}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            //minimumHeight={100}
            //multiline={true}
            onChangeText={item => {
              setEmailCC(item);
            }}
          />
          <AnimatedTextInput
            label={'Email BCC'}
            keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={emailBcc}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            //minimumHeight={100}
            //multiline={true}
            onChangeText={item => {
              setEmailBcc(item);
            }}
          />
          <View
            style={{
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              padding: ms(10),
              borderRadius: ms(6),
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Reminders
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: ms(20),
              paddingHorizontal: ms(12),
            }}>
            <Text
              style={{
                fontSize: ms(12),
                fontFamily: FONTS.Regular,
                color: COLORS.placeholderColor,
                width: '89%',
              }}>
              Send payment reminders by {'\n'}email to your customers
            </Text>
            {paymentReminder ? (
              <TouchableOpacity
                onPress={() => setPaymentReminder(!paymentReminder)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setPaymentReminder(!paymentReminder)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          {paymentReminder ? (
            <View style={{paddingLeft: ms(10), width: '100%'}}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setReminderthree(!reminderThree)}
                  style={{
                    height: ms(25),
                    width: ms(25),
                    borderWidth: ms(1),
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: ms(4),
                    borderColor: COLORS.themeColor,
                    backgroundColor: reminderThree
                      ? COLORS.themeColor
                      : COLORS.white,
                  }}>
                  {reminderThree ? (
                    <Image
                      resizeMode="contain"
                      style={{height: ms(10), width: ms(15)}}
                      source={ICONS.whitetick}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    marginLeft: ms(20),
                  }}>
                  3 Day Before Due Date
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setReminderDuedate(!reminderDueDate)}
                  style={{
                    height: ms(25),
                    width: ms(25),
                    borderWidth: ms(1),
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: ms(4),
                    borderColor: COLORS.themeColor,
                    backgroundColor: reminderDueDate
                      ? COLORS.themeColor
                      : COLORS.white,
                  }}>
                  {reminderDueDate ? (
                    <Image
                      resizeMode="contain"
                      style={{height: ms(10), width: ms(15)}}
                      source={ICONS.whitetick}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    marginLeft: ms(20),
                  }}>
                  On Due Date
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setAfterThree(!afterThree)}
                  style={{
                    height: ms(25),
                    width: ms(25),
                    borderWidth: ms(1),
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: ms(4),
                    borderColor: COLORS.themeColor,
                    backgroundColor: afterThree
                      ? COLORS.themeColor
                      : COLORS.white,
                  }}>
                  {afterThree ? (
                    <Image
                      resizeMode="contain"
                      style={{height: ms(10), width: ms(15)}}
                      source={ICONS.whitetick}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    marginLeft: ms(20),
                  }}>
                  3 Days After Due Date
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setAfterSeven(!afterSeven)}
                  style={{
                    height: ms(25),
                    width: ms(25),
                    borderWidth: ms(1),
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: ms(4),
                    borderColor: COLORS.themeColor,
                    backgroundColor: afterSeven
                      ? COLORS.themeColor
                      : COLORS.white,
                  }}>
                  {afterSeven ? (
                    <Image
                      resizeMode="contain"
                      style={{height: ms(10), width: ms(15)}}
                      source={ICONS.whitetick}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    marginLeft: ms(20),
                  }}>
                  7 Days After Due Date
                </Text>
              </View>
            </View>
          ) : null}
          <View style={{paddingLeft: ms(10), width: '100%'}}>
            <Text
              style={{
                color: COLORS.themeColor,
                fontSize: ms(12),
                marginTop: ms(20),
                fontFamily: FONTS.Regular,
              }}>
              Send me a preview
            </Text>
            <Text style={{fontSize: ms(12), fontFamily: FONTS.Regular}}>
              Example reminders will be sent to askyoff@gmail.com.
            </Text>
          </View>
          <View
            style={{
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              padding: ms(10),
              borderRadius: ms(6),
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Post payment option
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Payment notification
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Your clients can notify you when they have paid
              </Text>
            </View>
            {paymentNotification ? (
              <TouchableOpacity
                onPress={() => setPaymentNotification(!paymentNotification)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setPaymentNotification(!paymentNotification)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              width: '100%',
              height: ms(1),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              //marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Payment receipts
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Send a receipt to your client after they pay you.
              </Text>
            </View>
            {paymentReceipt ? (
              <TouchableOpacity
                onPress={() => setPaymentReceipt(!paymentReceipt)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setPaymentReceipt(!paymentReceipt)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              padding: ms(10),
              borderRadius: ms(6),
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Communication Preferences
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Email
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Subscribe to emails
              </Text>
            </View>
            {emailComm ? (
              <TouchableOpacity onPress={() => setEmailComm(!emailComm)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => setEmailComm(!emailComm)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              width: '100%',
              height: ms(1),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              // marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Business Resources
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Articles, videos and podcasts
              </Text>
            </View>
            {businessResource ? (
              <TouchableOpacity
                onPress={() => setBusinessResource(!businessResource)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setBusinessResource(!businessResource)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              width: '100%',
              height: ms(1),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              // marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Invoice2go Fundamentals
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Tips and how-to guides
              </Text>
            </View>
            {invoiceFundamental ? (
              <TouchableOpacity
                onPress={() => setInvoiceFundamental(!invoiceFundamental)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setInvoiceFundamental(!invoiceFundamental)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              width: '100%',
              height: ms(1),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              // marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Product Updates
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                New features and improvements
              </Text>
            </View>
            {productUpdate ? (
              <TouchableOpacity
                onPress={() => setProductUpdate(!productUpdate)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => setProductUpdate(!productUpdate)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>
          <View
            style={{
              width: '100%',
              height: ms(1),
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              // marginTop: ms(20),
              paddingHorizontal: ms(10),
            }}>
            <View style={{width: '89%'}}>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  //color: COLORS.placeholderColor,
                }}>
                Special Offers
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  //color: COLORS.placeholderColor,
                }}>
                Contests, giveaways and prizes
              </Text>
            </View>
            {specialOffer ? (
              <TouchableOpacity onPress={() => setSpecialOffer(!specialOffer)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switch}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => setSpecialOffer(!specialOffer)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={ICONS.switchoff}
                />
              </TouchableOpacity>
            )}
          </View>

          <TouchableOpacity
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,
              // position: 'absolute',
              // bottom: ms(10),
              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginTop: ms(20),
            }}
            onPress={() => {
              //checkValidation();
              console.log('submit');
              callAddCommunicationApi();
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
