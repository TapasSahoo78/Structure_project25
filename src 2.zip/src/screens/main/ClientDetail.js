import React, {useEffect, useState, useCallback, useRef} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Linking,
  Alert,
  Animated,
  Appearance,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {goBack, navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import Header from '../../components/Header';
import MainHeader from '../../components/MainHeader';
import Modal from 'react-native-modal';
import {useSelector} from 'react-redux';
import normalize from '../../utils/helpers/normalize';
import {useFocusEffect} from '@react-navigation/native';
import {getClientDetailsRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch} from 'react-redux';
import IsEmpty from '../../utils/helpers/IsEmpty';

export default function ClientDetail() {
  //const [scrollY, setScrollY] = useState(0);

  const scrollY = useRef(new Animated.Value(0)).current;

  const windowWidth = Dimensions.get('window').width;

  const dispatch = useDispatch();
  const {clientDetails} = useSelector(state => state.ProfileReducer);
  const [setupStep, setSetupStep] = useState(false);
  const [clientName, setClientName] = useState('');
  const [option, setOption] = useState('Activity');
  const [toggleButtonFlag, setToggleButtonFlag] = useState(false);
  const [filterModalOpen, setFilterModalOpen] = useState(false);
  const phoneNumber = clientDetails?.phone.replace(/\s/g, '');
  console.log('cccc', JSON.stringify(clientDetails));
  const email = clientDetails?.email; // Replace with the desired email address
  const subject = 'Hello';
  const body = 'This is a test email.';
  const [billContent, setBillContent] = useState(true);
  const [contactDetail, setContactDetail] = useState(true);
  const [moreContent, setMoreContent] = useState(true);

  useEffect(() => {
    let fullName = clientDetails?.name;
    const names = fullName.split(' ');
    const initials = names.map(name => name.charAt(0).toUpperCase()).join('');
    setClientName(initials);
  }, []);
  useFocusEffect(
    useCallback(() => {
      // This function will be called when the screen is focused
      console.log('Screen is focused');

      // Call your function here
      getClientDetails();

      // Optionally return a cleanup function
    }, []),
  );
  const openDialer = () => {
    console.log('phone:::', phoneNumber);
    // Check if the device can handle the URL
    const url = `tel:${phoneNumber}`;
    Linking.openURL(`tel:${phoneNumber}`);
    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     console.log("lllddd",supported)
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       Alert.alert('Error', 'Unable to open dialer');
    //     }
    //   })
    //   .catch(err => console.error('An error occurred', err));
  };
  const openEmail = () => {
    const url = `mailto:${email}?subject=${encodeURIComponent(
      subject,
    )}&body=${encodeURIComponent(body)}`;
    Linking.openURL(url);

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       Alert.alert('Error', 'Unable to open email client');
    //     }
    //   })
    //   .catch(err => console.error('An error occurred', err));
  };

  const getClientDetails = () => {
    let payload = `main/client/${clientDetails.id}`;
    dispatch(getClientDetailsRequest(payload));
  };

  //const whPhone = '+916296983369'; // Replace with the desired phone number
  const message = 'Hello, this is a test message!';
  const openWhatsApp = () => {
    const url = `whatsapp://send?text=${encodeURIComponent(
      message,
    )}&phone=${phoneNumber}`;

    Linking.openURL(url);

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       Alert.alert('Error', 'WhatsApp is not installed on this device');
    //     }
    //   })
    //   .catch(err => console.error('An error occurred', err));
  };

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(120), ms(125), ms(150)],
    outputRange: [ms(150), ms(125), ms(120)],
    extrapolate: 'clamp',
  });

  const profileHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(40), ms(50), ms(60)],
    outputRange: [ms(60), ms(50), ms(40)],
    extrapolate: 'clamp',
  });
  const profileBorder = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(20), ms(25), ms(30)],
    outputRange: [ms(30), ms(25), ms(20)],
    extrapolate: 'clamp',
  });
  const nameFontSize = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(14), ms(16), ms(18)],
    outputRange: [ms(18), ms(16), ms(14)],
    extrapolate: 'clamp',
  });

  const boxHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(49), ms(60), ms(72)],
    outputRange: [ms(72), ms(60), ms(49)],
    extrapolate: 'clamp',
  });
  const boxWidth = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: ['25%', '29%', '33%'],
    outputRange: [
      windowWidth * 0.33 * 0.7,
      windowWidth * 0.29 * 0.7,
      windowWidth * 0.25 * 0.7,
    ],
    extrapolate: 'clamp',
  });

  const receiverHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(16), ms(19), ms(23)],
    outputRange: [ms(23), ms(19), ms(16)],
    extrapolate: 'clamp',
  });
  const iconTop = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(5), ms(7), ms(10)],
    outputRange: [ms(10), ms(7), ms(5)],
    extrapolate: 'clamp',
  });

  const emailHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(13), ms(16), ms(19)],
    outputRange: [ms(19), ms(16), ms(13)],
    extrapolate: 'clamp',
  });
  const emailWidth = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(21), ms(25), ms(30)],
    outputRange: [ms(30), ms(25), ms(21)],
    extrapolate: 'clamp',
  });
  const emailTop = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(7), ms(10), ms(14)],
    outputRange: [ms(14), ms(10), ms(7)],
    extrapolate: 'clamp',
  });

  const messageHeight = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(16), ms(19), ms(23)],
    outputRange: [ms(23), ms(19), ms(16)],
    extrapolate: 'clamp',
  });

  const messageWidth = scrollY.interpolate({
    inputRange: [0, 50, 100],
    //outputRange: [ms(18), ms(22), ms(26)],
    outputRange: [ms(26), ms(22), ms(18)],
    extrapolate: 'clamp',
  });

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Modal
        isVisible={filterModalOpen}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={800}
        backdropTransitionOutTiming={0}
        onBackdropPress={() => {
          setFilterModalOpen(false);
        }}
        onBackButtonPress={() => {
          setFilterModalOpen(false);
        }}
        style={{margin: 0}}>
        <View style={styles.conntainer}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}}>
            <Text>Apply</Text>
          </TouchableOpacity>
        </View>
      </Modal>
      <Animated.View
        style={{
          width: Dimensions?.get('window')?.width,
          //height: ms(150),
          //height: scrollY > 50 ? ms(120) : ms(150),
          height: headerHeight,
          backgroundColor: '#e6f2ff',
          borderBottomLeftRadius: ms(65),
          borderBottomRightRadius: ms(65),
          paddingTop: ms(15),
          //paddingTop: scrollY > 50 ? ms(10) : ms(15),
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            paddingHorizontal: ms(15),
          }}>
          <TouchableOpacity
            onPress={() => {
              goBack();
            }}>
            <Image
              source={ICONS?.upArrow}
              style={{
                height: ms(15),
                width: ms(15),
                transform: [{rotate: '-90deg'}],
                tintColor: COLORS?.themeColor,
              }}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigate('EditClient')}>
            <Text
              style={{
                color: COLORS?.themeColor,
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
              }}>
              Edit
            </Text>
          </TouchableOpacity>
        </View>
        {IsEmpty(clientDetails?.otherDetails?.profileImage) ? (
          <Animated.View
            style={{
              height: profileHeight,
              width: profileHeight,
              backgroundColor: '#44BBFE',
              borderRadius: profileBorder,
              alignSelf: 'center',
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: -ms(20),
            }}>
            <Text
              style={{
                textAlign: 'center',
                color: COLORS?.white,
                fontFamily: FONTS?.Medium,
                fontSize: ms(14.59),
              }}>
              {clientName}
            </Text>
          </Animated.View>
        ) : (
          <Animated.View
            style={{
              height: headerHeight,
              width: headerHeight,
              backgroundColor: '#44BBFE',
              borderRadius: profileBorder,
              alignSelf: 'center',
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: -ms(20),
            }}>
            <Animated.Image
              source={{
                uri:
                  constants?.IMAGE_URL +
                  clientDetails?.otherDetails?.profileImage,
              }}
              style={{
                height: '100%',
                width: '100%',
                backgroundColor: '#44BBFE',
                borderRadius: profileBorder,
              }}
            />
          </Animated.View>
        )}

        <Animated.Text
          style={[
            {
              textAlign: 'center',
              color: 'rgba(52, 64, 84, 1)',
              marginTop: ms(10),
              fontFamily: FONTS?.Medium,
            },
            {fontSize: nameFontSize},
          ]}>
          {clientDetails?.name}
        </Animated.Text>
      </Animated.View>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          width: '70%',
          // paddingHorizontal: ms(70),
          justifyContent: 'center',
          marginTop: -ms(30),
          gap: ms(15),
        }}>
        <Animated.View
          style={{
            padding: ms(10),
            height: boxHeight,
            width: boxWidth,
            borderWidth: ms(0.2),
            borderRadius: ms(12),
            borderColor: COLORS?.themeColor,
            backgroundColor: COLORS?.white,
            alignItems: 'center',
            justifyContent: 'center',
            //alignItems:'center',

            elevation: 5,
            shadowColor: COLORS.themeColor,
          }}>
          <TouchableOpacity
            style={{justifyContent: 'center', alignItems: 'center'}}
            onPress={() => openDialer()}>
            <Animated.Image
              source={ICONS?.receiver}
              style={[
                {
                  tintColor: COLORS?.themeColor,
                },
                {height: receiverHeight, width: receiverHeight},
              ]}
              // resizeMode="contain"
            />
            <Animated.Text
              style={[
                {
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                  color: COLORS?.black,
                },
                {marginTop: iconTop},
              ]}>
              Call
            </Animated.Text>
          </TouchableOpacity>
        </Animated.View>
        <Animated.View
          style={{
            padding: ms(10),
            height: boxHeight,
            width: boxWidth,
            borderWidth: ms(0.2),
            borderRadius: ms(12),
            borderColor: COLORS?.themeColor,
            backgroundColor: COLORS?.white,
            alignItems: 'center',
            justifyContent: 'center',
            // marginRight: ms(15),
            elevation: 5,
            shadowColor: COLORS.themeColor,
          }}>
          <TouchableOpacity
            style={{justifyContent: 'center', alignItems: 'center'}}
            onPress={() => openEmail()}>
            <Animated.Image
              source={ICONS?.email}
              style={[
                {
                  tintColor: COLORS?.themeColor,
                },
                {height: emailHeight, width: emailWidth},
              ]}
              resizeMode="contain"
            />
            <Animated.Text
              style={[
                {
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                  color: COLORS?.black,
                },
                {marginTop: emailTop},
              ]}>
              Mail
            </Animated.Text>
          </TouchableOpacity>
        </Animated.View>
        <Animated.View
          style={{
            padding: ms(10),
            height: boxHeight,
            width: boxWidth,
            borderWidth: ms(0.2),
            borderRadius: ms(12),
            borderColor: COLORS?.themeColor,
            backgroundColor: COLORS?.white,
            alignItems: 'center',
            justifyContent: 'center',
            // marginRight: ms(15),
            elevation: 5,
            shadowColor: COLORS.themeColor,
          }}>
          <TouchableOpacity
            style={{justifyContent: 'center', alignItems: 'center'}}
            onPress={() => openWhatsApp()}>
            <Animated.Image
              source={ICONS?.message}
              style={[
                {
                  tintColor: COLORS?.themeColor,
                },
                {height: messageHeight, width: messageWidth},
              ]}
              resizeMode="contain"
            />
            <Animated.Text
              style={[
                {
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                  color: COLORS?.black,
                },
                {marginTop: iconTop},
              ]}>
              Message
            </Animated.Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
      <View style={{height: ms(10)}} />

      <Animated.ScrollView
        // onScroll={e => {
        //   const offsetY = e.nativeEvent.contentOffset.y;
        //   setScrollY(offsetY);
        // }}
        onScroll={Animated.event(
          [{nativeEvent: {contentOffset: {y: scrollY}}}],
          {useNativeDriver: true},
        )}
        scrollEventThrottle={16}
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, marginBottom: ms(30)}}>
          <View
            style={{
              borderTopWidth: ms(0.6),
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              borderTopColor: '#E5E7EB',
              borderBottomWidth: ms(0.6),
              borderBottomColor: '#E5E7EB',
              marginTop: ms(10),
              justifyContent: 'space-between',
              elevation: ms(2),
              shadowColor: 'rgba(0,0,0,0.2)',
              paddingHorizontal: ms(30),
              backgroundColor: COLORS?.white,
              elevation: 5,
              //alignSelf:'center'
            }}>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                borderBottomWidth: option == 'Activity' ? ms(2) : ms(0),
                borderBottomColor: '#047FFF',
                width: '35%',
                marginHorizontal: ms(20),
                //marginLeft:ms(25)
                //paddingLeft:ms(25)
              }}
              onPress={() => {
                setOption('Activity');
              }}>
              <Text
                style={{
                  textAlign: 'center',
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color:
                    option == 'Activity'
                      ? 'rgba(52, 64, 84, 1)'
                      : 'rgba(52, 64, 84, 0.75)',
                }}>
                Activity
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                borderBottomWidth: option == 'More Info' ? ms(2) : ms(0),
                borderBottomColor: '#047FFF',
                width: '35%',
                marginHorizontal: ms(20),
              }}
              onPress={() => {
                setOption('More Info');
              }}>
              <Text
                style={{
                  textAlign: 'center',
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color:
                    option == 'More Info'
                      ? 'rgba(52, 64, 84, 1)'
                      : 'rgba(52, 64, 84, 0.75)',
                }}>
                More Info
              </Text>
            </TouchableOpacity>
          </View>
          {/* <View style={{alignSelf: 'center'}}>
            <Image
              source={ICONS?.noactivity}
              style={{height: ms(200), width: ms(200)}}
              resizeMode="contain"
            />
          </View> */}
          {option == 'Activity' ? (
            // <View>
            //   <View
            //     style={{
            //       flexDirection: 'row',
            //       justifyContent: 'space-between',
            //       marginHorizontal: ms(25),
            //       paddingVertical: ms(15),
            //       borderBottomWidth: ms(0.5),
            //       borderBottomColor: '#ADADAD',
            //       alignItems: 'center',
            //     }}>
            //     <View>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(14),
            //           color: "#344054",
            //         }}>
            //         Outstanding Balance
            //       </Text>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Regular,
            //           fontSize: ms(12),
            //           color: '#344054',
            //         }}>
            //         1 unpaid(1 overdue)
            //       </Text>
            //     </View>
            //     <Text
            //       style={{
            //         fontFamily: FONTS?.Medium,
            //         fontSize: ms(20),
            //         color: '#344054'
            //       }}>
            //       $120
            //     </Text>
            //   </View>

            //   <View
            //     style={{
            //       flexDirection: 'row',
            //       justifyContent: 'space-between',
            //       paddingHorizontal: ms(25),
            //       paddingVertical: ms(10),
            //       borderBottomWidth: ms(0.4),
            //       borderBottomColor: '#ADADAD',
            //       alignItems: 'center',
            //     }}>
            //     <View>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(14),
            //           color: "#344054",
            //         }}>
            //         Statement
            //       </Text>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Regular,
            //           fontSize: ms(13),
            //           color: "#344054",
            //         }}>
            //         Collect Payment
            //       </Text>
            //     </View>
            //     <TouchableOpacity>
            //       <Image
            //         source={ICONS?.next_arrow_circle}
            //         style={{height: ms(25), width: ms(25)}}
            //         resizeMode="contain"
            //       />
            //     </TouchableOpacity>
            //   </View>

            //   <View
            //     style={{
            //       flexDirection: 'row',
            //       justifyContent: 'space-between',
            //       paddingHorizontal: ms(25),
            //       paddingVertical: ms(10),
            //       borderBottomWidth: ms(0.4),
            //       borderBottomColor: '#ADADAD',
            //       alignItems: 'center',
            //     }}>
            //     <View
            //       style={{
            //         flexDirection: 'row',
            //         gap: ms(10),
            //         alignItems: 'center',
            //       }}>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(14),
            //           color: "#344054",
            //         }}>
            //         2025 sorted by category
            //       </Text>
            //       <Image
            //         source={ICONS?.arrow}
            //         style={{
            //           height: ms(15),
            //           width: ms(15),
            //           transform: [{rotate: '180deg'}],
            //           tintColor: COLORS?.themeColor,
            //         }}
            //         resizeMode="contain"
            //       />
            //     </View>
            //     <TouchableOpacity>
            //       <Image
            //         source={ICONS?.sort}
            //         style={{height: ms(15), width: ms(15)}}
            //         resizeMode="contain"
            //       />
            //     </TouchableOpacity>
            //   </View>
            //   <View
            //     style={{
            //       padding: ms(10),
            //       borderWidth: ms(0.6),
            //       width: '60%',
            //       alignSelf: 'center',
            //       marginTop: ms(20),
            //       borderRadius: ms(6),
            //       flexDirection: 'row',
            //       justifyContent: 'space-between',
            //       alignItems: 'center',
            //     }}>
            //     <View>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(14),
            //           color: COLORS?.black,
            //         }}>
            //         Akash Mishra
            //       </Text>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(12),
            //           color: COLORS?.gray,
            //         }}>
            //         23 Oct, Due in 2 days
            //       </Text>
            //     </View>
            //     <View>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(14),
            //           color: COLORS?.black,
            //         }}>
            //         $125
            //       </Text>
            //       <Text
            //         style={{
            //           fontFamily: FONTS?.Medium,
            //           fontSize: ms(12),
            //           color: COLORS?.red,
            //         }}>
            //         Unsent
            //       </Text>
            //     </View>
            //   </View>
            // </View>
            <View style={{marginTop: ms(70)}}>
              <Image
                resizeMode="contain"
                style={{
                  height: ms(188.65),
                  width: ms(236),
                  alignSelf: 'center',
                }}
                source={ICONS.nodata}
              />
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Regular,
                  alignSelf: 'center',
                  color: '#344054',
                  textAlign: 'center',
                  marginTop: ms(40),
                }}>
                Create an invoice or an{'\n'} estimate for {clientDetails?.name}
              </Text>
            </View>
          ) : null}
          {option == 'More Info' ? (
            <View>
              <View
                style={{
                  marginHorizontal: ms(25),
                  padding: ms(15),
                  borderWidth: ms(0.3),
                  //borderColor: '#ADADAD',
                  borderColor: COLORS.white,
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  backgroundColor: COLORS?.white,
                  elevation: 5,
                  shadowColor: COLORS.themeColor,
                }}>
                <TouchableOpacity
                  onPress={() => setBillContent(!billContent)}
                  style={{
                    backgroundColor: '#e6f2ff',
                    padding: ms(5),
                    paddingHorizontal: ms(10),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderRadius: ms(6),
                    alignItems: 'center',
                    height: ms(40),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: '#047FFF',
                    }}>
                    Billing Details
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      tintColor: COLORS?.themeColor,
                      transform: [{rotate: billContent ? '0deg' : '180deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
                {billContent ? (
                  <View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(12),
                          fontFamily: FONTS.Regular,
                          color: '#344054',
                        }}>
                        Billing Name
                      </Text>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: '#344054',
                          fontFamily: FONTS.Medium,
                        }}>
                        {clientDetails?.name}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'flex-start',
                          gap: ms(5),
                        }}>
                        <Image
                          source={ICONS?.call}
                          style={{
                            height: ms(18),
                            width: ms(15),
                            tintColor: '#44BBFE',
                            marginTop: ms(2),
                          }}
                          resizeMode="contain"
                        />
                        <View>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color: '#344054',
                            }}>
                            Mobile
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: '#344054',
                              fontFamily: FONTS.Medium,
                            }}>
                            +{clientDetails?.dialCode} {clientDetails?.phone}
                          </Text>
                        </View>
                      </View>
                    </View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'flex-start',
                          gap: ms(5),
                        }}>
                        <Image
                          source={ICONS?.mail}
                          style={{
                            height: ms(15),
                            width: ms(15),
                            tintColor: '#44BBFE',
                            marginTop: ms(2),
                          }}
                          resizeMode="contain"
                        />
                        <View style={{marginLeft: ms(4)}}>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color: '#344054',
                            }}>
                            Email Address
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: '#344054',
                              fontFamily: FONTS.Medium,
                            }}>
                            {clientDetails?.email}
                          </Text>
                        </View>
                      </View>
                    </View>

                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        //borderBottomWidth: ms(0.5),
                        //borderBottomColor: '#AAA',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'flex-start',
                          gap: ms(5),
                        }}>
                        <Image
                          source={ICONS?.location_pin}
                          style={{
                            height: ms(15),
                            width: ms(15),
                            tintColor: '#44BBFE',
                            marginTop: ms(2),
                          }}
                          resizeMode="contain"
                        />
                        <View>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color: '#344054',
                            }}>
                            Location
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: '#344054',
                              fontFamily: FONTS.Medium,
                            }}>
                            12, Worli Place, near worli, fort, Mumbai,
                            Maharashtra 400030
                          </Text>
                        </View>
                      </View>
                    </View>
                  </View>
                ) : null}
              </View>
              <View
                style={{
                  marginHorizontal: ms(25),
                  padding: ms(15),
                  borderWidth: ms(0.3),
                  //borderColor: '#ADADAD',
                  borderColor: COLORS.white,
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  backgroundColor: COLORS?.white,
                  elevation: 5,
                  shadowColor: COLORS.themeColor,
                }}>
                <TouchableOpacity
                  onPress={() => setContactDetail(!contactDetail)}
                  style={{
                    backgroundColor: '#e6f2ff',
                    padding: ms(5),
                    paddingHorizontal: ms(10),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderRadius: ms(6),
                    alignItems: 'center',
                    height: ms(40),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: COLORS?.themeColor,
                    }}>
                    Contact Details
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      tintColor: COLORS?.themeColor,
                      transform: [{rotate: contactDetail ? '0deg' : '180deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
                {contactDetail ? (
                  <View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(12),
                          fontFamily: FONTS.Regular,
                          color: '#344054',
                        }}>
                        Contact Name
                      </Text>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: '#344054',
                          fontFamily: FONTS.Medium,
                        }}>
                        {clientDetails?.contacts?.contact_name}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'flex-start',
                          gap: ms(5),
                        }}>
                        <Image
                          source={ICONS?.call}
                          style={{
                            height: ms(18),
                            width: ms(15),
                            tintColor: '#44BBFE',
                            marginTop: ms(2),
                          }}
                          resizeMode="contain"
                        />
                        <View>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color: '#344054',
                            }}>
                            Phone No.
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: '#344054',
                              fontFamily: FONTS.Medium,
                            }}>
                            +{clientDetails?.contacts?.dialCode}{' '}
                            {clientDetails?.contacts?.phone}
                          </Text>
                        </View>
                      </View>
                    </View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        // borderBottomWidth: ms(0.5),
                        //borderBottomColor: '#AAA',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'flex-start',
                          gap: ms(5),
                        }}>
                        <Image
                          source={ICONS?.website}
                          style={{
                            height: ms(15),
                            width: ms(15),
                            tintColor: '#44BBFE',
                            marginTop: ms(2),
                          }}
                          resizeMode="contain"
                        />
                        <View>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Regular,
                              color: '#344054',
                            }}>
                            Website
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(14),
                              color: '#344054',
                              fontFamily: FONTS.Medium,
                            }}>
                            {clientDetails?.contacts?.website}
                          </Text>
                        </View>
                      </View>
                    </View>
                  </View>
                ) : null}
              </View>
              <View
                style={{
                  marginHorizontal: ms(25),
                  padding: ms(15),
                  borderWidth: ms(0.4),
                  //borderColor: '#ADADAD',
                  borderColor: COLORS.white,
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  backgroundColor: COLORS?.white,
                  elevation: 5,
                  shadowColor: COLORS.themeColor,
                }}>
                <TouchableOpacity
                  onPress={() => setMoreContent(!moreContent)}
                  style={{
                    backgroundColor: '#e6f2ff',
                    padding: ms(5),
                    paddingHorizontal: ms(10),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderRadius: ms(6),
                    alignItems: 'center',
                    height: ms(40),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: COLORS?.themeColor,
                    }}>
                    Other Details
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      tintColor: COLORS?.themeColor,
                      transform: [{rotate: moreContent ? '0deg' : '180deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
                {moreContent ? (
                  <View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        borderBottomWidth: ms(0.4),
                        borderBottomColor: '#E5E7EB',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(12),
                          fontFamily: FONTS.Regular,
                          color: '#344054',
                        }}>
                        Tax No.
                      </Text>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: '#344054',
                          fontFamily: FONTS.Medium,
                        }}>
                        {clientDetails?.otherDetails?.tax_no}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginTop: ms(10),
                        padding: ms(10),
                        //borderBottomWidth: ms(0.5),
                        //borderBottomColor: '#AAA',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          gap: ms(5),
                        }}>
                        <Text
                          style={{
                            fontSize: ms(12),
                            fontFamily: FONTS.Regular,
                            color: '#344054',
                          }}>
                          Payment Terms
                        </Text>
                      </View>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: '#344054',
                          fontFamily: FONTS.Medium,
                        }}>
                        {clientDetails?.otherDetails?.payment_term} Days
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={{
                        padding: ms(8),
                        borderWidth: ms(0.6),
                        //marginTop: ms(10),
                        borderRadius: ms(10),
                        borderColor: COLORS?.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                        //marginBottom:ms(5),
                        height: ms(45),
                        elevation: 3,
                        backgroundColor: COLORS.white,
                        shadowColor: COLORS.themeColor,
                        marginTop: ms(25),
                        //alignSelf:'center'
                      }}>
                      <View
                        style={{flexDirection: 'row', alignItems: 'center'}}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(15), width: ms(15)}}
                          source={ICONS.plusicn}
                        />
                        <Text
                          style={{
                            fontFamily: FONTS.Regular,
                            fontSize: ms(16),
                            color: COLORS.themeColor,
                            marginLeft: ms(5),
                          }}>
                          Add note
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </View>
            </View>
          ) : null}
        </View>
      </Animated.ScrollView>
      {option == 'Activity' ? (
        <TouchableOpacity
          style={{
            height: ms(50),
            width: ms(50),
            borderRadius: ms(25),
            backgroundColor: COLORS?.themeColor,
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(20),
            right: ms(20),
            zIndex: 10,
          }}
          onPress={() => {
            setToggleButtonFlag(!toggleButtonFlag);
          }}>
          {!toggleButtonFlag ? (
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[styles.iconStyle, {tintColor: COLORS?.white}]}
            />
          ) : (
            <Image
              source={ICONS?.addMore}
              //style={[styles.iconStyle, {height: ms(50), width: ms(50)}]}
              style={[styles.iconStyle, {tintColor: COLORS?.white,borderRadius:ms(10),transform: [{ rotate: '45deg' }]}]}
            />
          )}
        </TouchableOpacity>
      ) : null}
      {toggleButtonFlag ? (
        <View
          style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0, 0.5)',
            height: Dimensions?.get('window')?.height,
            width: Dimensions?.get('window')?.width,
            position: 'absolute',
          }}>
          <View
            style={{
              position: 'absolute',
              backgroundColor: COLORS?.white,
              width: ms(190),
              paddingVertical: ms(10),
              bottom: ms(80),
              right: ms(20),
              borderRadius: ms(8),
              paddingHorizontal: ms(4),
            }}>
            <TouchableOpacity
              onPress={() => navigate('AddCreditNote')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                // paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Credit Note
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddPurchaseOrder')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Purchase Order
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddEstimate')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Estimate
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddInvoice')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Invoice
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text style={{color: '#344054', opacity: 0.25}}>Statement</Text>
              <Image
                source={ICONS?.download}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                  opacity: 0.25,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
  conntainer: {
    height: ms(170),
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: COLORS.white,
    paddingVertical: mvs(20),
    borderTopLeftRadius: ms(15),
    borderTopRightRadius: ms(15),
  },
});
