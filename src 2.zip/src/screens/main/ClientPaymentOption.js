import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import DeviceInfo from 'react-native-device-info';
import { useSelector } from 'react-redux';
import Modal from 'react-native-modal';
export default function ClientPaymentOption() {
  const {commonList, loading} = useSelector(state => state.ProfileReducer);
  const [option, setOption] = useState('All');
  const [isEnabled, setIsEnabled] = useState(false);
  const [cashMode, setCashMode] = useState(false);
  const [allowTips, setAllowTips] = useState(false);
  const [remittance, setRemittance] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
   const [termsModal, setTermsModal] = useState(false);
   const [selectedTerms, setSelectedTerms] = useState('');
     const [selectedTermsShow, setSelectedTermsShow] = useState('');
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          // borderBottomWidth: ms(0.3),
          // backgroundColor: COLORS?.white,
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Client Payment Options'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <>
            {/* <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: COLORS?.themeColor,
                }}>
                Raise Invoice Money
              </Text>
            </View> */}
            {/* <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                gap: ms(10),
                justifyContent: 'space-between',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.card_payment}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(12),
                        color: '#344054',
                      }}>
                      Card Payment
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                    }}>
                    Powered by raiseinvoice.com
                  </Text>
                </View>
              </View>
              <Text
                style={{
                  marginLeft: ms(60),
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                  color: '#047FFF',
                }}>
                Setup
              </Text>
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                gap: ms(10),
                justifyContent: 'space-between',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.bank_transfer}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(12),
                        color: '#344054',
                      }}>
                      Bank Transfers
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                    }}>
                    Powered by raiseinvoice.com
                  </Text>
                </View>
              </View>
              <Text
                style={{
                  marginLeft: ms(60),
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                  color: '#047FFF',
                }}>
                Setup
              </Text>
            </View> */}
          </>
          <>
            <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
                //marginTop: ms(10),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Online Payment Methods
              </Text>
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                gap: ms(10),
                justifyContent: 'space-between',
                alignItems: 'center',
                // height: ms(45),
                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  gap: ms(10),
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.paypal}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(14),
                        color: '#344054',
                      }}>
                      Paypal
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </View>
              {/* <Text
                onPress={() => navigate('PaypalPayment')}
                style={{
                  marginLeft: ms(60),
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                  color: '#047FFF',
                }}>
                {' '}
                Setup
              </Text> */}
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                gap: ms(10),
                justifyContent: 'space-between',
                alignItems: 'center',
                // height: ms(45),
                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  gap: ms(10),
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.stripe}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      //tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(14),
                        color: '#344054',
                      }}>
                      Stripe
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </View>
              {/* <Text
                onPress={() => navigate('StripePayment')}
                style={{
                  marginLeft: ms(60),
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                  color: '#047FFF',
                }}>
                {' '}
                Setup
              </Text> */}
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                gap: ms(10),
                justifyContent: 'space-between',
                alignItems: 'center',
                // height: ms(45),
                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  gap: ms(10),
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.razorpay}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      //tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(14),
                        color: '#344054',
                      }}>
                      Razorpay
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </View>
              <TouchableOpacity onPress={() => navigate('RazorPay')}>
                {/* <Text
                  style={{
                    marginLeft: ms(60),
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color: '#047FFF',
                  }}>
                  {' '}
                  Setup
                </Text> */}
              </TouchableOpacity>
            </View>
          </>
          <>
            <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
                marginTop: ms(10),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Offline Payment Methods
              </Text>
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                // gap: ms(10),
                // justifyContent: 'space-between',
                alignItems: 'center',
                // height: ms(45),
                elevation: 2,
                paddingRight: ms(5),
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  gap: ms(10),
                  alignItems: 'center',
                  // backgroundColor: '#FF0',
                  width: '89%',
                }}>
                <View
                  style={{
                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                    padding: ms(10),
                    borderRadius: ms(3),
                  }}>
                  <Image
                    source={ICONS?.dollar}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      //tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
                <View style={{}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: ms(10),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(14),
                        color: '#344054',
                      }}>
                      Cash
                    </Text>
                    <Image
                      source={ICONS?.info}
                      style={{height: ms(10), width: ms(10)}}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </View>
              <TouchableOpacity onPress={() => setCashMode(!cashMode)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={cashMode ? ICONS.switch : ICONS.switchoff}
                />
              </TouchableOpacity>
            </View>
            <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
                marginTop: ms(10),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Tips
              </Text>
            </View>
            <View
              style={{
                paddingVertical: ms(10),
                paddingHorizontal: isTablet ? ms(10) : ms(10),
                borderWidth: ms(1),
                marginTop: ms(10),
                borderRadius: ms(6),
                borderColor: '#EDEDED',
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                gap: ms(0),
                // height: ms(45),
                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  width: '89%',
                  alignSelf: 'flex-start',
                  // backgroundColor: '#FF0',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(10),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: COLORS?.black,
                    }}>
                    Allow Tips
                  </Text>
                  <Image
                    source={ICONS?.info}
                    style={{height: ms(10), width: ms(10)}}
                    resizeMode="contain"
                  />
                </View>
                <Text style={{fontFamily: FONTS?.Light, fontSize: ms(10)}}>
                  Let customers add a tip when they pay online
                </Text>
              </View>
              {/* <Switch
                trackColor={{false: '#767577', true: '#81b0ff'}}
                thumbColor={isEnabled ? '#f4f3f4' : '#f4f3f4'}
                ios_backgroundColor="#3e3e3e"
                onValueChange={() => {
                  setIsEnabled(!isEnabled);
                }}
                value={isEnabled}
              /> */}
              <TouchableOpacity onPress={() => setAllowTips(!allowTips)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={allowTips ? ICONS.switch : ICONS.switchoff}
                />
              </TouchableOpacity>
            </View>
          </>
          <>
            <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
                marginTop: ms(10),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Invoice Due Date
              </Text>
            </View>

            <TouchableOpacity
              onPress={()=> setTermsModal(true)}
              style={{
                padding: ms(12),
                borderWidth: ms(0.6),
                borderColor: COLORS?.themeColor,
                borderRadius: ms(6),
                width: '100%',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: ms(10),
                height: ms(45),
                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <View
                style={{
                  position: 'absolute',
                  top: -ms(8),
                  left: ms(8),
                  backgroundColor: COLORS?.white,
                  paddingHorizontal: ms(2),
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(10),
                    color: '#344054',
                  }}>
                  Payment Terms
                </Text>
              </View>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(10),
                  color: 'rgba(52, 64, 84, 0.5)',
                }}>
                {selectedTermsShow}
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(8),
                  width: ms(8),
                  tintColor: COLORS?.themeColor,
                  transform: [{rotate: '180deg'}],
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </>
          <>
            <View
              style={{
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                padding: ms(10),
                borderRadius: ms(6),
                marginTop: ms(10),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Invoice Instructions
              </Text>
            </View>
            <View
              style={{
                // padding: ms(10),
                // borderWidth: ms(1),
                marginTop: ms(10),
                // borderRadius: ms(6),
                // borderColor: '#EDEDED',
                // backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                // gap: ms(10),
                paddingRight: isTablet ? ms(0) : ms(15),
              }}>
              <View style={{width: '89%', paddingLeft: ms(10)}}>
                <Text style={{fontFamily: FONTS?.Regular, fontSize: ms(14)}}>
                  Payment Instruction
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(10),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(14),
                      color: 'rgba(52, 64, 84, 1)',
                    }}>
                    Remittance Advice
                  </Text>
                  <Image
                    source={ICONS?.info}
                    style={{height: ms(10), width: ms(10)}}
                    resizeMode="contain"
                  />
                </View>
                <Text
                  style={{
                    fontFamily: FONTS?.Light,
                    fontSize: ms(10),
                    color: 'rgba(52, 64, 84, 1)',
                    marginTop: ms(5),
                  }}>
                  Show remittance advice at the bottom of invoices so clients
                  can attach payments
                </Text>
              </View>
              {/* <Switch
                trackColor={{false: '#767577', true: '#81b0ff'}}
                thumbColor={isEnabled ? '#f4f3f4' : '#f4f3f4'}
                ios_backgroundColor="#3e3e3e"
                onValueChange={() => {
                  setIsEnabled(!isEnabled);
                }}
                value={isEnabled}
              /> */}
              <TouchableOpacity onPress={() => setRemittance(!remittance)}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(40)}}
                  source={remittance ? ICONS.switch : ICONS.switchoff}
                />
              </TouchableOpacity>
            </View>
          </>
        </View>
      </ScrollView>
      <Modal
              isVisible={termsModal}
              backdropOpacity={0.6}
              animationIn={'slideInUp'}
              animationOut={'slideOutDown'}
              animationInTiming={800}
              animationOutTiming={500}
              backdropTransitionOutTiming={0}
              hasBackdrop={true}
              onBackdropPress={() => {
                setTermsModal(false);
              }}
              style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
              <View
                style={{
                  // maxHeight: Dimensions.get('window').height,
                  width: '100%',
                  height: Dimensions.get('window').height * 0.6,
                  paddingTop: normalize(10),
                  paddingHorizontal: normalize(30),
                  backgroundColor: '#FFF',
                  borderTopLeftRadius: normalize(20),
                  borderTopRightRadius: normalize(20),
                  padding: normalize(40),
                }}>
                <View
                  style={{
                    width: ms(63),
                    height: ms(6),
                    borderRadius: ms(8),
                    backgroundColor: 'rgba(217, 217, 217, 1)',
                    alignSelf: 'center',
                    marginBottom: ms(20),
                    marginTop: ms(10),
                  }}
                />
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{
                      fontSize: normalize(18),
                      fontFamily: FONTS.Medium,
                      paddingVertical: normalize(20),
                      //paddingHorizontal: normalize(20),
                    }}>
                    Payment Terms
                  </Text>
                  <TouchableOpacity
                    onPress={() => setTermsModal(false)}
                    style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text
                      style={{
                        fontSize: normalize(16),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                      }}>
                      Apply
                    </Text>
                    <Image
                      resizeMode="contain"
                      style={{
                        height: normalize(17),
                        width: normalize(17),
                        marginLeft: normalize(5),
                      }}
                      source={ICONS.bluetick}
                    />
                  </TouchableOpacity>
                </View>
      
                <FlatList
                  data={commonList?.paymentTerms}
                  //style={{maxHeight: Dimensions.get('window').height / 3}}
                  showsVerticalScrollIndicator={false}
                  ListEmptyComponent={
                    <View style={{alignItems: 'center'}}>
                      <Text style={{color: COLORS?.orange}}>No data found.</Text>
                    </View>
                  }
                  renderItem={({item, index}) => {
                    console.log('www', item);
                    let selected = item.value == selectedTerms;
                    return (
                      <TouchableOpacity
                        style={{
                          borderBottomWidth: normalize(0),
                          borderBottomColor: COLORS.dark_grey,
                          padding: normalize(10),
                          //backgroundColor: '#EBF4F6',
                          marginTop: normalize(5),
                          borderRadius: normalize(5),
                          flexDirection: 'row',
                          alignItems: 'center',
                        }}
                        onPress={() => {
                          console.log('itemaaa', item);
                          // setSelectedTerms(item?.value);
                          setSelectedTerms(item?.value);
                          setSelectedTermsShow(item?.title);
                    
                        
                        }}>
                        <View
                          style={{
                            height: normalize(22),
                            width: normalize(22),
                            borderWidth: 1,
                            borderRadius: normalize(11),
                            borderColor: COLORS.themeColor,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}>
                          {selected ? (
                            <View
                              style={{
                                height: normalize(15),
                                width: normalize(15),
                                borderRadius: normalize(7.5),
                                backgroundColor: COLORS.themeColor,
                              }}
                            />
                          ) : null}
                        </View>
                        <Text
                          style={{
                            color: '#000',
                            fontFamily: FONTS.Fredoka_Regular,
                            textTransform: 'capitalize',
                            marginLeft: normalize(10),
                          }}>
                          {item?.title}
                        </Text>
                      </TouchableOpacity>
                    );
                  }}
                />
                <TouchableOpacity
                  style={{
                    padding: ms(10),
                    borderWidth: ms(0.6),
                    marginTop: ms(15),
                    borderRadius: ms(10),
                    borderColor: COLORS?.themeColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View
                      style={{
                        height: ms(25),
                        width: ms(25),
                        borderRadius: ms(5),
                        backgroundColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(15),
                          fontWeight: '800',
                          color: COLORS.white,
                        }}>
                        +
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(16),
                        color: COLORS.themeColor,
                        marginLeft: ms(5),
                      }}>
                      Add custom terms
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
