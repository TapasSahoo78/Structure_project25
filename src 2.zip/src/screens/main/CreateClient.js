import React, { useEffect, useState,useRef } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
  PermissionsAndroid,
  Platform,
  Alert,
  Linking,
  AppState,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { goBack } from '../../utils/helpers/RootNaivgation';
import Toast from '../../utils/helpers/Toast';
import constants from '../../utils/helpers/constants';
import { addClientRequest } from '../../redux/reducer/ProfileReducer';
import { useDispatch, useSelector } from 'react-redux';
import Contacts from 'react-native-contacts';
import Modal from 'react-native-modal';
import normalize from '../../utils/helpers/normalize';
import CameraDropDown from '../../components/CameraDropDown';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo from 'react-native-device-info';
import AsyncStorage from '@react-native-async-storage/async-storage';
const SEARCH_HISTORY_KEY = 'searchHistory';
//const appState = useRef(AppState.currentState);
import { phonePre } from '../../utils/helpers/GlobalJson';
export default function CreateClient() {
  const dispatch = useDispatch();
  const { commonList, loading } = useSelector(state => state.ProfileReducer);
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [billAddress, setBillAddress] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [website, setWebsite] = useState('');
  const [taxNo, setTaxNo] = useState('');
  const [note, setNote] = useState('');
  const [contactModal, setContactModal] = useState(false);
  const [myContacts, setMyContacts] = useState([]);
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [filteredDialcode,setFilterdDialCode] = useState(phonePre)
  const [selctedContact, setSelectedContact] = useState('');
  const [termsModal, setTermsModal] = useState(false);
  const [selectedTerms, setSelectedTerms] = useState('');
  const [selectedTermsShow, setSelectedTermsShow] = useState('');
  const [addAlternate, setAddAlternate] = useState(false);
  const [alternateEmail, setAlternateEmail] = useState('');
  const [cameraModal, setCameraModal] = useState(false);
  const [imageObject, setImageObject] = useState('');
  const [billContent, setBillContent] = useState(true);
  const [itemContent, setItemContent] = useState(true);
  const [moreContent, setMoreContent] = useState(true);
  const [searchHistory, setSearchHistory] = useState([]);
  const [openAddressModal, setOpenAddressModal] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [contactDisabled,setContactDisabled] = useState(false)
  const [dialCode,setDialCode] = useState("+91")
  const [dialCodeModal,setDialCodeModal] = useState(false)
  const [selectedDial,setSelecteddial] = useState("")
  const [contactDialCode,setContactDialCode] = useState("+91")
  const [dialStatus,setDialStatus] = useState(false)
  
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  // useEffect(() => {
  //   if (Platform.OS == "android") {
  //     PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
  //       title: 'Contacts',
  //       message: 'This app would like to view your contacts.',
  //       buttonPositive: 'Please accept bare mortal',
  //     })
  //       .then(res => {
  //         console.log('Permission: ', res);
  //         Contacts.getAll()
  //           .then(contacts => {

  //             setMyContacts(contacts);
  //             setFilteredContacts(contacts);
  //           })
  //           .catch(e => {
  //             console.log(e);
  //           });
  //       })
  //       .catch(error => {
  //         console.error('Permission error: ', error);
  //       });

  //   }

  // }, []);
useEffect(() => {
    const loadContacts = async () => {
      if (Platform.OS === 'android') {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
            {
              title: 'Contacts',
              message: 'This app would like to view your contacts.',
              buttonPositive: 'Please accept',
            }
          );

          // ✅ Only proceed if permission is granted
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            const contacts = await Contacts.getAll();
            //setContactDisabled(false)
            setMyContacts(contacts);
            setFilteredContacts(contacts);
          } else {
            console.log('Contacts permission denied');
            // Optionally: show a message to the user
            // e.g., Alert.alert('Permission needed', 'Contact access is required...');
             Alert.alert(
            'Permission Required',
            'Contact access is required to use this feature. Please enable it in Settings.',
            [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Open Settings',
                onPress: () => {
                  //setContactDisabled(true)
                  Linking.openSettings()
                },
              },
            ]
          );
          }
        } catch (error) {
          console.error('Error requesting contact permission:', error);
        }
      } else {
        // For iOS — you'll need a different approach (see note below)
        try {
          const contacts = await Contacts.getAll();
          setMyContacts(contacts);
          setFilteredContacts(contacts);
        } catch (error) {
          console.error('iOS Contacts error:', error);
        }
      }
    };

    loadContacts();
   
  }, []);
  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await AsyncStorage.getItem(SEARCH_HISTORY_KEY);
      if (history) {
        console.log("my search history", history)
        setSearchHistory(JSON.parse(history));
      }
    } catch (error) {
      console.error('Error loading search history:', error);
    }
  };

  const saveSearchHistory = async (newPlace) => {
    try {
      let updatedHistory = [newPlace, ...searchHistory.filter(item => item.description !== newPlace.description)];
      updatedHistory = updatedHistory.slice(0, 3); // Keep only the latest 3
      setSearchHistory(updatedHistory);
      console.log("updated places", JSON.stringify(newPlace))
      await AsyncStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Error saving search history:', error);
    }
  };

  const checkValidation = () => {
    if (projectName == '') {
      Toast('Enter billing name');
    } else if (phoneNumber == '') {
      Toast('Enter phone');
    } else if (email == '') {
      Toast('Enter Email');
    } else if (!constants.EMAIL_REGEX.test(email)) {
      Toast('Enter valid email');
    } else if (billAddress == '') {
      Toast('Enter billing address');
    } else if (contactName == '') {
      Toast('Enter contact name');
    } else if (contactPhone == '') {
      Toast('Enter contact phone');
    } else if (website == '') {
      Toast('Enter website');
    } else if (taxNo == '') {
      Toast('Enter tax number');
    } else if (note == '') {
      Toast('Enter note');
    } else {
      let payload = {
        name: projectName,
        email: email,
        dialCode: 91,
        phone: phoneNumber,
        contact_name: contactName,
        contactdialCode: 91,
        contactPhone: contactPhone,
        contactWebsite: website,
        tax_no: taxNo,
        notes: note,
        payment_term: selectedTerms,
        profileImage: imageObject,
      };
      const formData = new FormData();
      formData.append('name', projectName);
      formData.append('email', email);
      formData.append('dialCode', 91);
      formData.append('phone', phoneNumber);
      formData.append('contact_name', contactName);
      formData.append('contactdialCode', 91);
      formData.append('contactPhone', contactPhone);
      formData.append('contactWebsite', website);
      formData.append('tax_no', taxNo);
      formData.append('notes', note);
      formData.append('payment_term', selectedTerms);
      formData.append('address', billAddress);
      formData.append('profileImage', imageObject);
      dispatch(addClientRequest(formData));
    }
  };
  const handleSearch = text => {
    setSelectedContact(text);
    const filteredData = myContacts.filter(contact => {
      return contact.displayName.toLowerCase().includes(text.toLowerCase());
    });
    setFilteredContacts(filteredData);
  };

  const handleDialSearch = text =>{
    setSelecteddial(text)
    const filteredDialcode = phonePre.filter(contact => {
      return contact.name.toLowerCase().includes(text.toLowerCase());
    });
    setFilterdDialCode(filteredDialcode);
  }
  const formatPhoneNumber = number => {
    // Check if the number starts with +91
    if (number.startsWith('+91')) {
      // Remove the +91 prefix
      return number.slice(3); // Remove the first 3 characters
    }
    return number; // Return the original number if it doesn't start with +91
  };

  const saveItem = item => {
    setProjectName(item?.displayName);
    const formattedNumber = formatPhoneNumber(item?.phoneNumbers[0].number.trim().replace(/\s/g, ""));
    //alert(formattedNumber)

    setPhoneNumber(formattedNumber);
    setContactModal(false);
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add Client'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={()=> checkValidation()}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        {' '}
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(50),
            alignItems: 'center',
          }}>
          <TouchableOpacity
            onPress={() => setBillContent(!billContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: '#047FFF',
              }}>
              Billing Details
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(12),
                transform: [{ rotate: billContent ? '0deg' : '180deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {billContent ? (
            <View>
              <TouchableOpacity
                onPress={() => {
                  if(myContacts.length > 0){
                    setContactModal(true)
                  }
                  
                }}
                
                style={{
                  borderWidth: ms(1.2),
                  marginTop: ms(20),
                  padding: ms(10),
                  borderColor: COLORS?.themeColor,
                  borderRadius: ms(9),
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  height: ms(45),
                  justifyContent: 'center',
                  alignSelf: 'center',
                }}>
                <Text
                  style={{
                    textAlign: 'center',
                    color: '#047FFF',
                    fontFamily: FONTS?.Regular,
                  }}>
                  Choose From Contacts
                </Text>
              </TouchableOpacity>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  alignSelf: 'center',
                  marginTop: ms(15),
                  marginBottom: ms(0),
                }}>
                <View
                  style={{
                    height: ms(2),
                    width: ms(32),
                    backgroundColor: '#047FFF40',
                  }}
                />
                <Text
                  style={{
                    marginHorizontal: ms(8),
                    fontFamily: FONTS.Regular,
                    fontSize: ms(12),
                    color: '#344054',
                  }}>
                  or
                </Text>
                <View
                  style={{
                    height: ms(2),
                    width: ms(32),
                    backgroundColor: '#047FFF40',
                  }}
                />
              </View>

              <AnimatedTextInput
                label={'Billing Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={projectName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setProjectName(item);
                }}
              />
              <View
                //elevation={3}
                style={{
                  paddingLeft: ms(15),
                  borderWidth: ms(0.5),
                  marginTop: ms(18),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  //borderWidth:ms(0.7),
                  flexDirection: 'row',
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  alignItems: 'center',
                  gap: ms(3),
                  height: ms(45),
                  elevation: 2,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                }}>
                  <TouchableOpacity onPress={()=> {
                    setDialCodeModal(true)
                    setDialStatus(true)
                    }} style={{flexDirection:'row',alignItems:'center'}}>
                <Text  style={{ fontSize: ms(14), color: '#344054' }}>{dialCode}</Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(10),
                    width: ms(10),
                    transform: [{ rotate: '180deg' }],
                    tintColor: COLORS?.themeColor,
                    marginHorizontal: ms(5),
                  }}
                  resizeMode="contain"
                />
                </TouchableOpacity>
                <View
                  style={{
                    height: '60%',
                    width: ms(0.4),
                    backgroundColor: COLORS?.placeholderColor,

                    marginLeft: ms(4),
                  }}
                />
                <TextInput
                  placeholder="Phone No."
                  placeholderTextColor={COLORS.placeholderColor}
                  autoComplete="off"
                  selectTextOnFocus={false}
                  style={{
                    fontSize: ms(13),
                    paddingLeft: ms(10),
                    color: COLORS.dark_grey,
                    //borderRadius: ms(10),
                    //backgroundColor: COLORS.white,
                    //minHeight: ms(45),
                    //borderWidth: ms(0.6),
                    width: '83%',
                    height: ms(45),
                    //borderColor: COLORS?.white,
                  }}
                  value={phoneNumber}
                  keyboardType='numeric'
                  maxLength={10}
                  onChangeText={item => {
                    setPhoneNumber(item);
                  }}
                />
              </View>
              <AnimatedTextInput
                label={'Email'}
                keyboardType={'email-address'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={email}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setEmail(item);
                }}
              />
              <TouchableOpacity
                onPress={() => setAddAlternate(true)}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                  marginTop: ms(20),
                  //marginBottom: -ms(5),
                  paddingLeft: ms(10),
                }}>
                <Image
                  source={ICONS?.addMore}
                  style={{
                    height: ms(16),
                    width: ms(16),
                    tintColor: '#44BBFE',
                  }}
                />
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(15),
                    color: '#44BBFE',
                    // marginTop: ms(10),
                  }}>
                  Add alternate email id
                </Text>
              </TouchableOpacity>
              {addAlternate ? (
                <AnimatedTextInput
                  label={'Alternate Email'}
                  keyboardType={'email-address'}
                  width={
                    isTablet
                      ? Dimensions.get('window').width - 70
                      : Dimensions.get('window').width - 50
                  }
                  value={alternateEmail}
                  borderColor={COLORS?.themeColor}
                  onChangeText={item => {
                    setAlternateEmail(item);
                  }}
                />
              ) : null}
              <AnimatedTextInput
                label={'Billing Address'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={billAddress}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setBillAddress(item);
                }}
              />
              <TouchableOpacity
                onPress={() => setOpenAddressModal(true)}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                  marginTop: ms(15),
                  //marginBottom: -ms(5),
                  paddingLeft: ms(10),
                }}>
                <Image
                  source={ICONS?.location_pin}
                  style={{
                    height: ms(18),
                    width: ms(15.43),
                    tintColor: '#44BBFE',
                  }}
                  resizeMode="contain"
                />
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(15),
                    color: '#44BBFE',
                    marginVertical: ms(10),
                  }}>
                  Or select address on map
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  if (imageObject.name) {
                    setImageObject("")
                  } else {
                    setCameraModal(true)

                  }
                }}

                style={{
                  paddingHorizontal: ms(15),
                  borderWidth: ms(0.5),
                  marginTop: ms(10),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: ms(5),
                  height: ms(45),
                  elevation: 2,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  shadowOpacity: 0.2,
                  shadowRadius: 3.84,
                }}>
                <Text
                  //onPress={() => setCameraModal(true)}

                  style={{
                    fontSize: imageObject.name ? ms(10) : ms(14),
                    fontFamily: FONTS.Regular,
                    color: COLORS.placeholderColor,
                  }}>
                  {imageObject.name ? imageObject.name.slice(0, -20) : " Logo (if any)"}

                </Text>
                <View >
                  <Image
                    source={imageObject.name ? ICONS.crossbtn : ICONS?.upload}
                    style={{
                      height: ms(17),
                      width: ms(14),
                      // transform: [{rotate: '180deg'}],
                      tintColor: imageObject.name ? null : '#047FFF80',
                    }}
                    resizeMode="contain"
                  />
                </View>
              </TouchableOpacity>
              {/* {imageObject.name ?<Text style={{fontSize:ms(10),width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,color:COLORS.themeColor,fontFamily:FONTS.Regular}}>{imageObject.name.slice(10)}</Text>:null} */}
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => setItemContent(!itemContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(15),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: '#047FFF',
              }}>
              Contact Details
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(12),
                transform: [{ rotate: itemContent ? '0deg' : '180deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {itemContent ? (
            <View style={{}}>
              <AnimatedTextInput
                label={'Contact Name'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={contactName}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setContactName(item);
                }}
              />
              <View
                style={{
                  paddingLeft: ms(15),
                  borderWidth: ms(0.5),
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  alignItems: 'center',
                  gap: ms(5),
                  height: ms(45),
                  elevation: 2,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                  marginBottom: ms(-5),
                }}>
                  <TouchableOpacity onPress={()=> setDialCodeModal(true)} style={{flexDirection:'row',alignItems:'center'}}>
                <Text
                  style={{
                    fontSize: ms(14),
                    color: '#344054',
                    fontFamily: FONTS.Regular,
                  }}>
                  {contactDialCode}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(10),
                    width: ms(10),
                    transform: [{ rotate: '180deg' }],
                    tintColor: COLORS?.themeColor,
                    marginHorizontal: ms(5),
                  }}
                  resizeMode="contain"
                />
                </TouchableOpacity>
                <View
                  style={{
                    height: '60%',
                    width: ms(0.4),
                    backgroundColor: COLORS?.placeholderColor,

                    marginLeft: ms(4),
                  }}
                />
                <TextInput
                  placeholder="Phone No."
                  keyboardType='numeric'
                  placeholderTextColor={COLORS.placeholderColor}
                  autoComplete="off"
                  selectTextOnFocus={false}
                  style={{
                    fontSize: ms(13),
                    paddingLeft: ms(10),
                    color: COLORS.dark_grey,
                    borderRadius: ms(10),
                    //backgroundColor: COLORS.white,
                    //minHeight: ms(52),
                    minimumHeight: ms(45),
                    //borderWidth: ms(0.8),
                    width: '83%',
                    //borderColor: COLORS?.themeColor,
                  }}
                  value={contactPhone}
                  maxLength={10}
                  onChangeText={item => {
                    setContactPhone(item);
                  }}
                />
              </View>
              <AnimatedTextInput
                label={'Website'}
                keyboardType={'email-address'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={website}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setWebsite(item);
                }}
              />
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => setMoreContent(!moreContent)}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(15),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: '#047FFF',
              }}>
              Other Details
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(12),
                transform: [{ rotate: moreContent ? '0deg' : '180deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {moreContent ? (
            <View>
              <TouchableOpacity
                onPress={() => setTermsModal(true)}
                style={{
                  paddingHorizontal: ms(15),
                  borderWidth: ms(0.5),
                  marginTop: ms(15),
                  borderRadius: ms(10),
                  borderColor: COLORS?.themeColor,
                  flexDirection: 'row',
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: ms(5),
                  height: ms(45),
                  elevation: 2,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                }}>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Regular,
                    color:
                      selectedTermsShow == ''
                        ? COLORS.placeholderColor
                        : COLORS.dark_grey,
                  }}>
                  {selectedTermsShow == ''
                    ? 'Payment Terms'
                    : selectedTermsShow}
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(12),
                    transform: [{ rotate: '180deg' }],
                    tintColor: COLORS?.themeColor,
                  }}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <AnimatedTextInput
                label={'Tax No'}
                keyboardType={'email-address'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={taxNo}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setTaxNo(item);
                }}
              />
              <AnimatedTextInput
                label={'Notes'}
                keyboardType={'default'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={note}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(82)}
                textAlign={''}
                multiline={true}
                numberOfLines={10}
                onChangeText={item => {
                  setNote(item);
                }}
              />
            </View>
          ) : null}
        </View>
        <TouchableOpacity
          style={{
            paddingHorizontal: ms(20),
            paddingVertical: ms(8),
            backgroundColor: COLORS?.themeColor,
            // position: 'absolute',
            // bottom: ms(10),
            alignSelf: 'center',
            width: ms(150),
            borderRadius: ms(20),
            marginBottom: ms(20),
          }}
          onPress={() => {
            checkValidation();
          }}>
          <Text
            style={{
              color: COLORS?.white,
              textAlign: 'center',
              fontFamily: FONTS?.Medium,
              fontSize: ms(15),
            }}>
            Save
          </Text>
        </TouchableOpacity>
      </ScrollView>
      {/* <View style={{backgroundColor:COLORS.white,width:'100%',marginTop:ms(10),paddingBottom:ms(30)}}>
      
      </View> */}
      <Modal
        isVisible={contactModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setContactModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.6,
            width: '100%',
            // height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(28),
            borderTopRightRadius: normalize(28),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setContactModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingRight: ms(10),
              marginTop: ms(10),
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(10),
                //paddingHorizontal: normalize(20),
                color: '#344054',
              }}>
              Choose Client
            </Text>
            {/* <TouchableOpacity
              onPress={() => {
                if (projectName == '' || phoneNumber == '') {
                  Toast('Select contact');
                } else {
                  setContactModal(false);
                }
              }}
              style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Regular,
                  color: COLORS.themeColor,
                }}>
                Add
              </Text>
              <Image
                resizeMode="contain"
                style={{
                  height: ms(15),
                  width: ms(15),
                  marginLeft: ms(5),
                  tintColor: COLORS.themeColor,
                }}
                source={ICONS.plusicn}
              />
            </TouchableOpacity> */}
          </View>
          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
                fontSize: ms(12),
                fontFamily: FONTS?.Regular,
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={selctedContact}
              onChangeText={text => handleSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{ height: normalize(14), width: normalize(14) }}
              source={ICONS.search}
            />
          </View>
          <FlatList
            data={filteredContacts}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              console.log('www', item);
              let selected = item?.displayName == projectName;
              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0.6),
                    borderBottomColor: COLORS.border,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    if (item.phoneNumbers[0]) {
                      console.log('itemaaa', item);
                      saveItem(item);
                    }

                    //selectCountryy(item);
                    //setContactModal(false);

                    //setSelectCountryCategory(item?.name);
                  }}>
                  <View>
                    <View
                      style={{
                        height: ms(36),
                        width: ms(36),
                        borderRadius: ms(18),
                        backgroundColor: '#D9D9D9',
                      }}
                    />
                  </View>
                  <View style={{ marginLeft: ms(10) }}>
                    <Text
                      style={{
                        color: selected ? '#344054' : '#000',
                        fontFamily: FONTS.Medium,
                        textTransform: 'capitalize',
                        fontSize: ms(14),
                      }}>
                      {item?.displayName}
                    </Text>
                    <Text
                      style={{
                        color: selected ? COLORS.themeColor : '#000',
                        fontFamily: FONTS.Fredoka_Regular,
                        textTransform: 'capitalize',
                      }}>
                      {item?.phoneNumbers.length > 0
                        ? item?.phoneNumbers[0].number
                        : null}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <Modal
        isVisible={termsModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setTermsModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            // maxHeight: Dimensions.get('window').height,
            width: '100%',
            height: Dimensions.get('window').height * 0.6,
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Payment Terms
            </Text>
            <TouchableOpacity
              onPress={() => setTermsModal(false)}
              style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  fontSize: normalize(16),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Apply
              </Text>
              <Image
                resizeMode="contain"
                style={{
                  height: normalize(17),
                  width: normalize(17),
                  marginLeft: normalize(5),
                }}
                source={ICONS.bluetick}
              />
            </TouchableOpacity>
          </View>

          <FlatList
            data={commonList?.paymentTerms}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              console.log('www', item);
              let selected = item.value == selectedTerms;
              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0),
                    borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    console.log('itemaaa', item);
                    setSelectedTerms(item?.value);
                    setSelectedTermsShow(item?.title);

                    setContactModal(false);

                    //setSelectCountryCategory(item?.name);
                  }}>
                  <View
                    style={{
                      height: normalize(22),
                      width: normalize(22),
                      borderWidth: 1,
                      borderRadius: normalize(11),
                      borderColor: COLORS.themeColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    {selected ? (
                      <View
                        style={{
                          height: normalize(15),
                          width: normalize(15),
                          borderRadius: normalize(7.5),
                          backgroundColor: COLORS.themeColor,
                        }}
                      />
                    ) : null}
                  </View>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS.Fredoka_Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                    }}>
                    {item?.title}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.6),
              marginTop: ms(15),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View
                style={{
                  height: ms(25),
                  width: ms(25),
                  borderRadius: ms(5),
                  backgroundColor: COLORS.themeColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: ms(15),
                    fontWeight: '800',
                    color: COLORS.white,
                  }}>
                  +
                </Text>
              </View>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(16),
                  color: COLORS.themeColor,
                  marginLeft: ms(5),
                }}>
                Add custom terms
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </Modal>
      

      <Modal
        animationIn={'fadeInUp'}
        animationOut={'fadeOutDown'}
        isVisible={openAddressModal}
        backdropTransitionOutTiming={0}
        onBackButtonPress={() => setOpenAddressModal(false)}
        onBackdropPress={() => setOpenAddressModal(false)}
        avoidKeyboard={false}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View style={styless.centeredView}>
          <View style={styless.modalView}>

            <View
              style={{
                width: ms(63),
                height: ms(6),
                borderRadius: ms(8),
                backgroundColor: 'rgba(217, 217, 217, 1)',
                alignSelf: 'center',
                marginBottom: ms(20),
              }}
            />
            <TouchableOpacity
              style={{ position: 'absolute', right: 10 }}
              onPress={() => {
                setOpenAddressModal(false);
                // setWorkAddressType(1);
              }}>
              <Image
                source={ICONS?.crossbtn}
                style={{ height: normalize(20), width: normalize(20) }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <View
              style={{
                height: Dimensions?.get('window')?.height * 0.6,
                width: '100%',
                alignSelf: 'center',
              }}>
              <Text
                style={{
                  paddingBottom: ms(10),
                  color: COLORS?.blue,
                  height: ms(12),
                }}>
                Enter Address
              </Text>
              <GooglePlacesAutocomplete
                GooglePlacesDetailsQuery={{ fields: 'geometry' }}
                placeholder={'Enter Address'}
                minLength={3}
                fetchDetails={true}
                returnKeyType={'default'}
                listViewDisplayed="auto"
                enablePoweredByContainer={false}
                listEmptyComponent={() => (
                  <View style={{ flex: 1 }}>
                    <Text>No results were found</Text>
                  </View>
                )}
                textInputProps={{
                  autoFocus: true,
                  blurOnSubmit: false,
                }}
                // keyboardShouldPersistTaps="never"
                styles={{
                  textInput: {
                    height: 58,
                    color: '#000',
                    fontSize: 16,
                    borderWidth: 1,
                    borderColor: '#2144C1',
                    borderRadius: 10,
                  },
                  predefinedPlacesDescription: {
                    color: '#1faadb',
                  },
                }}
                onPress={(data, details) => {
                  console.log(data);
                  console.log('llll', details?.geometry?.location);
                  //setFrom({...data, ...details?.geometry?.location});
                  setBillAddress(data.description);
                  saveSearchHistory({ description: data.description, place_id: details.place_id });
                  setOpenAddressModal(false);
                }}
                predefinedPlaces={searchHistory}
                onFail={error => console.error(error)}
                query={{
                  key: constants?.GOOGLE_API_KEY,
                  language: 'en',
                  // components: 'country:ind',
                }}
              />
            </View>

            {/* <Container bg={"#2144C1"} radius={10} pv={10} align="center" width={'70%'}>
                            <CText color={'#fff'}> Submit </CText>
                        </Container> */}
          </View>
        </View>
      </Modal>
      <Modal
        isVisible={dialCodeModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setDialCodeModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.6,
            width: '100%',
            // height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(28),
            borderTopRightRadius: normalize(28),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setDialCodeModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingRight: ms(10),
              marginTop: ms(10),
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(10),
                //paddingHorizontal: normalize(20),
                color: '#344054',
              }}>
              Choose Dialcode
            </Text>
            
          </View>
          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
                fontSize: ms(12),
                fontFamily: FONTS?.Regular,
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={selectedDial}
              onChangeText={text => handleDialSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{ height: normalize(14), width: normalize(14) }}
              source={ICONS.search}
            />
          </View>
          <FlatList
            data={filteredDialcode}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>No data found.</Text>
              </View>
            }
            renderItem={({ item, index }) => {
              console.log('www', item);
              //let selected = item?.displayName == projectName;
              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0.6),
                    borderBottomColor: COLORS.border,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    if(dialStatus){
                      setDialCode(item?.code)
                    }else{
                      setContactDialCode(item?.code)
                    }
                    setDialStatus(false)
                    setDialCodeModal(false)

                    
                  }}>
                  <View>
                    <View
                      style={{
                        height: ms(36),
                        width: ms(36),
                        borderRadius: ms(18),
                        backgroundColor: '#D9D9D9',
                      }}
                    />
                  </View>
                  <View style={{ marginLeft: ms(10) }}>
                    <Text
                      style={{
                        color: '#000',
                        fontFamily: FONTS.Medium,
                        textTransform: 'capitalize',
                        fontSize: ms(14),
                      }}>
                      {item?.name}
                    </Text>
                    <Text
                      style={{
                        color:  '#000',
                        fontFamily: FONTS.Fredoka_Regular,
                        textTransform: 'capitalize',
                      }}>
                      {item?.code}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <CameraDropDown
        visible={cameraModal}
        onBackdropPress={() => {
          setCameraModal(false);
        }}
        onPressCamera={item => {
          console.log('images: ', item);
          setImageObject(item);
        }}
        onPressGallery={item => {
          console.log('images: ', item);
          setImageObject(item);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});

const styless = StyleSheet.create({
  centeredView: {
    maxHeight:
      Platform.OS == 'ios'
        ? Dimensions?.get('window')?.height / 2.2
        : Dimensions?.get('window')?.height / 2,
    width: '100%',
    paddingTop: 10,
    // paddingHorizontal: 30,
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopEndRadius: 20,
  },
  modalView: {
    paddingHorizontal: 20,
    paddingTop: 20,
    // margin: 20,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    //   textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    //   textAlign: "center"
  },
});
