import React, { useCallback, useEffect, useState } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { goBack } from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import Contacts from 'react-native-contacts';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import constants from '../../utils/helpers/constants';
import { useFocusEffect } from '@react-navigation/native';
import {
  getClientRequest,
  projectCreateRequest,
} from '../../redux/reducer/ProfileReducer';
import { useDispatch, useSelector } from 'react-redux';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo, { isTablet } from 'react-native-device-info';
import Toast from '../../utils/helpers/Toast';
import normalize from '../../utils/helpers/normalize';
import AsyncStorage from '@react-native-async-storage/async-storage';
const SEARCH_HISTORY_KEY = 'searchHistory';

export default function CreateProject() {
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [contactModal, setContactModal] = useState(false);
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selctedContact, setSelectedContact] = useState('');
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [filteredClient, setFilteredClient] = useState([]);
  const [client, setClient] = useState('');
  const [myContacts, setMyContacts] = useState([]);
  const [openAddressModal, setOpenAddressModal] = useState(false);
  const [from, setFrom] = useState('');
  const [isTablet, setIsTablet] = useState(false);
  const [isButtonPressed, setIsButtonPressed] = useState(false);
  const [searchHistory, setSearchHistory] = useState([]);
  const { clientList, loading } = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();

  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await AsyncStorage.getItem(SEARCH_HISTORY_KEY);
      if (history) {
        console.log("my search history", history)
        setSearchHistory(JSON.parse(history));
      }
    } catch (error) {
      console.error('Error loading search history:', error);
    }
  };

  const saveSearchHistory = async (newPlace) => {
    try {
      let updatedHistory = [newPlace, ...searchHistory.filter(item => item.description !== newPlace.description)];
      updatedHistory = updatedHistory.slice(0, 3); // Keep only the latest 3
      setSearchHistory(updatedHistory);
      console.log("updated places", JSON.stringify(newPlace))
      await AsyncStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Error saving search history:', error);
    }
  };
  useEffect(() => {
    // if (clientList) {
    //   setFilteredClient(clientList);
    // }

    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  function isEmpty(item) {
    if (item == null || item == '' || item == undefined) return true;
    return false;
  }

  useEffect(() => {
    setFilteredClient(clientList);
  }, [clientList]);
  useEffect(() => {
    if (Platform.OS == 'android') {
      PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
        title: 'Contacts',
        message: 'This app would like to view your contacts.',
        buttonPositive: 'Please accept bare mortal',
      })
        .then(res => {
          console.log('Permission: ', res);
          Contacts.getAll()
            .then(contacts => {
              // work with contacts
              //console.log('my device contacts...', JSON.stringify(contacts));
              setMyContacts(contacts);
              setFilteredContacts(contacts);
            })
            .catch(e => {
              console.log(e);
            });
        })
        .catch(error => {
          console.error('Permission error: ', error);
        });
    }

  }, []);
  const saveItem = item => {
    setClient(item);
    setContactModal(false);
  };
  const formatPhoneNumber = number => {
    // Check if the number starts with +91
    if (number.startsWith('+91')) {
      // Remove the +91 prefix
      return number.slice(3); // Remove the first 3 characters
    }
    return number; // Return the original number if it doesn't start with +91
  };
  const handleSearch = text => {
    setSelectedContact(text);
    const filteredData = clientList.filter(contact => {
      return contact?.name?.toLowerCase()?.includes(text.toLowerCase());
    });
    if (filteredData.length > 0) {
      setFilteredClient(filteredData);
    } else {
      setFilteredClient([]);
    }
  };
  useFocusEffect(
    useCallback(() => {
      let payload = {};
      dispatch(getClientRequest(payload));
    }, []),
  );

  const checkValidation =async()=>{
    if (client == '') {
                Toast('Select client');
              } else if (projectName == '') {
                Toast('Enter project name');
              } else if (from == '') {
                Toast('Select project location');
              } else {
                try {
                  await dispatch(
                    projectCreateRequest({
                      client_id: client?.id,
                      project_name: projectName,
                      project_location: from?.description,
                      latitude: from?.lat,
                      longitude: from?.lng,
                      project_desc: '',
                      start_date: null,
                      end_date: null,
                      status: '1',
                    }),
                  );
                } catch (error) {
                  // Optionally handle error
                } finally {
                  //setIsButtonPressed(false); // Re-enable button after request finishes
                }

              }
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      {/* <TouchableOpacity
        onPress={() => setOpenAddressModal(false)}
        style={{position: 'absolute', top: 20, right: 20}}>
        <Image
          resizeMode="contain"
          style={{height: ms(20), width: ms(20)}}
          source={ICONS.crossbtn}
        />
      </TouchableOpacity>{' '} */}
      <Modal
        isVisible={contactModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setContactModal(false);
          setSelectedContact('');
          setFilteredClient(clientList);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height,
            width: '100%',
            height: Dimensions?.get('window')?.height * 0.6,
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setContactModal(false);
              setSelectedContact('');
              setFilteredClient(clientList);
            }}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Client
            </Text>
          </View>
          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
                fontSize: ms(12),
                fontFamily: FONTS?.Regular,
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={selctedContact}
              onChangeText={text => handleSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{ height: normalize(14), width: normalize(14) }}
              source={ICONS.search}
            />
          </View>

          <FlatList
            data={filteredClient}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{ alignItems: 'center' }}>
                <Text style={{ color: COLORS?.orange }}>
                  No client found. Please add client before project creation
                </Text>
              </View>
            }
            renderItem={({ item, index }) => {
              console.log('www', item);
              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0.6),
                    borderBottomColor: COLORS.border,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    console.log('itemaaa', item);
                    saveItem(item);
                  }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View
                      style={{
                        height: ms(36),
                        width: ms(36),
                        borderRadius: ms(18),
                        backgroundColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: FONTS.Medium,
                          fontSize: ms(14),
                          color: COLORS.white,
                        }}>
                        {item.name
                          .split(' ') // Split by space → ['Subhadeep', 'Saha']
                          .map(word => word.charAt(0)) // Take first character of each word → ['S', 'S']
                          .join('')}
                      </Text>
                    </View>
                    <View style={{ marginLeft: ms(10) }}>
                      <Text
                        style={{
                          color: '#000',
                          fontFamily: FONTS.SemiBold,
                          textTransform: 'capitalize',
                          fontSize: ms(12),
                        }}>
                        {item?.name}
                      </Text>
                      <Text
                        style={{
                          color: COLORS.placeholderColor,
                          fontFamily: FONTS.Regular,
                          textTransform: 'capitalize',
                          fontSize: ms(10),
                        }}>
                        {item?.email}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <Modal
        animationIn={'fadeInUp'}
        animationOut={'fadeOutDown'}
        isVisible={openAddressModal}
        backdropTransitionOutTiming={0}
        onBackButtonPress={() => setOpenAddressModal(false)}
        onBackdropPress={() => setOpenAddressModal(false)}
        avoidKeyboard={true}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View style={styless.centeredView}>
          <View style={styless.modalView}>
            <View
              style={{
                width: ms(63),
                height: ms(6),
                borderRadius: ms(8),
                backgroundColor: 'rgba(217, 217, 217, 1)',
                alignSelf: 'center',
                marginBottom: ms(20),
              }}
            />
            <TouchableOpacity
              onPress={() => {

                setOpenAddressModal(false)
              }}
              style={{ position: 'absolute', top: 20, right: 20 }}>
              <Image
                resizeMode="contain"
                style={{ height: ms(20), width: ms(20) }}
                source={ICONS.crossbtn}
              />
            </TouchableOpacity>
            <View
              style={{
                height: Dimensions?.get('window')?.height * 0.6,
                width: '100%',
                alignSelf: 'center',
              }}>
              <TouchableOpacity
                onPress={() => setOpenAddressModal(false)}
                style={{ position: 'absolute', top: 20, right: 20 }}>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(20), width: ms(20) }}
                  source={ICONS.crossbtn}
                />
              </TouchableOpacity>
              <Text
                style={{
                  paddingBottom: ms(10),
                  color: COLORS?.blue,
                  height: ms(12),
                }}>
                Enter Address
              </Text>
              <GooglePlacesAutocomplete
                GooglePlacesDetailsQuery={{ fields: 'geometry' }}
                placeholder={'Enter Address'}
                minLength={3}
                fetchDetails={true}
                returnKeyType={'default'}
                listViewDisplayed="auto"
                enablePoweredByContainer={false}
                listEmptyComponent={() => (
                  <View style={{ flex: 1 }}>
                    <Text>No results were found</Text>
                  </View>
                )}
                textInputProps={{
                  autoFocus: true,
                  blurOnSubmit: false,
                }}
                // keyboardShouldPersistTaps="never"
                styles={{
                  textInput: {
                    height: 58,
                    color: '#000',
                    fontSize: 16,
                    borderWidth: 1,
                    borderColor: '#2144C1',
                    borderRadius: 10,
                    width: isTablet
                      ? Dimensions?.get('window')?.width - 70
                      : Dimensions?.get('window')?.width - 50,
                    marginTop: isTablet ? ms(30) : ms(0),
                  },
                  predefinedPlacesDescription: {
                    color: '#1faadb',
                  },
                  listView: {
                    backgroundColor: 'white',
                  },
                }}
                onPress={(data, details) => {
                  console.log(data);
                  console.log(details?.geometry?.location);
                  setFrom({ ...data, ...details?.geometry?.location });
                  saveSearchHistory({ description: data.description, place_id: details.place_id });
                  setOpenAddressModal(false);
                }}
                onFail={error => console.error(error)}
                query={{
                  key: constants?.GOOGLE_API_KEY,
                  language: 'en',
                  // components: 'country:ind',
                }}
                predefinedPlaces={searchHistory}

              />
            </View>

            {/* <Container bg={"#2144C1"} radius={10} pv={10} align="center" width={'70%'}>
                <CText color={'#fff'}> Submit </CText>
            </Container> */}
          </View>
        </View>
      </Modal>
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Add Project'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={()=> checkValidation()}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{ flex: 1, padding: ms(20), alignItems: 'center' }}>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Client
            </Text>
          </View>
          {client ? (
            <View
              style={{
                backgroundColor: COLORS.backgraound,
                borderRadius: ms(10),
                borderWidth: 0.6,
                borderColor: COLORS.themeColor,
                justifyContent: 'center',
                padding: ms(15),
                // height: ms(45),
                width: '98%',
                marginTop: ms(10),

                elevation: 2,
                shadowColor: COLORS?.themeColor,
                backgroundColor: COLORS?.white,
              }}>
              <TouchableOpacity
                style={{ position: 'absolute', top: 15, right: 15 }}
                onPress={() => {
                  setClient('');
                  //setContactModal(false)
                }}>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(16), width: ms(16) }}
                  source={ICONS.crossbtn}
                />
              </TouchableOpacity>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View
                  style={{
                    height: ms(80),
                    width: ms(80),
                    borderRadius: ms(40),
                    backgroundColor: '#44BBFE',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {client.profileImage ? <Image resizeMode='contain' style={{ height: ms(80), width: ms(80), borderRadius: ms(40) }} source={{ uri: client.profileImage }} /> : <Text
                    style={{
                      fontFamily: FONTS?.Bold,
                      fontSize: ms(18),
                      color: COLORS?.white,
                    }}>
                    {!isEmpty(client?.name?.split?.(' ', 2)?.[0]?.[0])
                      ? client?.name?.split?.(' ', 2)?.[0]?.[0]
                      : '' + !isEmpty(client?.name?.split?.(' ', 2)?.[1]?.[0])
                        ? client?.name?.split?.(' ', 2)?.[1]?.[0]
                        : ''}
                  </Text>}

                </View>
                <View style={{ paddingLeft: ms(13), width: '70%' }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(16),
                      color: '#344054',
                    }}>
                    {client?.name}
                  </Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Image
                      style={{
                        height: ms(12),
                        width: ms(15),
                        resizeMode: 'contain',
                      }}
                      source={ICONS.mail}
                    />
                    <Text
                      style={{
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: '#344054',
                        marginLeft: ms(5),
                      }}>
                      {client?.email}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Image
                      style={{
                        height: ms(15),
                        width: ms(15),
                        resizeMode: 'contain',
                      }}
                      source={ICONS.call}
                    />
                    <Text
                      style={{
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: '#344054',
                        marginLeft: ms(5),
                      }}>
                      {client?.phone}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Image
                      style={{
                        height: ms(15),
                        width: ms(15),
                        resizeMode: 'contain',
                      }}
                      source={ICONS.pinloc}
                    />
                    <Text

                      style={{
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: '#344054',
                        marginLeft: ms(5),
                        flex: 1


                        //width:ms(200)
                      }}>
                      {client?.address}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          ) : (
            <TouchableOpacity
              style={{
                borderWidth: ms(0.6),
                marginTop: ms(15),
                padding: ms(10),
                borderColor: COLORS?.themeColor,
                borderRadius: ms(12),
                // flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                elevation: 3,
                backgroundColor: COLORS.white,
                shadowColor: COLORS.themeColor,
                width: isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50,
              }}
              onPress={() => {
                setContactModal(true);
              }}>
              <Text
                style={{
                  color: COLORS?.themeColor,
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(12),
                }}>
                Select a client
              </Text>
            </TouchableOpacity>
          )}

          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              marginTop: ms(15),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(12),
                color: COLORS?.themeColor,
              }}>
              Other Details
            </Text>
          </View>
          <AnimatedTextInput
            label={'Project Name'}
            keyboardType={'default'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={projectName}
            minimumHeight={ms(40)}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setProjectName(item);
            }}
          />

          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.3),

              marginTop: ms(15),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              justifyContent: 'space-between',
              elevation: 2,
              backgroundColor: COLORS.white,
              shadowColor: COLORS.themeColor,
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}
            onPress={() => {
              setOpenAddressModal(true);
            }}>
            {/* <Text
              style={{
                color: COLORS.placeholderColor,
                fontFamily: FONTS?.Regular,
                fontSize:from?.description ?ms(8): ms(12),
              }}>
                {from?.description ? from?.description:"Project Location"}
              
            </Text> */}

            <Text
              numberOfLines={1}
              ellipsizeMode="tail"
              style={{
                color: COLORS.placeholderColor,
                fontFamily: FONTS?.Regular,
                fontSize: from?.description ? ms(12) : ms(12),
                flex: 1,
                marginLeft: ms(5),
                marginRight: ms(10),
              }}>
              {from?.description || 'Project Location'}
            </Text>
            <Image
              source={ICONS?.location_pin}
              style={{
                height: ms(20),
                width: ms(20),
                tintColor: 'rgba(68, 187, 254, 1)',
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>



          <TouchableOpacity
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: isButtonPressed
                ? COLORS?.gray
                : COLORS?.themeColor, // Optional: show disabled state
              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginTop: ms(30),
              opacity: isButtonPressed ? 0.6 : 1, // Visual feedback when disabled
            }}
            onPress={async () => {
              if (isButtonPressed) return; // Prevent multiple presses

              if (client == '') {
                Toast('Select client');
              } else if (projectName == '') {
                Toast('Enter project name');
              } else if (from == '') {
                Toast('Select project location');
              } else {
                setIsButtonPressed(true); // Disable button

                try {
                  await dispatch(
                    projectCreateRequest({
                      client_id: client?.id,
                      project_name: projectName,
                      project_location: from?.description,
                      latitude: from?.lat,
                      longitude: from?.lng,
                      project_desc: '',
                      start_date: null,
                      end_date: null,
                      status: '1',
                    }),
                  );
                } catch (error) {
                  // Optionally handle error
                } finally {
                  setIsButtonPressed(false); // Re-enable button after request finishes
                }
              }
            }}
            disabled={isButtonPressed} // This ensures native-level disable
          >
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              {isButtonPressed ? 'Saving...' : 'Save'}{' '}
              {/* Optional: show loading text */}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});

const styless = StyleSheet.create({
  centeredView: {
    maxHeight:
      Platform.OS == 'ios'
        ? Dimensions?.get('window')?.height / 2.2
        : Dimensions?.get('window')?.height / 2,
    width: '100%',
    paddingTop: 10,
    // paddingHorizontal: 30,
    backgroundColor: '#fff',
    borderTopLeftRadius: ms(30),
    borderTopEndRadius: ms(30),
  },
  modalView: {
    paddingHorizontal: 20,
    paddingTop: 20,
    // margin: 20,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    //   textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    //   textAlign: "center"
  },
});
