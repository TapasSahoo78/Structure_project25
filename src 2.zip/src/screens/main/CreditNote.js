import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useFocusEffect} from '@react-navigation/native';
import {deleteCreditNoteRequest, getCreditNoteDetailsRequest, getCreditNoteListRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../utils/helpers/Loader';
export default function CreditNote() {
  const {creditNoteList,loading} = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [isEnabled, setIsEnabled] = useState(false);
  const [status, setStatus] = useState('unbilled');
  const [totalAm, setTotalAm] = useState(0);

  useFocusEffect(
    useCallback(() => {
      let payload = {};
      dispatch(getCreditNoteListRequest(payload));
    }, []),
  );
  const calculatedTotal = creditNoteList.reduce((sum, item) => {
    return sum + Number(item.total);
  }, 0);
  

  const callToNavigate = () => {
    navigate('AddCreditNoteWithoutClient');
  };

  const getDetails =(item)=>{
    console.log("estimate item",JSON.stringify(item))
          let payload = {
            id:item.id
          }
      dispatch(getCreditNoteDetailsRequest(payload))
  }

  console.log('credit note list', JSON.stringify(creditNoteList));
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
       <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: COLORS?.white,
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Credit Note'}
          searchOptionPresent={true}
          tickOptionPresent={true}
          addMoreOptionPresent={true}
          isBackPresent={true}
          onPress={() => callToNavigate()}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <>
            <View
              style={{
                padding: ms(10),
                marginTop: ms(10),
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                borderBottomWidth: ms(0.6),
                borderBottomColor: '#DEDEDE',
                gap: ms(10),
                width: Dimensions?.get('window')?.width,
                marginLeft: -ms(20),
              }}>
              <View style={{width: '85%'}}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(10),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    2025 sorted by category
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(5),
                      width: ms(14),
                      transform: [{rotate: '180deg'}],
                      tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
              </View>
              <Image
                source={ICONS?.sort}
                style={{height: ms(12), width: ms(12)}}
                resizeMode="contain"
              />
            </View>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                borderBottomWidth: ms(0.6),
                borderBottomColor: '#DEDEDE',
                width: Dimensions?.get('window')?.width,
                marginLeft: -ms(20),
                //elevation: 1,
              }}>
              <TouchableOpacity
                onPress={() => setStatus('unbilled')}
                style={{
                  height: ms(45),
                  width: '40%',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderBottomColor:
                    status == 'unbilled' ? COLORS.themeColor : COLORS.white,
                  borderBottomWidth: 1,
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color:
                      status == 'unbilled'
                        ? 'rgba(52, 64, 84, 1)'
                        : 'rgba(52, 64, 84, 0.75)',
                  }}>
                  Unbilled
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setStatus('billed')}
                style={{
                  height: ms(45),
                  width: '40%',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderBottomColor:
                    status == 'billed' ? COLORS.themeColor : COLORS.white,
                  borderBottomWidth: 1,
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(12),
                    color:
                      status == 'billed'
                        ? 'rgba(52, 64, 84, 1)'
                        : 'rgba(52, 64, 84, 0.75)',
                  }}>
                  Billed
                </Text>
              </TouchableOpacity>
            </View>
            <FlatList
              data={creditNoteList}
              contentContainerStyle={{marginBottom: ms(60)}}
              ListEmptyComponent={() => {
                return (
                  <View
                    style={{
                      width: '100%',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        textAlign: 'center',
                        fontSize: ms(12),
                        fontFamily: FONTS.Medium,
                        marginTop: ms(10),
                        color: COLORS.themeColor,
                      }}>
                      No Data Found !
                    </Text>
                  </View>
                );
              }}
              renderItem={({item, index}) => {
                return (
                  <View
                    style={{
                      borderRadius: ms(15),
                      borderWidth: 1,
                      borderColor: COLORS.border,
                      marginTop: ms(40),
                      padding: 10,
                      elevation: 2,
                      backgroundColor: COLORS?.white,
                      shadowColor: 'rgba(4, 127, 255, 0.2)',
                    }}>
                    <View
                      style={{
                        backgroundColor: 'rgba(4, 127, 255, 0.1)',
                        padding: ms(10),
                        borderRadius: ms(6),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}></View>
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginTop: ms(10),
                        paddingHorizontal: 10,
                      }}>
                      <TouchableOpacity onPress={() => getDetails(item)}>
                        <Text
                          style={{
                            fontSize: ms(12),
                            fontFamily: FONTS.Medium,
                            color: '#344054',
                          }}>
                          {item?.client?.name}
                        </Text>
                        <Text
                          style={{
                            fontSize: ms(10),
                            fontFamily: FONTS.Light,
                            color: '#344054',
                          }}>
                          {item?.items.length} Items
                        </Text>
                      </TouchableOpacity>
                      <View
                        style={{flexDirection: 'row', alignItems: 'center'}}>
                        <View>
                          <Text
                            style={{
                              fontSize: ms(12),
                              fontFamily: FONTS.Medium,
                              color: '#344054',
                            }}>
                            ${item?.total}
                          </Text>
                          <Text
                            style={{
                              fontSize: ms(10),
                              fontFamily: FONTS.Regular,
                              color: '#F25022',
                            }}>
                            Unsent
                          </Text>
                        </View>
                        <View style={{marginLeft: ms(10)}}>
                          <TouchableOpacity
                            onPress={() => {
                              console.log(item);
                              navigate('UpdateCreditNote', {item: item});
                            }}>
                            <Image
                              resizeMode="contain"
                              style={{height: ms(15), width: ms(15)}}
                              source={ICONS.editicn}
                            />
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => {
                              Alert.alert(
                                'Confirmation',
                                'Are you sure you want to delete?',
                                [
                                  {
                                    text: 'Cancel',
                                    onPress: () =>
                                      console.log('Cancel Pressed'),
                                    style: 'cancel', // Optional: 'cancel' style on iOS
                                  },
                                  {
                                    text: 'OK',
                                    onPress: () => {
                                      let payload = {
                                        id: item.id,
                                      };
                                      dispatch(deleteCreditNoteRequest(payload));
                                    },
                                  },
                                ],
                              );
                            }}
                            style={{marginTop: ms(10)}}>
                            <Image
                              resizeMode="contain"
                              style={{height: ms(15), width: ms(15)}}
                              source={ICONS.delete}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                );
              }}
            />
          </>
        </View>
      </ScrollView>

      <View
        style={{
          width: '100%',
          backgroundColor: '#FFF',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(0),
          paddingHorizontal: ms(25),
          paddingVertical: ms(15),
          borderTopLeftRadius: ms(20),
          borderTopRightRadius: ms(20),
          flexDirection: 'row',
          justifyContent: 'space-between',
          borderWidth: ms(0.6),
          borderColor: '#EFEFEF',
          elevation: ms(3),
          shadowColor: 'rgba(4, 127, 255, 0.2)',
        }}>
        <Text
          style={{
            fontSize: ms(10),
            fontFamily: FONTS.Medium,
            color: '#344054',
          }}>
          Total
        </Text>
        <Text
          style={{
            fontSize: ms(12),
            fontFamily: FONTS.Medium,
            color: '#344054',
          }}>
          ${calculatedTotal}
        </Text>
      </View>
      {/* <TouchableOpacity
                onPress={() => navigate('AddCreditNoteWithoutClient')}
                style={{
                  //marginTop: -ms(80),
                  //backgroundColor: 'rgb(232, 243, 255)',
                  height: ms(70),
                  width: ms(70),
                  borderRadius: ms(35),
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'absolute',
                  bottom: ms(60),
                  zIndex: 1,
                  right: 10,
                  borderColor: COLORS.border,
                  //borderWidth: 2,
                }}>
                <View
                  style={{
                    height: ms(50),
                    width: ms(50),
                    borderRadius: ms(25),
                    backgroundColor: COLORS?.themeColor,
      
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image
                    source={ICONS.addMore}
                    resizeMode="contain"
                    style={[
                      styles.iconStyle,
                      {tintColor: COLORS?.white, marginRight: ms(0)},
                    ]}
                  />
                </View>
              </TouchableOpacity> */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
