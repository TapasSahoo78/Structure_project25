import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
  Modal,
  Button,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import FormHeader from '../../components/FormHeader';
import CameraDropDown from '../../components/CameraDropDown';
import {useDispatch, useSelector} from 'react-redux';
import {
  createLogoRequest,
  getInvoiceTemplateRequest,
  getLogoRequest,
  getColourListRequest,
  getWaterMarkListRequest,
  getHeaderListRequest,
  addInvoiceDesignRequest,
  getInvoiceSettingsRequest,
  updateInvoiceSettingsRequest,
  addCustomLogoRequest,
  addCustomHeaderRequest,
  addCustomWaterRequest,
  createCustomTemplateRequest,
} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';
//import CustomizeColorPicker from '../../components/CustomizeColorPicker';
import ColorPicker from 'react-native-wheel-color-picker';

export default function CustomInvoiceDesign() {
  const [templateContent, setTemplateContent] = useState(true);
  const [logoContent, setLogoContent] = useState(true);
  const [selectedTemp, setSelectedTemp] = useState('');
  const [logoFlag, setLogoFlag] = useState('image');
  const [alignPos, setAlignPos] = useState('left');
  const [selectedsize, setSelectedSize] = useState('small');
  const [headerContent, setHeaderContent] = useState(true);
  const [shippingDetails, setShippingDetails] = useState(true);
  const [dueDate, setDueDate] = useState(true);
  const [paymentTerm, setPaymentTerm] = useState(true);
  const [selectedId, setSelectedId] = useState('');
  const [noneLogo, setNoneLogo] = useState(false);
  const [cameraModal, setCameraModal] = useState(false);
  const [imageObject, setImageObject] = useState('');
  const [colourFlag, setColourFlag] = useState(true);
  const [selectedColour, setSelectedColour] = useState('');
  const [waterMarkFlag, setWaterMarkFlag] = useState(true);
  const [selectedWatermark, setSelectedWatermark] = useState('');
  const [selectedHeader, setSelectedHeader] = useState('');
  const [showColorModal, setShowColorModal] = useState(false);
 // const [selectedColor, setSelectedColor] = useState('#ffff');
  const [selectedColor, setSelectedColor] = useState('');
  const [status, setStatus] = useState('');
  const [headerImage, setHeaderImage] = useState('');
  const [waterImage, setWaterImage] = useState('');
  const [noneLogoHeader,setNoneLogoHeader] = useState(false)
  const [noneLogoWater,setNoneLogoWater] = useState(false)

  const dispatch = useDispatch();
  const {
    logoList,
    colourList,
    waterMarkList,
    headerList,
    loading,
    invoiceTemplate,
    invoiceSettings,
    customLogo,
    customWaterMark,
    customheader
  } = useSelector(state => state.ProfileReducer);
  const iconList = [
    {
      id: 100,
      img: ICONS.drill,
    },
    {
      id: 101,
      img: ICONS.bulb,
    },
    {
      id: 102,
      img: ICONS.paintbrush,
    },
    {
      id: 103,
      img: ICONS.silhouette,
    },
    {
      id: 104,
      img: ICONS.business,
    },
    {
      id: 105,
      img: ICONS.configure,
    },
    {
      id: 106,
      img: ICONS.computer,
    },
  ];
  

  console.log('invoice settings', JSON.stringify(invoiceSettings));

  const FooterComponent = () => {
    return (
      <View
        style={{flexDirection: 'row', marginLeft: ms(5), marginTop: ms(10)}}>
        <TouchableOpacity
          onPress={() => {
            setNoneLogo(!noneLogo);
            setSelectedId(0);
          }}
          style={{
            height: ms(70),
            width: ms(70),
            borderWidth: 0.6,
            borderColor: COLORS.border,
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: ms(10),
            backgroundColor: COLORS.white,
          }}>
          <Image
            resizeMode="contain"
            style={{height: ms(15), width: ms(20)}}
            source={ICONS.pic}
          />
          <Text
            style={{
              fontSize: ms(12),
              color: COLORS.themeColor,
              fontFamily: FONTS.Regular,
              marginTop: ms(10),
            }}>
            None
          </Text>
          {noneLogo ? (
            <Image
              resizeMode="contain"
              style={{
                height: ms(20),
                width: ms(20),
                position: 'absolute',
                top: 0,
                right: 0,
              }}
              source={ICONS.bluetick}
            />
          ) : null}
        </TouchableOpacity>
        {/* <TouchableOpacity
          onPress={() => {
            setSelectedId(0);
            setNoneLogo(false);
            setCameraModal(true);
          }}
          style={{
            height: ms(70),
            marginLeft: ms(10),
            width: ms(70),
            borderWidth: 0.6,
            borderColor: COLORS.border,
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: ms(10),
            backgroundColor: COLORS.white,
          }}>
          <Image
            resizeMode="contain"
            style={{height: ms(19), width: ms(19)}}
            source={ICONS.plusicn}
          />
          <Text
            style={{
              fontSize: ms(12),
              color: COLORS.themeColor,
              fontFamily: FONTS.Regular,
              marginTop: ms(10),
            }}>
            Add Photo
          </Text>
        </TouchableOpacity> */}
      </View>
    );
  };
  useEffect(() => {
    //dispatch(getLogoRequest());
    //dispatch(getColourList());
    //dispatch(getColourListRequest());
    //dispatch(getWaterMarkListRequest());
    //dispatch(getHeaderListRequest());
    dispatch(getInvoiceSettingsRequest());
   
  }, []);

  useEffect(() => {
    if (invoiceSettings) {
      setSelectedTemp(invoiceSettings?.name || '');
      //setSelectedId(invoiceSettings?.logoDetails || '');
      //setSelectedColour(invoiceSettings?.colourDetails || '');
      //setSelectedHeader(invoiceSettings?.headerDetails || '');
      //setSelectedWatermark(invoiceSettings?.waterMarkDetails || '');
      setSelectedSize(invoiceSettings?.logoSize);
      setAlignPos(invoiceSettings?.logoPosition);
    }
  }, [invoiceSettings]);
  function storeImage(item) {
    let form = new FormData();
    form?.append('logoImage', item);
    dispatch(createLogoRequest(form));
  }

  const handleColorSelect = color => {
    // Update the selected color (in hex)
    setSelectedColor(color);
    console.log("selected colour",color)
  };

  const handleClose = () => {
    setShowColorModal(false);
    // You can do something with the final selectedColor here
    console.log('Final selected color:', selectedColor);
  };

  const submitData = () => {
    console.log('logo...', selectedId);
    if (selectedTemp == '') {
      Toast('Select template');
    } else {
      //alert(selectedId.id)
      let payload = {
        id:invoiceSettings?.id||"",
        templateName: selectedTemp,
        logoId: customLogo?.id || "",
        logoImage:customLogo?.logoImage || "",
        logoSize: selectedsize,
        logoPosition: alignPos,
        //colourId:'',
        customColour:selectedColor || "",
        headerId:customheader?.id || "",
        headerImg:customheader?.headerImg || "",
        waterMarkId:customWaterMark?.id || "",
        waterMarkImg:customWaterMark?.waterMarkImg ||""
      };
      console.log('submit payload', payload);

      dispatch(createCustomTemplateRequest(payload));
    }
  };

  const updateData = () => {
    let payload = {
        id:invoiceSettings?.id||"",
        templateName: selectedTemp,
        logoId: customLogo?.id || "",
        logoImage:customLogo?.logoImage || "",
        logoSize: selectedsize,
        logoPosition: alignPos,
        //colourId:'',
        customColour:selectedColor || "",
        headerId:customheader?.id || "",
        headerImg:customheader?.headerImg || "",
        waterMarkId:customWaterMark?.id || "",
        waterMarkImg:customWaterMark?.waterMarkImg ||""
      };
    dispatch(createCustomTemplateRequest(payload));
  };

  const callSaveLogo =(item)=>{
    let formData = new FormData();
    formData.append('logoImage',item)
    dispatch(addCustomLogoRequest(formData))
  }
  const callSaveHeader =(item)=>{
    let formData = new FormData();
    formData.append('headerImg',item)
    dispatch(addCustomHeaderRequest(formData))
    
  }
  const callSaveWater =(item)=>{
    let formData = new FormData();
    formData.append('waterMarkImg',item)
    dispatch(addCustomWaterRequest(formData))
    
  }

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Cutomize Invoice Design'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{padding: ms(20)}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              onPress={() => {
                setTemplateContent(!templateContent);
              }}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Template
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: templateContent ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {templateContent ? (
            <View style={{paddingHorizontal: ms(10)}}>
              <View
                style={{
                  flexDirection: 'row',
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginTop: ms(10),
                  alignSelf: 'center',
                }}>
                <TouchableOpacity
                  onPress={() => {
                    setSelectedTemp('impact');
                    // dispatch(
                    //   getInvoiceTemplateRequest({
                    //     templateName: 'Impact',
                    //   }),
                    // );
                  }}
                  style={{width: '33%'}}>
                  <ImageBackground
                    imageStyle={{
                      resizeMode: 'contain',
                      borderWidth: selectedTemp == 'impact' ? ms(0.3) : 0,
                      borderColor: COLORS.themeColor,
                    }}
                    style={{height: ms(100), width: ms(100)}}
                    source={IMAGES.templateone}>
                    {selectedTemp == 'impact' ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(20),
                          width: ms(20),
                          position: 'absolute',
                          top: 0,
                          right: 0,
                        }}
                        source={ICONS.bluetick}
                      />
                    ) : null}
                  </ImageBackground>
                  <Text
                    style={{
                      alignSelf: 'center',
                      fontSize: ms(14),
                      fontFamily: FONTS.Medium,
                      marginTop: ms(10),
                    }}>
                    Impact
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    setSelectedTemp('classic');
                    // dispatch(
                    //   getInvoiceTemplateRequest({
                    //     templateName: 'Classic',
                    //   }),
                    // );
                  }}
                  style={{width: '33%'}}>
                  <ImageBackground
                    style={{height: ms(100), width: ms(100)}}
                    imageStyle={{
                      resizeMode: 'contain',
                      borderWidth: selectedTemp == 'classic' ? ms(0.6) : 0,
                      borderColor: COLORS.themeColor,
                    }}
                    source={IMAGES.templatetwo}>
                    {selectedTemp == 'classic' ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(20),
                          width: ms(20),
                          position: 'absolute',
                          top: 0,
                          right: 0,
                        }}
                        source={ICONS.bluetick}
                      />
                    ) : null}
                  </ImageBackground>
                  <Text
                    style={{
                      alignSelf: 'center',
                      fontSize: ms(14),
                      fontFamily: FONTS.Medium,
                      marginTop: ms(10),
                    }}>
                    Classic
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    setSelectedTemp('modern');
                    // dispatch(
                    //   getInvoiceTemplateRequest({
                    //     templateName: 'Modern',
                    //   }),
                    // );
                  }}
                  style={{width: '33%'}}>
                  <ImageBackground
                    imageStyle={{
                      resizeMode: 'contain',
                      borderWidth: selectedTemp == 'modern' ? ms(0.6) : 0,
                      borderColor: COLORS.themeColor,
                    }}
                    style={{height: ms(100), width: ms(100)}}
                    source={IMAGES.templateone}>
                    {selectedTemp == 'modern' ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(20),
                          width: ms(20),
                          position: 'absolute',
                          top: 0,
                          right: 0,
                        }}
                        source={ICONS.bluetick}
                      />
                    ) : null}
                  </ImageBackground>
                  <Text
                    style={{
                      alignSelf: 'center',
                      fontSize: ms(14),
                      fontFamily: FONTS.Medium,
                      marginTop: ms(10),
                    }}>
                    Modern
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => setLogoContent(!logoContent)}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Logo
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: logoContent ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {logoContent ? (
            <View style={{marginTop: ms(20)}}>
              <View
                style={{
                  //padding: ms(10),
                  height: ms(40),
                  backgroundColor: COLORS.white,
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '100%',
                  borderWidth: ms(1),
                  borderColor: COLORS.border,
                  paddingHorizontal: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setLogoFlag('image')}
                  style={{
                    width: '50%',
                    alignItems: 'center',
                    height: '100%',
                    borderBottomWidth: logoFlag == 'image' ? ms(1) : 0,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    Image
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setLogoFlag('position')}
                  style={{
                    width: '50%',
                    alignItems: 'center',
                    height: '100%',
                    borderBottomWidth: logoFlag == 'position' ? ms(1) : 0,
                    borderColor: COLORS.themeColor,
                    justifyContent: 'center',
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    Position
                  </Text>
                </TouchableOpacity>
              </View>
              {logoFlag == 'position' ? (
                <View style={{marginTop: ms(20), paddingLeft: ms(10)}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    Alignment
                  </Text>
                  <View
                    style={{
                      width: '100%',
                      height: ms(1),
                      backgroundColor: COLORS.border,
                      marginVertical: ms(10),
                    }}
                  />
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => setAlignPos('left')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {alignPos == 'left' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Left
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setAlignPos('center')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {alignPos == 'center' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Center
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setAlignPos('right')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {alignPos == 'right' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Right
                    </Text>
                  </View>

                  <Text
                    style={{
                      marginTop: ms(20),
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    Size
                  </Text>
                  <View
                    style={{
                      width: '100%',
                      height: ms(1),
                      backgroundColor: COLORS.border,
                      marginVertical: ms(10),
                    }}
                  />
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => setSelectedSize('small')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {selectedsize == 'small' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Small
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setSelectedSize('medium')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {selectedsize == 'medium' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Medium
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setSelectedSize('large')}
                      style={{
                        height: ms(17),
                        width: ms(17),
                        borderRadius: ms(8.5),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {selectedsize == 'large' ? (
                        <View
                          style={{
                            height: ms(9),
                            width: ms(9),
                            borderRadius: ms(9 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        marginLeft: ms(10),
                        fontFamily: FONTS?.Regular,
                        fontSize: ms(12),
                        color: COLORS?.black,
                      }}>
                      Large
                    </Text>
                  </View>
                </View>
              ) : null}
              {logoFlag == 'image' ? (
                <View style={{marginTop: ms(20)}}>
                  {imageObject ? (
                    <View>
                      <TouchableOpacity
                        onPress={() => setImageObject('')}
                        style={{alignItems: 'flex-end', width: ms(70)}}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(15), width: ms(15)}}
                          source={ICONS.crossbtn}
                        />
                      </TouchableOpacity>
                      <Image
                        resizeMode="contain"
                        style={{height: ms(60), width: ms(40)}}
                        source={{uri: imageObject.uri}}
                      />
                    </View>
                  ) : (
                    <View
                      style={{
                        flexDirection: 'row',
                        marginLeft: ms(5),
                        marginTop: ms(10),
                      }}>
                      <TouchableOpacity
                        onPress={() => {
                          setNoneLogo(!noneLogo);
                          setSelectedId(0);
                        }}
                        style={{
                          height: ms(70),
                          width: ms(70),
                          borderWidth: 0.6,
                          borderColor: COLORS.border,
                          justifyContent: 'center',
                          alignItems: 'center',
                          borderRadius: ms(10),
                          backgroundColor: COLORS.white,
                        }}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(15), width: ms(20)}}
                          source={ICONS.pic}
                        />
                        <Text
                          style={{
                            fontSize: ms(12),
                            color: COLORS.themeColor,
                            fontFamily: FONTS.Regular,
                            marginTop: ms(10),
                          }}>
                          None
                        </Text>
                        {noneLogo ? (
                          <Image
                            resizeMode="contain"
                            style={{
                              height: ms(20),
                              width: ms(20),
                              position: 'absolute',
                              top: 0,
                              right: 0,
                            }}
                            source={ICONS.bluetick}
                          />
                        ) : null}
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => {
                          setSelectedId(0);
                          setNoneLogo(false);
                          setStatus('logo');
                          setCameraModal(true);
                        }}
                        style={{
                          height: ms(70),
                          marginLeft: ms(10),
                          width: ms(70),
                          borderWidth: 0.6,
                          borderColor: COLORS.border,
                          justifyContent: 'center',
                          alignItems: 'center',
                          borderRadius: ms(10),
                          backgroundColor: COLORS.white,
                        }}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(19), width: ms(19)}}
                          source={ICONS.plusicn}
                        />
                        <Text
                          style={{
                            fontSize: ms(12),
                            color: COLORS.themeColor,
                            fontFamily: FONTS.Regular,
                            marginTop: ms(10),
                          }}>
                          Add Photo
                        </Text>
                      </TouchableOpacity>
                    </View>
                  )}

                  
                </View>
              ) : null}
            </View>
          ) : null}
          
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => setColourFlag(!colourFlag)}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Colour
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: colourFlag ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {colourFlag ? (
            <View style={{marginTop: ms(15),width:ms(100),flexDirection:'row',}}>
              
              {selectedColor ? <View>
              <TouchableOpacity style={{alignItems:"flex-end"}} onPress={()=> setSelectedColor("")}>
              <Image resizeMode='contain' style={{height:ms(15),width:ms(15),marginLeft:ms(30)}} source={ICONS.crossbtn}/>
              </TouchableOpacity>
              <View style={{
              height:ms(30),
              width:ms(30),
              borderRadius:ms(15),
              backgroundColor:selectedColor
              }}/></View>:<TouchableOpacity style={{alignItems:'center'}} onPress={() => setShowColorModal(true)}>
              <Image resizeMode='contain' style={{height:ms(25),width:ms(25),alignSelf:'center'}} source={ICONS.colorwheel}/>
              
              <Text style={{fontFamily:FONTS.Regular,fontSize:ms(14)}}>Add colour</Text>
              </TouchableOpacity>}
            </View>
          ) : null}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => setHeaderContent(!headerContent)}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Header
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: headerContent ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {headerContent ? (
            
            <View style={{marginTop: ms(20)}}>
              {headerImage ? (
                <View>
                  <TouchableOpacity
                    onPress={() => setHeaderImage('')}
                    style={{alignItems: 'flex-end', width: ms(70)}}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(15), width: ms(15)}}
                      source={ICONS.crossbtn}
                    />
                  </TouchableOpacity>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(60), width: ms(40)}}
                    source={{uri: headerImage.uri}}
                  />
                </View>
              ) : (
                <View
                  style={{
                    flexDirection: 'row',
                    marginLeft: ms(5),
                    marginTop: ms(10),
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      setNoneLogoHeader(!noneLogoHeader);
                      setSelectedId(0);
                    }}
                    style={{
                      height: ms(70),
                      width: ms(70),
                      borderWidth: 0.6,
                      borderColor: COLORS.border,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: ms(10),
                      backgroundColor: COLORS.white,
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(15), width: ms(20)}}
                      source={ICONS.pic}
                    />
                    <Text
                      style={{
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                        marginTop: ms(10),
                      }}>
                      None
                    </Text>
                    {noneLogoHeader ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(20),
                          width: ms(20),
                          position: 'absolute',
                          top: 0,
                          right: 0,
                        }}
                        source={ICONS.bluetick}
                      />
                    ) : null}
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setSelectedId(0);
                      setNoneLogoHeader(false);
                      setStatus('header');
                      setCameraModal(true);
                    }}
                    style={{
                      height: ms(70),
                      marginLeft: ms(10),
                      width: ms(70),
                      borderWidth: 0.6,
                      borderColor: COLORS.border,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: ms(10),
                      backgroundColor: COLORS.white,
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(19), width: ms(19)}}
                      source={ICONS.plusicn}
                    />
                    <Text
                      style={{
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                        marginTop: ms(10),
                      }}>
                      Add Photo
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              
            </View>
          ) : null}

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
            }}>
            <TouchableOpacity
              onPress={() => setWaterMarkFlag(!waterMarkFlag)}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Watermark
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: waterMarkFlag ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {waterMarkFlag ? (
            <View style={{marginTop: ms(20)}}>
              {waterImage ? (
                <View>
                  <TouchableOpacity
                    onPress={() => setWaterImage('')}
                    style={{alignItems: 'flex-end', width: ms(70)}}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(15), width: ms(15)}}
                      source={ICONS.crossbtn}
                    />
                  </TouchableOpacity>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(60), width: ms(40)}}
                    source={{uri: waterImage.uri}}
                  />
                </View>
              ) : (
                <View
                  style={{
                    flexDirection: 'row',
                    marginLeft: ms(5),
                    marginTop: ms(10),
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      setNoneLogoWater(!noneLogoWater);
                      setSelectedId(0);
                    }}
                    style={{
                      height: ms(70),
                      width: ms(70),
                      borderWidth: 0.6,
                      borderColor: COLORS.border,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: ms(10),
                      backgroundColor: COLORS.white,
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(15), width: ms(20)}}
                      source={ICONS.pic}
                    />
                    <Text
                      style={{
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                        marginTop: ms(10),
                      }}>
                      None
                    </Text>
                    {noneLogoWater ? (
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(20),
                          width: ms(20),
                          position: 'absolute',
                          top: 0,
                          right: 0,
                        }}
                        source={ICONS.bluetick}
                      />
                    ) : null}
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setSelectedId(0);
                      setNoneLogoWater(false);
                      setStatus('water');
                      setCameraModal(true);
                    }}
                    style={{
                      height: ms(70),
                      marginLeft: ms(10),
                      width: ms(70),
                      borderWidth: 0.6,
                      borderColor: COLORS.border,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: ms(10),
                      backgroundColor: COLORS.white,
                    }}>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(19), width: ms(19)}}
                      source={ICONS.plusicn}
                    />
                    <Text
                      style={{
                        fontSize: ms(12),
                        color: COLORS.themeColor,
                        fontFamily: FONTS.Regular,
                        marginTop: ms(10),
                      }}>
                      Add Photo
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ) : null}
        </View>
        {invoiceSettings ? (
          <TouchableOpacity
            onPress={() => updateData()}
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,
              // position: 'absolute',
              // bottom: ms(10),
              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginVertical: ms(30),
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Update
            </Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={() => submitData()}
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,
              // position: 'absolute',
              // bottom: ms(10),
              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginVertical: ms(30),
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Save
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>
      <CameraDropDown
        visible={cameraModal}
        onBackdropPress={() => {
          setCameraModal(false);
        }}
        onPressCamera={item => {
          console.log('images: ', item);
          if (status == 'logo') {
            setImageObject(item);
          } else if (status == 'header') {
            setHeaderImage(item);
          } else {
            setWaterImage(item);
          }

          //storeImage(item);
        }}
        onPressGallery={item => {
          console.log('images: ', item);
          if (status == 'logo') {
            setImageObject(item);
            callSaveLogo(item)
          } else if (status == 'header') {
            setHeaderImage(item);
            callSaveHeader(item)
          } else {
            setWaterImage(item);
            callSaveWater(item)
          }
        }}
      />
      <Modal
        animationType="slide"
        transparent={false}
        visible={showColorModal}
        onRequestClose={handleClose}>
        <View style={styles.modalContainer}>
          <ColorPicker
            color={selectedColor}
            onColorChange={handleColorSelect}
            thumbSize={40}
            sliderSize={40}
            noSnap={true}
            row={false}
            style={styles.colorPicker}
          />

          <View style={styles.buttonContainer}>
            <Button title="Cancel" onPress={handleClose} color="#ccc" />
            <Button title="OK" onPress={handleClose} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  colorPreview: {
    width: 100,
    height: 100,
    borderWidth: 1,
    borderColor: '#000',
    marginBottom: 10,
  },
  hexText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
  colorPicker: {
    width: '100%',
    height: 400,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
  },
});
