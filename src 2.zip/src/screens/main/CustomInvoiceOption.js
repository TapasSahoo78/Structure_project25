import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import {useDispatch, useSelector} from 'react-redux';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo from 'react-native-device-info';
import AnimatedTextInput from '../../components/AnimatedTextInput';

import { getInvoiceOptionsSettingsRequest,addInvoiceOptionRequest, getInvoiceSettingsRequest, getInvoicePreviewRequest } from '../../redux/reducer/ProfileReducer';
import { navigate } from '../../utils/helpers/RootNaivgation';
export default function CustomInvoiceOption() {
  const dispatch = useDispatch();
  const {
      invoiceOptionSettings,
      loading,
      invoiceSettings
    } = useSelector(state => state.ProfileReducer);

  const [headerContent, setHeaderContent] = useState(true);
  const [tableContent, setTableContent] = useState(true);
  const [footerContent, setFooterContent] = useState(true);
  const [numberContent, setNumberContent] = useState(true);

  const [shipDetails, setShipDetails] = useState(true);
  const [dueDate, setDueDate] = useState(true);
  const [paymentTerm, setPaymentTerm] = useState(true);

  const [itemCode, setItemCode] = useState(true);
  const [qtyRate, setQtyRate] = useState(true);
  const [pTax, setPTax] = useState(true);

  const [activeFooter, setActiveFooter] = useState('Tax');
  const [taxAmount, setTaxAmount] = useState(true);
  const [includeSignature, setIncludeSignature] = useState(true);
  const [prefixNumber, setPrefixNumber] = useState("");

  const [isTablet, setIsTablet] = useState(false);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  useEffect(()=> {
    dispatch(getInvoiceOptionsSettingsRequest());
    dispatch(getInvoiceSettingsRequest());
  },[])
  // useEffect(()=> {
  //   let payload = {
  //       templateName: invoiceSettings?.name,
  //       invoiceId: "",
  //     };
  //     dispatch(getInvoicePreviewRequest(payload));

  // },[invoiceSettings])
  

  const submitData =()=>{
    let payload = {
        id:invoiceOptionSettings?.id || "",
        shippingDetails:shipDetails,
        due_date:dueDate,
        payment_terms:paymentTerm,
        itemCode:itemCode,
        quantityAndRate:qtyRate,
        pTax:pTax,
        tax_amounts:taxAmount,
        includeSignatureLine:includeSignature,
        invoicePrifix:prefixNumber
    }
    dispatch(addInvoiceOptionRequest(payload))
    let payloads = {
        templateName: invoiceSettings?.name,
        invoiceId: "",
      };
      dispatch(getInvoicePreviewRequest(payloads));
      navigate("InvoiceWebview")
  }
  useEffect(() => {
    if (invoiceOptionSettings) {
      setShipDetails(invoiceOptionSettings?.shippingDetails);
      setDueDate(invoiceOptionSettings?.due_date);
      setPaymentTerm(invoiceOptionSettings?.payment_terms);
      setItemCode(invoiceOptionSettings?.itemCode);
      setQtyRate(invoiceOptionSettings?.quantityAndRate);
      setPTax(invoiceOptionSettings?.pTax);
      setTaxAmount(invoiceOptionSettings?.tax_amounts);
      setIncludeSignature(invoiceOptionSettings?.includeSignatureLine)
      setPrefixNumber(invoiceOptionSettings?.invoicePrifix)
    }
  }, [invoiceOptionSettings]);

 
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Cutomize Invoice Options'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{padding: ms(20)}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              onPress={() => {
                setHeaderContent(!headerContent);
              }}
              style={{
                padding: ms(10),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(6),
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(14),
                  color: COLORS?.themeColor,
                }}>
                Header
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{rotate: headerContent ? '0deg' : '180deg'}],
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
          {headerContent ? (
            <View style={{padding: ms(10)}}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TouchableOpacity
                  onPress={() => setShipDetails(!shipDetails)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: shipDetails
                      ? COLORS.themeColor
                      : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {shipDetails ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  Shipping Details
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(20),
                }}>
                <TouchableOpacity
                  onPress={() => setDueDate(!dueDate)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: dueDate ? COLORS.themeColor : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {dueDate ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  Due Date
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(20),
                }}>
                <TouchableOpacity
                  onPress={() => setPaymentTerm(!paymentTerm)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: paymentTerm
                      ? COLORS.themeColor
                      : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {paymentTerm ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  Payment Terms
                </Text>
              </View>
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => {
              setTableContent(!tableContent);
            }}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Table
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: tableContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {tableContent ? (
            <View style={{padding: ms(10)}}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TouchableOpacity
                  onPress={() => setItemCode(!itemCode)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: itemCode
                      ? COLORS.themeColor
                      : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {itemCode ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  Item Code
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(20),
                }}>
                <TouchableOpacity
                  onPress={() => setQtyRate(!qtyRate)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: qtyRate ? COLORS.themeColor : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {qtyRate ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  Quantity and Rate
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(20),
                }}>
                <TouchableOpacity
                  onPress={() => setPTax(!pTax)}
                  style={{
                    height: ms(23),
                    width: ms(23),
                    borderWidth: ms(1),
                    borderColor: COLORS.themeColor,
                    borderRadius: ms(5),
                    backgroundColor: pTax ? COLORS.themeColor : COLORS.white,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {pTax ? (
                    <Image
                      resizeMode="contain"
                      source={ICONS.whitetick}
                      style={{height: ms(7), width: ms(10)}}
                    />
                  ) : null}
                </TouchableOpacity>
                <Text
                  style={{
                    fontFamily: FONTS.Medium,
                    fontSize: ms(14),
                    marginLeft: ms(10),
                  }}>
                  P-Tax
                </Text>
              </View>
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => {
              setFooterContent(!footerContent);
            }}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Footer
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: footerContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {footerContent ? (
            <View>
              <View
                style={{
                  paddingHorizontal: ms(10),
                  //backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '100%',
                  marginTop: ms(10),
                }}>
                <TouchableOpacity
                  onPress={() => setActiveFooter('Tax')}
                  style={{
                    width: '50%',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderBottomWidth: ms(1),
                    borderBottomColor:
                      activeFooter == 'Tax' ? COLORS.themeColor : COLORS.white,
                    paddingVertical: ms(10),
                  }}>
                  <Text style={{fontFamily: FONTS.Medium, fontSize: ms(14)}}>
                    Tax Summery
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setActiveFooter('Signature')}
                  style={{
                    width: '50%',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderBottomWidth: ms(1),
                    borderBottomColor:
                      activeFooter == 'Signature'
                        ? COLORS.themeColor
                        : COLORS.white,
                    paddingVertical: ms(10),
                  }}>
                  <Text style={{fontFamily: FONTS.Medium, fontSize: ms(14)}}>
                    Signature
                  </Text>
                </TouchableOpacity>
              </View>
              {activeFooter == 'Tax' ? (
                <View style={{paddingLeft: ms(10)}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setTaxAmount(!taxAmount)}
                      style={{
                        height: ms(23),
                        width: ms(23),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        borderRadius: ms(5),
                        backgroundColor: taxAmount
                          ? COLORS.themeColor
                          : COLORS.white,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {taxAmount ? (
                        <Image
                          resizeMode="contain"
                          source={ICONS.whitetick}
                          style={{height: ms(7), width: ms(10)}}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(14),
                        marginLeft: ms(10),
                      }}>
                      Tax Amount
                    </Text>
                  </View>
                </View>
              ) : (
                <View style={{paddingLeft: ms(10)}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: ms(20),
                    }}>
                    <TouchableOpacity
                      onPress={() => setIncludeSignature(!includeSignature)}
                      style={{
                        height: ms(23),
                        width: ms(23),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        borderRadius: ms(5),
                        backgroundColor: includeSignature
                          ? COLORS.themeColor
                          : COLORS.white,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {includeSignature ? (
                        <Image
                          resizeMode="contain"
                          source={ICONS.whitetick}
                          style={{height: ms(7), width: ms(10)}}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Medium,
                        fontSize: ms(14),
                        marginLeft: ms(10),
                      }}>
                      Include Signature Line
                    </Text>
                  </View>
                </View>
              )}
            </View>
          ) : null}
          <TouchableOpacity
            onPress={() => {
              setNumberContent(!numberContent);
            }}
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Numbering
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: numberContent ? '0deg' : '180deg'}],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {numberContent ? (
            <View>
              <Text
                style={{
                  marginLeft: ms(10),
                  marginTop: ms(10),
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                }}>
                Invoice Numbers
              </Text>

              <AnimatedTextInput
                label={'Enter a prefix'}
                //keyboardType={'email-address'}
                width={
                  isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50
                }
                value={prefixNumber}
                borderColor={COLORS?.themeColor}
                minimumHeight={ms(45)}
                onChangeText={item => {
                  setPrefixNumber(item);
                }}
              />
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => submitData()}
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,
              // position: 'absolute',
              // bottom: ms(10),
              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginTop: ms(30),
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },
});
