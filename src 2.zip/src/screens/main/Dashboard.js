import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import Header from '../../components/Header';
import {useFocusEffect} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {
  getAppointmentListRequest,
  getClientRequest,
  getProfileRequest,
  getProfileStatusRequest,
} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo from 'react-native-device-info';

import {
  getCommonListRequest,
  getCountryListRequest,
} from '../../redux/reducer/ProfileReducer';

import {AnimatedCircularProgress} from 'react-native-circular-progress';
import moment from 'moment';
var status = '';

export default function Dashboard() {
  const profileDetailsRes = useSelector(
    state => state.ProfileReducer?.profileResponse,
  );
  // const load = useSelector(
  //   state => state.ProfileReducer?.loading
  // )
  const {loading, profile_status, dashboardStatus} = useSelector(
    state => state.ProfileReducer,
  );
  const dispatch = useDispatch();
  const [setupStep, setSetupStep] = useState(true);
  const [loadFlag, setLoadFlag] = useState(false);
  const [closeBanner, setCloseBanner] = useState(false);
  const [money, setMoney] = useState(true);
  const [refreshing, setRefresing] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [toggleButtonFlag, setToggleButtonFlag] = useState(false);
  const [steps, setSteps] = useState([
    'Set up your general account',
    'Set up your company account',
    'Create your first Client',
    'Raise your first Invoice',
  ]);
  const overViewSteps = [
    1,2,3
  ]
  const [overview, setOverview] = useState(true);
  const [filterProgress,setFillProgress] = useState(0)
  const [currentYear, setCurrentYear] = useState(moment().year());
  if (status == '' || status != profile_status) {
    switch (profile_status) {
      case 'Profile/getProfileStatusRequest':
        status = profile_status;
        break;
      case 'Profile/getProfileStatusSuccess':
        status = profile_status;

        setTimeout(() => {
          checkProfile();
        }, 2000);
        break;
      case 'Profile/getProfileStatusFailure':
        status = profile_status;
        setTimeout(() => {
          checkProfile();
        }, 2000);
        break;
    }
  }

  // useEffect(()=> {
  //   let progressval = 0
  //   if(dashboardStatus?.isVerified){
      
  //     //setFillProgress(prev => prev+20)
  //     //setFillProgress(progressval + 20)
  //     progressval = progressval + 20
  //   }
  //   if(dashboardStatus?.userCompany !== null){
  //     //setFillProgress(progressval + 20)
      
  //     progressval = progressval + 20
  //     //setFillProgress(prev => prev+20)
  //   }
  //   if(dashboardStatus?.InvoiceOptionSetting !== null && dashboardStatus?.InvoiceSetting !== null){
  //     //alert("hii")
  //     //setFillProgress(prev => prev+20)
  //     //setFillProgress(progressval + 20)
  //     progressval = progressval + 20
  //   }
  //   if(dashboardStatus?.clientCreation){
      
  //     setFillProgress(progressval + 20)
  //     //setFillProgress(prev => prev+20)
  //   }
  //   if(dashboardStatus?.invoiceCreation){
  //     //alert("hii")
  //     //setFillProgress(prev => prev+20)
  //     //setFillProgress(progressval + 20)
  //     progressval = progressval + 20
  //   }
  //   setFillProgress(progressval)

  // },[dashboardStatus])

  useEffect(() => {
  let progressval = 0;

  if (dashboardStatus?.isVerified) {
    progressval += 25;
  }

  if (dashboardStatus?.userCompany !== null) {
    progressval += 25;
  }

  // if (
  //   dashboardStatus?.InvoiceOptionSetting !== null &&
  //   dashboardStatus?.InvoiceSetting !== null
  // ) {
  //   progressval += 20;
  // }

  if (dashboardStatus?.clientCreation) {
    progressval += 25;
  }

  if (dashboardStatus?.invoiceCreation) {
    progressval += 25;
  }
  if(progressval === 100){
    setSetupStep(false)
  }

  setFillProgress(progressval);
}, [dashboardStatus]);
  useEffect(() => {
    //getProfile();
    callCommon();
    //getCountryList();
    //alert("hii")
    //console.log("profile resp",JSON.stringify(profileDetailsRes))
    //checkProfile();
  }, []);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  const checkProfile = () => {
    //alert(profileDetailsRes?.isVerified)
    // 'Setup your Currency, Payment and Invoice template',
    // 'Create your first Client'
    // if (profileDetailsRes?.isVerified && profileDetailsRes?.isSubscribed) {
    //   var arr = [];
    //   arr.push('Set up your general account');
    //   arr.push('Set up your company account');
    //   arr.push('Setup your Currency, Payment \nand Invoice template');
    //   arr.push('Create your first Client');
    //   setSteps(arr);
    // } else if (
    //   profileDetailsRes?.isVerified &&
    //   !profileDetailsRes?.isSubscribed
    // ) {
    //   var arr = [];
    //   arr.push('Set up your general account');
    //   arr.push('Set up your company account');
    //   arr.push('Setup your Currency, Payment \nand Invoice template');
    //   setSteps(arr);
    // }
    if (dashboardStatus?.isVerified == false) {
      setLoadFlag(true);
      setTimeout(() => {
        setLoadFlag(false);
        navigate('AddCompanyDetails');
      }, 3000);
    } else if (dashboardStatus?.isSubscribed == false) {
      setLoadFlag(true);
      setTimeout(() => {
        setLoadFlag(false);
        navigate('Subscription');
      }, 3000);
    }
  };
  const callCommon = () => {
    dispatch(getCommonListRequest());
  };
  useFocusEffect(
    useCallback(() => {
      // This function will be called when the screen is focused
      console.log('Screen is focused');

      // Call your function here
      let payload = {};
      getClientRequest(payload);
      getProfile();
      getUserprofile();
      getAllAppointments();
    }, []),
  );

  const getAllAppointments = () => {
    const today = moment();
    const isCurrentYear = currentYear === today.year();
    const currentMonth = isCurrentYear ? today.month() + 1 : 1;

    //const currentMonth = moment().month() + 1;
    let payload = {
      month: currentMonth,
      year: currentYear,
    };
    dispatch(getAppointmentListRequest(payload));
  };
  const getCountryList = () => {
    dispatch(getCountryListRequest());
  };

  const getProfile = () => {
    let payload = {};
    dispatch(getProfileRequest(payload));
  };

  const getUserprofile = () => {
    let payload = {};
    dispatch(getProfileStatusRequest(payload));
  };
  const _onRefresh = () => {
    setRefresing(true);
    setCloseBanner(false);
    setRefresing(false);
  };
  return (
    <SafeAreaView style={styles.container}>
      {/* <Loader
        visible={!profileDetailsRes?.isVerified}
        msg={'Checking your profile status...'}
        backgroundColor={COLORS?.themeColor}
      /> */}

      {/* {!profileDetailsRes?.isVerified ? (
        <View
          style={{
            height: Dimensions?.get('window')?.height,
            width: Dimensions?.get('window')?.width,
            backgroundColor: 'rgba(0,0,0,0.2)',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            zIndex: 10,
          }}>
          <View
            style={{
              width: '90%',
              padding: ms(10),
              borderRadius: ms(10),
              backgroundColor: COLORS?.white,
            }}>
            <ActivityIndicator color={COLORS.themeColor} size={'large'} />
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(18),
                color: COLORS?.themeColor,
                textAlign: 'center',
              }}>
              {'Checking your profile status...'}
            </Text>
          </View>
        </View>
      ) : null} */}

      <MyStatusBar />
      <Header backVisible={false} />
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          // justifyContent: 'center',
          flex: 1,
        }}
        source={IMAGES?.colorBackground}>
        <ScrollView
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={_onRefresh} />
          }
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1}}>
            {filterProgress === 100?null:<View
              style={{
                margin: ms(15),
                marginTop: ms(0),
                borderWidth: ms(1),
                borderColor: 'rgba(4, 127, 255, 0.25)',
                width: '90%',
                borderRadius: ms(11),
                backgroundColor: COLORS.white,
                shadowOffset: {width: 0, height: 0},
                shadowColor: 'rgba(4, 127, 255, 0.1)',
                shadowOpacity: 20,
                elevation: 5,
                paddingBottom: setupStep ? ms(20) : ms(0),
                alignSelf: 'center',
              }}>
              <View
                style={{
                  gap: ms(10),
                  flexDirection: 'row',
                  alignItems: 'center',
                  //paddingVertical:ms(20)
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginVertical: ms(10),
                    marginLeft: ms(10),

                    //backgroundColor:'red'
                    //marginTop: ms(20),
                  }}>
                  {/* <Image
                    source={ICONS?.completeMark}
                    style={{height: ms(50), width: ms(50)}}
                    resizeMode="contain"
                  /> */}
                  <AnimatedCircularProgress
                    //size={50}
                    size={isTablet ? 70 : 60}
                    width={5}
                    fill={ filterProgress
                      // dashboardStatus?.isVerified
                      //   ? 20
                      //   : profileDetailsRes?.useCompany!== null
                      //   ? 20
                      //   : 10
                    }
                    tintColor="#34A853"
                    onAnimationComplete={() =>
                      console.log('onAnimationComplete')
                    }
                    backgroundColor="#FFF"
                  />
                  <Text
                    style={{
                      position: 'absolute',
                      left: ms(10),
                      fontFamily: FONTS?.ExtraBold,
                      fontSize: ms(12),
                    }}>
                    {filterProgress/* {profileDetailsRes?.isVerified &&
                    profileDetailsRes?.isSubscribed
                      ? 30
                      : profileDetailsRes?.isVerified
                      ? 20
                      : 10} */}
                      
                    %
                  </Text>
                </View>
                <View style={{marginVertical: ms(20), marginLeft: ms(10)}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(10),
                      textTransform: 'uppercase',
                      color: '#344054',
                    }}>
                    Complete Your Setup guide
                  </Text>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(10),
                      textTransform: 'capitalize',
                      color: COLORS?.themeColor,
                    }}>
                    Your profile completion is at{' '}
                    {/* {profileDetailsRes?.isVerified &&
                    profileDetailsRes?.isSubscribed
                      ? 30
                      : profileDetailsRes?.isVerified
                      ? 20
                      : 10} */}
                      {filterProgress}
                    %
                  </Text>
                  <Text
                    style={{
                      fontSize: ms(10),
                      color: '#8990A1',
                      fontFamily: FONTS.Regular,
                    }}>
                    You are so close! Complete Now
                  </Text>
                </View>
                <TouchableOpacity
                  style={{
                    padding: ms(4),
                    alignItems: 'flex-end',
                    backgroundColor: COLORS?.themeColor,
                    position: 'absolute',
                    right: ms(0),
                    height: '100%',
                    justifyContent: 'center',
                    borderTopRightRadius: ms(10),
                    borderBottomRightRadius: ms(10),
                    borderBottomLeftRadius: setupStep ? ms(10) : ms(0),
                  }}
                  onPress={() => {
                    setSetupStep(!setupStep);
                  }}>
                  <Image
                    source={ICONS?.upArrow}
                    style={{
                      height: ms(15),
                      width: ms(15),
                      transform: [{rotate: !setupStep ? '180deg' : '0deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              {setupStep
                ? steps?.map((item, index) => {
                    return (
                      <View
                        style={{
                          // marginTop: ms(10),
                          //elevation: 5,
                          borderWidth: ms(0.1),
                          shadowColor: 'rgba(4, 127, 255, 0.2)',

                          // marginTop: mvs(10),
                          width: '90%',
                          alignSelf: 'center',
                          justifyContent: 'center',
                          padding: ms(10),
                          marginTop: index == 0 ? ms(0) : -ms(10),
                          backgroundColor: COLORS.white,
                        }}>
                        <TouchableOpacity
                          onPress={() => {
                            if (index == 1) {
                              if (!dashboardStatus?.isVerified) {
                                navigate('AddCompanyDetails');
                              } else if (!dashboardStatus?.isSubscribed) {
                                navigate('Subscription');
                              }
                            } else if (index == 2) {
                               
                                if (!dashboardStatus?.clientCreation) {
                                  navigate('CreateClient');
                                }
                            } else if (index == 3) {
                                if (!dashboardStatus?.invoiceCreation) {
                                  navigate('AddInvoiceWithoutClient');
                                }
                              }
                            // else if (index == 2) {
                            //   if (!profileDetailsRes?.isSubscribed) {
                            //     navigate('Subscription');
                            //   }
                            // profileDetailsRes?.companyTaxDetails !=
                            //           null &&
                            //         profileDetailsRes?.companyLanguageDetails !=
                            //           null &&
                            //         profileDetailsRes?.companyLanguageDetails !=
                            //           null &&
                            //         profileDetailsRes?.companyPaymentDetails !=
                            //           null
                            // }
                          }}
                          style={{
                            borderWidth: ms(0.6),
                            borderColor: 'rgba(4, 127, 255, 0.25)',
                            padding: ms(10),
                            elevation: ms(5),
                            backgroundColor: COLORS.white,
                            shadowColor: COLORS.themeColor,

                            // height: ms(42),

                            flexDirection: 'row',
                            alignItems: 'center',
                            borderRadius: ms(4),
                            //
                            gap: ms(10),
                          }}>
                          <View
                            style={{
                              height: ms(23),
                              width: ms(23),
                              borderRadius: ms(12),
                              backgroundColor:
                                index === 0
                                  ? COLORS.themeColor
                                  : index === 1 &&
                                    dashboardStatus?.isVerified &&
                                    dashboardStatus?.isSubscribed
                                  ? COLORS.themeColor
                                  
                                  : index === 2 &&
                                    dashboardStatus?.clientCreation
                                  ? COLORS.themeColor
                                  : index === 3 &&
                                    dashboardStatus?.invoiceCreation
                                  ? COLORS.themeColor
                                  : 'rgba(229, 231, 235, 1)',
                              // index == 0 || index == 1
                              //   ? COLORS?.themeColor
                              //   : COLORS?.gray,

                              alignItems: 'center',
                              justifyContent: 'center',
                            }}>
                            <Image
                              source={ICONS?.tick}
                              style={{height: ms(16), width: ms(16)}}
                            />
                          </View>
                          <Text
                            style={{
                              fontFamily: FONTS?.Regular,
                              fontSize: ms(12),
                              color: COLORS?.black,
                              textDecorationLine:
                                index === 0
                                  ? 'line-through'
                                  : index === 1 &&
                                    dashboardStatus?.isVerified &&
                                    dashboardStatus?.isSubscribed
                                  ? 'line-through'
                                  
                                  : index === 2 &&
                                    dashboardStatus?.clientCreation
                                  ? 'line-through'
                                  : index === 3 &&
                                    dashboardStatus?.invoiceCreation
                                  ? 'line-through'
                                  : 'none',
                            }}>
                            {item}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    );
                  })
                : // <FlatList
                  //   data={steps}
                  //   style={{marginBottom: ms(20)}}
                  //   initialNumToRender={3}
                  //   renderItem={({item, index}) => {
                  //     return (
                  //       <TouchableOpacity
                  //         onPress={() => {
                  //           if (index == 1) {
                  //             if (!profileDetailsRes?.isVerified) {
                  //               navigate('AddCompanyDetails');
                  //             } else if (!profileDetailsRes?.isSubscribed) {
                  //               navigate('Subscription');
                  //             }
                  //           } else if (index == 2) {
                  //             if (profileDetailsRes?.companyTaxDetails == null) {
                  //               navigate('TaxCurrency');
                  //             } else if (
                  //               profileDetailsRes?.companyPaymentDetails == null
                  //             ) {
                  //               navigate('ClientPaymentOption');
                  //             }
                  //           }
                  //           // else if (index == 2) {
                  //           //   if (!profileDetailsRes?.isSubscribed) {
                  //           //     navigate('Subscription');
                  //           //   }
                  //           // profileDetailsRes?.companyTaxDetails !=
                  //           //           null &&
                  //           //         profileDetailsRes?.companyLanguageDetails !=
                  //           //           null &&
                  //           //         profileDetailsRes?.companyLanguageDetails !=
                  //           //           null &&
                  //           //         profileDetailsRes?.companyPaymentDetails !=
                  //           //           null
                  //           // }
                  //         }}
                  //         style={{
                  //           borderWidth: ms(1),
                  //           paddingHorizontal: ms(10),
                  //           height: ms(42),
                  //           marginTop: mvs(10),
                  //           width: '90%',
                  //           alignSelf: 'center',
                  //           borderRadius: ms(4),
                  //           flexDirection: 'row',
                  //           alignItems: 'center',
                  //           borderColor: 'rgba(4, 127, 255, 0.25)',
                  //           shadowColor: 'rgba(4, 127, 255, 0.1)',
                  //           gap: ms(10),
                  //           elevation: 5,
                  //         }}>
                  //         <View
                  //           style={{
                  //             height: ms(23),
                  //             width: ms(23),
                  //             borderRadius: ms(12),
                  //             backgroundColor:
                  //               index === 0
                  //                 ? COLORS.themeColor
                  //                 : index === 1 &&
                  //                   profileDetailsRes?.isVerified &&
                  //                   profileDetailsRes?.isSubscribed
                  //                 ? COLORS.themeColor
                  //                 : index === 2 &&
                  //                   profileDetailsRes?.companyTaxDetails !=
                  //                     null &&
                  //                   profileDetailsRes?.companyLanguageDetails !=
                  //                     null &&
                  //                   profileDetailsRes?.companyLanguageDetails !=
                  //                     null &&
                  //                   profileDetailsRes?.companyPaymentDetails !=
                  //                     null
                  //                 ? COLORS.themeColor
                  //                 : // : index === 2 && profileDetailsRes?.isSubscribed
                  //                   // ? COLORS.themeColor
                  //                   'rgba(229, 231, 235, 1)',
                  //             // index == 0 || index == 1
                  //             //   ? COLORS?.themeColor
                  //             //   : COLORS?.gray,

                  //             alignItems: 'center',
                  //             justifyContent: 'center',
                  //           }}>
                  //           <Image
                  //             source={ICONS?.tick}
                  //             style={{height: ms(16), width: ms(16)}}
                  //           />
                  //         </View>
                  //         <Text
                  //           style={{
                  //             fontFamily: FONTS?.Regular,
                  //             fontSize: ms(12),
                  //             color: COLORS?.black,
                  //             textDecorationLine:
                  //               index === 0
                  //                 ? 'line-through'
                  //                 : index === 1 &&
                  //                   profileDetailsRes?.isVerified &&
                  //                   profileDetailsRes?.isSubscribed
                  //                 ? 'line-through'
                  //                 : index === 2 &&
                  //                   profileDetailsRes?.companyTaxDetails ==
                  //                     null &&
                  //                   profileDetailsRes?.companyLanguageDetails !=
                  //                     null &&
                  //                   profileDetailsRes?.companyLanguageDetails !=
                  //                     null &&
                  //                   profileDetailsRes?.companyPaymentDetails !=
                  //                     null
                  //                 ? // : index === 2 && profileDetailsRes?.isSubscribed
                  //                   'line-through'
                  //                 : 'none',
                  //           }}>
                  //           {item}
                  //         </Text>
                  //       </TouchableOpacity>
                  //     );
                  //   }}
                  // />
                  null}
            </View>}
            
            {!closeBanner ? (
              <View style={{}}>
                <Image
                  source={IMAGES?.banncerpic}
                  style={{
                    width: '90%',
                    //height: mvs(173),
                    //height: mvs(265),
                    height: isTablet
                      ? Dimensions.get('window').height * 0.31
                      : mvs(173),
                    alignSelf: 'center',
                    marginLeft: ms(3),
                    // backgroundColor: '#FF0',
                  }}
                  resizeMode="contain"
                />
                {/* <View
                  style={{
                    backgroundColor: '#f3faff', //
                    position: 'absolute',
                    width: '40%',
                    bottom: ms(0),
                    right: ms(20),
                    paddingHorizontal: ms(10),
                    paddingTop: ms(10),
                    borderRadius: ms(15),
                  }}>
                  <TouchableOpacity
                    style={{
                      backgroundColor: COLORS?.themeColor,
                      padding: ms(15),
                      borderRadius: ms(15),
                    }}>
                    <Text style={{color: COLORS?.white, textAlign: 'center'}}>
                      Tell Me More
                    </Text>
                  </TouchableOpacity>
                </View> */}
                <TouchableOpacity
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(5),
                    position: 'absolute',
                    right: ms(45),
                    top: ms(15),
                  }}
                  onPress={() => {
                    setCloseBanner(true);
                  }}>
                  <Text
                    style={{
                      color: COLORS?.white,
                      fontFamily: FONTS?.Light,
                      fontSize: ms(12),
                      textDecorationLine: 'underline',
                    }}>
                    Close
                  </Text>
                  <Image
                    source={ICONS?.close}
                    style={{height: ms(13), width: ms(13)}}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
            ) : null}
            <View
              style={{
                margin: mvs(15),

                width: '90%',
                borderRadius: ms(10),
                backgroundColor: COLORS?.white,
                padding: ms(10),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.2)',
                alignSelf: 'center',
              }}>
              <View
                style={{
                  gap: ms(10),
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#e6f2ff',
                  padding: ms(10),
                  borderRadius: ms(10),
                }}>
                <View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(13),
                      textTransform: 'capitalize',
                      color: COLORS?.themeColor,
                    }}>
                    Overview
                  </Text>
                </View>
                <TouchableOpacity
                  style={{
                    padding: ms(3),
                    alignItems: 'center',
                    position: 'absolute',
                    right: ms(10),
                    height: '100%',
                    justifyContent: 'center',
                    borderTopRightRadius: ms(10),
                    borderBottomRightRadius: ms(10),
                    borderBottomLeftRadius: setupStep ? ms(10) : ms(0),
                    flexDirection: 'row',
                    gap: ms(5),
                  }}
                  onPress={() => {
                    setOverview(!overview);
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                      textDecorationLine: 'underline',
                    }}>
                    {!overview ? 'Expand' : 'Hide'}
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(10),
                      width: ms(10),
                      transform: [{rotate: !overview ? '180deg' : '0deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              {overview ? (
                <FlatList
                  data={overViewSteps}
                  style={{marginBottom: ms(20)}}
                  renderItem={({item, index}) => {
                    return (
                      <View
                        style={{
                          elevation: 5,

                          //backgroundColor:'red',
                          // borderWidth: ms(0.1),
                          shadowColor: 'rgba(4, 127, 255, 0.2)',
                          borderColor: COLORS?.themeColor,
                          marginTop: mvs(10),
                          // width: '90%',
                          alignSelf: 'center',
                          justifyContent: 'center',
                          padding: ms(15),
                          shadowRadius: ms(11),
                          borderRadius: ms(11),

                          // marginTop: index == 0 ? ms(0) : -ms(10),
                        }}>
                        <View
                          style={{
                            //borderWidth: ms(0.2),

                            // padding: ms(10),
                            // marginTop: mvs(20),
                            width: '100%',
                            alignSelf: 'center',
                            borderRadius: ms(11),
                            flexDirection: 'row',
                            alignItems: 'center',
                            height: ms(56),
                            paddingHorizontal: ms(10),
                            // borderColor: COLORS?.themeColor,
                            // shadowOffset: {width: -2, height: 4},
                            // shadowColor: 'rgba(4, 127, 255, 0.2)',
                            // shadowOpacity: 0.2,
                            // shadowRadius: 3,
                            justifyContent: 'space-between',
                            paddingTop: ms(10),
                            // elevation: ms(5),
                          }}>
                          <View>
                            <Text
                              style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(10),
                                color: 'rgba(52, 64, 84, 1)',
                              }}>
                                {index == 0 ? 'Sent Invoices': 
                                index == 1? 'Unsent Invoices' : 
                                index == 2 ?'Total Invoices':
                                null}
                              
                            </Text>
                            <Text
                              style={{
                                fontFamily: FONTS?.Medium,
                                fontSize: ms(18),
                                color: 'rgba(52, 64, 84, 1)',
                              }}>
                               {index == 0 ?
                               dashboardStatus?.invoiceStats?.totalSentAmount: 
                                index == 1? dashboardStatus?.invoiceStats?.totalUnsentAmount : 
                                index == 2 ?dashboardStatus?.invoiceStats?.totalAmount:
                                null}
                            </Text>
                          </View>
                          <View>
                            <Text
                              style={{
                                fontFamily: FONTS?.Medium,
                                fontSize: ms(10),
                                color: 'rgba(33, 150, 83, 1)',
                                textAlign: 'right',
                              }}>
                              ${index == 0 ?
                               dashboardStatus?.invoiceStats?.thisMonthSentAmount: 
                                index == 1? dashboardStatus?.invoiceStats?.thisMonthUnsentAmount : 
                                index == 2 ?dashboardStatus?.invoiceStats?.thisMonthTotalAmount:
                                null}
                            </Text>
                            <Text
                              style={{
                                fontFamily: FONTS?.Regular,
                                fontSize: ms(10),
                                color: 'rgba(52, 64, 84, 1)',
                                textAlign: 'right',
                              }}>
                              {'This Month'}
                            </Text>
                          </View>
                        </View>
                      </View>
                    );
                  }}
                />
              ) : // <FlatList
              //   contentContainerStyle={{marginTop:ms(15)}}
              //   data={steps}
              //   renderItem={({item, index}) => {
              //     return (
              //       <View
              //         style={{
              //           backgroundColor: COLORS.white,
              //           padding: ms(15),
              //           alignSelf: 'center',
              //           width: '100%',
              //           elevation: 10,
              //           borderWidth: ms(0.2),
              //           borderColor: COLORS.border,
              //           borderRadius: ms(10),
              //           marginBottom: ms(15),
              //           shadowColor:COLORS.themeColor
              //         }}>
              //         <View
              //           style={{
              //             flexDirection: 'row',
              //             alignItems: 'center',
              //             justifyContent: 'space-between',
              //           }}>
              //           <View>
              //             <Text
              //               style={{
              //                 fontFamily: FONTS?.Regular,
              //                 fontSize: ms(10),
              //                 color: 'rgba(52, 64, 84, 1)',
              //               }}>
              //               {'Overdue Invoices'}
              //             </Text>
              //             <Text
              //               style={{
              //                 fontFamily: FONTS?.Medium,
              //                 fontSize: ms(18),
              //                 color: 'rgba(52, 64, 84, 1)',
              //               }}>
              //               {'$125'}
              //             </Text>
              //           </View>
              //           ;
              //           <View>
              //             <Text
              //               style={{
              //                 fontFamily: FONTS?.Medium,
              //                 fontSize: ms(10),
              //                 color: 'rgba(33, 150, 83, 1)',
              //                 textAlign: 'right',
              //               }}>
              //               {'+ $500.00'}
              //             </Text>
              //             <Text
              //               style={{
              //                 fontFamily: FONTS?.Regular,
              //                 fontSize: ms(10),
              //                 color: 'rgba(52, 64, 84, 1)',
              //                 textAlign: 'right',
              //               }}>
              //               {'This Month'}
              //             </Text>
              //           </View>
              //           ;
              //         </View>
              //       </View>
              //     );
              //   }}
              // />
              null}
            </View>

            <View
              style={{
                margin: mvs(15),
                marginTop: ms(0),
                width: '90%',
                borderRadius: ms(10),
                backgroundColor: COLORS?.white,
                padding: ms(10),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.2)',
                marginBottom: ms(55),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.2)',
                alignSelf: 'center',
              }}>
              <View
                style={{
                  gap: ms(10),
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#e6f2ff',
                  padding: ms(10),
                  borderRadius: ms(10),
                }}>
                <View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(13),
                      textTransform: 'capitalize',
                      color: COLORS?.themeColor,
                    }}>
                    Money (In Last 30 Days)
                  </Text>
                </View>
                <TouchableOpacity
                  style={{
                    padding: ms(3),
                    alignItems: 'center',
                    position: 'absolute',
                    right: ms(10),
                    height: '100%',
                    justifyContent: 'center',
                    borderTopRightRadius: ms(10),
                    borderBottomRightRadius: ms(10),
                    borderBottomLeftRadius: setupStep ? ms(10) : ms(0),
                    flexDirection: 'row',
                    gap: ms(5),
                  }}
                  onPress={() => {
                    //setOverview(!overview);
                    setMoney(!money);
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                      textDecorationLine: 'underline',
                    }}>
                    {!money ? 'Expand' : 'Hide'}
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(10),
                      width: ms(10),
                      transform: [{rotate: !money ? '180deg' : '0deg'}],
                    }}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              {money ? (
                <FlatList
                  data={steps}
                  style={{marginBottom: ms(20)}}
                  renderItem={({item, index}) => {
                    return (
                      <View
                        style={{
                          elevation: 5,
                          // borderWidth: ms(0.1),
                          shadowColor: 'rgba(4, 127, 255, 0.2)',
                          borderColor: COLORS?.themeColor,
                          marginTop: mvs(10),
                          // width: '90%',
                          alignSelf: 'center',
                          justifyContent: 'center',
                          padding: ms(15),
                          shadowRadius: ms(11),
                          borderRadius: ms(11),

                          // marginTop: index == 0 ? ms(0) : -ms(10),
                        }}>
                        <View
                          style={{
                            // borderWidth: ms(0.2),
                            // padding: ms(10),
                            // marginTop: mvs(20),
                            width: '100%',
                            alignSelf: 'center',
                            borderRadius: ms(11),
                            flexDirection: 'row',
                            alignItems: 'center',
                            height: ms(56),
                            paddingHorizontal: ms(7),
                            // borderColor: COLORS?.themeColor,
                            // shadowOffset: {width: -2, height: 4},
                            // shadowColor: 'rgba(4, 127, 255, 0.2)',
                            // shadowOpacity: 0.2,
                            // shadowRadius: 3,
                            justifyContent: 'space-between',
                            paddingTop: ms(10),
                            // elevation: ms(5),
                          }}>
                          <View>
                            {index == 1 ? (
                              <View
                                style={{
                                  flexDirection: 'row',
                                  alignItems: 'center',
                                }}>
                                <View
                                  style={{
                                    backgroundColor: 'rgba(4, 127, 255, 0.2)',
                                    padding: ms(8),
                                    borderRadius: ms(5),
                                  }}>
                                  <Image
                                    resizeMode="contain"
                                    style={{height: ms(35), width: ms(35)}}
                                    source={ICONS.card_payment}
                                  />
                                </View>
                                <View style={{marginLeft: ms(20)}}>
                                  <Text
                                    style={{
                                      fontFamily: FONTS.Regular,
                                      fontSize: ms(12),
                                      color: '#344054',
                                    }}>
                                    Credit/Debit Cards
                                  </Text>
                                  <Text
                                    style={{
                                      fontSize: ms(18),
                                      fontFamily: FONTS.Medium,
                                      color: '#344054',
                                    }}>
                                    $125
                                  </Text>
                                </View>
                              </View>
                            ) : index == 2 ? (
                              <View
                                style={{
                                  flexDirection: 'row',
                                  alignItems: 'center',
                                }}>
                                <View
                                  style={{
                                    backgroundColor: 'rgba(4, 127, 255, 0.2)',
                                    padding: ms(8),
                                    borderRadius: ms(5),
                                  }}>
                                  <Image
                                    resizeMode="contain"
                                    style={{height: ms(35), width: ms(35)}}
                                    source={ICONS.bank_transfer}
                                  />
                                </View>
                                <View style={{marginLeft: ms(20)}}>
                                  <Text
                                    style={{
                                      fontFamily: FONTS.Regular,
                                      fontSize: ms(12),
                                      color: '#344054',
                                    }}>
                                    Bank Transfer
                                  </Text>
                                  <Text
                                    style={{
                                      fontSize: ms(18),
                                      fontFamily: FONTS.Medium,
                                      color: '#344054',
                                    }}>
                                    $125
                                  </Text>
                                </View>
                              </View>
                            ) : index == 3 ? (
                              <View
                                style={{
                                  flexDirection: 'row',
                                  alignItems: 'center',
                                }}>
                                <View
                                  style={{
                                    backgroundColor: 'rgba(4, 127, 255, 0.2)',
                                    padding: ms(8),
                                    borderRadius: ms(5),
                                  }}>
                                  <Image
                                    resizeMode="contain"
                                    style={{height: ms(35), width: ms(35)}}
                                    source={ICONS.paypal}
                                  />
                                </View>
                                <View style={{marginLeft: ms(20)}}>
                                  <Text
                                    style={{
                                      fontFamily: FONTS.Regular,
                                      fontSize: ms(12),
                                      color: '#344054',
                                    }}>
                                    PayPal
                                  </Text>
                                  <Text
                                    style={{
                                      fontSize: ms(18),
                                      fontFamily: FONTS.Medium,
                                      color: '#344054',
                                    }}>
                                    $125
                                  </Text>
                                </View>
                              </View>
                            ) : (
                              <View>
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Regular,
                                    fontSize: ms(10),
                                    color: 'rgba(52, 64, 84, 1)',
                                  }}>
                                  {'Overdue Invoices'}
                                </Text>
                                <Text
                                  style={{
                                    fontFamily: FONTS?.Medium,
                                    fontSize: ms(18),
                                    color: 'rgba(52, 64, 84, 1)',
                                  }}>
                                  {dashboardStatus?.invoiceStats?.totalOverDueAmount}
                                </Text>
                              </View>
                            )}
                          </View>
                          {index == 1 || index == 2 || index == 3 ? (
                            <View style={{width: ms(56)}} />
                          ) : (
                            <View>
                              <Text
                                style={{
                                  fontFamily: FONTS?.Medium,
                                  fontSize: ms(10),
                                  color: 'rgba(33, 150, 83, 1)',
                                  textAlign: 'right',
                                }}>
                                {`+ $${dashboardStatus?.invoiceStats?.thisMonthOverDueAmount}`}
                              </Text>
                              <Text
                                style={{
                                  fontFamily: FONTS?.Regular,
                                  fontSize: ms(10),
                                  color: 'rgba(52, 64, 84, 1)',
                                  textAlign: 'right',
                                }}>
                                {'This Month'}
                              </Text>
                            </View>
                          )}
                        </View>
                      </View>
                    );
                  }}
                />
              ) : null}
            </View>
          </View>
        </ScrollView>
        {/* <View
          style={{
            //marginTop: -ms(80),
            //backgroundColor: 'rgb(232, 243, 255)',
            height: ms(64),
            width: ms(64),
            borderRadius: ms(32),
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(2),
            zIndex: 1,
            right: 10,
            borderColor: COLORS.border,
            //borderWidth: 2,
          }}>
          <View
            style={{
              height: ms(50),
              width: ms(50),
              borderRadius: ms(25),
              backgroundColor: COLORS?.themeColor,

              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[
                styles.iconStyle,
                {tintColor: COLORS?.white, marginRight: ms(0)},
              ]}
            />
          </View>
        </View> */}
      </ImageBackground>
      <TouchableOpacity
        style={{
          height: ms(50),
          width: ms(50),
          borderRadius: ms(25),
          backgroundColor: COLORS?.themeColor,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(20),
          right: ms(20),
          zIndex: 10,
        }}
        onPress={() => {
          setToggleButtonFlag(!toggleButtonFlag);
        }}>
        {!toggleButtonFlag ? (
          <Image
            source={ICONS.addMore}
            resizeMode="contain"
            style={[styles.iconStyle, {tintColor: COLORS?.white}]}
          />
        ) : (
          <Image
            source={ICONS?.addMore}
            //style={[styles.iconStyle, {height: ms(50), width: ms(50)}]}
            style={[
              styles.iconStyle,
              {
                tintColor: COLORS?.white,
                borderRadius: ms(10),
                transform: [{rotate: '45deg'}],
              },
            ]}
          />
        )}
      </TouchableOpacity>
      {toggleButtonFlag ? (
        <View
          style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0, 0.5)',
            height: Dimensions?.get('window')?.height,
            width: Dimensions?.get('window')?.width,
            position: 'absolute',
          }}>
          <View
            style={{
              position: 'absolute',
              backgroundColor: COLORS?.white,
              width: ms(190),
              paddingVertical: ms(10),
              bottom: ms(106),
              right: ms(20),
              borderRadius: ms(8),
              paddingHorizontal: ms(4),
            }}>
            <TouchableOpacity
              onPress={() => navigate('AddCreditNoteWithoutClient')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                // paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Credit Note
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddPurchaseOrderWithoutClient')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Purchase Order
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddEstimateWithoutClient')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Estimate
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigate('AddInvoiceWithoutClient')}
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
                borderBottomWidth: ms(0.4),
                borderBottomColor: '#E5E7EB',
                paddingHorizontal: ms(8),
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Invoice
              </Text>
              <Image
                source={ICONS?.addMore}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: ms(10),
                paddingVertical: ms(6),
              }}>
              <Text style={{color: '#344054', opacity: 0.25}}>Statement</Text>
              <Image
                source={ICONS?.download}
                style={{
                  height: ms(15),
                  width: ms(15),
                  tintColor: COLORS?.themeColor,
                  opacity: 0.25,
                }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
    // tintColor: COLORS.dark_grey,
    //marginRight: ms(10),
  },
});
