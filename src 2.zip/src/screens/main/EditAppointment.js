import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {
  getClientRequest,
  addAppointmentRequest,
  updateAppointmentRequest,
  getAppointmentContactsRequest,
} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import constants from '../../utils/helpers/constants';
import {pick} from '@react-native-documents/picker';
import Loader from '../../utils/helpers/Loader';
import DeviceInfo from 'react-native-device-info';
import Toast from '../../utils/helpers/Toast';
import AsyncStorage from '@react-native-async-storage/async-storage';
const SEARCH_HISTORY_KEY = 'searchHistory';

export default function EditAppointment(props) {
  console.log(props.route.params.item);
  const prevApp = props.route.params.item;
  let myDocc = {
    name: prevApp?.document,
  };
  const [isTablet, setIsTablet] = useState(false);
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [projectName, setProjectName] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('');
  const [note, setNote] = useState(prevApp?.notes);
  const [clientModal, setClientModal] = useState(false);
  const [openStart, setOpenStart] = useState(false);
  const [startDate, setStartDate] = useState(new Date(prevApp?.start_date));
  const [openEnd, setOpenEnd] = useState(false);
  const [endDate, setEnddate] = useState(new Date(prevApp?.end_date));
  const [clientId, setClientId] = useState('');
  const {clientList, appointmentContacts,loading} = useSelector(state => state.ProfileReducer);
  const [openAddressModal, setOpenAddressModal] = useState(false);
  const [from, setFrom] = useState('');
  const [myDoc, setMydoc] = useState(myDocc);
  const [selctedContact, setSelectedContact] = useState('');
  const [searchHistory, setSearchHistory] = useState([]);
  const [filteredClient, setFilteredClient] = useState(clientList);
   const [contactModal, setContactModal] = useState(false);
   const [contactsPrimary, setContactsPrimary] = useState([]);
     const [contactsSecondary, setContactSecondary] = useState([]);
     const [selectedContactIds, setSelectedContactIds] = useState(new Set());
     const [addedContacts, setAddedContacts] = useState(prevApp?.contacts||[]);
  const [appointmentLocation, setAppointmentLocation] = useState(
    prevApp?.location,
  );
  const [selectedClient, setSelectedClient] = useState(prevApp?.client);
  useEffect(() => {
    getClient();
  }, []);
  useEffect(() => {
    // if (clientList) {
    //   setFilteredClient(clientList);
    // }
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useEffect(() => {
    setFilteredClient(clientList);
  }, [clientList]);
  const getClient = () => {
    let payload = {};
    dispatch(getClientRequest(payload));
    dispatch(getAppointmentContactsRequest(payload))
  };
useEffect(() => {
    
    setContactsPrimary(appointmentContacts?.primary);
    setContactSecondary(appointmentContacts?.secondary);

    
  }, [appointmentContacts]);
  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await AsyncStorage.getItem(SEARCH_HISTORY_KEY);
      if (history) {
        console.log("my search history",history)
        setSearchHistory(JSON.parse(history));
      }
    } catch (error) {
      console.error('Error loading search history:', error);
    }
  };
  const saveSearchHistory = async (newPlace) => {
    try {
      let updatedHistory = [newPlace, ...searchHistory.filter(item => item.description !== newPlace.description)];
      updatedHistory = updatedHistory.slice(0, 3); // Keep only the latest 3
      setSearchHistory(updatedHistory);
      console.log("updated places",JSON.stringify(newPlace))
      await AsyncStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Error saving search history:', error);
    }
  };

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };
  function isEmpty(item) {
    if (item == null || item == '' || item == undefined) return true;
    return false;
  }

  const checkValidation = () => {
    //console.log('kkkkkkkkkkkkkkkkkkkkkkkkkk', from);
    //console.log('jjjjjjjjjjjjjjjjjjjjjjjjjj', clientId);
    let contact_id = addedContacts.map((item)=>{
      return item.id
    })

    const formData = new FormData();
    formData.append('id', prevApp.id);
    formData.append('contact_ids', contact_id);
    //formData.append('client_id', clientId);
    formData.append('location', from.description);
    formData.append(
      'start_date',
      moment(startDate).format('YYYY-MM-DD HH:mm:ss'),
    );
    formData.append('start_time', moment(startDate).utc().format('HH:mm'));
    formData.append('end_time', moment(endDate).utc().format('HH:mm'));
    formData.append('end_date', moment(endDate).format('YYYY-MM-DD HH:mm:ss'));
    formData.append('notes', note);
    const payload = {
      id: prevApp.id,
      client_id: prevApp?.client?.id,
      location: from.description,
      start_date: moment(startDate).format('YYYY-MM-DD'),
      start_time: moment(startDate).utc().format('HH:mm:ss'),
      end_time: moment(endDate).utc().format('HH:mm:ss'),
      end_date: moment(endDate).format('YYYY-MM-DD'),
      notes: note,
    };
    //formData.append('document', myDoc);

    dispatch(updateAppointmentRequest(payload));
    //goBack();
  };

  const handleSearch = text => {
    setSelectedContact(text);
    const filteredData = clientList.filter(contact => {
      return contact?.name?.toLowerCase()?.includes(text.toLowerCase());
    });
    setFilteredClient(filteredData);
  };
   const renderContactItem = ({item}) => {
      const isSelected = selectedContactIds.has(item.id);
      return (
        <TouchableOpacity
          style={[styles.contactItem, isSelected && styles.selectedItem]}
          onPress={() => toggleSelectContact(item.id,item.is_primary)}>
            <View style={{flexDirection:'row',alignItems:'center'}}>
              <View style={{height:ms(20),width:ms(20),borderRadius:ms(5),borderWidth:ms(1),borderColor:COLORS.themeColor,justifyContent:'center',alignItems:'center'}}>
              {isSelected ? <Image tintColor={COLORS.themeColor} resizeMode='contain' source={ICONS.tick} style={{height:ms(15),width:ms(15)}}/>:null}
            </View>
             <View style={{marginLeft:ms(20)}}>
          <Text
            style={
              isSelected
                ? {fontFamily: FONTS.Regular, fontSize:ms(14),color: COLORS.themeColor}
                : {fontFamily: FONTS.Regular, fontSize:ms(14)}
            }>
            {item.contact_name}
          </Text>
          <Text style={isSelected ? {fontFamily:FONTS.Regular,color:COLORS.themeColor,fontSize:ms(14)} : {fontFamily:FONTS.Regular,fontSize:ms(14)}}>
            {item.contact_email}
          </Text>
          </View>
            </View>
            
           
        </TouchableOpacity>
      );
    };
    const toggleSelectContact = (id,is_primary) => {
    const newSelected = new Set(selectedContactIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedContactIds(newSelected);
  };

  const handleAddSelected = () => {
    let contact_list = contactsPrimary.concat(contactsSecondary)
    const newlySelected = contact_list
      .filter(c => selectedContactIds.has(c.id)) // Get selected items
      .filter(c => !addedContacts.some(ac => ac.id === c.id)); // Exclude already added

    setAddedContacts(prev => [...prev, ...newlySelected]);

    // Clear selection after adding
    setSelectedContactIds(new Set());
    setContactModal(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Update Appointment'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <DatePicker
        modal
        //mode={'date'}
        open={openStart}
        date={startDate}
        onConfirm={date => {
          setStartDate(date);
          setOpenStart(false);
        }}
        onCancel={() => {
          setOpenStart(false);
        }}
      />
      <DatePicker
        modal
        //mode={'date'}
        open={openEnd}
        date={endDate}
        onConfirm={date => {
          setEnddate(date);
          setOpenEnd(false);
        }}
        onCancel={() => {
          setOpenEnd(false);
        }}
      />

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
          //marginBottom: ms(40),
        }}>
        <View style={{flex: 1, padding: ms(20), alignItems: 'center'}}>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(10),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
                marginLeft: ms(5),
              }}>
              Contact
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
                      style={{
                        padding: ms(10),
                        borderWidth: ms(0.6),
                        borderRadius: ms(10),
                        borderColor: COLORS?.themeColor,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        paddingHorizontal: ms(12),
                        marginTop:ms(20),
                        height: ms(45),
                        elevation: 5,
                        backgroundColor: 'white',
                        shadowColor: COLORS.themeColor,
                        width: '100%',
                      }}
                      onPress={() => {
                        if (!appointmentContacts) {
                          navigate('CreateClient');
                        } else {
                          setContactModal(true);
                        }
                      }}>
                      <Text
                        style={{
                          fontFamily: FONTS?.Regular,
                          fontSize: ms(13),
                          color: COLORS?.themeColor,
                        }}>
                        Select Contact
                      </Text>
                      <Image
                        source={ICONS?.arrow}
                        style={{
                          height: ms(5),
                          width: ms(14),
                          transform: [{rotate: '180deg'}],
                        }}
                        resizeMode="contain"
                        tintColor={COLORS.themeColor}
                      />
                    </TouchableOpacity>
                    {addedContacts.length > 0 && (
                                <>
                                  <View style={styles.addedContainer}>
                                    {addedContacts.map(item => {
                                      //const initials = getInitials(item.contact_name);
                    
                                      return (
                                        <View key={`added-${item.id}`} style={styles.addedChip}>
                                          {/* <View style={styles.avatarSmall}>
                                  <Text style={styles.avatarTextSmall}>{initials}</Text>
                                </View> */}
                                          <Text style={styles.chipText}>{item.contact_name}</Text>
                                          <TouchableOpacity
                                            style={styles.removeButton}
                                            onPress={() => {
                                              setAddedContacts(prev =>
                                                prev.filter(contact => contact.id !== item.id),
                                              );
                                            }}>
                                            <Text style={styles.removeButtonText}>✖</Text>
                                          </TouchableOpacity>
                                        </View>
                                      );
                                    })}
                                  </View>
                                </>
                              )}

          {/* <TouchableOpacity
            onPress={() => setClientModal(true)}
            style={{
              padding: ms(10),
              borderWidth: ms(1),
              marginTop: ms(15),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              justifyContent: 'center',
              alignItems: 'center',
              elevation: 2,
              backgroundColor: COLORS?.white,
              shadowColor: 'rgba(4, 127, 255, 0.2)',
              height: ms(45),
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                  color: COLORS.themeColor,
                  marginLeft: ms(5),
                }}>
                {selectedClient ? selectedClient : 'Choose Client'}
              </Text>
            </View>
          </TouchableOpacity> */}
          
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(10),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
              //marginLeft:ms(5)
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
                marginLeft: ms(5),
              }}>
              Location
            </Text>
          </TouchableOpacity>
          {/* <TouchableOpacity
            style={{
              height: ms(45),
              borderWidth: ms(0.6),
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: COLORS.gray,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(14),
                }}>
                Select Location
              </Text>
              <Image
                style={{
                  height: ms(18),
                  width: ms(16),
                  resizeMode: 'contain',
                  marginLeft: ms(10),
                }}
                source={ICONS.location}
              />
            </View>
          </TouchableOpacity> */}
          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.6),
              marginTop: ms(15),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              justifyContent: 'space-between',
              //elevation: 2,
              backgroundColor: COLORS?.white,
              shadowColor: 'rgba(4, 127, 255, 0.2)',
              //height: ms(45),
              alignItems: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}
            onPress={() => {
              setOpenAddressModal(true);
            }}>
            <Text
              numberOfLines={2} // Allow up to 2 lines
              ellipsizeMode="tail"
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                color: '#34405480',
                width:'90%'
              }}>
              {appointmentLocation}
            </Text>
            <Image
              source={ICONS?.location_pin}
              style={{
                height: ms(20),
                width: ms(20),
                tintColor: '#44BBFE',
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(10),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Date & Time
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setOpenStart(true)}
            style={{
              height: ms(45),
              borderWidth: ms(0.6),
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              backgroundColor: COLORS?.white,
              shadowColor: COLORS.themeColor,
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: '#34405480',
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                Start Date : {moment(startDate).format('YYYY-MM-DD HH:mm:ss')}
              </Text>
              <Image
                style={{
                  height: ms(18),
                  width: ms(16),
                  resizeMode: 'contain',
                  marginLeft: ms(10),
                }}
                source={ICONS.calendar}
              />
            </View>
          </TouchableOpacity>

          <View
            style={{
              width: '100%',
              height: ms(0.6),
              backgroundColor: COLORS.border,
              marginVertical: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setOpenEnd(true)}
            style={{
              height: ms(45),
              borderWidth: ms(0.6),
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(0),
              justifyContent: 'center',
              elevation: 2,
              backgroundColor: COLORS?.white,
              shadowColor: COLORS.themeColor,
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: '#34405480',
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                End Date : {moment(endDate).format('YYYY-MM-DD HH:mm:ss')}
              </Text>
              <Image
                style={{
                  height: ms(18),
                  width: ms(16),
                  resizeMode: 'contain',
                  marginLeft: ms(10),
                }}
                source={ICONS.calendar}
              />
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(10),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Document
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => {
              if (myDoc.name) {
                setMydoc('');
              } else {
                try {
                  const [result] = await pick({
                    mode: 'open',
                  });
                  console.log('result on open file pdf', result);

                  setMydoc(result);
                } catch (err) {
                  // see error handling
                }
              }
            }}
            style={{
              padding: ms(8),
              borderWidth: ms(1),
              marginTop: ms(10),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: ms(20),
              elevation: 2,
              backgroundColor: COLORS?.white,
              shadowColor: 'rgba(4, 127, 255, 0.2)',
              height: ms(45),
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                  color: COLORS.themeColor,
                  marginLeft: ms(5),
                }}>
                {myDoc?.name ? myDoc.name : 'Upload File'}
              </Text>
              <Image
                source={myDoc?.name ? ICONS.crossbtn : ICONS.upload}
                style={{
                  height: ms(17),
                  width: ms(14),
                  resizeMode: 'contain',
                  marginLeft: ms(5),
                }}
              />
            </View>
          </TouchableOpacity>
          {/* {myDoc?.name ? (
            <Text
              style={{
                color: COLORS.themeColor,
                fontSize: ms(10),
                fontFamily: FONTS.Regular,
                alignSelf: 'flex-start',
                marginLeft: ms(10),
              }}>
              {myDoc.name}
            </Text>
          ) : null} */}

          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(10),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Note
            </Text>
          </TouchableOpacity>

          <AnimatedTextInput
            label={'Description'}
            keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={note}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(100)}
            multiline={true}
            numberOfLines={10}
            onChangeText={item => {
              setNote(item);
            }}
          />

          <TouchableOpacity
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,

              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
              marginVertical: ms(30),
            }}
            onPress={() => {
              //navigate("AddInvoice")
              //goBack();
              checkValidation();
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Update
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal
        isVisible={clientModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setClientModal(false);
          setSelectedContact('');
          setFilteredClient(clientList);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            height: Dimensions.get('window').height * 0.6,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setClientModal(false);
              setSelectedContact('');
              setFilteredClient(clientList);
            }}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Client
            </Text>
          </View>
          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
                fontSize: ms(12),
                fontFamily: FONTS?.Regular,
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={selctedContact}
              onChangeText={text => handleSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{height: normalize(14), width: normalize(14)}}
              source={ICONS.search}
            />
          </View>

          <FlatList
            data={filteredClient}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: COLORS?.orange}}>No data found.</Text>
              </View>
            }
            renderItem={({item, index}) => {
              console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0.6),
                    borderBottomColor: COLORS.border,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    console.log(item);
                    setSelectedClient(item);
                    setClientId(item.id);
                    setClientModal(false);
                  }}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View
                      style={{
                        height: ms(36),
                        width: ms(36),
                        borderRadius: ms(18),
                        backgroundColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: FONTS.Medium,
                          fontSize: ms(14),
                          color: COLORS.white,
                        }}>
                        {item.name
                          .split(' ') // Split by space → ['Subhadeep', 'Saha']
                          .map(word => word.charAt(0)) // Take first character of each word → ['S', 'S']
                          .join('')}
                      </Text>
                    </View>
                    <View style={{marginLeft: ms(10)}}>
                      <Text
                        style={{
                          color: '#000',
                          fontFamily: FONTS.SemiBold,
                          textTransform: 'capitalize',
                          fontSize: ms(12),
                        }}>
                        {item?.name}
                      </Text>
                      <Text
                        style={{
                          color: COLORS.placeholderColor,
                          fontFamily: FONTS.Regular,
                          textTransform: 'capitalize',
                          fontSize: ms(10),
                        }}>
                        {item?.email}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <Modal
        animationIn={'fadeInUp'}
        animationOut={'fadeOutDown'}
        isVisible={openAddressModal}
        backdropTransitionOutTiming={0}
        onBackButtonPress={() => setOpenAddressModal(false)}
        onBackdropPress={() => setOpenAddressModal(false)}
        avoidKeyboard={false}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View style={styless.centeredView}>
          <View style={styless.modalView}>
            <TouchableOpacity
              onPress={() => setOpenAddressModal(false)}
              style={{position: 'absolute', top: 20, right: 20}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(20)}}
                source={ICONS.crossbtn}
              />
            </TouchableOpacity>
            <View
              style={{
                height: Dimensions?.get('window')?.height * 0.6,
                width: '100%',
                alignSelf: 'center',
              }}>
              <Text
                style={{
                  paddingBottom: ms(10),
                  color: COLORS?.blue,
                  height: ms(12),
                }}>
                Enter Address
              </Text>
              <GooglePlacesAutocomplete
                GooglePlacesDetailsQuery={{fields: 'geometry'}}
                placeholder={'Enter Address'}
                minLength={3}
                fetchDetails={true}
                returnKeyType={'default'}
                listViewDisplayed="auto"
                enablePoweredByContainer={false}
                listEmptyComponent={() => (
                  <View style={{flex: 1}}>
                    <Text>No results were found</Text>
                  </View>
                )}
                textInputProps={{
                  autoFocus: true,
                  blurOnSubmit: false,
                }}
                // keyboardShouldPersistTaps="never"
                styles={{
                  textInput: {
                    height: 58,
                    color: '#000',
                    fontSize: 16,
                    borderWidth: 1,
                    borderColor: '#2144C1',
                    borderRadius: 10,
                    marginTop: ms(20),
                  },
                  predefinedPlacesDescription: {
                    color: '#1faadb',
                  },
                }}
                onPress={(data, details) => {
                  console.log(data);
                  console.log('llll', details?.geometry?.location);
                  setFrom({...data, ...details?.geometry?.location});
                  saveSearchHistory({ description: data.description, place_id: details.place_id });
                  setAppointmentLocation(data?.description);
                  setOpenAddressModal(false);
                }}
                predefinedPlaces={searchHistory}
                onFail={error => console.error(error)}
                query={{
                  key: constants?.GOOGLE_API_KEY,
                  language: 'en',
                  // components: 'country:ind',
                }}
              />
            </View>

            {/* <Container bg={"#2144C1"} radius={10} pv={10} align="center" width={'70%'}>
                      <CText color={'#fff'}> Submit </CText>
                  </Container> */}
          </View>
        </View>
      </Modal>
      <Modal
              isVisible={contactModal}
              backdropOpacity={0.6}
              animationIn={'slideInUp'}
              animationOut={'slideOutDown'}
              animationInTiming={800}
              animationOutTiming={500}
              backdropTransitionOutTiming={0}
              hasBackdrop={true}
              onBackdropPress={() => {
                setClientModal(false);
                setSelectedContact('');
                setFilteredClient(clientList);
              }}
              style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
              <View
                style={{
                  height: Dimensions.get('window').height * 0.6,
                  width: '100%',
                  //height: Dimensions.get('window').height - normalize(200),
                  paddingTop: normalize(10),
                  paddingHorizontal: normalize(30),
                  backgroundColor: '#FFF',
                  borderTopLeftRadius: normalize(20),
                  borderTopRightRadius: normalize(20),
                  padding: normalize(40),
                }}>
                <View
                  style={{
                    width: ms(63),
                    height: ms(6),
                    borderRadius: ms(8),
                    backgroundColor: 'rgba(217, 217, 217, 1)',
                    alignSelf: 'center',
                    marginBottom: ms(20),
                  }}
                />
                <TouchableOpacity
                  onPress={() => {
                    setContactModal(false);
                  }}
                  style={{position: 'absolute', top: 20, right: 20}}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(20), width: ms(20)}}
                    source={ICONS.crossbtn}
                  />
                </TouchableOpacity>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{
                      fontSize: normalize(18),
                      fontFamily: FONTS.Medium,
                      paddingVertical: normalize(20),
                      //paddingHorizontal: normalize(20),
                    }}>
                    Select Contact
                  </Text>
                  <TouchableOpacity
                    onPress={() => handleAddSelected()}
                    style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text
                      style={{
                        fontStyle: FONTS.Medium,
                        fontSize: ms(18),
                        color: COLORS.themeColor,
                      }}>
                      Add
                    </Text>
                    <Image
                      resizeMode="contain"
                      style={{height: ms(15), width: ms(15), marginLeft: ms(5)}}
                      source={ICONS.plusicn}
                    />
                  </TouchableOpacity>
                </View>
                {/* <View
                  style={{
                    height: normalize(46),
                    width: '100%',
                    borderWidth: ms(0.5),
                    borderColor: COLORS.themeColor,
                    borderRadius: normalize(10),
                    marginBottom: normalize(20),
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingHorizontal: normalize(10),
                    elevation: 3,
                    backgroundColor: 'white',
                    shadowColor: COLORS.themeColor,
                  }}>
                  <TextInput
                    style={{
                      height: '100%',
                      width: '75%',
                      fontSize: ms(12),
                      fontFamily: FONTS?.Regular,
                    }}
                    placeholder="Search"
                    placeholderTextColor={COLORS.placeholderColor}
                    value={selctedContact}
                    onChangeText={text => handleSearch(text)}
                  />
                  <Image
                    resizeMode="contain"
                    style={{height: normalize(14), width: normalize(14)}}
                    source={ICONS.search}
                  />
                </View> */}
      
                {contactsPrimary?.length > 0 ? (
                  <View>
                    <View
                      style={{
                        height: ms(40),
                        borderRadius: ms(5),
                        backgroundColor: 'rgba(4, 127, 255, 0.1)',
                        paddingHorizontal: ms(10),
                        marginTop: ms(20),
                        justifyContent: 'center',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: COLORS.themeColor,
                          fontWeight: '600',
                        }}>
                        Primary Contact
                      </Text>
                    </View>
                    <View style={{marginLeft: ms(0)}}>
                      <FlatList
                        data={contactsPrimary}
                        renderItem={renderContactItem}
                      />
                    </View>
                  </View>
                ) : null}
                {contactsSecondary?.length > 0 ? (
                  <View>
                    <View
                      style={{
                        height: ms(40),
                        borderRadius: ms(5),
                        backgroundColor: 'rgba(4, 127, 255, 0.1)',
                        paddingHorizontal: ms(10),
                        marginTop: ms(20),
                        justifyContent: 'center',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: COLORS.themeColor,
                          fontWeight: '600',
                        }}>
                        Secondary Contact
                      </Text>
                    </View>
                    <FlatList
                      data={contactsSecondary}
                      renderItem={renderContactItem}
                    />
                  </View>
                ) : null}
              </View>
            </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
  contactItem: {
    padding: 12,
    marginVertical: 4,
    //backgroundColor: '#f0f0f0',
    borderRadius: 8,
    borderWidth:ms(0.6),
    borderColor:COLORS.themeColor
    //flexDirection: 'row', // <-- Important: for avatar + text side by side
    //alignItems: 'center',
  },
  selectedItem: {
    backgroundColor: '#d0e6ff',
    borderColor: '#2196f3',
    borderWidth: 2,
  },
  horizontalList: {
    paddingVertical: ms(6),
    gap: 8, // Space between chips (React Native >= 0.71)
    // If you're on older RN, use marginLeft/marginRight in chip instead
  },

  addedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    //backgroundColor: '#e8f5e8',
    borderColor: COLORS.themeColor,
    borderWidth: ms(1),
    borderRadius: 20,
    paddingVertical: ms(6),
    paddingHorizontal: 12,
    marginRight: ms(0),
  },

  avatarSmall: {
    width: 28,
    height: 28,
    borderRadius: 14,
    //backgroundColor: '#4caf50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },

  addedContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: ms(20),
    alignSelf: 'flex-start',
    gap: 8, // Modern RN (0.71+) — space between chips
    // If using older RN, remove `gap` and add `marginRight`/`marginBottom` to `addedChip`
  },

  // addedChip: {
  //   flexDirection: 'row',
  //   //alignItems: 'center',
  //   //backgroundColor: '#e8f5e8',
  //   borderColor: COLORS.themeColor,
  //   borderWidth: 1,
  //   borderRadius: 20,
  //   paddingVertical: 6,
  //   paddingHorizontal: 12,
  //   marginBottom: 8, // for wrap spacing (if no gap)
  //   // marginRight: 8, // uncomment if no gap support
  // },

  avatarSmall: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#4caf50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },

  avatarTextSmall: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },

  chipText: {
    fontSize: ms(14),
    //color: '#333',
    fontFamily: FONTS.Regular,
    marginRight: 6,
  },

  removeButton: {
    padding: 2,
  },

  removeButtonText: {
    fontSize: 16,
    color: '#44BBFE',
    fontWeight: '200',
  },
});

const styless = StyleSheet.create({
  centeredView: {
    maxHeight:
      Platform.OS == 'ios'
        ? Dimensions?.get('window')?.height / 2.2
        : Dimensions?.get('window')?.height / 2,
    width: '100%',
    paddingTop: 10,
    // paddingHorizontal: 30,
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopEndRadius: 20,
  },
  modalView: {
    paddingHorizontal: 20,
    paddingTop: 20,
    // margin: 20,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    //   textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    //   textAlign: "center"
  },
});
