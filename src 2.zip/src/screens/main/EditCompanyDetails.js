import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import normalize from '../../utils/helpers/normalize';
import {addBusinessDetailsRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Toast from '../../utils/helpers/Toast';
import constants from '../../utils/helpers/constants';
//import Loader from '../../utils/helpers/Loader';
import FullLoader from '../../utils/helpers/FullLoader';
import DeviceInfo from 'react-native-device-info';
//import {isTablet} from 'react-native-device-info';
//import Loader from '../../utils/helpers/Loader';
//import Modal from 'react-native-modal';

export default function EditCompanyDetails() {
  const {loading = false} = useSelector(state => state.ProfileReducer || {});
  const dispatch = useDispatch();
  const {profileResponse} = useSelector(state => state.ProfileReducer);
  const [isModalVisible, setModalVisible] = useState(false);

  const [selectedPayment, setSelectedPayment] = useState('');

  const [companyName, setCompanyName] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [website, setWebsite] = useState('');
  const [aboutBusiness, setAboutBusiness] = useState('');
  const [legalName, setLegalName] = useState('');
  const [legalBusinessAddress, setLegalBusinessAddress] = useState('');
  const [legalPhoneNo, setLegalPhoneNo] = useState('');
  const [employeeNo, setEmployeeNo] = useState('No of employees');
  const [employeeModal, setEmployeeModal] = useState(false);
   const [isTablet, setIsTablet] = useState(false);

   useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  const EmployeeNo = [
    {
      id: 100,
      emp_no: '1',
    },
    {
      id: 101,
      emp_no: '2',
    },
    {
      id: 102,
      emp_no: '3',
    },
    {
      id: 103,
      emp_no: '4',
    },
    {
      id: 104,
      emp_no: '5',
    },
    {
      id: 105,
      emp_no: '6-10',
    },
    {
      id: 106,
      emp_no: '6-10',
    },
    {
      id: 107,
      emp_no: '11-15',
    },
    {
      id: 108,
      emp_no: '16+',
    },
  ];
  useEffect(() => {
    if (profileResponse) {
      console.log('ioioio', JSON.stringify(profileResponse));
      if (profileResponse?.userCompany?.companyName) {
        setCompanyName(profileResponse.userCompany.companyName);
      }
      if (profileResponse?.userCompany?.companyAddress) {
        setBusinessAddress(profileResponse.userCompany.companyAddress);
      }
      if (profileResponse?.userCompany?.companyPhone) {
        setPhoneNumber(profileResponse.userCompany.companyPhone);
      }
      if (profileResponse?.userCompany?.companyEmail) {
        setEmailAddress(profileResponse.userCompany.companyEmail);
      }
      if (profileResponse?.userCompany?.companyWebsite) {
        setWebsite(profileResponse.userCompany.companyWebsite);
      }
      if (profileResponse?.userCompany?.companyInfo) {
        setAboutBusiness(profileResponse.userCompany.companyInfo);
      }
      if (profileResponse?.userCompany?.legalBusinessName) {
        setLegalName(profileResponse?.userCompany?.legalBusinessName);
      }
      if (profileResponse?.userCompany?.businessAddress) {
        setLegalBusinessAddress(profileResponse?.userCompany?.businessAddress);
      }
      if (profileResponse?.userCompany?.businessPhone) {
        setLegalPhoneNo(profileResponse?.userCompany?.businessPhone);
      }
      if (profileResponse?.userCompany?.businessPhone) {
        setLegalPhoneNo(profileResponse?.userCompany?.businessPhone);
      }
      if (profileResponse?.userCompany?.noOfEmployee) {
        setEmployeeNo(profileResponse?.userCompany?.noOfEmployee);
      }
    }
  }, []);

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  const paymentMethod = [
    {
      id: 100,
      method: 'Card Payment',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.card,
    },
    {
      id: 101,
      method: 'Bank Transfers',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.bank,
    },
    {
      id: 102,
      method: 'Paypal',
      description: 'Powered by raiseinvoice.com',
      img: ICONS.paypal,
    },
  ];

  const renderPayment = ({item, index}) => {
    let isSelected = item.id == selectedPayment;
    return (
      <View
        style={{
          flex: 1,
          padding: 20,
          backgroundColor: COLORS.white,
          borderWidth: 1,
          borderColor: COLORS.border,
          borderRadius: ms(10),
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <View
            style={{
              padding: 10,
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(5),
            }}>
            <Image
              style={{height: ms(30), width: ms(30), resizeMode: 'contain'}}
              source={item.img}
            />
          </View>
          <View>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  color: COLORS.textColor,
                  marginLeft: ms(15),
                  fontSize: ms(14),
                }}>
                {item.method}
              </Text>
              <Image
                source={ICONS.knowmore}
                style={{
                  height: ms(11),
                  width: ms(11),
                  resizeMode: 'contain',
                  marginLeft: ms(5),
                }}
              />
            </View>
            <Text
              style={{
                fontFamily: FONTS.Regular,
                color: COLORS.gray,
                marginLeft: ms(15),
                fontSize: ms(12),
              }}>
              {item.description}
            </Text>
          </View>

          <TouchableOpacity
            style={{position: 'absolute', top: 1, right: 10}}
            onPress={() => {
              if (selectedPayment == item.id) {
                setSelectedPayment('');
              } else {
                setSelectedPayment(item.id);
              }
            }}>
            {isSelected ? (
              <Image
                source={ICONS.switch}
                style={{height: ms(20), width: ms(32), resizeMode: 'contain'}}
              />
            ) : (
              <Image
                source={ICONS.switchoff}
                style={{height: ms(20), width: ms(32), resizeMode: 'contain'}}
              />
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const ItemSeparator = () => {
    return <View style={{height: ms(1), marginVertical: ms(5)}} />;
  };

  const checkValidation = () => {
    if (companyName == '') {
      Toast('Enter company name');
    } else if (businessAddress == '') {
      Toast('Enter company address');
    } else if (phoneNumber == '') {
      Toast('Enter company phone');
    } else if (emailAddress == '') {
      Toast('Enter company email');
    } else if (!constants.EMAIL_REGEX.test(emailAddress)) {
      Toast('Enter valid company email');
    } else if (website == '') {
      Toast('Enter valid company website');
    } else if (aboutBusiness == '') {
      Toast('Enter valid company information');
    } else {
      let payload = {
        companyName: companyName,
        companyAddress: businessAddress,
        companyPhone: phoneNumber,
        companyEmail: emailAddress,
        companyWebsite: website,
        companyInfo: aboutBusiness,
      };
      dispatch(addBusinessDetailsRequest(payload));
    }
  };
  const renderItemseparator = () => {
    return (
      <View
        style={{
          height: ms(1),
          width: Dimensions.get('window').width,
          marginLeft: ms(-20),
          marginVertical: ms(5),
          backgroundColor: COLORS.border,
        }}
      />
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Edit Company Details'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={()=> goBack()}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20), alignItems: 'center'}}>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Company Details
            </Text>
          </TouchableOpacity>

          <AnimatedTextInput
            label={'Doing business as'}
            editable={false}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={companyName}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setCompanyName(item);
            }}
          />
          <AnimatedTextInput
            label={'Business address'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={businessAddress}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setBusinessAddress(item);
            }}
          />
          <View
            style={{
              paddingLeft: ms(15),
              borderWidth: ms(0.6),
              marginTop: ms(15),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
              alignItems: 'center',
              gap: ms(2),
              elevation: 2,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              height: ms(45),
            }}>
            <Text
              style={{
                fontSize: ms(14),
                color: '#344054',
                fontFamily: FONTS.Regular,
              }}>
              +91
            </Text>
            <Image
              source={ICONS?.arrow}
              //tintColor={COLORS.placeholderColor}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: '180deg'}],
                tintColor: COLORS?.themeColor,
                marginHorizontal: ms(5),
              }}
              resizeMode="contain"
            />
            <View
              style={{
                height: '80%',
                width: ms(0.6),
                backgroundColor: COLORS?.border,
                marginLeft: ms(5),
              }}
            />
            <TextInput
              placeholder="Phone No."
              keyboardType="number-pad"
              autoComplete="off"
              selectTextOnFocus={false}
              editable={false}
              placeholderTextColor={COLORS.placeholderColor}
              style={{
                fontSize: ms(13),
                paddingLeft: ms(15),
                color: COLORS.dark_grey,
                borderRadius: ms(10),
                //backgroundColor: COLORS.white,
                minHeight: ms(52),

                //borderWidth: ms(0.8),
                //width: '85%',
                //borderColor: COLORS?.white,
              }}
              value={phoneNumber}
              onChangeText={item => {
                setPhoneNumber(item);
              }}
            />
          </View>
          <AnimatedTextInput
            label={'Email address'}
            //keyboardType={'email-address'}
            editable={false}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={emailAddress}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setEmailAddress(item);
            }}
          />
          <AnimatedTextInput
            label={'Website'}
            //keyboardType={'email-address'}
            editable={false}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={website}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setWebsite(item);
            }}
          />
          <TextInput
            placeholder="About business."
            placeholderTextColor={COLORS.placeholderColor}
            autoComplete="off"
            selectTextOnFocus={false}
            multiline={true}
            numberOfLines={10}
            textAlignVertical="top"
            style={{
              fontSize: ms(13),
              paddingLeft: ms(15),
              color: COLORS.dark_grey,
              borderRadius: ms(10),
              backgroundColor: COLORS.white,
              minHeight: ms(52),
              borderWidth: ms(0.6),
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
              borderColor: COLORS?.themeColor,
              height: normalize(100),
              marginTop: normalize(20),
              elevation: 5,
              shadowColor: COLORS.themeColor,
              //overflow:'hidden'
            }}
            value={aboutBusiness}
            onChangeText={item => {
              setAboutBusiness(item);
            }}
          />
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Legal Entity Details
            </Text>
          </TouchableOpacity>

          <AnimatedTextInput
            label={'Doing business as'}
            editable={false}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={legalName}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setLegalName(item);
            }}
          />

          <AnimatedTextInput
            label={'Registered business address'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={legalBusinessAddress}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setLegalBusinessAddress(item);
            }}
          />
          <View
            style={{
              paddingLeft: ms(15),
              borderWidth: ms(0.6),
              marginTop: ms(20),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
              alignItems: 'center',
              gap: ms(2),
              elevation: 2,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              height: ms(45),
            }}>
            <Text
              style={{
                fontSize: ms(14),
                color: '#344054',
                fontFamily: FONTS.Regular,
              }}>
              +91
            </Text>
            <Image
              source={ICONS?.arrow}
              //tintColor={COLORS.placeholderColor}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{rotate: '180deg'}],
                tintColor: COLORS?.themeColor,
                marginHorizontal: ms(5),
              }}
              resizeMode="contain"
            />
            <View
              style={{
                height: '80%',
                width: ms(0.6),
                backgroundColor: COLORS?.border,
                marginLeft: ms(5),
              }}
            />
            <TextInput
              placeholder="Legal Phone No."
              keyboardType="number-pad"
              editable={false}
              placeholderTextColor={COLORS.placeholderColor}
              autoComplete="off"
              selectTextOnFocus={false}
              style={{
                fontSize: ms(13),
                paddingLeft: ms(15),
                color: COLORS.dark_grey,
                borderRadius: ms(10),
                //backgroundColor: COLORS.white,
                minHeight: ms(45),
                //borderWidth: ms(0.8),
                //width: '85%',
                //borderColor: COLORS?.white,
              }}
              value={legalPhoneNo}
              onChangeText={item => {
                setLegalPhoneNo(item);
              }}
            />
          </View>

          <TouchableOpacity
            onPress={() => setEmployeeModal(true)}
            style={{
              paddingHorizontal: ms(15),
              borderWidth: ms(0.3),
              marginTop: ms(20),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
              alignItems: 'center',
              gap: ms(2),
              elevation: 2,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              height: ms(45),
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                color:
                  employeeNo == 'No of employees'
                    ? COLORS.placeholderColor
                    : COLORS.black,
                fontFamily: FONTS.Regular,
              }}>
              {employeeNo}
            </Text>
            <Image
              resizeMode="contain"
              style={{
                height: ms(5),
                width: ms(14),
                tintColor: COLORS.themeColor,
                transform: [{rotate: employeeModal ? '0deg' : '180deg'}],
              }}
              source={ICONS.arrow}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={{
            paddingHorizontal: ms(20),
            paddingVertical: ms(8),
            backgroundColor: COLORS?.themeColor,

            alignSelf: 'center',
            width: ms(150),
            borderRadius: ms(20),
            marginBottom: ms(30),
          }}
          onPress={() => {
            // checkValidation()
            goBack();
          }}>
          <Text
            style={{
              color: COLORS?.white,
              textAlign: 'center',
              fontFamily: FONTS?.Medium,
              fontSize: ms(15),
            }}>
            Save
          </Text>
        </TouchableOpacity>
      </ScrollView>
      <Modal
        isVisible={employeeModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setEmployeeModal(false);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height * 0.6,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Employee No.
            </Text>
          </View>

          <FlatList
            data={EmployeeNo}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={renderItemseparator}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: COLORS?.orange}}>No data found.</Text>
              </View>
            }
            renderItem={({item, index}) => {
              console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0),
                    borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                    //width:Dimensions.get('window').width,
                    //marginLeft:ms(-20)
                  }}
                  onPress={() => {
                    //console.log('itemaaa', item);
                    //alert(item?.id)
                    setEmployeeNo(item?.emp_no);
                    //callUpdateProfile(item?.id);

                    setEmployeeModal(false);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS.Fredoka_Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                    }}>
                    {item?.emp_no}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
