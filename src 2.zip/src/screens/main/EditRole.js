import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {
  addAccountRequest,
  getRoleListRequest,
  roleCreateRequest,
  roleUpdateRequest,
} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';

export default function EditRole(props) {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [roleModal, setRoleModal] = useState(false);
  const dispatch = useDispatch();
  const {roleList, loading} = useSelector(state => state.ProfileReducer);
  useEffect(() => {
    dispatch(getRoleListRequest());
    setName(props?.route?.params?.item?.roleName);
    setRole(
      props?.route?.params?.item?.accessStatus == 0
        ? 'Full Access'
        : 'Limited Access',
    );
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <Modal
        isVisible={roleModal}
        onBackdropPress={() => {
          setRoleModal(false);
        }}
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: ms(22),
            //alignItems: 'center',
            borderTopLeftRadius: ms(15),
            borderTopRightRadius: ms(15),
            height: Dimensions.get('window').height * 0.6,
          }}>
          <TouchableOpacity
            style={{
              paddingBottom: ms(5),
              marginTop: ms(5),
              borderBottomWidth: ms(0.5),
              borderBottomColor: '#DFDFDF',
            }}
            onPress={() => {
              setRoleModal(false);
              setRole('Full Access');
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(13),
                color: COLORS?.black,
              }}>
              Full Access
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              paddingBottom: ms(5),
              marginTop: ms(5),
              borderBottomWidth: ms(0.5),
              borderBottomColor: '#DFDFDF',
            }}
            onPress={() => {
              setRoleModal(false);
              setRole('Limited Access');
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(13),
                color: COLORS?.black,
              }}>
              Limited Access
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Edit Role'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20), marginBottom: ms(50)}}>
          <View style={{paddingTop: ms(40), alignItems: 'center'}}>
            <Text
              style={{
                fontFamily: FONTS.Medium,
                fontSize: ms(14),
                color: 'rgba(52, 64, 84, 1)',
              }}>
              New Role
            </Text>
          </View>
          <View style={{marginTop: ms(40)}} />
          <AnimatedTextInput
            label={'Role Name'}
            //keyboardType={'email-address'}
            width={Dimensions?.get('window')?.width - 50}
            editable={false}
            value={name}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setName(item);
            }}
          />
          <TouchableOpacity
            style={{
              padding: ms(13),
              borderWidth: ms(0.7),
              borderColor: COLORS?.themeColor,
              borderRadius: ms(6),
              marginTop: ms(10),
              width: Dimensions?.get('window')?.width - 50,
              backgroundColor: COLORS?.white,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: ms(10),
            }}
            onPress={() => {
              setRoleModal(true);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                color: 'rgba(52, 64, 84, 0.5)',
              }}>
              {role ? role : 'Select Access'}
            </Text>
            <Image
              style={{
                height: ms(5),
                width: ms(14),
                resizeMode: 'contain',
                tintColor: COLORS.themeColor,
                transform: [{rotate: '180deg'}],
              }}
              source={ICONS.arrow}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={{
            paddingHorizontal: ms(20),
            paddingVertical: ms(8),
            backgroundColor: COLORS?.themeColor,
            alignSelf: 'center',
            width: ms(150),
            borderRadius: ms(20),
            marginTop: ms(30),
          }}
          onPress={() => {
            if (role == '') {
              Toast('Access is required');
            } else if (name == '') {
              Toast('Name is required');
            } else {
              // goBack();
              dispatch(
                roleUpdateRequest({
                  id: props?.route?.params?.item?.id,
                  roleName: name,
                  accessStatus: role == 'Limited Access' ? 1 : 0,
                }),
              );
            }
          }}>
          <Text
            style={{
              color: COLORS?.white,
              textAlign: 'center',
              fontFamily: FONTS?.Medium,
              fontSize: ms(15),
            }}>
            Save
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
