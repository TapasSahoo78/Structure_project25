import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';
import DeviceInfo from 'react-native-device-info';
import {useFocusEffect} from '@react-navigation/native';
import {deleteEstimateRequest, getEstimateDetailsRequest, getEstimateRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../utils/helpers/Loader';

export default function Estimate() {
  const dispatch = useDispatch();
  const {estimateList, loading} = useSelector(state => state.ProfileReducer);
  const [option, setOption] = useState('unpaid');
  const [isTablet, setIsTablet] = useState(false);
  const clientList = [
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
  ];
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useFocusEffect(
    useCallback(() => {
      let payload = {};
      dispatch(getEstimateRequest(payload));
    }, []),
  );
   const getDetails =(item)=>{
      console.log("estimate item",JSON.stringify(item))
      let payload = {
        id:item.id
      }
      dispatch(getEstimateDetailsRequest(payload))
    }

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
       <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <MainHeader
          moreOptionPresent={item => {
            console.log('scdsfvdgvf');
            navigate('AddEstimateWithoutClient');
          }}
          label={'Estimate'}
        />
        <View
          style={{
            marginVertical: ms(10),
            backgroundColor: COLORS?.white,
            flexDirection: 'row',
            width: isTablet
              ? Dimensions.get('window').width - 70
              : Dimensions.get('window').width - 50,
            alignSelf: 'center',
            borderRadius: ms(10),
            justifyContent: 'center',
            elevation: 3,
            shadowColor: 'rgba(0, 0, 0, 0.1)',
          }}>
          <Text
            style={{
              padding: ms(15),
              width: '45%',
              textAlign: 'center',
              borderBottomWidth: option == 'unpaid' ? ms(1) : ms(0),
              borderBottomColor: COLORS?.themeColor,
              color:
                option == 'unpaid'
                  ? 'rgba(52, 64, 84, 1)'
                  : 'rgba(52, 64, 84, 0.75)',
              fontFamily: FONTS?.Regular,
              fontSize: ms(14),
            }}
            onPress={() => {
              setOption('unpaid');
            }}>
            Pending
          </Text>
          <Text
            style={{
              padding: ms(15),
              width: '45%',
              textAlign: 'center',
              borderBottomWidth: option == 'paid' ? ms(1) : ms(0),
              borderBottomColor: COLORS?.themeColor,
              color:
                option == 'paid'
                  ? 'rgba(52, 64, 84, 1)'
                  : 'rgba(52, 64, 84, 0.75)',
              fontFamily: FONTS?.Regular,
              fontSize: ms(14),
            }}
            onPress={() => {
              setOption('paid');
            }}>
            Done
          </Text>
        </View>
        <View
          style={{
            paddingHorizontal: ms(35),
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginTop: ms(10),
            marginBottom: ms(20),
          }}>
          <View
            style={{flexDirection: 'row', alignItems: 'center', gap: ms(10)}}>
            <Text
              style={{
                fontFamily: FONTS?.SemiBold,
                color: '#344054',
                fontSize: ms(14),
              }}>
              2025 sorted by category
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                tintColor: COLORS?.themeColor,
                transform: [{rotate: '180deg'}],
              }}
              resizeMode="contain"
            />
          </View>
          <Image
            source={ICONS?.sort}
            style={{height: ms(15), width: ms(15)}}
            resizeMode="contain"
          />
        </View>
      </View>
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          flex: 1,
        }}
        imageStyle={{opacity: 0.5}}
        source={IMAGES?.colorBackground}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1}}>
            <FlatList
              data={estimateList}
              style={{paddingHorizontal: ms(20), marginTop: ms(10)}}
              renderItem={({item, index}) => {
                return (
                  <View
                    style={{
                      padding: ms(15),
                      backgroundColor: COLORS?.white,
                      borderRadius: ms(10),
                      marginBottom: ms(10),
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems:'center',
                      width: isTablet
                        ? Dimensions.get('window').width - 70
                        : Dimensions.get('window').width - 50,
                      // height: ms(45),
                      elevation: 2,
                      shadowColor: COLORS?.themeColor,
                      backgroundColor: COLORS?.white,
                    }}>
                      <TouchableOpacity onPress={()=> getDetails(item)}>
                    <Text
                      style={{
                        fontFamily: FONTS?.SemiBold,
                        fontSize: ms(12),
                        color: '#344054',
                      }}>
                      {item?.client?.name}
                      <Text
                        style={{fontFamily: FONTS?.Light, fontSize: ms(12)}}>
                        {'\n\n'}
                        {item?.note}
                      </Text>
                    </Text>
                    </TouchableOpacity>
                    <View style={{flexDirection:'row',alignItems:'center'}}>
                    <Text
                      style={{
                        fontFamily: FONTS?.SemiBold,
                        fontSize: ms(13),
                        color: '#344054',
                      }}>
                      ${item?.balance}
                      
                    </Text>
                    <View style={{marginLeft:ms(10)}}>
                      <TouchableOpacity onPress={()=> navigate("UpdateEstimate",{item:item})} style={{justifyContent:'flex-start',padding:ms(5)}}>
                        <Image resizeMode='contain' style={{height:ms(15),width:ms(15)}} source={ICONS.editicn}/>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={()=> {
                        Alert.alert(
                              "Delete",
                              "Are you sure you want to delete ?",
                              [
                                {
                                  text: "Cancel",
                                  onPress: () => console.log("Cancel Pressed"),
                                  style: "cancel"
                                },
                                {
                                  text: "OK",
                                  onPress: () => {
                                    let payload ={
                                      id:item.id
                                    }
                                    dispatch(deleteEstimateRequest(payload))
                                  }
                                }
                              ],
                              { cancelable: false } // Prevents dismissal by tapping outside the alert
                            );
                      }} style={{justifyContent:'flex-end',padding:ms(5)}}>
                        <Image resizeMode='contain' style={{height:ms(15),width:ms(15)}} source={ICONS.delete}/>
                      </TouchableOpacity>
                    </View>
                    </View>

                  </View>
                );
              }}
            />
          </View>
        </ScrollView>
        <TouchableOpacity
          onPress={() => navigate('AddEstimateWithoutClient')}
          style={{
            //marginTop: -ms(80),
            //backgroundColor: 'rgb(232, 243, 255)',
            height: ms(70),
            width: ms(70),
            borderRadius: ms(35),
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(2),
            zIndex: 1,
            right: 10,
            borderColor: COLORS.border,
            //borderWidth: 2,
          }}>
          <View
            style={{
              height: ms(50),
              width: ms(50),
              borderRadius: ms(25),
              backgroundColor: COLORS?.themeColor,

              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[
                styles.iconStyle,
                {tintColor: COLORS?.white, marginRight: ms(0)},
              ]}
            />
          </View>
        </TouchableOpacity>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
    // tintColor: COLORS.dark_grey,
    marginRight: ms(10),
  },
});
