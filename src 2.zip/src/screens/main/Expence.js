import React, {useEffect, useState, useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useFocusEffect} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {
  deleteExpenseRequest,
  getExpenseListRequest,
} from '../../redux/reducer/ProfileReducer';
export default function Expence() {
  const dispatch = useDispatch();
  const {expenseList} = useSelector(state => state.ProfileReducer);
  const [option, setOption] = useState('All');
  const [isEnabled, setIsEnabled] = useState(false);
  useEffect(() => {}, []);
  const totalRate = expenseList.reduce(
    (sum, expense) => sum + (expense.totalAmount || 0),
    0,
  );
  useFocusEffect(
    useCallback(() => {
      dispatch(getExpenseListRequest());
    }, []),
  );

  const callDeleteApi = item => {
    Alert.alert('Delete', 'Do you want to delete ?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: () => {
          let payload = {
            id: item.id,
          };
          dispatch(deleteExpenseRequest(payload));
        },
      },
    ]);

    console.log('from expense', JSON.stringify(item));

    //dispatch(deleteExpenseRequest(payload))
  };

  const getDetails = item => {
    navigate('UpdateExpence', {item: item});
  };
  const MySeparator = () => <View style={styles.separator} />;
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: COLORS?.white,
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Expenses'}
          searchOptionPresent={true}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          downloadPresent={true}
        />
      </View>

      <View
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20), marginBottom: ms(50)}}>
          <>
            <View
              style={{
                padding: ms(10),
                marginTop: ms(10),
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                borderBottomWidth: ms(0.6),
                borderBottomColor: '#DEDEDE',
                gap: ms(10),
                width: Dimensions?.get('window')?.width,
                marginLeft: -ms(20),
              }}>
              <View style={{width: '85%'}}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(10),
                    marginLeft: ms(10),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    2025 sorted by category
                  </Text>
                  <Image
                    source={ICONS?.arrow}
                    style={{
                      height: ms(10),
                      width: ms(10),
                      transform: [{rotate: '180deg'}],
                      tintColor: COLORS?.themeColor,
                    }}
                    resizeMode="contain"
                  />
                </View>
              </View>
              <Image
                source={ICONS?.sort}
                style={{height: ms(12), width: ms(12)}}
                resizeMode="contain"
              />
            </View>
            {expenseList.length > 0 ? (
              <FlatList
                data={expenseList}
                ItemSeparatorComponent={MySeparator}
                contentContainerStyle={{marginTop:ms(10)}}
                renderItem={({item, index}) => {
                  return (
                    <View>
                      <View
                        style={{
                          height: ms(45),
                          width: '100%',
                          //borderWidth: ms(0.6),
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          backgroundColor: 'rgba(4, 127, 255, 0.1)',
                          borderColor:COLORS.themeColor,
                          padding: ms(10),
                          borderRadius: ms(6),
                          

                        }}>
                        <Text style={{
                                      fontFamily: FONTS?.Medium,
                                      fontSize: ms(12),
                                      color: COLORS?.themeColor,
                                    }}>{item?.catagory}</Text>
                        <Text style={{
                                      fontFamily: FONTS?.Medium,
                                      fontSize: ms(12),
                                      color: COLORS?.black,
                                    }}>${item?.totalAmount}</Text>
                      </View>
                      {item?.expenses?.length > 0 ? (
                        <FlatList
                          data={item?.expenses}
                          renderItem={({item, index}) => {
                            return (
                              <View
                                style={{
                                  padding: ms(10),
                                  backgroundColor: COLORS?.white,
                                  borderWidth: ms(0.5),
                                  borderColor: '#DEDEDE',
                                  borderRadius: ms(6),
                                  marginTop: ms(10),
                                  elevation: ms(3),
                                  shadowColor: 'rgba(4, 127, 255, 0.2)',
                                }}>
                                <View
                                  style={{
                                    backgroundColor: 'rgba(4, 127, 255, 0.1)',
                                    padding: ms(10),
                                    borderRadius: ms(6),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    gap: ms(10),
                                  }}>
                                  <Image
                                    source={ICONS?.digital_marketing}
                                    style={{height: ms(15), width: ms(15)}}
                                    resizeMode="contain"
                                  />

                                  <Text
                                    style={{
                                      fontFamily: FONTS?.Medium,
                                      fontSize: ms(12),
                                      color: COLORS?.themeColor,
                                    }}>
                                    {item?.merchant}
                                  </Text>
                                </View>
                                <View
                                  style={{
                                    paddingLeft: ms(10),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                  }}>
                                  <View style={{width: '70%'}}>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Medium,
                                        fontSize: ms(12),
                                        color: '#344054',
                                        marginTop: ms(10),
                                      }}>
                                      ${item?.rate}
                                    </Text>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Light,
                                        fontSize: ms(10),
                                        color: COLORS?.black,
                                      }}>
                                      {item?.description}
                                    </Text>
                                  </View>
                                  <View
                                    style={{
                                      marginRight: ms(10),
                                      marginTop: ms(10),
                                    }}>
                                    <TouchableOpacity
                                      onPress={() => getDetails(item)}>
                                      <Image
                                        resizeMode="contain"
                                        source={ICONS.editicn}
                                        style={{height: ms(15), width: ms(15)}}
                                      />
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                      onPress={() => callDeleteApi(item)}
                                      style={{marginTop: ms(10)}}>
                                      <Image
                                        resizeMode="contain"
                                        source={ICONS.delete}
                                        style={{height: ms(15), width: ms(15)}}
                                      />
                                    </TouchableOpacity>
                                  </View>
                                </View>
                              </View>
                            );
                          }}
                        />
                      ) : null}
                    </View>
                  );
                }}
              />
            ) : (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(204), width: ms(232)}}
                  source={ICONS.noexpense}
                />
              </View>
            )}
          </>
        </View>
      </View>
      <TouchableOpacity
        onPressIn={() => navigate('AddNewExpense')}
        style={{
          height: ms(50),
          width: ms(50),
          borderRadius: ms(25),
          backgroundColor: COLORS?.themeColor,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(60),
          right: ms(20),
        }}
        onPress={() => {
          // navigate('CreateProject');
        }}>
        <Image
          source={ICONS.addMore}
          resizeMode="contain"
          style={[styles.iconStyle, {tintColor: COLORS?.white}]}
        />
      </TouchableOpacity>
      {totalRate !== 0  ? <View
        style={{
          width: '100%',
          backgroundColor: '#FFF',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(0),
          paddingHorizontal: ms(25),
          paddingVertical: ms(15),
          borderTopLeftRadius: ms(20),
          borderTopRightRadius: ms(20),
          flexDirection: 'row',
          justifyContent: 'space-between',
          borderWidth: ms(0.6),
          borderColor: '#EFEFEF',
          elevation: ms(3),
          shadowColor: 'rgba(4, 127, 255, 0.2)',
        }}>
        <Text
          style={{
            fontFamily: FONTS?.Medium,
            fontSize: ms(10),
            color: '#344054',
          }}>
          Total
        </Text>
        <Text
          style={{
            fontFamily: FONTS?.Medium,
            fontSize: ms(12),
            color: '#344054',
          }}>
          ${totalRate}
        </Text>
      </View>:null}
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
  separator: {
    height: ms(1),
    //backgroundColor: 'lightgray',
    marginVertical: ms(8),
  },
});
