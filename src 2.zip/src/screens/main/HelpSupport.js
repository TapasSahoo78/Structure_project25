import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';
import DepthHeader from '../../components/DepthHeader';

export default function HelpSupport() {
  const [option, setOption] = useState('unpaid');
  const clientList = [
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
  ];
  useEffect(() => {}, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          // borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Help'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
        <View
          style={{
            marginVertical: ms(10),
            backgroundColor: COLORS?.white,
            flexDirection: 'row',
            width: Dimensions?.get('window')?.width - 60,
            alignSelf: 'center',
            borderRadius: ms(10),
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingHorizontal: ms(10),
            paddingVertical: ms(10),
          }}>
          <Text
            style={{
              //padding: ms(15),
              // width: '45%',
              textAlign: 'center',
            }}>
            FAQ
          </Text>
          <View
            style={{
              height: 20,
              width: 20,
              borderRadius: 10,
              backgroundColor: COLORS.themeColor,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image
              resizeMode="contain"
              source={ICONS.rightarrow}
              style={{height: ms(10), width: ms(10)}}
            />
          </View>
        </View>
      </View>
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          flex: 1,
        }}
        source={IMAGES?.colorBackground}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1, paddingHorizontal: ms(20)}}>
            <View
              style={{
                height: ms(46),
                backgroundColor: 'rgba(4, 127, 255, 0.1)',
                borderRadius: ms(10),
                justifyContent: 'center',
                paddingLeft: ms(10),
                marginTop: ms(20),
              }}>
              <Text
                style={{fontSize: ms(14), color: '#047FFF', fontWeight: '600'}}>
                Help & Support
              </Text>
            </View>
            <View
              style={{
                padding: ms(10),
                borderWidth: 1,
                borderColor: COLORS.border,
                backgroundColor: COLORS.white,
                flexDirection: 'row',
                alignItems: 'center',
                borderRadius: ms(10),
                marginTop: ms(20),
              }}>
              <View
                style={{
                  padding: 6,
                  borderRadius: ms(8),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(19), width: ms(30)}}
                  source={ICONS.email}
                />
              </View>

              <View style={{marginLeft: ms(10)}}>
                <Text style={{fontFamily: FONTS.Regular, fontSize: ms(14)}}>
                  Email Us
                </Text>
                <Text style={{fontFamily: FONTS.Regular, fontSize: ms(12)}}>
                  raiseinvoice@gmail.com
                </Text>
              </View>
            </View>

            <View
              style={{
                padding: ms(10),
                borderWidth: 1,
                borderColor: COLORS.border,
                backgroundColor: COLORS.white,
                flexDirection: 'row',
                alignItems: 'center',
                borderRadius: ms(10),
                marginTop: ms(20),
              }}>
              <View
                style={{
                  padding: 6,
                  borderRadius: ms(8),
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(23), width: ms(23)}}
                  source={ICONS.receiver}
                />
              </View>

              <View style={{marginLeft: ms(10)}}>
                <Text style={{fontFamily: FONTS.Regular, fontSize: ms(14)}}>
                  Call Us
                </Text>
                <Text style={{fontFamily: FONTS.Regular, fontSize: ms(12)}}>
                  1800 2502 2456
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
