import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Linking,
  Alert,
  Platform,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import normalize from '../../utils/helpers/normalize';
import DepthHeader from '../../components/DepthHeader';
import {useFocusEffect} from '@react-navigation/native';
import DeviceInfo from 'react-native-device-info';
import {
  deleteInvoiceRequest,
  getInvoicePreviewRequest,
  getInvoiceSettingsRequest,
  invoiceDeletelRequest,
  invoiceDetailRequest,
} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
//import {Print} from 'react-native-print';
import RNPrint from 'react-native-print';
import RNHTMLtoPDF from 'react-native-html-to-pdf';
import moment from 'moment';
import Share from 'react-native-share';
import Loader from '../../utils/helpers/Loader';
import {pick, types} from '@react-native-documents/picker';
import SignatureModal from '../../components/SignatureModal';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import Toast from '../../utils/helpers/Toast';

const pdfUrl = 'https://www.pdf995.com/samples/pdf.pdf';

export default function InvoiceDetails(props) {
  const dispatch = useDispatch();
  const [previewUrl, setPreviewUrl] = useState('');
  const [pdfFilePath, setPdfFilePath] = useState('');
  const [myDoc, setMydoc] = useState('');
  const [signatureVisible, setSignatureVisible] = useState(false);
  const [capturedSignature, setCapturedSignature] = useState(null);
  const [signatureOptionModal, setSignatureOptionModal] = useState(false);
  const [sigOption, setSigOption] = useState('');
  const [isTablet, setIsTablet] = useState(false);
  const [inputSignature, setInputSignature] = useState('');
  const [camModal, setCamModal] = useState(false);
  const [signatureImg,setSignatureImg] = useState("")
  const {invoiceDetail, invoiceSettings, invoicePreview, loading} = useSelector(
    state => state.ProfileReducer,
  );
  useFocusEffect(
    useCallback(() => {
      let payload = {id: props?.route?.params?.item_id};
      dispatch(invoiceDetailRequest(payload));
      dispatch(getInvoiceSettingsRequest());
    }, []),
  );
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useEffect(() => {
    setPreviewUrl(invoicePreview);
    if (invoicePreview) {
      getPdfFile(invoicePreview);
    }
  }, [invoicePreview]);

  const getPdfFile = async previewData => {
    try {
      // Step 1: Generate PDF
      const pdf = await RNHTMLtoPDF.convert({
        html: `${previewData}`,
        fileName: 'InvoiceReport',
        base64: false,
        options: {
          width: 612, // 8.5 inch (portrait, letter)
          height: 792,
          orientation: 'portrait', // or 'landscape'
          margin: {top: 40, bottom: 40, left: 40, right: 40},
        },
      });

      const filePath = pdf.filePath;
      console.log('PDF generated at:', filePath);
      setPdfFilePath(filePath);
      // await Share.open({
      //   url: `file://${filePath}`, // must use file:// protocol
      //   type: 'application/pdf',
      //   title: 'Invoice Report',
      //   message: 'Hi, please find the attached PDF report.', // This appears in email body
      //   subject: 'Monthly Invoice Report', // Email subject
      // });

      // Step 2: Share via email or other apps
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Error', `Failed: ${error.message || 'Unknown error'}`);
    }
  };

  useEffect(() => {
    // if (!invoiceDetail?.invoice?.id || !invoiceSettings?.name) {
    //   console.log('Missing required data for preview:', {
    //     invoiceId: invoiceDetail?.invoice?.id,
    //     templateName: invoiceSettings?.name,
    //   });
    //   return; // Wait until data is ready
    // }
    if (!invoiceDetail?.invoice?.id ) {
      console.log('Missing required data for preview:', {
        invoiceId: invoiceDetail?.invoice?.id,
        templateName: invoiceSettings?.name,
      });
      return; // Wait until data is ready
    }

    let payload = {
      templateName: invoiceSettings?.name || "impact",
      invoiceId: invoiceDetail?.invoice?.id,
    };
    dispatch(getInvoicePreviewRequest(payload));
    console.log('preview payload', payload);
  }, [invoiceSettings, invoiceDetail, dispatch]);

  const printInvoice = async () => {
    try {
      await RNPrint.print({
        html: previewUrl,
      });
    } catch (error) {
      console.log('print error', error);
    }
  };

  const [sendOptionModal, setSendOptionModal] = useState(false);

  function getDaysUntilDue(dueDateStr) {
    const dueDate = new Date(dueDateStr);

    const today = new Date();

    // Reset time part to ensure only date difference is calculated
    const dueDateOnly = new Date(
      dueDate.getFullYear(),
      dueDate.getMonth(),
      dueDate.getDate(),
    );
    const todayOnly = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
    );

    // Calculate the difference in milliseconds
    const differenceMs = dueDateOnly - todayOnly;

    // Convert milliseconds to days
    const days = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

    return days;
  }

  const handleSaveSignature = signatureUri => {
    setCapturedSignature(signatureUri);
    //Alert.alert('Success', 'Signature saved successfully!');
  };

  const checkValidation = () => {
    if (inputSignature == '') {
      Toast('Enter signature');
    }else{
      setSignatureOptionModal(false)
    }
  };

  const onPressGallery = () => {
      launchImageLibrary(
        {
          mediaType: 'photo',
          quality: 0.5,
          maxWidth: ms(500),
          maxHeight: ms(500),
          includeBase64: true,
        },
        response => {
          if (response.didCancel || response.errorCode) {
            console.log('Image picker cancelled or failed:', response);
            return;
          }
  
          if (response.assets && response.assets.length > 0) {
            const asset = response.assets[0];
  
            // Create image object with Base64
            const imageObj = {
              name: asset.fileName || asset.uri.split('/').pop(), // fallback to last part of URI
              type: asset.type, // e.g., 'image/jpeg'
              uri: asset.uri,
              size: asset.fileSize,
              base64: `data:${asset.type};base64,${asset.base64}`, // Full data URL
            };
  
            console.log('Image with Base64:', imageObj);
            setSignatureImg(imageObj.base64);
  
            // Pass to parent component
  
            setCamModal(false); // Close modal
          }
        },
      );
    };
  
    const onPressCamera = () => {
      launchCamera(
        {
          mediaType: 'photo',
          quality: 0.5,
          maxWidth: ms(500),
          maxHeight: ms(500),
          includeBase64: true,
        },
        response => {
          if (response.didCancel || response.errorCode) {
            console.log('Camera cancelled or error:', response);
            return;
          }
  
          if (response.assets && response.assets.length > 0) {
            const asset = response.assets[0];
  
            const imageObj = {
              name: asset.fileName || asset.uri.split('/').pop(),
              type: asset.type,
              uri: asset.uri,
              size: asset.fileSize,
              base64: `data:${asset.type};base64,${asset.base64}`, // Ready for upload or display
            };
  
            console.log('Photo with Base64:', imageObj);
  
            setSignatureImg(imageObj.base64);
            setCamModal(false);
          }
        },
      );
    };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={''}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          editOptionPresent={true}
        />
      </View>

      <View style={{width: '100%', marginBottom: ms(60)}}>
        <ScrollView>
          <View
            style={{
              paddingHorizontal: ms(20),
              marginTop: ms(20),
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View>
              <Text
                style={{
                  fontSize: ms(22),
                  fontFamily: FONTS.Medium,
                  color: '#344054',
                }}>
                Invoice {invoiceDetail?.invoice?.id}
              </Text>
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Regular,
                  color: '#344054',
                }}>
                {invoiceDetail?.invoice?.client_id?.name}
              </Text>
              <Text
                style={{
                  fontSize: ms(10),
                  fontFamily: FONTS.Regular,
                  color: '#F25022',
                }}>
                Unsent
              </Text>
            </View>

            <View>
              <Text
                style={{
                  fontSize: ms(10),
                  fontFamily: FONTS.Light,
                  color: '#344054',
                  textAlign: 'center',
                }}>
                {moment(invoiceDetail?.invoice?.date).format('LL')}
              </Text>
              <Text
                style={{
                  fontSize: ms(18),
                  fontFamily: FONTS.Medium,
                  textAlign: 'center',
                  color: '#344054',
                }}>
                ${invoiceDetail?.invoice?.balance}
              </Text>
              <Text
                style={{
                  fontSize: ms(10),
                  fontFamily: FONTS.Light,
                  color: '#344054',
                  textAlign: 'center',
                }}>
                Due in {getDaysUntilDue(invoiceDetail?.invoice?.dueDate)} days
              </Text>
            </View>
          </View>
          <View
            style={{
              height: normalize(230),
              width: '80%',
              alignSelf: 'center',
              backgroundColor: 'rgb(232, 243, 255)',
              borderBottomColor: 'rgb(195, 211, 226)',
              marginTop: ms(30),
              borderRadius: ms(10),
            }}>
            <View
              style={{
                width: '80%',
                height: normalize(230),
                marginTop: normalize(20),
                backgroundColor: COLORS.white,
                alignSelf: 'center',
                padding: ms(10),
              }}>
              <View
                style={{
                  width: '100%',
                  backgroundColor: 'rgb(232, 243, 255)',
                  padding: ms(10),
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: ms(9),
                      fontFamily: FONTS.Bold,
                      color: COLORS.themeColor,
                    }}>
                    Invoice
                  </Text>
                  <View>
                    <Text style={{fontSize: ms(5), fontFamily: FONTS.Regular}}>
                      Invoice No.
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Bold}}>
                      #000123
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginTop: ms(10),
                  }}>
                  <View>
                    <Text style={{fontSize: ms(5), fontFamily: FONTS.Regular}}>
                      Billed To
                    </Text>
                    <Text style={{fontSize: ms(5), fontFamily: FONTS.Bold}}>
                      Client Name
                    </Text>
                    <Text style={{fontSize: ms(5), fontFamily: FONTS.Regular}}>
                      Address / Contact Info
                    </Text>
                  </View>

                  <View>
                    <Text style={{fontSize: ms(5), fontFamily: FONTS.Regular}}>
                      Issued on
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Bold}}>
                      December 7, 2022.
                    </Text>
                    <Text
                      style={{
                        fontSize: ms(5),
                        fontFamily: FONTS.Regular,
                        marginTop: ms(10),
                      }}>
                      Payment Due
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Bold}}>
                      December 7, 2022.
                    </Text>
                  </View>

                  <View></View>
                </View>
                <TouchableOpacity
                  onPress={() => navigate('InvoiceWebview')}
                  style={{
                    height: ms(40),
                    width: ms(116),
                    borderRadius: ms(20),
                    backgroundColor: '#121722',
                    position: 'absolute',
                    bottom: -20,
                    right: '25%',
                    left: '25%',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: ms(12), width: ms(12)}}
                    source={ICONS.preview}
                  />
                  <Text
                    style={{
                      fontSize: ms(14),
                      color: COLORS.white,
                      fontFamily: FONTS.Medium,
                      marginLeft: ms(5),
                    }}>
                    Preview
                  </Text>
                </TouchableOpacity>
              </View>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: ms(20),
                }}>
                <View style={{width: '40%'}}>
                  <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                    Services
                  </Text>
                  <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                    Invoice Item 1
                  </Text>
                </View>
                <View
                  style={{
                    width: '60%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}>
                  <View>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      Qty
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      1
                    </Text>
                  </View>
                  <View>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      Price
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      40000
                    </Text>
                  </View>
                  <View>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      Total
                    </Text>
                    <Text style={{fontSize: ms(6), fontFamily: FONTS.Medium}}>
                      40000
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '93%',
              justifyContent: 'space-between',
              padding: ms(20),
              alignSelf: 'center',
            }}>
            <TouchableOpacity
              // onPress={async () => {
              //   try {
              //     const [result] = await pick({
              //       mode: 'open',
              //       type: [types.pdf],
              //       allowMultiSelection: false,
              //     });
              //     console.log('result on open file pdf', result);
              //     let uri = result.uri;
              //     if (Platform.OS === 'android' && !uri.startsWith('file://')) {
              //       uri = `file://${uri}`;
              //     }
              //     setMydoc(uri);
              //   } catch (error) {}
              // }}
              style={{
                height: ms(40),
                width: ms(140),
                borderWidth: ms(1),
                borderColor: COLORS.themeColor,
                borderRadius: ms(10),
                flexDirection: 'row',
                // justifyContent: 'center',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                //backgroundColor:'#CCCCCC',
                opacity: 0.4,
              }}>
              <Image
                resizeMode="contain"
                style={{height: ms(15), width: ms(14)}}
                source={ICONS.attach}
                //tintColor={COLORS.black}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  color: COLORS.themeColor,
                  marginLeft: ms(4),
                  fontFamily: FONTS.Regular,
                }}>
                Attach File
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={async () => {
                //setSendOptionModal(true)
                await Share.open({
                  url: `file://${pdfFilePath}`, // must use file:// protocol
                  type: 'application/pdf',
                  title: 'Invoice Report',
                  message: 'Hi, please find the attached PDF report.', // This appears in email body
                  subject: 'Monthly Invoice Report', // Email subject
                });
              }}
              style={{
                height: ms(40),
                width: ms(130),
                borderWidth: 1,
                borderColor: COLORS.themeColor,
                borderRadius: ms(20),
                backgroundColor: COLORS.themeColor,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text
                style={{
                  fontSize: ms(12),
                  color: COLORS.white,
                  fontFamily: FONTS.Medium,
                }}>
                Send
              </Text>
            </TouchableOpacity>
          </View>
          <View
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              justifyContent: 'center',
              backgroundColor: 'rgb(232, 243, 255)',
              borderRadius: ms(10),
              paddingLeft: ms(10),
            }}>
            <Text
              style={{
                fontSize: ms(12),
                color: COLORS.themeColor,
                fontFamily: FONTS.Medium,
              }}>
              Payment
            </Text>
          </View>
          <Text
            style={{
              fontSize: ms(12),
              color: COLORS.themeColor,
              fontFamily: FONTS.Medium,
              alignSelf: 'center',
              marginTop: ms(20),
            }}>
            Mark as Fully Paid
          </Text>

          <View
            style={{
              height: ms(40),
              alignSelf: 'center',
              width: '85%',
              borderTopWidth: ms(1),
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: ms(10),
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.qrcode}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Show QR Code
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </View>
          <View
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.record}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Record Payment
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </View>

          <View
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              justifyContent: 'center',
              backgroundColor: 'rgb(232, 243, 255)',
              borderRadius: ms(10),
              paddingLeft: ms(10),
              marginTop: ms(20),
            }}>
            <Text
              style={{
                fontSize: ms(12),
                color: COLORS.themeColor,
                fontFamily: FONTS.Medium,
              }}>
              More
            </Text>
          </View>

          <View
            style={{
              height: ms(40),
              alignSelf: 'center',
              width: '85%',
              borderTopWidth: ms(1),
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: ms(20),
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.recurring}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Recurring Invoice
              </Text>
            </View>
          </View>
          <View
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.printer}
              />
              <Text
                onPress={() => printInvoice()}
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Print
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              navigate('EditInvoice', {item: props.route.params.item});
            }}
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.copypdf}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Copy
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </TouchableOpacity>
          <View
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.exportpdf}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Export as PDF
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              //setSignatureVisible(true)
              setSigOption("")
              setSignatureOptionModal(true);
              //navigate('SignatureScreen')
            }}
            style={{
              height: ms(40),
              width: '85%',
              alignSelf: 'center',
              borderBottomWidth: ms(1),
              borderColor: COLORS.border,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.sign}
              />
              <Text
                style={{
                  fontSize: ms(12),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(20),
                  color: '#344054',
                }}>
                Sign
              </Text>
            </View>
            <Image
              resizeMode="contain"
              style={{height: ms(18), width: ms(20)}}
              source={ICONS.next_arrow_circle}
            />
          </TouchableOpacity>
          <Text
            style={{
              alignSelf: 'center',
              marginTop: ms(20),
              fontSize: ms(12),
              fontFamily: FONTS.Medium,
              color: '#047FFF',
            }}>
            Mark as Sent
          </Text>
          <TouchableOpacity
            style={{
              width: '80%',
              marginTop: ms(40),
              alignSelf: 'center',
              height: ms(34),
              backgroundColor: '#fdf9fa',
              borderRadius: ms(10),
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onPress={() => {
              Alert.alert(
                'Delete',
                'Are you sure you want to delete ?',
                [
                  {
                    text: 'Cancel',
                    onPress: () => console.log('Cancel Pressed'),
                    style: 'cancel',
                  },
                  {
                    text: 'Ok',
                    onPress: () => {
                      dispatch(
                        deleteInvoiceRequest({
                          id: props?.route?.params?.item_id,
                        }),
                      );
                      goBack();
                    },
                  },
                ],
                {cancelable: false},
              );
            }}>
            <Text
              style={{
                fontSize: ms(14),
                color: 'rgba(234, 67, 53, 1)',
                fontFamily: FONTS.Medium,
              }}>
              Delete
            </Text>
          </TouchableOpacity>
        </ScrollView>
        <Modal
          isVisible={sendOptionModal}
          backdropOpacity={0.6}
          animationIn={'slideInUp'}
          animationOut={'slideOutDown'}
          animationInTiming={800}
          animationOutTiming={500}
          backdropTransitionOutTiming={0}
          hasBackdrop={true}
          onBackdropPress={() => {
            setSendOptionModal(false);
          }}
          style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
          <View
            style={{
              maxHeight: Dimensions.get('window').height,
              width: '100%',
              //height: Dimensions.get('window').height - normalize(200),
              paddingTop: normalize(10),
              paddingHorizontal: normalize(30),
              backgroundColor: '#FFF',
              borderTopLeftRadius: normalize(20),
              borderTopRightRadius: normalize(20),
              padding: normalize(40),
            }}>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontSize: normalize(18),
                  fontFamily: FONTS.Medium,
                  paddingVertical: normalize(20),
                  //paddingHorizontal: normalize(20),
                }}>
                Send By
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => {
                const subject = 'Check out this link';
                const body = 'Here is an interesting link: https://example.com';
                const url = `mailto:${
                  invoiceDetail?.invoice?.client_id?.email
                }?subject=${encodeURIComponent(
                  subject,
                )}&body=${encodeURIComponent(body)}`;

                Linking.openURL(url).catch(err =>
                  console.error('Error opening email app:', err),
                );
              }}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                height: ms(46),
                width: '100%',
                borderBottomWidth: 1,
                borderBottomColor: COLORS.border,
              }}>
              <Image
                resizeMode="contain"
                style={{height: ms(17), width: ms(26)}}
                source={ICONS.email}
              />
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(10),
                }}>
                Email
              </Text>
            </TouchableOpacity>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                height: ms(46),
                width: '100%',
                borderBottomWidth: 1,
                borderBottomColor: COLORS.border,
              }}>
              <Image
                resizeMode="contain"
                style={{height: ms(22), width: ms(25)}}
                source={ICONS.message}
              />
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(10),
                }}>
                Text Message
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                height: ms(46),
                width: '100%',
              }}>
              <Image
                resizeMode="contain"
                style={{height: ms(22), width: ms(22)}}
                source={ICONS.other}
              />
              <Text
                style={{
                  fontSize: ms(14),
                  fontFamily: FONTS.Medium,
                  marginLeft: ms(10),
                }}>
                Other
              </Text>
            </View>
          </View>
        </Modal>

        <Modal
          isVisible={signatureOptionModal}
          onBackdropPress={() => {
            setSignatureOptionModal(false);
          }} // Close modal when tapping outside
          style={{justifyContent: 'flex-end', margin: 0}}>
          <View
            style={{
              backgroundColor: 'white',
              padding: 22,
              //alignItems: 'center',
              borderTopLeftRadius: 15,
              borderTopRightRadius: 15,
              height: Dimensions.get('window').height * 0.6,
            }}>
            <View
              style={{
                width: ms(63),
                height: ms(6),
                borderRadius: ms(8),
                backgroundColor: 'rgba(217, 217, 217, 1)',
                alignSelf: 'center',
                marginBottom: ms(20),
              }}
            />
            <TouchableOpacity
              onPress={() => setSignatureOptionModal(false)}
              style={{position: 'absolute', top: 20, right: 20}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(20)}}
                source={ICONS.crossbtn}
              />
            </TouchableOpacity>
            <ScrollView showsVerticalScrollIndicator={false}>
              <View
                style={{
                  //flexDirection: 'row',
                  widt: '100%',
                  //alignItems: 'center',
                  marginBottom: 12,
                  justifyContent: 'space-between',
                  marginTop: ms(20),
                }}>
                <Text
                  style={{
                    //textAlign: 'center',
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                  }}>
                  Select Signature Option
                </Text>

                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => {
                        setSigOption('camera')
                        setSignatureOptionModal(false)
                        setCamModal(true)
                      }}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'camera' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Upload using camera or gallery
                    </Text>
                  </View>
                </View>

                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => {
                        setSigOption('canvas')
                        setSignatureOptionModal(false)
                        setSignatureVisible(true)

                      }}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'canvas' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Upload using canvas
                    </Text>
                  </View>
                </View>
                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => setSigOption('input')}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'input' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Manual entry
                    </Text>
                  </View>
                </View>
                {sigOption == 'input' ? (
                  <View>
                    <AnimatedTextInput
                      label={'Signature'}
                      //keyboardType={'numeric'}
                      minimumHeight={ms(45)}
                      width={
                        isTablet
                          ? Dimensions?.get('window')?.width - 70
                          : Dimensions?.get('window')?.width - 50
                      }
                      value={inputSignature}
                      borderColor={COLORS?.themeColor}
                      multiline={true}
                      numberOfLines={5}
                      onChangeText={item => {
                        setInputSignature(item);
                      }}
                    />

                    <TouchableOpacity
                      style={{
                        paddingHorizontal: ms(20),
                        paddingVertical: ms(8),
                        backgroundColor: COLORS?.themeColor,
                        // position: 'absolute',
                        // bottom: ms(10),
                        alignSelf: 'center',
                        width: ms(150),
                        borderRadius: ms(20),
                        marginTop: ms(30),
                      }}
                      onPress={() => {
                        checkValidation();
                      }}>
                      <Text
                        style={{
                          color: COLORS?.white,
                          textAlign: 'center',
                          fontFamily: FONTS?.Medium,
                          fontSize: ms(15),
                        }}>
                        Save
                      </Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </View>
            </ScrollView>
          </View>
        </Modal>
        <Modal
                isVisible={camModal}
                backdropOpacity={0.6}
                animationIn={'slideInUp'}
                animationOut={'slideOutDown'}
                animationInTiming={800}
                animationOutTiming={500}
                backdropTransitionOutTiming={0}
                hasBackdrop={true}
                onBackdropPress={() => {
                  setCamModal(false);
                }}
                style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
                <View
                  style={{
                    maxHeight: Dimensions.get('window').height,
                    width: '100%',
                    //height: Dimensions.get('window').height - normalize(200),
                    paddingTop: normalize(10),
                    paddingHorizontal: normalize(30),
                    backgroundColor: '#FFF',
                    borderTopLeftRadius: normalize(20),
                    borderTopRightRadius: normalize(20),
                    padding: normalize(40),
                  }}>
                  <View
                    style={{
                      width: ms(63),
                      height: ms(6),
                      borderRadius: ms(8),
                      backgroundColor: 'rgba(217, 217, 217, 1)',
                      alignSelf: 'center',
                      marginBottom: ms(20),
                      marginTop: ms(10),
                    }}
                  />
                  <View
                    style={{
                      width: '100%',
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}>
                    <Text
                      style={{
                        fontSize: normalize(18),
                        fontFamily: FONTS.Medium,
                        paddingVertical: normalize(20),
                        //paddingHorizontal: normalize(20),
                      }}>
                      Open gallery
                    </Text>
                    <TouchableOpacity
                      //onPress={() => (false)}
                      style={{flexDirection: 'row', alignItems: 'center'}}>
                      <Text
                        style={{
                          fontSize: normalize(16),
                          color: COLORS.themeColor,
                          fontFamily: FONTS.Regular,
                        }}>
                        Upload
                      </Text>
                      <Image
                        resizeMode="contain"
                        style={{
                          height: normalize(17),
                          width: normalize(17),
                          marginLeft: normalize(5),
                        }}
                        source={ICONS.bluetick}
                      />
                    </TouchableOpacity>
                  </View>
        
                  <Text
                    style={{
                      fontSize: normalize(14),
                      fontFamily: FONTS.Regular,
                      //marginTop: normalize(35),
                    }}>
                    Add image here upload from gallery or click a picture
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      width: '100%',
                      marginTop: normalize(25),
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}>
                    <TouchableOpacity
                      onPress={() => onPressGallery()}
                      style={{
                        height: normalize(120),
                        width: normalize(140),
                        justifyContent: 'center',
                        alignItems: 'center',
                        borderWidth: 1,
                        //borderColor: COLORS.border,
                        borderRadius: normalize(20),
                        borderStyle: 'dotted',
                        borderColor: COLORS.themeColor,
                        elevation: 3,
                        backgroundColor: COLORS.white,
                        shadowColor: COLORS.themeColor,
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{height: normalize(30), width: normalize(40)}}
                        source={ICONS.gallery}
                      />
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          marginTop: normalize(20),
                        }}>
                        <Image
                          resizeMode="contain"
                          style={{height: ms(15), width: ms(15), marginRight: ms(5)}}
                          source={ICONS.plusicn}
                        />
                        <Text
                          style={{
                            fontSize: normalize(14),
                            color: COLORS.themeColor,
                            fontFamily: FONTS.Regular,
                          }}>
                          Add photo
                        </Text>
                      </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => onPressCamera()}
                      style={{
                        height: normalize(120),
                        width: normalize(140),
                        borderWidth: 1,
                        //borderColor: COLORS.border,
                        borderRadius: normalize(20),
                        justifyContent: 'center',
                        alignItems: 'center',
                        borderStyle: 'dotted',
                        borderColor: COLORS.themeColor,
                        elevation: 3,
                        backgroundColor: COLORS.white,
                        shadowColor: COLORS.themeColor,
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{height: normalize(30), width: normalize(40)}}
                        source={ICONS.cam}
                      />
                      <Text
                        style={{
                          fontSize: normalize(14),
                          marginTop: normalize(20),
                          color: COLORS.themeColor,
                          fontFamily: FONTS.Regular,
                        }}>
                        Camera
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
        </Modal>
        <SignatureModal
          visible={signatureVisible}
          onClose={() => setSignatureVisible(false)}
          onSignatureSave={handleSaveSignature}
        />
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    //justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
