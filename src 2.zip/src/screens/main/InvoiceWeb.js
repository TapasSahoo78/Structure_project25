import React, { useRef } from 'react';
import { View, Button, Alert } from 'react-native';
import { WebView } from 'react-native-webview';

const InvoiceWeb = () => {
  const webviewRef = useRef(null);

  const injectPrintScript = () => {
    if (webviewRef.current) {
      webviewRef.current.injectJavaScript(`
        if (window.ReactNativeWebView) {
          // If running within React Native WebView, use postMessage to signal print
          window.ReactNativeWebView.postMessage('triggerPrint');
        } else {
          // Fallback for web environment (e.g., if opened in external browser)
          window.print();
        }
      `);
    }
  };

  const handleWebViewMessage = (event) => {
    const data = event.nativeEvent.data;
    if (data === 'triggerPrint') {
      // Handle print logic on the React Native side
      Alert.alert('Print Request', 'Initiating print process from WebView...');
      // You would integrate a native printing solution here, e.g., react-native-print
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <WebView
        ref={webviewRef}
        source={{ html: '<h1>Hello from WebView!</h1><button onclick="window.print()">Print This Page</button>' }}
        // Or source={{ uri: 'https://example.com' }}
        onMessage={handleWebViewMessage}
        style={{ flex: 1 }}
      />
      <Button title="Trigger Print from RN" onPress={injectPrintScript} />
    </View>
  );
};

export default InvoiceWeb;