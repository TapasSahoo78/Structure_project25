import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useFocusEffect} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {projectListRequest,getPreviewInvoiceRequest} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import WebView from 'react-native-webview';
export default function InvoiceWebview() {
  const [option, setOption] = useState('All');
  const {getTemplate, loading,invoiceSettings,previewInvoice,invoicePreview} = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();
  const activeProjects = [
    {
      name: 'Project 1',
      contact_name: 'Akash Mishra',
      date: '2024-11-01',
    },
  ];
  const allProjects = [];
  const completedProjects = [];

  useFocusEffect(
    useCallback(() => {
      let payload = {};
      dispatch(projectListRequest(payload));
    }, []),
  );

  // useEffect(()=>{
  //   if(invoiceSettings){
  //     let payload = {
  //       templateName:invoiceSettings.name
  //     }
  //     dispatch(getPreviewInvoiceRequest(payload))
  //   }else{
  //     let payload = {
  //       templateName:"impact"
  //     }
  //     dispatch(getPreviewInvoiceRequest(payload))
  //   }

  // },[invoiceSettings])
 
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Preview Invoice'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
          marginTop: ms(20),
        }}>
        <View style={{flex: 1}}>
          <View
            style={{
              height: Dimensions?.get('window')?.height,
              width: Dimensions?.get('window')?.width,
              backgroundColor: COLORS?.white,
              // paddingLeft: -ms(20),
            }}>
              {invoicePreview?<WebView
              mediaPlaybackRequiresUserAction={false}
              androidLayerType="hardware"
              mixedContentMode="always"
              style={{
                height: Dimensions?.get('window')?.height,
                width: Dimensions?.get('window')?.width,
                alignSelf: 'center',
                alignContent: 'center',
                flex: 1,
              }}
              javaScriptEnabled={true}
              source={{
                html: invoicePreview,
              }}
              // source={{
              //   uri:
              //     item?.post +
              //     '? loop=1&autoplay=1&showinfo=0&controls=0&fullscreen=1',
              // }}
            />:null}
            
          </View>
        </View>
      </ScrollView>
      {/* <TouchableOpacity
        style={{
          height: ms(50),
          width: ms(50),
          borderRadius: ms(25),
          backgroundColor: COLORS?.themeColor,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(20),
          right: ms(20),
        }}
        onPress={() => {
          navigate('CreateProject');
        }}>
        <Image
          source={ICONS.addMore}
          resizeMode="contain"
          style={[styles.iconStyle, {tintColor: COLORS?.white}]}
        />
      </TouchableOpacity> */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
