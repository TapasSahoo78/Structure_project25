import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';

export default function MoreOption() {
  const [option, setOption] = useState('unpaid');
  const [toggleButtonFlag, setToggleButtonFlag] = useState(false);
  const clientList = [
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
  ];
  useEffect(() => {}, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <MainHeader
          label={'More'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
        />
      </View>
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          flex: 1,
        }}
        source={IMAGES?.colorBackground}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1, padding: ms(20)}}>
            <TouchableOpacity
              style={{
                backgroundColor: COLORS?.white,
                padding: ms(10),
                borderRadius: ms(10),
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: ms(20),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.5)',
              }}
              onPress={() => {
                navigate('Project');
              }}>
              <View>
                <Text
                  style={{
                    fontFamily: FONTS?.Light,
                    fontSize: ms(10),
                    color: '#344054',
                  }}>
                  Workflow
                </Text>
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(12),
                    color: '#344054',
                  }}>
                  Projects
                </Text>
              </View>
              <Image
                source={ICONS?.next_arrow_circle}
                style={{height: ms(20), width: ms(20)}}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                backgroundColor: COLORS?.white,
                padding: ms(10),
                borderRadius: ms(10),
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: ms(20),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.5)',
              }}
              onPress={() => {
                navigate('ClientPaymentOption');
              }}>
              <View>
                <Text
                  style={{
                    fontFamily: FONTS?.Light,
                    fontSize: ms(10),
                    color: '#344054',
                  }}>
                  Cashflow
                </Text>
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(12),
                    color: '#344054',
                  }}>
                  Client Payment Options
                </Text>
              </View>
              <Image
                source={ICONS?.next_arrow_circle}
                style={{height: ms(20), width: ms(20)}}
                resizeMode="contain"
              />
            </TouchableOpacity>
            <View
              style={{
                backgroundColor: COLORS?.white,
                padding: ms(10),
                borderRadius: ms(10),
                marginBottom: ms(20),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.5)',
              }}>
              <TouchableOpacity
                onPress={() => navigate('PurchaseOrder')}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                    }}>
                    Other
                  </Text>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Purchase Order
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => navigate('CreditNote')}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderTopWidth: ms(0.8),
                  borderTopColor: '#EFEFEF',
                  paddingTop: ms(10),
                  marginTop: ms(10),
                }}>
                <View style={{}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Credit Notes
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
            </View>
            <View
              style={{
                backgroundColor: COLORS?.white,
                padding: ms(10),
                borderRadius: ms(10),

                marginBottom: ms(20),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.5)',
              }}>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
                onPress={() => {
                  navigate('OtherItem');
                }}>
                <View>
                  <Text
                    style={{
                      fontFamily: FONTS?.Light,
                      fontSize: ms(10),
                      color: '#344054',
                    }}>
                    Other
                  </Text>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Items
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderTopWidth: ms(0.8),
                  borderTopColor: '#EFEFEF',
                  paddingTop: ms(10),
                  marginTop: ms(10),
                }}
                onPress={() => {
                  navigate('Expence');
                }}>
                <View style={{}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Expenses
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => navigate('Appointment')}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderTopWidth: ms(0.8),
                  borderTopColor: '#EFEFEF',
                  paddingTop: ms(10),
                  marginTop: ms(10),
                }}>
                <View style={{}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Appointments
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => navigate('Project')}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderTopWidth: ms(0.8),
                  borderTopColor: '#EFEFEF',
                  paddingTop: ms(10),
                  marginTop: ms(10),
                }}>
                <View style={{}}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: '#344054',
                    }}>
                    Time Tracking
                  </Text>
                </View>
                <Image
                  source={ICONS?.next_arrow_circle}
                  style={{height: ms(20), width: ms(20)}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              onPress={() => navigate('Reports')}
              style={{
                backgroundColor: COLORS?.white,
                padding: ms(10),
                borderRadius: ms(10),
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: ms(20),
                elevation: ms(5),
                shadowColor: 'rgba(4, 127, 255, 0.5)',
              }}>
              <View>
                <Text
                  style={{
                    fontFamily: FONTS?.Light,
                    fontSize: ms(10),
                    color: '#344054',
                  }}>
                  Insights
                </Text>
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(12),
                    color: '#344054',
                  }}>
                  Reports
                </Text>
              </View>
              <Image
                source={ICONS?.next_arrow_circle}
                style={{height: ms(20), width: ms(20)}}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </ScrollView>
        {/* <View
          style={{
            //marginTop: -ms(80),
            //backgroundColor: 'rgb(232, 243, 255)',
            height: ms(70),
            width: ms(70),
            borderRadius: ms(35),
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: ms(2),
            zIndex: 1,
            right: 10,
            borderColor: COLORS.border,
            //borderWidth: 2,
          }}>
          <View
            style={{
              height: ms(50),
              width: ms(50),
              borderRadius: ms(25),
              backgroundColor: COLORS?.themeColor,

              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={ICONS.addMore}
              resizeMode="contain"
              style={[
                styles.iconStyle,
                {tintColor: COLORS?.white, marginRight: ms(0)},
              ]}
            />
          </View>
        </View> */}
      </ImageBackground>
      <TouchableOpacity
                        style={{
                          height: ms(50),
                          width: ms(50),
                          borderRadius: ms(25),
                          backgroundColor: COLORS?.themeColor,
                          alignItems: 'center',
                          justifyContent: 'center',
                          position: 'absolute',
                          bottom: ms(20),
                          right: ms(20),
                          zIndex: 10,
                        }}
                        onPress={() => {
                          setToggleButtonFlag(!toggleButtonFlag);
                        }}>
                        {!toggleButtonFlag ? (
                          <Image
                            source={ICONS.addMore}
                            resizeMode="contain"
                            style={[styles.iconStyle, {tintColor: COLORS?.white}]}
                          />
                        ) : (
                          <Image
                            source={ICONS?.addMore}
                            //style={[styles.iconStyle, {height: ms(50), width: ms(50)}]}
                            style={[styles.iconStyle, {tintColor: COLORS?.white,borderRadius:ms(10),transform: [{ rotate: '45deg' }]}]}
                          />
                        )}
                      </TouchableOpacity>
                      {toggleButtonFlag ? (
                              <View
                                style={{
                                  flex: 1,
                                  backgroundColor: 'rgba(0,0,0, 0.5)',
                                  height: Dimensions?.get('window')?.height,
                                  width: Dimensions?.get('window')?.width,
                                  position: 'absolute',
                                }}>
                                <View
                                  style={{
                                    position: 'absolute',
                                    backgroundColor: COLORS?.white,
                                    width: ms(190),
                                    paddingVertical: ms(10),
                                    bottom: ms(106),
                                    right: ms(20),
                                    borderRadius: ms(8),
                                    paddingHorizontal: ms(4),
                                  }}>
                                  <TouchableOpacity
                                    onPress={() => navigate('AddCreditNoteWithoutClient')}
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'space-between',
                                      // paddingHorizontal: ms(10),
                                      paddingVertical: ms(6),
                                      borderBottomWidth: ms(0.4),
                                      borderBottomColor: '#E5E7EB',
                                      paddingHorizontal: ms(8),
                                    }}>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Medium,
                                        fontSize: ms(12),
                                        color: '#344054',
                                      }}>
                                      Credit Note
                                    </Text>
                                    <Image
                                      source={ICONS?.addMore}
                                      style={{
                                        height: ms(15),
                                        width: ms(15),
                                        tintColor: COLORS?.themeColor,
                                      }}
                                      resizeMode="contain"
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={() => navigate('AddPurchaseOrderWithoutClient')}
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'space-between',
                                      paddingHorizontal: ms(10),
                                      paddingVertical: ms(6),
                                      borderBottomWidth: ms(0.4),
                                      borderBottomColor: '#E5E7EB',
                                      paddingHorizontal: ms(8),
                                    }}>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Medium,
                                        fontSize: ms(12),
                                        color: '#344054',
                                      }}>
                                      Purchase Order
                                    </Text>
                                    <Image
                                      source={ICONS?.addMore}
                                      style={{
                                        height: ms(15),
                                        width: ms(15),
                                        tintColor: COLORS?.themeColor,
                                      }}
                                      resizeMode="contain"
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={() => navigate('AddEstimateWithoutClient')}
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'space-between',
                                      paddingHorizontal: ms(10),
                                      paddingVertical: ms(6),
                                      borderBottomWidth: ms(0.4),
                                      borderBottomColor: '#E5E7EB',
                                      paddingHorizontal: ms(8),
                                    }}>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Medium,
                                        fontSize: ms(12),
                                        color: '#344054',
                                      }}>
                                      Estimate
                                    </Text>
                                    <Image
                                      source={ICONS?.addMore}
                                      style={{
                                        height: ms(15),
                                        width: ms(15),
                                        tintColor: COLORS?.themeColor,
                                      }}
                                      resizeMode="contain"
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={() => navigate('AddInvoiceWithoutClient')}
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'space-between',
                                      paddingHorizontal: ms(10),
                                      paddingVertical: ms(6),
                                      borderBottomWidth: ms(0.4),
                                      borderBottomColor: '#E5E7EB',
                                      paddingHorizontal: ms(8),
                                    }}>
                                    <Text
                                      style={{
                                        fontFamily: FONTS?.Medium,
                                        fontSize: ms(12),
                                        color: '#344054',
                                      }}>
                                      Invoice
                                    </Text>
                                    <Image
                                      source={ICONS?.addMore}
                                      style={{
                                        height: ms(15),
                                        width: ms(15),
                                        tintColor: COLORS?.themeColor,
                                      }}
                                      resizeMode="contain"
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'space-between',
                                      paddingHorizontal: ms(10),
                                      paddingVertical: ms(6),
                                    }}>
                                    <Text style={{color: '#344054', opacity: 0.25}}>Statement</Text>
                                    <Image
                                      source={ICONS?.download}
                                      style={{
                                        height: ms(15),
                                        width: ms(15),
                                        tintColor: COLORS?.themeColor,
                                        opacity: 0.25,
                                      }}
                                      resizeMode="contain"
                                    />
                                  </TouchableOpacity>
                                </View>
                              </View>
                            ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
    // tintColor: COLORS.dark_grey,
    //marginRight: ms(10),
  },
});
