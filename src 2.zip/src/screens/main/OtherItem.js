import React, {useEffect, useState,useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
  Alert
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useDispatch, useSelector} from 'react-redux';
import {getItemsListReqest,deleteItemRequest} from '../../redux/reducer/ProfileReducer';
import { useFocusEffect } from '@react-navigation/native';
import Loader from '../../utils/helpers/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
export default function OtherItem() {
  const dispatch = useDispatch();
  const [option, setOption] = useState('All');
  const [isEnabled, setIsEnabled] = useState(false);
  const {itemList,loading} = useSelector(state => state.ProfileReducer);
  useEffect(() => {
   // getItemList();
   getAutosave()
  }, []);
  const getAutosave =async()=>{
    let temp = await AsyncStorage.getItem("autosave")
    if(temp == "enabled"){
      setIsEnabled(true)
    }else{
      setIsEnabled(false)
    }
  }

   useFocusEffect(
      useCallback(() => {
        getItemList();
      }, []),
    );
  const getItemList = () => {
    let payload = {};
    dispatch(getItemsListReqest(payload));
  };

  const renderItemList = ({item}) => {
    return (
      <TouchableOpacity
        onPress={()=> navigate("UpdateItem",{item:item})}
        style={{
          padding: ms(10),
          // paddingBottom: ms(0),
          backgroundColor: COLORS?.white,
          borderWidth: ms(0.5),
          borderColor: '#DEDEDE',
          borderRadius: ms(6),
          marginVertical: ms(10),
          // elevation: 10,
        }}>
        <View
          style={{
            backgroundColor: 'rgba(4, 127, 255, 0.1)',
            padding: ms(10),
            borderRadius: ms(6),
            flexDirection: 'row',
            alignItems: 'center',
            gap: ms(10),
          }}>
          <Image
            source={ICONS?.digital_marketing}
            style={{height: ms(10), width: ms(10)}}
            resizeMode="contain"
          />
          <Text
            style={{
              fontFamily: FONTS?.Medium,
              fontSize: ms(12),
              color: COLORS?.themeColor,
            }}>
            {item?.item_name}
          </Text>
        </View>
        <View style={{padding: 10,flexDirection:'row',justifyContent:'space-between'}}>
          <Text
            style={{
              fontFamily: FONTS?.Medium,
              fontSize: ms(13),
              color: COLORS?.black,
            }}>
            ${Number(item?.rate) * Number(item?.qty)}
          </Text>
          <View style={{position:'absolute',top:10,right:10,flexDirection:'row'}}>
            <TouchableOpacity onPress={()=> navigate("UpdateItem",{item:item})}>
              <Image resizeMode='contain' style={{height:ms(15),width:ms(15),tintColor:COLORS.themeColor}} source={ICONS.edit}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={()=> createTwoButtonAlert(item?.uuid)} style={{marginLeft:ms(5)}}>
              <Image resizeMode='contain' style={{height:ms(15),width:ms(15)}} source={ICONS.delete}/>
            </TouchableOpacity>
          </View>
        </View>
        <View style={{padding: 10}}>
          <Text
            style={{
              fontFamily: FONTS?.Regular,
              fontSize: ms(13),
              color: COLORS?.black,
            }}>
            {item?.item_Description}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const createTwoButtonAlert = uuid => {
      Alert.alert('Delete', 'Do you want to delete this item?', [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK',
          onPress: () => {
            let payload = {
              uuid: uuid,
            };
            dispatch(deleteItemRequest(payload));
            // setTimeout(() => {
            //   getClient();
            // }, 2000);
          },
        },
      ]);
    };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: COLORS?.white,
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Items'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <>
            <View
              style={{
                padding: ms(10),
                marginTop: ms(10),
                backgroundColor: '#FEFEFE',
                flexDirection: 'row',
                alignItems: 'center',
                borderBottomWidth: ms(0.6),
                borderBottomColor: '#DEDEDE',
                gap: ms(10),
                width: Dimensions?.get('window')?.width,
                marginLeft: -ms(20),
              }}>
              <View style={{width: '85%', paddingHorizontal: ms(10)}}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: ms(10),
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Medium,
                      fontSize: ms(12),
                      color: COLORS?.black,
                    }}>
                    Autosave New Items
                  </Text>
                  <Image
                    source={ICONS?.info}
                    style={{height: ms(10), width: ms(10)}}
                    resizeMode="contain"
                  />
                </View>
                <Text style={{fontFamily: FONTS?.Light, fontSize: ms(10)}}>
                  Add items to the list here if added elsewhere
                </Text>
              </View>
              {/* <Switch
                trackColor={{false: '#767577', true: '#81b0ff'}}
                thumbColor={isEnabled ? '#f4f3f4' : '#f4f3f4'}
                ios_backgroundColor="#3e3e3e"
                onValueChange={() => {
                  setIsEnabled(!isEnabled);
                }}
                value={isEnabled}
              /> */}
              <TouchableOpacity onPress={async() => {
                if(isEnabled){
                  await AsyncStorage.setItem("autosave","disabled")
                  setIsEnabled(false)
                }else{
                  await AsyncStorage.setItem("autosave","enabled")
                  setIsEnabled(true)
                }
                
                setIsEnabled(!isEnabled)
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(20), width: ms(32)}}
                  source={isEnabled ? ICONS.switch : ICONS.switchoff}
                />
              </TouchableOpacity>
            </View>
            <FlatList data={itemList} renderItem={renderItemList} />

            {/* <View
              style={{
                padding: ms(10),
                backgroundColor: COLORS?.white,
                borderWidth: ms(0.5),
                borderColor: '#DEDEDE',
                borderRadius: ms(6),
                marginTop: ms(10),
                elevation: 2,
                shadowColor: 'rgba(4, 127, 255, 0.2)',
              }}>
              <View
                style={{
                  backgroundColor: 'rgba(4, 127, 255, 0.1)',
                  padding: ms(10),
                  borderRadius: ms(6),
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                }}>
                <Image
                  source={ICONS?.digital_marketing}
                  style={{height: ms(15), width: ms(15)}}
                  resizeMode="contain"
                />
                <Text
                  style={{
                    fontFamily: FONTS?.Medium,
                    fontSize: ms(12),
                    color: COLORS?.themeColor,
                  }}>
                  Digital Marketing
                </Text>
              </View>
              <Text
                style={{
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(12),
                  color: COLORS?.black,
                  marginTop: ms(10),
                }}>
                ₹20,000
              </Text>
              <Text
                style={{
                  fontFamily: FONTS?.Light,
                  fontSize: ms(10),
                  color: COLORS?.black,
                  marginTop: ms(10),
                }}>
                Item description
              </Text>
            </View> */}
          </>
        </View>
      </ScrollView>
      <TouchableOpacity
        style={{
          height: ms(50),
          width: ms(50),
          borderRadius: ms(25),
          backgroundColor: COLORS?.themeColor,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(20),
          right: ms(20),
        }}
        onPress={() => {
          navigate('AddItem');
        }}>
        <Image
          source={ICONS.addMore}
          resizeMode="contain"
          style={[styles.iconStyle, {tintColor: COLORS?.white}]}
        />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(15),
    height: ms(15),
  },
});
