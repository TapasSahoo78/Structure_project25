import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {
  addAccountRequest,
  getRoleListRequest,
  updateProfileRequest,
} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';
import CameraDropDown from '../../components/CameraDropDown';

export default function PersonalInfoUpdate() {
  const {roleList, loading, profileResponse} = useSelector(
    state => state.ProfileReducer,
  );
  const [name, setName] = useState(profileResponse?.name);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState(
    profileResponse?.phone == null ? '' : profileResponse?.phone,
  );
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [roleModal, setRoleModal] = useState(false);
  const dispatch = useDispatch();
  const [imageObject, setImageObject] = useState('');
  const [cameraModal, setCameraModal] = useState(false);
  useEffect(() => {
    dispatch(getRoleListRequest());
    console.log(name);
  }, []);
  const formatNameToInitials = name => {
    // Split the name into words
    const words = name.split(' ');

    // Extract the first letter of each word and convert to uppercase
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');

    return initials;
  };
  function UpdateProfile() {
    if (name == '') {
      Toast('Name is required');
    } else if (phone == '') {
      Toast('Phone is required');
    } else {
      console.log('Update profile is calling');
      let formData = new FormData();
      formData?.append('name', name);
      formData?.append('phone', phone);
      formData?.append('profileImage', imageObject);
      // goBack();
      dispatch(updateProfileRequest(formData));
    }
  }
  function isEmpty(item) {
    if (item == '' || item == null || item == undefined) return true;
    return false;
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <Modal
        isVisible={roleModal}
        onBackdropPress={() => {
          setRoleModal(false);
        }}
        style={{justifyContent: 'flex-end', margin: 0}}>
        <View
          style={{
            backgroundColor: 'white',
            padding: ms(22),
            //alignItems: 'center',
            borderTopLeftRadius: ms(15),
            borderTopRightRadius: ms(15),
            height: Dimensions.get('window').height * 0.6,
          }}>
          <FlatList
            data={roleList}
            renderItem={({item, index}) => {
              return (
                <TouchableOpacity
                  style={{
                    paddingBottom: ms(5),
                    marginTop: ms(5),
                    borderBottomWidth: ms(0.5),
                    borderBottomColor: '#DFDFDF',
                  }}
                  onPress={() => {
                    setRoleModal(false);
                    setRole(item);
                  }}>
                  <Text
                    style={{
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(13),
                      color: COLORS?.black,
                    }}>
                    {item?.roleName}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
      <CameraDropDown
        title={'Profile Image'}
        visible={cameraModal}
        onBackdropPress={() => {
          setCameraModal(false);
        }}
        onPressCamera={item => {
          console.log('images: ', item);
          setImageObject(item);
        }}
        onPressGallery={item => {
          console.log('images: ', item);
          setImageObject(item);
        }}
      />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Edit Profile'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={() => {
            UpdateProfile();
          }}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(50),
            alignItems: 'center',
          }}>
          {/* <View style={{paddingTop: ms(40), alignItems: 'center'}}></View>
          <View style={{marginTop: ms(20)}} /> */}
          <TouchableOpacity
            onPress={() => {
              setCameraModal(true);
            }}>
            {isEmpty(profileResponse?.profileImage) &&
            isEmpty(imageObject?.uri) &&
            !isEmpty(profileResponse?.name) ? (
              <View
                style={{
                  height: ms(60),
                  width: ms(60),
                  borderRadius: ms(30),
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#44BBFE',
                }}>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    color: COLORS.white,
                  }}>
                  {formatNameToInitials(profileResponse?.name)}
                </Text>
              </View>
            ) : !isEmpty(imageObject?.uri) ? (
              <View
                style={{
                  height: ms(60),
                  width: ms(60),
                  borderRadius: ms(30),
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#44BBFE',
                }}>
                <Image
                  source={{uri: imageObject?.uri}}
                  style={{height: ms(60), width: ms(60), borderRadius: ms(30)}}
                />
              </View>
            ) : !isEmpty(profileResponse?.profileImage) ? (
              <View
                style={{
                  height: ms(60),
                  width: ms(60),
                  borderRadius: ms(30),
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#44BBFE',
                }}>
                <Image
                  source={{uri: profileResponse?.profileImage}}
                  style={{
                    height: ms(60),
                    width: ms(60),
                    borderRadius: ms(30),
                  }}
                />
              </View>
            ) : null}
            <View
              style={{
                height: ms(30),
                width: ms(30),
                borderRadius: ms(15),
                backgroundColor: COLORS?.themeColor,
                alignItems: 'center',
                justifyContent: 'center',
                position: 'absolute',
                right: -ms(7),
                bottom: ms(2),
              }}>
              <Image
                source={ICONS?.whitecam}
                style={{
                  height: ms(13),
                  width: ms(15.68),
                  tintColor: COLORS?.white,
                }}
                resizeMode="contain"
              />
            </View>
          </TouchableOpacity>
          <Text
            style={{
              marginTop: ms(15),
              fontFamily: FONTS?.Medium,
              fontSize: ms(13),
              color: COLORS?.black,
            }}>
            {profileResponse?.email}
          </Text>
          <AnimatedTextInput
            label={'Name'}
            //keyboardType={'email-address'}
            width={Dimensions?.get('window')?.width - 50}
            value={name}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setName(item);
            }}
          />

          <AnimatedTextInput
            label={'Phone No.'}
            keyboardType={'numeric'}
            width={Dimensions?.get('window')?.width - 50}
            value={phone}
            maxLength={10}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setPhone(item);
            }}
          />
          <Text
            style={{
              marginTop: ms(20),
              fontFamily: FONTS?.Medium,
              fontSize: ms(13),
              color: '#44BBFE',
              alignSelf: 'flex-end',
              marginRight: ms(25),
            }}
            onPress={() => {
              navigate('ChangePassword');
            }}>
            Change Password
          </Text>
        </View>
        <TouchableOpacity
          style={{
            paddingHorizontal: ms(20),
            paddingVertical: ms(8),
            backgroundColor: COLORS?.themeColor,
            marginTop: ms(20),
            alignSelf: 'center',
            width: ms(150),
            borderRadius: ms(20),
          }}
          onPress={() => {
            UpdateProfile();
          }}>
          <Text
            style={{
              color: COLORS?.white,
              textAlign: 'center',
              fontFamily: FONTS?.Medium,
              fontSize: ms(15),
            }}>
            Save
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
