import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import {useFocusEffect} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {projectDeleteRequest, projectListRequest} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
export default function Project() {
  const [option, setOption] = useState('All');
  const {projectList, loading} = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();
  const activeProjects = [
    {
      project_name: 'Project 1',
      contact_name: 'Akash Mishra',
      date: '2024-11-01',
    },
  ];
  const allProjects = [];
  const completedProjects = [];
  const [completedList,setCompletedList] = useState([])

  useFocusEffect(
    useCallback(() => {
      setOption("All")
      
      let payload = {};
      dispatch(projectListRequest(payload));
    }, []),
  );
  console.log(".........",JSON.stringify(projectList));
  useEffect(()=> {
    if(projectList.length > 0){
      let completedProj = projectList.filter((item)=> {
        return item.status ===  3
      })
      if(completedProj.length > 0){
        setCompletedList(completedProj)
      }
    }

  },[projectList])

  const deleteProject=(item)=>{
    //alert(JSON.stringify(item))
     Alert.alert('Delete', 'Do you want to delete this project ?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => {
        let payload = {
          client_id:item?.client_id,
          projectId:item?.id
        }
        dispatch(projectDeleteRequest(payload))
      }},
    ]);
    
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Projects'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: ms(20),
              borderWidth: ms(0.6),
              borderRadius: ms(10),
              borderColor: '#BBB',
              //backgroundColor:'red'
            }}>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                width: '33.33%',
                borderBottomWidth: option == 'All' ? ms(1) : ms(0),
                alignItems: 'center',
                borderBottomColor: COLORS?.themeColor,
              }}
              onPress={() => {
                setOption('All');
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color:
                    option == 'All'
                      ? 'rgba(52, 64, 84, 1)'
                      : 'rgba(52, 64, 84, 0.75)',
                  textAlign: 'center',
                }}>
                All
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                width: '33.33%',
                borderBottomWidth: option == 'Active' ? ms(1) : ms(0),
                alignItems: 'center',
                borderBottomColor: COLORS?.themeColor,
              }}
              onPress={() => {
                setOption('Active');
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color:
                    option == 'Active'
                      ? 'rgba(52, 64, 84, 1)'
                      : 'rgba(52, 64, 84, 0.75)',
                  textAlign: 'center',
                }}>
                Active
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                width: '33.33%',
                borderBottomWidth: option == 'Completed' ? ms(1) : ms(0),
                alignItems: 'center',
                borderBottomColor: COLORS?.themeColor,
              }}
              onPress={() => {
                setOption('Completed');
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(14),
                  color:
                    option == 'Completed'
                      ? 'rgba(52, 64, 84, 1)'
                      : 'rgba(52, 64, 84, 0.75)',
                  textAlign: 'center',
                }}>
                Completed
              </Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={
              option == 'All'
                ? projectList
                : option == 'Active'
                ? projectList
                : completedList
            }
            renderItem={({item, index}) => {
              return (
                <View
                  style={{
                    marginTop: ms(20),
                    padding: ms(10),
                    borderWidth: ms(0.8),
                    borderRadius: ms(10),
                    borderColor: '#DEDEDE',
                  }}
                 >
                  <View
                 
                    style={{
                      padding: ms(10),
                      backgroundColor: 'rgba(4, 127, 255, 0.1)',
                      borderRadius: ms(5),
                    }}>
                    <Text
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(13),
                        color: COLORS?.themeColor,
                      }}>
                      {item?.project_name}
                    </Text>
                  </View>
                  <View
                    
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginTop: ms(10),
                      paddingHorizontal: ms(10),
                    }}>
                    <Text
                       onPress={()=> navigate('AddClient', {item: item,status:"view"})}
                      style={{
                        fontFamily: FONTS?.Medium,
                        fontSize: ms(12),
                        color: '#344054',
                      }}>
                      {item?.client?.name}
                    </Text>
                    <Text
                      style={{
                        fontFamily: FONTS?.Light,
                        fontSize: ms(10),
                        color: '#344054',
                      }}>
                      {moment(item?.createdAt)?.format('Do MMM, YYYY')}
                    </Text>
                    <View style={{alignItems:'flex-end'}}>
                    <TouchableOpacity onPress={()=> navigate('AddClient', {item: item,status:"update"})} style={{padding:ms(5)}}>
                      <Image resizeMode='contain' style={{height:ms(15),width:ms(15)}} source={ICONS.editicn}/>
                    </TouchableOpacity>
                     <TouchableOpacity onPress={()=> deleteProject(item)} style={{padding:ms(5)}}>
                      <Image resizeMode='contain' style={{height:ms(15),width:ms(15)}} source={ICONS.delete}/>
                    </TouchableOpacity>
                  </View>
                  </View>
                  
                </View>
              );
            }}
            ListEmptyComponent={() => {
              return (
                <View
                  style={{
                    height: Dimensions?.get('window')?.height / 2.2,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image
                    source={ICONS?.no_project}
                    style={{
                      height: ms(250),
                      width: ms(250),
                      alignSelf: 'center',
                    }}
                    resizeMode="contain"
                  />
                  <Text
                    style={{
                      textAlign: 'center',
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: 'rgba(52, 64, 84, 1)',
                    }}
                    onPress={() => {
                      navigate('CreateProject');
                    }}>
                    {option == 'Completed'
                      ? 'No project yet'
                      : 'Create Project'}
                  </Text>
                </View>
              );
            }}
          />
        </View>
      </ScrollView>
      <TouchableOpacity
        style={{
          height: ms(50),
          width: ms(50),
          borderRadius: ms(25),
          backgroundColor: COLORS?.themeColor,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: ms(20),
          right: ms(20),
        }}
        onPress={() => {
          navigate('CreateProject');
        }}>
        <Image
          source={ICONS.addMore}
          resizeMode="contain"
          style={[styles.iconStyle, {tintColor: COLORS?.white}]}
        />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
