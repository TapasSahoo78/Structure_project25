import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../utils/helpers/Loader';
import {
  projectSettingsDetailRequest,
  projectSettingsRequest,
} from '../../redux/reducer/ProfileReducer';

export default function ProjectSettings() {
  const [prefix, setPrifix] = useState('');
  const [newClient, setNewWClient] = useState(false);
  const [newEstimate, setNewWEstimate] = useState(false);
  const [newInvoice, setNewWInvoice] = useState(false);
  const {projectSettingsDetail, loading} = useSelector(
    state => state.ProfileReducer,
  );
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(projectSettingsDetailRequest());
  }, []);
  function isEmpty(item) {
    if (item == '' || item == null || item == undefined) return true;
    return false;
  }
  useEffect(() => {
    setNewWClient(projectSettingsDetail?.addNewClient);
    setNewWEstimate(projectSettingsDetail?.newEstimate);
    setNewWInvoice(projectSettingsDetail?.newInvoice);
    setPrifix(
      !isEmpty(projectSettingsDetail?.prefix)
        ? projectSettingsDetail?.prefix
        : '',
    );
  }, [projectSettingsDetail]);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Project Settings'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20),alignItems:'center'}}>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(0),
              width:'100%'
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Settings
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(10),
              width:'95%'
            }}>
            <Text style={{fontSize: ms(14), fontFamily: FONTS.Medium}}>
              When adding new client
            </Text>
            <TouchableOpacity
              onPress={() => {
                // console.log(newClient);
                // var dataset = newClient;
                setNewWClient(!newClient);
              }}
              style={{paddingTop: ms(3)}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(40), marginLeft: ms(20)}}
                source={newClient ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
            }}
          />

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              //marginTop: ms(10),
               width:'95%'
            }}>
            <Text style={{fontSize: ms(14), fontFamily: FONTS.Medium}}>
              When creating new estimate
            </Text>
            <TouchableOpacity
              onPress={() => setNewWEstimate(!newEstimate)}
              style={{paddingTop: ms(3)}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(40), marginLeft: ms(20)}}
                source={newEstimate ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              height: 1,
              width: '100%',
              backgroundColor: COLORS.border,
              marginVertical: ms(10),
              
              // width:'100%'
            }}
          />
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              //marginTop: ms(10),
               width:'95%'
            }}>
            <Text style={{fontSize: ms(14), fontFamily: FONTS.Medium}}>
              When creating new invoice
            </Text>
            <TouchableOpacity
              onPress={() => setNewWInvoice(!newInvoice)}
              style={{paddingTop: ms(3)}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(40), marginLeft: ms(20)}}
                source={newInvoice ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>

          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(16),
               width:'100%'
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Project numbers
            </Text>
          </View>
          <AnimatedTextInput
            label={'Add a prefix before project numbers'}
            //keyboardType={'email-address'}
            width={Dimensions?.get('window')?.width - 50}
            value={prefix}
            minimumHeight={ms(45)}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setPrifix(item);
            }}
          />

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <TouchableOpacity
              style={{
                paddingVertical: ms(10),
                width: '45%',
                borderRadius: ms(20),
                backgroundColor: COLORS.themeColor,
                alignItems: 'center',
                alignSelf: 'center',
                justifyContent: 'center',
                marginTop: ms(50),
              }}
              onPress={() => {
                dispatch(
                  projectSettingsRequest({
                    id: projectSettingsDetail?.id,
                    addNewClient: newClient ? 1 : 0,
                    newEstimate: newEstimate ? 1 : 0,
                    newInvoice: newInvoice ? 1 : 0,
                    prefix: prefix,
                  }),
                );
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Medium,
                  color: COLORS.white,
                  fontSize: ms(14),
                }}>
                Save Changes
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },
});
