import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import DepthHeader from '../../components/DepthHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import moment from 'moment';
import AnimatedTextInput from '../../components/AnimatedTextInput';

export default function RazorPay() {
  const [paypalStatus, setPaypalStatus] = useState(false);
  const [paypalApi, setPaypalApi] = useState('');
  const [paypalSecret, setPaypalSecret] = useState('');
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Paypal Credentials'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, padding: ms(20)}}>
          <View style={{flexDirection: 'row', alignItems: 'center',justifyContent:'space-between'}}>
            <Text style={{fontSize: ms(16), fontFamily: FONTS.Medium}}>
              Status
            </Text>
            <TouchableOpacity
              onPress={() => setPaypalStatus(!paypalStatus)}
              style={{paddingTop: ms(3)}}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(40), marginLeft: ms(20)}}
                source={paypalStatus ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>

          <AnimatedTextInput
            label={'API Key'}
            //keyboardType={'email-address'}
            width={Dimensions?.get('window')?.width - 50}
            value={paypalApi}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setPaypalApi(item);
            }}
          />
          <AnimatedTextInput
            label={'API Secret'}
            //keyboardType={'email-address'}
            width={Dimensions?.get('window')?.width - 50}
            value={paypalSecret}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setPaypalSecret(item);
            }}
          />

          <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                             <TouchableOpacity
                               style={{
                                 paddingVertical: ms(10),
                                 width: '45%',
                                 borderRadius: ms(20),
                                 backgroundColor: COLORS.themeColor,
                                 alignItems: 'center',
                                 alignSelf: 'center',
                                 justifyContent: 'center',
                                 marginTop: ms(20),
                               }}>
                               <Text
                                 style={{
                                   fontFamily: FONTS.Medium,
                                   color: COLORS.white,
                                   fontSize: ms(14),
                                 }}>
                                 Save Changes
                               </Text>
                             </TouchableOpacity>
                             <TouchableOpacity
                               style={{
                                 paddingVertical: ms(10),
                                 width: '45%',
                                 borderRadius: ms(20),
                                 backgroundColor: COLORS.white,
                                 alignItems: 'center',
                                 alignSelf: 'center',
                                 justifyContent: 'center',
                                 marginTop: ms(20),
                                 borderWidth:ms(0.6),
                                 borderColor:COLORS.themeColor
                               }}>
                               <Text
                                 style={{
                                   fontFamily: FONTS.Medium,
                                   color: COLORS.themeColor,
                                   fontSize: ms(14),
                                 }}>
                                 Cancel
                               </Text>
                             </TouchableOpacity>
                   
                             </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },
});
