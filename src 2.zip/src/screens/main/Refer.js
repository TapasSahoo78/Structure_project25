import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';
import DepthHeader from '../../components/DepthHeader';

export default function Refer() {
  const [option, setOption] = useState('unpaid');
  const clientList = [
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
    {
      name: 'Akash Mishra',
      days: '23 Oct, Due in 2 days',
      amount: '$125',
      status: 'Unsent',
    },
  ];
  useEffect(() => {}, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          // borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Refer'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <ImageBackground
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          flex: 1,
        }}
        source={IMAGES?.background}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1, paddingHorizontal: ms(20)}}>
            <Image
              resizeMode="contain"
              style={{
                height: ms(59),
                width: ms(151),
                alignSelf: 'center',
                marginTop: ms(120),
              }}
              source={ICONS.logoWithName}
            />
            <Text
              style={{
                fontFamily: FONTS.Regular,
                fontSize: ms(24),
                alignSelf: 'center',
                marginTop: ms(60),
              }}>
              Share Raise Invoice
            </Text>
            <Text
              style={{
                fontFamily: FONTS.Regular,
                fontSize: ms(24),
                alignSelf: 'center',
              }}>
              With Someone
            </Text>

            <Text
              style={{
                textAlign: 'center',
                alignSelf: 'center',
                fontFamily: FONTS.Regular,
                fontSize: ms(12),
                marginTop: ms(20),
              }}>
              Make someone else’s life easier. Give {'\n'} them a free 1 month
              trial
            </Text>

            <TouchableOpacity
              style={{
                height: ms(47),
                width: ms(179),
                alignSelf: 'center',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                backgroundColor: COLORS.themeColor,
                borderRadius: ms(30),
                paddingHorizontal: ms(10),
                marginTop: ms(40),
              }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Regular,
                  color: COLORS.white,
                }}>
                Share
              </Text>

              <View
                style={{
                  height: ms(34),
                  width: ms(34),
                  backgroundColor: COLORS.white,
                  borderRadius: ms(20),
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: ms(30), width: ms(30)}}
                  source={ICONS.next}
                />
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
