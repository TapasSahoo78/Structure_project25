import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';
import DepthHeader from '../../components/DepthHeader';
import {
  LineChart,
  BarChart,
  PieChart,
  ProgressChart,
  ContributionGraph,
  StackedBarChart,
} from 'react-native-chart-kit';
import {Colors} from 'react-native/Libraries/NewAppScreen';

export default function Reports() {
  const [option, setOption] = useState('unpaid');
  const reportlist = [
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 100,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 101,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 102,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 103,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 104,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 105,
    },
    {
      date: 'January 2024',
      price: '$125',
      total_invoice: '15 Invoices',
      id: 106,
    },
  ];
  const data = {
    labels: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ],
    datasets: [
      {
        data: [0, 100, 200, 300, 500],
      },
    ],
  };

  const deatils = [
    {
      id: 100,
      color: '#23BBC5',
      space: 75,
      name: 'Akash',
      price: '$125',
    },
    {
      id: 101,
      color: '#9747FF',
      space: 25,
      name: 'Navin',
      price: '$125',
    },
  ];
  const [order, setOrder] = useState('month');
  useEffect(() => {}, []);

  const renderReportlist = ({item, index}) => {
    return (
      <View
        style={{
          padding: 10,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <View>
          <Text
            style={{
              fontSize: ms(12),
              fontFamily: FONTS.Regular,
              color: '#344054',
            }}>
            {item.date}
          </Text>
          <Text
            style={{
              fontSize: ms(12),
              fontFamily: FONTS.Regular,
              color: COLORS.themeColor,
            }}>
            {item.total_invoice}
          </Text>
        </View>
        <Text style={{fontSize: ms(14), fontFamily: FONTS.Regular}}>
          {item.price}
        </Text>
      </View>
    );
  };
  const ItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '100%',
          backgroundColor: COLORS.border,
        }}
      />
    );
  };

  const renderDetail = ({item, index}) => {
    return (
      <View
        style={{
          height: ms(50),
          width: (Dimensions.get('window').width - 40) * (item.space / 100),
          backgroundColor: item.color,
        }}
      />
    );
  };
  const renderDetails = ({item, index}) => {
    return (
      <View
        style={{
          padding: ms(15),
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <View
            style={{height: ms(42), width: 4, backgroundColor: item.color}}
          />
          <View style={{marginLeft: ms(10)}}>
            <Text style={{fontSize: ms(12), fontFamily: FONTS.Regular}}>
              {item.name}
            </Text>
            <Text style={{fontSize: 20, fontFamily: FONTS.Medium}}>
              {item.price}
            </Text>
          </View>
        </View>
        <Text
          style={{
            color: item.space > 50 ? '#0CC04E' : '#EA4335',
            fontSize: ms(12),
          }}>
          {item.space}%
        </Text>
      </View>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          // borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Reports'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View style={{flex: 1, paddingHorizontal: ms(20)}}>
          <View
            style={{
              marginVertical: ms(10),
              backgroundColor: COLORS?.white,
              flexDirection: 'row',
              width: '100%',
              alignSelf: 'center',
              borderRadius: ms(10),
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: ms(12),
              elevation: 3,
              shadowColor: COLORS.themeColor,
            }}>
            <View>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                  color: '#344054',
                }}>
                Total Outstanding Balance
              </Text>
              <Text
                style={{
                  fontSize: ms(20),
                  color: '#344054',
                  fontWeight: '500',
                  //fontFamily:FONTS.Medium
                }}>
                $125
              </Text>
            </View>
            <View>
              <Image
                resizeMode="contain"
                style={{height: ms(18), width: ms(18)}}
                source={ICONS.redirect}
              />
              <Text style={{fontSize: ms(12), color: COLORS.themeColor}}>
                List
              </Text>
            </View>
          </View>
          <View
            style={{
              marginVertical: ms(10),
              backgroundColor: COLORS?.white,
              //flexDirection: 'row',
              width: '100%',
              alignSelf: 'center',
              borderRadius: ms(10),
              //justifyContent: 'space-between',
              //alignItems:'center',
              padding: ms(12),
              elevation: 3,
              shadowColor: COLORS.themeColor,
            }}>
            <View
              style={{
                //paddingHorizontal: ms(20),
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: ms(10),
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: ms(10),
                }}>
                <Text style={{fontFamily: FONTS?.Regular, fontSize: ms(12)}}>
                  Tax Year 2025 Sales
                </Text>
                <Image
                  source={ICONS?.arrow}
                  style={{
                    height: ms(5),
                    width: ms(14),
                    tintColor: COLORS?.themeColor,
                    transform: [{rotate: '180deg'}],
                  }}
                  resizeMode="contain"
                />
              </View>
            </View>
            <Text style={{fontSize: ms(12), color: COLORS.themeColor}}>
              15 Invoices
            </Text>
            <Text
              style={{fontSize: ms(20), color: '#344054', fontWeight: '500'}}>
              $125
            </Text>
          </View>
          <View
            style={{
              //paddingVertical: ms(15),
              //width: Dimensions?.get('window')?.width,
              width: '100%',
              alignSelf: 'center',
              //backgroundColor: 'red',
              backgroundColor: COLORS.white,
              // borderRadius: ms(10),
              // borderTopWidth: ms(1),
              // borderBottomWidth: ms(1),
              // borderTopColor: COLORS.border,
              // borderBottomColor: COLORS.border,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              //paddingHorizontal: 10,
              //elevation:3,
              height: ms(47),
              paddingHorizontal: ms(10),
              //marginLeft:ms(-10),
              borderTopWidth: 0.6,
              borderTopColor: COLORS.border,
              borderLeftWidth: 0.6,
              borderRightWidth: 0.6,
              borderLeftColor: COLORS.border,
              borderRightColor: COLORS.border,
              borderRadius: ms(10),
              elevation: 3,
              shadowColor: COLORS.themeColor,
            }}>
            <TouchableOpacity
              onPress={() => setOrder('month')}
              style={{
                borderBottomColor:
                  order == 'month' ? COLORS.themeColor : COLORS.border,
                borderBottomWidth: order == 'month' ? 2 : 1,
                width: '33%',
                //paddingBottom: ms(5),
                alignItems: 'center',
                justifyContent: 'center',
                //marginLeft:ms(10),
                height: '100%',
              }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Regular,
                  color:
                    order == 'month' ? '#344054' : 'rgba(52, 64, 84, 0.75)',
                }}>
                By Month
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setOrder('quarter')}
              style={{
                borderBottomColor:
                  order == 'quarter' ? COLORS.themeColor : COLORS.border,
                borderBottomWidth: order == 'quarter' ? 2 : 1,
                width: '33%',
                // paddingBottom: ms(5),
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
              }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Regular,
                  color:
                    order == 'quarter' ? '#344054' : 'rgba(52, 64, 84, 0.75)',
                }}>
                By Quarter
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setOrder('year')}
              style={{
                borderBottomColor:
                  order == 'year' ? COLORS.themeColor : COLORS.border,
                borderBottomWidth: order == 'year' ? 2 : 1,
                width: '33%',
                //paddingBottom: ms(5),
                alignItems: 'center',
                justifyContent: 'center',
                //marginRight:ms(15),
                height: '100%',
              }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Regular,
                  color: order == 'year' ? '#344054' : 'rgba(52, 64, 84, 0.75)',
                }}>
                By Year
              </Text>
            </TouchableOpacity>
          </View>
          <View
            style={{
              backgroundColor: COLORS.white,
              marginTop: ms(0),
              alignItems: 'center',
              marginTop:ms(20)
            }}>
            <Image
              source={IMAGES?.chart}
              //resizeMode='contain'
              style={{
                height: ms(270),
                width: Dimensions?.get('window')?.width - 50,
              }}
            />
            {/* <BarChart
              style={{
                marginVertical: 15,
                borderRadius: 16,
              }}
              data={data}
              width={Dimensions?.get('window')?.width - 50}
              height={220}
              yAxisLabel="$"
              chartConfig={{
                backgroundGradientFrom: '#FFFFFF',
                backgroundGradientFromOpacity: 0,
                backgroundGradientTo: '#FFFFFF',
                backgroundGradientToOpacity: 0.5,
                // formatXLabel=''
                color: (opacity = 1) => `rgba(4, 127, 255, ${opacity})`,
                strokeWidth: 1, // optional, default 3
                barPercentage: 0.5,
                useShadowColorFromDataset: false,
              }}
              verticalLabelRotation={30}
            /> */}
          </View>
          <View style={{backgroundColor: COLORS.white, padding: ms(20),borderWidth:ms(0.6),borderColor:COLORS.border,borderRadius:ms(10),elevation:ms(5),shadowColor:COLORS.themeColor}}>
            <FlatList
              data={reportlist}
              renderItem={renderReportlist}
              ItemSeparatorComponent={ItemSeparator}
              contentContainerStyle={{elevation: 1}}
            />
          </View>

          <View
            style={{
              height: ms(46),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(8),
              justifyContent: 'center',
              paddingLeft: ms(10),
              marginTop: ms(20),
            }}>
            <Text
              style={{fontSize: ms(14), color: '#047FFF', fontWeight: '500'}}>
              Annual Sales by Client
            </Text>
          </View>
          <View
            style={{
              padding: ms(20),
              backgroundColor: COLORS.white,
              borderRadius: ms(10),
              marginTop: ms(20),
              elevation: 3,
              marginBottom: ms(10),
              shadowColor: COLORS.themeColor,
            }}>
            <FlatList
              horizontal
              data={deatils}
              renderItem={renderDetail}
              showsHorizontalScrollIndicator={false}
            />

            <FlatList
              data={deatils}
              renderItem={renderDetails}
              ItemSeparatorComponent={ItemSeparator}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
