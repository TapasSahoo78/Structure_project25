import React, {useEffect, useState,useCallback} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {
  addAccountRequest,
  addSignatureSettingsRequest,
  getRoleListRequest,
  getSignatureDetailsRequest,
  updateProfileRequest,
} from '../../redux/reducer/ProfileReducer';
import Toast from '../../utils/helpers/Toast';
import Loader from '../../utils/helpers/Loader';
import CameraDropDown from '../../components/CameraDropDown';
import SignatureModal from '../../components/SignatureModal';
import { useFocusEffect } from '@react-navigation/native';

export default function SignatureSettings() {
  const {roleList, loading, profileResponse,signatureDetail} = useSelector(
    state => state.ProfileReducer,
  );
  const [name, setName] = useState(profileResponse?.name);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState(
    profileResponse?.phone == null ? '' : profileResponse?.phone,
  );
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [roleModal, setRoleModal] = useState(false);
  const dispatch = useDispatch();
  const [imageObject, setImageObject] = useState('');
  const [cameraModal, setCameraModal] = useState(false);

  const [signatureVisible, setSignatureVisible] = useState(false);

  const [signatureOptionModal, setSignatureOptionModal] = useState(false);
  const [sigOption, setSigOption] = useState('');
  const [isTablet, setIsTablet] = useState(false);
  const [inputSignature, setInputSignature] = useState(signatureDetail?.signatureText || '');
  const [camModal, setCamModal] = useState(false);
  const [signatureImg, setSignatureImg] = useState(signatureDetail?.signature ||'');

  // const [invFlag,setInvFlag] = useState(signatureDetail?.invoice == null ? false:true)
  // const [estFlag,setEstFlag] = useState(signatureDetail?.estimate == null ? false : true)
  // const [purFlag,setPurFlag] = useState(signatureDetail?.purchaseOrder == null ? false:true)
  // const [creditFlag,setCreditFlag] = useState(signatureDetail?.creditNote == null ?false:true)

  const [invFlag,setInvFlag] = useState(true)
  const [estFlag,setEstFlag] = useState(true)
  const [purFlag,setPurFlag] = useState(true)
  const [creditFlag,setCreditFlag] = useState(true)

  // useEffect(() => {
  //   dispatch(getSignatureDetailsRequest());
  //   //console.log(name);
  // }, []);
  useFocusEffect(
      useCallback(() => {
         dispatch(getSignatureDetailsRequest());
      }, []),
    );

  useEffect(()=>{
    if(signatureDetail){
      if(signatureDetail.invoice){
        setInvFlag(true)
      }else{
        setInvFlag(false)
      }

       if(signatureDetail.estimate){
        setEstFlag(true)
      }else{
        setEstFlag(false)
      }

      if(signatureDetail.purchaseOrder){
        setPurFlag(true)
      }else{
        setPurFlag(false)
      }

       if(signatureDetail.creditNote){
        setCreditFlag(true)
      }else{
        setCreditFlag(false)
      }
    }
  },[signatureDetail])

  const [capturedSignature, setCapturedSignature] = useState(signatureDetail?.signatureData ||null);

  const onPressGallery = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Image picker cancelled or failed:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          // Create image object with Base64
          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(), // fallback to last part of URI
            type: asset.type, // e.g., 'image/jpeg'
            uri: asset.uri,
            size: asset.fileSize,
            base64: `data:${asset.type};base64,${asset.base64}`, // Full data URL
          };

          console.log('Image with Base64:', imageObj);
          setSignatureImg(imageObj.base64);

          // Pass to parent component

          setCamModal(false); // Close modal
        }
      },
    );
  };

  const onPressCamera = () => {
    launchCamera(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Camera cancelled or error:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(),
            type: asset.type,
            uri: asset.uri,
            size: asset.fileSize,
            base64: `data:${asset.type};base64,${asset.base64}`, // Ready for upload or display
          };

          console.log('Photo with Base64:', imageObj);

          setSignatureImg(imageObj.base64);
          setCamModal(false);
        }
      },
    );
  };
  function isEmpty(item) {
    if (item == '' || item == null || item == undefined) return true;
    return false;
  }

  const handleSaveSignature = signatureUri => {
    setCapturedSignature(signatureUri);
    //setSignatureImg(signatureUri)
    //Alert.alert('Success', 'Signature saved successfully!');
  };

  const checkValidation =()=>{
    console.log("canvas",capturedSignature)
    if(signatureImg == "" && capturedSignature == "" && inputSignature==""){
      Toast("Select signature or enter signature")
    }else{
      let payload = {
        id:signatureDetail?.id || "",
        invoice:invFlag,
        estimate:estFlag,
        purchaseOrder:purFlag,
        creditNote:creditFlag,
        signature:signatureImg,
        signatureData:capturedSignature,
        signatureText:inputSignature,
        
      }

      if(sigOption == "camera"){
        payload.signatureType = "upload"
      }else if(sigOption == "canvas"){
        payload.signatureType = "pad"
      }else{
        payload.signatureType = "text"
      }

      dispatch(addSignatureSettingsRequest(payload))
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />

      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Signature'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          onSave={() => {
            //UpdateProfile();
          }}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(50),
            //alignItems: 'center',
          }}>
          <View
            style={{
              backgroundColor: 'white',
              //padding: 22,
             
            }}>
            <ScrollView showsVerticalScrollIndicator={false}>
              <View
                style={{
                  //flexDirection: 'row',
                  widt: '100%',
                  //alignItems: 'center',
                  marginBottom: 12,
                  justifyContent: 'space-between',
                  marginTop: ms(20),
                }}>
                <Text
                  style={{
                    //textAlign: 'center',
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                  }}>
                  Select Signature Option
                </Text>

                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => {
                        setSigOption('camera');
                        setSignatureOptionModal(false);
                        setCamModal(true);
                      }}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'camera' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Upload using camera or gallery
                    </Text>
                  </View>
                </View>

                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => {
                        setSigOption('canvas');
                        setSignatureOptionModal(false);
                        setSignatureVisible(true);
                      }}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'canvas' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Upload using canvas
                    </Text>
                  </View>
                </View>
                <View style={{marginTop: ms(20)}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => setSigOption('input')}
                      style={{
                        height: ms(20),
                        width: ms(20),
                        borderRadius: ms(10),
                        borderWidth: ms(1),
                        borderColor: COLORS.themeColor,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      {sigOption == 'input' ? (
                        <View
                          style={{
                            height: ms(15),
                            width: ms(15),
                            borderRadius: ms(15 / 2),
                            backgroundColor: COLORS.themeColor,
                          }}
                        />
                      ) : null}
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: FONTS.Regular,
                        fontSize: ms(14),
                        marginLeft: ms(5),
                      }}>
                      Manual entry
                    </Text>
                  </View>
                </View>
                {sigOption == 'input' ? (
                  <View>
                    <AnimatedTextInput
                      label={'Signature'}
                      //keyboardType={'numeric'}
                      minimumHeight={ms(45)}
                      width={
                        isTablet
                          ? Dimensions?.get('window')?.width - 70
                          : Dimensions?.get('window')?.width - 50
                      }
                      value={inputSignature}
                      borderColor={COLORS?.themeColor}
                      multiline={true}
                      numberOfLines={5}
                      onChangeText={item => {
                        setInputSignature(item);
                      }}
                    />

                    {/* <TouchableOpacity
                      style={{
                        paddingHorizontal: ms(20),
                        paddingVertical: ms(8),
                        backgroundColor: COLORS?.themeColor,
                        // position: 'absolute',
                        // bottom: ms(10),
                        alignSelf: 'center',
                        width: ms(150),
                        borderRadius: ms(20),
                        marginTop: ms(30),
                      }}
                      onPress={() => {
                        checkValidation();
                      }}>
                      <Text
                        style={{
                          color: COLORS?.white,
                          textAlign: 'center',
                          fontFamily: FONTS?.Medium,
                          fontSize: ms(15),
                        }}>
                        Save
                      </Text>
                    </TouchableOpacity> */}
                  </View>
                ) : null}
                <View style={{marginTop:ms(40)}}>
                    <View style={{flexDirection:'row',alignItems:'center',marginVertical:ms(10)}}>
                        <TouchableOpacity onPress={()=> setInvFlag(!invFlag)} style={{height:ms(20),width:ms(20),borderRadius:ms(5),borderWidth:ms(1),borderColor:COLORS.themeColor,justifyContent:'center',alignItems:'center'}}>
                            {invFlag ? <View style={{height:ms(20),width:ms(20),backgroundColor:COLORS.themeColor,justifyContent:'center',alignItems:'center',borderRadius:ms(5)}}>
                                <Image resizeMode='contain' style={{height:ms(10),width:ms(10)}} source={ICONS.tick}/>
                            </View>:null}
                        </TouchableOpacity>
                        <Text style={{fontSize:ms(16),fontFamily:FONTS.Medium,marginLeft:ms(10)}}>Invoice</Text>

                    </View>
                    <View style={{flexDirection:'row',alignItems:'center',marginVertical:ms(10)}}>
                        <TouchableOpacity onPress={()=> setEstFlag(!estFlag)} style={{height:ms(20),width:ms(20),borderRadius:ms(5),borderWidth:ms(1),borderColor:COLORS.themeColor,justifyContent:'center',alignItems:'center'}}>
                                {estFlag ? <View style={{height:ms(20),width:ms(20),backgroundColor:COLORS.themeColor,justifyContent:'center',alignItems:'center',borderRadius:ms(5)}}>
                                <Image resizeMode='contain' style={{height:ms(10),width:ms(10)}} source={ICONS.tick}/>
                            </View>:null}
                        </TouchableOpacity>
                        <Text style={{fontSize:ms(16),fontFamily:FONTS.Medium,marginLeft:ms(10)}}>Estimate</Text>

                    </View>
                    <View style={{flexDirection:'row',alignItems:'center',marginVertical:ms(10)}}>
                        <TouchableOpacity onPress={()=> setPurFlag(!purFlag)} style={{height:ms(20),width:ms(20),borderRadius:ms(5),borderWidth:ms(1),borderColor:COLORS.themeColor,justifyContent:'center',alignItems:'center'}}>
                            {purFlag ? <View style={{height:ms(20),width:ms(20),backgroundColor:COLORS.themeColor,justifyContent:'center',alignItems:'center',borderRadius:ms(5)}}>
                                <Image resizeMode='contain' style={{height:ms(10),width:ms(10)}} source={ICONS.tick}/>
                            </View>:null}
                        </TouchableOpacity>
                        <Text style={{fontSize:ms(16),fontFamily:FONTS.Medium,marginLeft:ms(10)}}>Purchase Order</Text>

                    </View>
                    <View style={{flexDirection:'row',alignItems:'center',marginVertical:ms(10)}}>
                        <TouchableOpacity onPress={()=> setCreditFlag(!creditFlag)} style={{height:ms(20),width:ms(20),borderRadius:ms(5),borderWidth:ms(1),borderColor:COLORS.themeColor}}>
                                {creditFlag ? <View style={{height:ms(20),width:ms(20),backgroundColor:COLORS.themeColor,justifyContent:'center',alignItems:'center',borderRadius:ms(5)}}>
                                <Image resizeMode='contain' style={{height:ms(10),width:ms(10)}} source={ICONS.tick}/>
                            </View>:null}
                        </TouchableOpacity>
                        <Text style={{fontSize:ms(16),fontFamily:FONTS.Medium,marginLeft:ms(10)}}>Credit Note</Text>

                    </View>
                </View>
                <TouchableOpacity
                      style={{
                        paddingHorizontal: ms(20),
                        paddingVertical: ms(8),
                        backgroundColor: COLORS?.themeColor,
                        // position: 'absolute',
                        // bottom: ms(10),
                        alignSelf: 'center',
                        width: ms(150),
                        borderRadius: ms(20),
                        marginTop: ms(30),
                      }}
                      onPress={() => {
                        checkValidation();
                      }}>
                      <Text
                        style={{
                          color: COLORS?.white,
                          textAlign: 'center',
                          fontFamily: FONTS?.Medium,
                          fontSize: ms(15),
                        }}>
                          {signatureDetail?.id ? "Update":"Save"}
                        
                      </Text>
                    </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
        <SignatureModal
          visible={signatureVisible}
          onClose={() => setSignatureVisible(false)}
          onSignatureSave={handleSaveSignature}
        />
      </ScrollView>
      <Modal
                      isVisible={camModal}
                      backdropOpacity={0.6}
                      animationIn={'slideInUp'}
                      animationOut={'slideOutDown'}
                      animationInTiming={800}
                      animationOutTiming={500}
                      backdropTransitionOutTiming={0}
                      hasBackdrop={true}
                      onBackdropPress={() => {
                        setCamModal(false);
                      }}
                      style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
                      <View
                        style={{
                          maxHeight: Dimensions.get('window').height,
                          width: '100%',
                          //height: Dimensions.get('window').height - normalize(200),
                          paddingTop: normalize(10),
                          paddingHorizontal: normalize(30),
                          backgroundColor: '#FFF',
                          borderTopLeftRadius: normalize(20),
                          borderTopRightRadius: normalize(20),
                          padding: normalize(40),
                        }}>
                        <View
                          style={{
                            width: ms(63),
                            height: ms(6),
                            borderRadius: ms(8),
                            backgroundColor: 'rgba(217, 217, 217, 1)',
                            alignSelf: 'center',
                            marginBottom: ms(20),
                            marginTop: ms(10),
                          }}
                        />
                        <TouchableOpacity
                                              onPress={() => setCamModal(false)}
                                              style={{position: 'absolute', top: 20, right: 20}}>
                                              <Image
                                                resizeMode="contain"
                                                style={{height: ms(20), width: ms(20)}}
                                                source={ICONS.crossbtn}
                                              />
                                              </TouchableOpacity>
                        <View
                          style={{
                            width: '100%',
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}>
                          <Text
                            style={{
                              fontSize: normalize(18),
                              fontFamily: FONTS.Medium,
                              paddingVertical: normalize(20),
                              //paddingHorizontal: normalize(20),
                            }}>
                            Open gallery
                          </Text>
                          <TouchableOpacity
                            //onPress={() => (false)}
                            style={{flexDirection: 'row', alignItems: 'center'}}>
                            <Text
                              style={{
                                fontSize: normalize(16),
                                color: COLORS.themeColor,
                                fontFamily: FONTS.Regular,
                              }}>
                              Upload
                            </Text>
                            <Image
                              resizeMode="contain"
                              style={{
                                height: normalize(17),
                                width: normalize(17),
                                marginLeft: normalize(5),
                              }}
                              source={ICONS.bluetick}
                            />
                          </TouchableOpacity>
                        </View>
              
                        <Text
                          style={{
                            fontSize: normalize(14),
                            fontFamily: FONTS.Regular,
                            //marginTop: normalize(35),
                          }}>
                          Add image here upload from gallery or click a picture
                        </Text>
                        <View
                          style={{
                            flexDirection: 'row',
                            width: '100%',
                            marginTop: normalize(25),
                            justifyContent: 'space-between',
                            alignItems: 'center',
                          }}>
                          <TouchableOpacity
                            onPress={() => onPressGallery()}
                            style={{
                              height: normalize(120),
                              width: normalize(140),
                              justifyContent: 'center',
                              alignItems: 'center',
                              borderWidth: 1,
                              //borderColor: COLORS.border,
                              borderRadius: normalize(20),
                              borderStyle: 'dotted',
                              borderColor: COLORS.themeColor,
                              elevation: 3,
                              backgroundColor: COLORS.white,
                              shadowColor: COLORS.themeColor,
                            }}>
                            <Image
                              resizeMode="contain"
                              style={{height: normalize(30), width: normalize(40)}}
                              source={ICONS.gallery}
                            />
                            <View
                              style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                marginTop: normalize(20),
                              }}>
                              <Image
                                resizeMode="contain"
                                style={{height: ms(15), width: ms(15), marginRight: ms(5)}}
                                source={ICONS.plusicn}
                              />
                              <Text
                                style={{
                                  fontSize: normalize(14),
                                  color: COLORS.themeColor,
                                  fontFamily: FONTS.Regular,
                                }}>
                                Add photo
                              </Text>
                            </View>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => onPressCamera()}
                            style={{
                              height: normalize(120),
                              width: normalize(140),
                              borderWidth: 1,
                              //borderColor: COLORS.border,
                              borderRadius: normalize(20),
                              justifyContent: 'center',
                              alignItems: 'center',
                              borderStyle: 'dotted',
                              borderColor: COLORS.themeColor,
                              elevation: 3,
                              backgroundColor: COLORS.white,
                              shadowColor: COLORS.themeColor,
                            }}>
                            <Image
                              resizeMode="contain"
                              style={{height: normalize(30), width: normalize(40)}}
                              source={ICONS.cam}
                            />
                            <Text
                              style={{
                                fontSize: normalize(14),
                                marginTop: normalize(20),
                                color: COLORS.themeColor,
                                fontFamily: FONTS.Regular,
                              }}>
                              Camera
                            </Text>
                          </TouchableOpacity>
                        </View>
                      </View>
              </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
