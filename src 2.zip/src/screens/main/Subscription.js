import React, {useEffect, useState, useCallback, useRef} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {useFocusEffect} from '@react-navigation/native';
import Loader from '../../utils/helpers/Loader';
import {
  getSubscriptionRequest,
  addSubscriptionRequest,
} from '../../redux/reducer/ProfileReducer';
import DeviceInfo from 'react-native-device-info';

export default function Subscription() {
  const dispatch = useDispatch();
  const [isTablet, setIsTablet] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pricingCategory, setPricingCategory] = useState('monthly');
  const planList = useSelector(
    state => state.ProfileReducer?.getSubscriptionRes,
  );
  const profileDetailsRes = useSelector(
    state => state.ProfileReducer?.profileResponse,
  );
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  const plan = [
    {
      id: 100,
      name: 'Starter Plan',
      price: '₹5,300.00/year',
      top_color: '#62B655',
      savings: 'Saving ₹5000 yr/-',
    },
    {
      id: 101,
      name: 'Premmium Plan',
      price: '₹8,300.00/year',
      top_color: '#952CB9',
      savings: 'Saving ₹6000 yr/-',
    },
  ];
  const {loading} = useSelector(state => state.ProfileReducer);

  const handleScroll = event => {
    const {width} = Dimensions.get('window');
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const index = Math.round(scrollPosition / width);
    setActiveIndex(index);
  };

  const StarRating = ({rating}) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <View
          style={{
            height: 20,
            width: 20,
            backgroundColor: '#219653',
            marginRight: ms(4),
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Image
            key={i}
            source={i <= rating ? ICONS.whitestar : ICONS.whitestar}
            //style={styles.star}
            style={{height: ms(12), width: ms(12), resizeMode: 'contain'}}
          />
        </View>,
      );
    }
    return (
      <View style={{flexDirection: 'row', marginHorizontal: ms(5)}}>
        {stars}
      </View>
    );
  };

  const comments = [
    {
      id: 100,
      comment: 'Best on the market',
      description: 'I love this product because the support is great. Ple ...',
      rating: 4,
      user: 'Worldtraveler',
    },
    {
      id: 101,
      comment: 'Best on the market',
      description: 'I love this product because the support is great. Ple ...',
      rating: 4,
      user: 'Worldtraveler',
    },
  ];

  useEffect(() => {
    //getSubscription();
  }, []);
  useFocusEffect(
    useCallback(() => {
      // This function will be called when the screen is focused
      console.log('Screen is focused');

      // Call your function here
      getSubscription();

      // Optionally return a cleanup function
    }, []),
  );
  const getSubscription = () => {
    let payload = {};
    dispatch(getSubscriptionRequest(payload));
  };

  const callSelectApi = item => {
    let payload = {
      planId: item.id,
      startDate: new Date(),
      planType: pricingCategory == 'monthly' ? 'monthly' : 'yearly',
      price:
        pricingCategory == 'monthly'
          ? item?.plan_prices[1]?.price
          : item?.plan_prices[0]?.price,
    };
    console.log('payloadddd', JSON.stringify(payload));
    dispatch(addSubscriptionRequest(payload));
  };

  const renderPlan = ({item, index}) => {
    const backgroundColor = index % 2 == 0 ? '#62B655' : '#952CB9';
    return (
      <View
        style={{
          //backgroundColor:'red',
          borderRadius: ms(15),
          borderWidth: ms(0.6),
          borderColor: COLORS.border,
          marginRight: ms(10),
          width: isTablet
            ? Dimensions.get('window').width - 100
            : Dimensions.get('window').width - 60,
          //paddingBottom:ms(20)
          // height:ms(400)
        }}>
        {index == 1 ? (
          <Image
            resizeMode="contain"
            style={{
              height: isTablet ? ms(40) : ms(40),
              width: isTablet ? 80 : 52,
              position: 'absolute',
              right: 0,
              top: 0,
            }}
            source={IMAGES.recomended}
          />
        ) : null}
        <View
          style={{
            //justifyContent:'center'
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontSize: ms(22),
              fontFamily: FONTS.Medium,
              color: '#0F172A',
              paddingVertical: ms(10),
              //alignSelf:'center'
            }}>
            {item.name}
          </Text>

          <View
            style={{
              backgroundColor: COLORS.white,
              //borderWidth: 1,
              //borderColor: COLORS.border,
              alignItems: 'center',
            }}>
            {pricingCategory == 'monthly' ? (
              <Text
                style={{
                  fontSize: 26,
                  color: item.top_color,
                  fontFamily: FONTS.Medium,
                  //marginLeft: ms(15),
                  //marginTop: ms(15),
                }}>
                ₹{item.plan_prices[1].price}
              </Text>
            ) : (
              <Text
                style={{
                  fontSize: 26,
                  color: item.top_color,
                  fontFamily: FONTS.Medium,
                  //marginLeft: ms(15),
                  //marginTop: ms(15),
                }}>
                ₹{item.plan_prices[0].price}
              </Text>
            )}
            {pricingCategory == 'monthly' ? (
              <Text
                style={{
                  fontSize: 16,
                  color: COLORS.dark_grey,
                  fontFamily: FONTS.Regular,
                  marginLeft: ms(15),
                  marginTop: ms(5),
                }}>
                {/* Saving ₹
                {item.plan_prices[1].price *
                  (item.plan_prices[1].discount / 100)}
                /{item.plan_prices[1].name} */}
                Per Month
              </Text>
            ) : (
              <Text
                style={{
                  fontSize: 16,
                  color: COLORS.dark_grey,
                  fontFamily: FONTS.Regular,
                  marginLeft: ms(15),
                  marginTop: ms(5),
                }}>
                {/* Saving ₹
                {item.plan_prices[0].price *
                  (item.plan_prices[0].discount / 100)}
                /{item.plan_prices[0].name} */}
                Per Year
              </Text>
            )}

            <TouchableOpacity
              onPress={() => callSelectApi(item)}
              style={{
                width: isTablet
                  ? Dimensions.get('window').width - 120
                  : Dimensions.get('window').width - 90,
                height: ms(40),
                backgroundColor:
                  profileDetailsRes?.planType == pricingCategory &&
                  profileDetailsRes?.planDetails?.id == item.id
                    ? '#6B747D'
                    : '#047FFF',
                justifyContent: 'center',
                alignItems: 'center',
                alignSelf: 'center',
                borderRadius: ms(12),
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  fontFamily: FONTS.Regular,
                  color: COLORS.white,
                  fontSize: ms(14),
                }}>
                {profileDetailsRes?.planType == pricingCategory &&
                profileDetailsRes?.planDetails?.id == item.id
                  ? 'Current Plan'
                  : 'Select Plan'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'flex-start',
            paddingVertical: ms(5),
            paddingLeft: ms(19),
            marginTop: 20,
            //backgroundColor:'red'
            //backgroundColor:'red'
            //paddingHorizontal:ms(10)
          }}>
          <Image
            source={ICONS.smalltick}
            style={{
              height: ms(9),
              width: ms(10.14),
              resizeMode: 'contain',
              marginTop: ms(4),
            }}
          />
          <Text
            style={{
              fontFamily: FONTS.Regular,
              fontSize: ms(12),
              color: COLORS.dark_grey,
              width: Dimensions.get('window').width - 120,
              marginLeft: ms(5),
              //textAlign:'center'
            }}>
            {item.short_description}
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'flex-start',
            paddingVertical: ms(5),
            paddingLeft: ms(19),
            marginTop: 0,
            //backgroundColor:'red'
            //paddingHorizontal:ms(10)
          }}>
          <Image
            source={ICONS.smalltick}
            style={{
              height: ms(9),
              width: ms(10.14),
              resizeMode: 'contain',
              marginTop: ms(4),
            }}
          />
          <Text
            style={{
              fontFamily: FONTS.Regular,
              fontSize: ms(12),
              color: COLORS.dark_grey,
              width: Dimensions.get('window').width - 80,
              marginLeft: ms(5),
              //textAlign:'center'
            }}>
            Unlimited quotes
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'flex-start',
            paddingVertical: ms(5),
            paddingLeft: ms(19),
            marginTop: 0,
            //backgroundColor:'red'
            //paddingHorizontal:ms(10)
          }}>
          <Image
            source={ICONS.smalltick}
            style={{
              height: ms(9),
              width: ms(10.14),
              resizeMode: 'contain',
              marginTop: ms(4),
            }}
          />
          <Text
            style={{
              fontFamily: FONTS.Regular,
              fontSize: ms(12),
              color: COLORS.dark_grey,
              width: Dimensions.get('window').width - 80,
              marginLeft: ms(5),
              //textAlign:'center'
            }}>
            Free bank transfer
          </Text>
        </View>
      </View>
    );
  };
  const renderComments = ({item, index}) => {
    return (
      <View
        style={{
          width: isTablet
            ? Dimensions.get('window').width - 100
            : Dimensions.get('window').width - 60,
          marginRight: ms(10),
          //elevation:3,
          backgroundColor: COLORS.white,
          //height:ms(220)
        }}>
        <View
          style={{
            backgroundColor: COLORS.white,
            borderWidth: 1,
            borderColor: COLORS.border,
            padding: 15,
          }}>
          <Image
            source={ICONS.quotes}
            style={{height: ms(25), width: ms(28), resizeMode: 'contain'}}
          />
          <Text
            style={{
              fontSize: ms(15),
              fontFamily: FONTS.Medium,
              color: COLORS.black,
              marginTop: ms(10),
              marginLeft: ms(0),
            }}>
            {item.comment}
          </Text>

          <View
            style={{
              paddingLeft: ms(0),
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: ms(5),
            }}>
            <StarRating rating={item.rating} />
            <Text style={{fontSize: ms(10), fontFamily: FONTS.Regular}}>
              2 days ago
            </Text>
          </View>
          <Text
            numberOfLines={3}
            style={{
              fontSize: ms(12),
              fontFamily: FONTS.Regular,
              marginTop: ms(5),
            }}>
            {item.description}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Subscription'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          isSavePresent={false}
        />
      </View>

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
          //marginBottom:30
          //backgroundColor:'red'
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(0),
            width: Dimensions?.get('window')?.width,
            alignItems: 'center',
          }}>
          {/* <ImageBackground
            style={{
              //height: Dimensions?.get('window')?.height,
              width: Dimensions?.get('window')?.width,
              alignItems: 'center',
              //justifyContent: 'center',
              //flex: 1
            }}
            source={IMAGES?.background}> */}
          {/* <TouchableOpacity
            // onPress={() => navigate('AccountSettings')}
            style={{
              marginTop: ms(40),
              backgroundColor: COLORS.white,
              width: ms(74),
              height: ms(24),
              borderRadius: ms(30),
              borderWidth: ms(0.2),
              alignItems: 'center',
              justifyContent: 'center',
              elevation: 5,
              shadowColor: 'rgba(4, 127, 255, 0.2)',
              borderColor: COLORS?.themeColor,
            }}>
            <Text
              style={{
                fontFamily: FONTS.Medium,
                color: '#047FFF',
                fontSize: ms(10),
                textAlign: 'center',
              }}>
              Active Plan
            </Text>
          </TouchableOpacity> */}
          {/* {profileDetailsRes?.planDetails?.name ? (
            <Text
              style={{
                fontSize: ms(24),
                fontFamily: FONTS.Header_SemiBold,
                color: COLORS.black,
                marginTop: ms(10),
                // textTransform: 'capitalize',
              }}>
              {profileDetailsRes?.planDetails?.name} (
              {profileDetailsRes?.planType})
            </Text>
          ) : (
            <Text
              style={{
                fontSize: ms(24),
                fontFamily: FONTS.Medium,
                color: COLORS.black,
                marginTop: ms(10),
              }}>
              Select Plan
            </Text>
          )} */}
          {/* {profileDetailsRes?.dayLeft ? (
            <View
              style={{
                marginTop: ms(5),
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text
                style={{
                  fontSize: ms(16),
                  fontFamily: FONTS.Italic,
                  color: COLORS.gray,
                }}>
                {profileDetailsRes?.dayLeft} days left
              </Text>
              <Image
                source={ICONS.knowmore}
                style={{
                  height: ms(12),
                  width: ms(12),
                  resizeMode: 'contain',
                  marginLeft: ms(4),
                }}
              />
            </View>
          ) : null} */}
          <Text
            style={{
              fontSize: ms(22),
              fontFamily: FONTS.Medium,
              color: '#262F3F',
              marginTop: profileDetailsRes?.dayLeft ? ms(25) : ms(15),
            }}>
            Select Pricing
          </Text>

          <View
            style={{
              backgroundColor: COLORS.white,
              borderWidth: 1,
              borderColor: COLORS.border,
              borderRadius: ms(15),
              marginTop: ms(15),
              elevation: 3,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-around',
              }}>
              <TouchableOpacity
                onPress={() => setPricingCategory('monthly')}
                style={{
                  width: '40%',
                  paddingVertical: ms(15),
                  borderTopColor: COLORS.white,
                  borderLeftColor: COLORS.white,
                  borderRightColor: COLORS.white,
                  borderBottomColor:
                    pricingCategory == 'monthly'
                      ? COLORS.themeColor
                      : COLORS.border,
                  borderWidth: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(14),
                    color:
                      pricingCategory == 'monthly'
                        ? 'rgba(52, 64, 84, 1)'
                        : 'rgba(52, 64, 84, 0.75)',
                  }}>
                  Monthly
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setPricingCategory('yearly')}
                style={{
                  width: '40%',
                  paddingVertical: ms(15),
                  borderTopColor: COLORS.white,
                  borderLeftColor: COLORS.white,
                  borderRightColor: COLORS.white,
                  borderBottomColor:
                    pricingCategory == 'yearly'
                      ? COLORS.themeColor
                      : COLORS.border,
                  borderWidth: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontFamily: FONTS?.Regular,
                    fontSize: ms(14),
                    color:
                      pricingCategory == 'yearly'
                        ? 'rgba(52, 64, 84, 1)'
                        : 'rgba(52, 64, 84, 0.75)',
                  }}>
                  Yearly
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View
            style={{
              paddingLeft: ms(20),
              marginTop: ms(20),
              // height: 300,
              marginBottom: 30,
              flex: 1,
            }}>
            <FlatList
              ref={flatListRef}
              // style={{flexGrow: 0}}
              horizontal={true}
              data={planList}
              renderItem={renderPlan}
              onScroll={handleScroll}
              //nestedScrollEnabled={true}
              showsHorizontalScrollIndicator={false}
            />
          </View>
          <View
            style={{
              flexDirection: 'row',
              marginTop: 10,
              justifyContent: 'center',
              alignItems: 'center',
              marginVertical: ms(20),
            }}>
            {planList?.map((_, index) => (
              <View
                key={index}
                style={{
                  width: index == activeIndex ? 12 : 10,
                  height: index == activeIndex ? 12 : 10,
                  borderRadius: index == activeIndex ? 6 : 5,
                  marginHorizontal: 5,
                  backgroundColor:
                    index === activeIndex ? '#047FFF' : '#44BBFE',
                }}
              />
            ))}
          </View>
          <View
            style={{
              paddingLeft: isTablet ? ms(20) : ms(20),
              alignSelf: 'flex-start',
            }}>
            <Text style={{fontFamily: FONTS.Medium, fontSize: ms(19)}}>
              What customers say about us{' '}
            </Text>
            <Text style={{fontFamily: FONTS.Regular, fontSize: ms(13)}}>
              We do our best to provide you the best experience ever
            </Text>
          </View>

          <View
            style={{
              paddingLeft: ms(20),
              marginTop: ms(20),
              marginBottom: 30,
            }}>
            <FlatList
              horizontal={true}
              data={comments}
              renderItem={renderComments}
              //nestedScrollEnabled={true}
            />
          </View>
          {/* </ImageBackground> */}
        </View>
      </ScrollView>
      <Image
        source={ICONS?.logoImage}
        style={{
          height: ms(170),
          width: ms(170),
          position: 'absolute',
          top: ms(90),
          left: -ms(70),
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
