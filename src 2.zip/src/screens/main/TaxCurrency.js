import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import {goBack} from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import {navigate} from '../../utils/helpers/RootNaivgation';
import normalize from '../../utils/helpers/normalize';
import {addTaxCurrencyRequest} from '../../redux/reducer/ProfileReducer';
import {useDispatch, useSelector} from 'react-redux';
import Toast from '../../utils/helpers/Toast';
import constants from '../../utils/helpers/constants';
import DatePicker from 'react-native-date-picker';
import DeviceInfo from 'react-native-device-info';

export default function TaxCurrency() {
  const {profileResponse} = useSelector(state => state.ProfileReducer);
  const dispatch = useDispatch();
  const {commonList} = useSelector(state => state.ProfileReducer);
  const [country, setCountry] = useState('Country');
  const [currency, setCurrency] = useState('Currency');
  const [gstIn, setGstIn] = useState('');
  const [regNo, setRegNo] = useState('');
  const [searchedText, setSerachedText] = useState('');
  const [panNo, setPanNo] = useState('');
  const [month, setMonth] = useState('Month');
  const [day, setDay] = useState('Day');
  const [gst, setGst] = useState('');
  const [countryModal, setCountryModal] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [countryId, setCountryId] = useState('');
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [isTablet, setIsTablet] = useState(false);

  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useEffect(() => {
    setPrefilledCountry();
  }, []);
  const setPrefilledCountry = () => {
    if (
      commonList.countries.length > 0 &&
      profileResponse?.companyTaxDetails?.countryId
    ) {
      commonList.countries.map(item => {
        if (item.value == profileResponse.companyTaxDetails.countryId) {
          setCountryId(item.value);
          setCountry(item.label);
          setCurrency(item?.currency);
        }
        return item;
      });
    }
    if (profileResponse?.companyTaxDetails?.gst_no) {
      setGstIn(profileResponse?.companyTaxDetails?.gst_no);
    }
    if (profileResponse?.companyTaxDetails?.gst_no) {
      setRegNo(profileResponse?.companyTaxDetails?.co_reg_no);
    }
    if (profileResponse?.companyTaxDetails?.gst_no) {
      setPanNo(profileResponse?.companyTaxDetails?.pan_no);
    }
    if (profileResponse?.companyTaxDetails?.tax_year_day) {
      setDay(profileResponse?.companyTaxDetails?.tax_year_day);
    }
    if (profileResponse?.companyTaxDetails?.tax_year_month) {
      setMonth(profileResponse?.companyTaxDetails?.tax_year_month);
    }
    if (profileResponse?.companyTaxDetails?.gst_rate) {
      setGst(profileResponse?.companyTaxDetails?.gst_rate);
    }
    if (profileResponse?.companyTaxDetails?.enable_withholding_tax) {
      setEnabled(profileResponse?.companyTaxDetails?.enable_withholding_tax);
    }
  };

  useEffect(() => {
    setCountryList(commonList?.countries);
  }, [commonList]);

  const handleSearch = text => {
    if (text !== '') {
      setSerachedText(text);
      const filteredData = countryList.filter(contact => {
        return contact?.label?.toLowerCase()?.includes(text?.toLowerCase());
      });
      setCountryList(filteredData);
    } else {
      setSerachedText('');
      setCountryList(commonList?.countries);
    }
  };

  // const day_month = [
  //   {
  //     id:100,
  //     month:"January",

  //   }
  // ]

  const checkValidation = () => {
    if (countryId == '') {
      Toast('Select country and currency');
    } else if (gstIn == '') {
      Toast('Enter GST IN');
    } else if (regNo == '') {
      Toast('Enter company registration number');
    } else if (panNo == '') {
      Toast('Enter PAN number');
    } else if (gst == '') {
      Toast('Enter GST');
    } else if (month == 'Month') {
      Toast('Select month and day');
    } else {
      let payload = {
        countryId: countryId,
        currency: currency,
        gst_no: gstIn,
        co_reg_no: regNo,
        pan_no: panNo,
        tax_year_month: month,
        tax_year_day: day,
        gst_rate: gst,
        enable_withholding_tax: enabled,
      };
      dispatch(addTaxCurrencyRequest(payload));
      // navigate('ClientPaymentOption');
    }
  };
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />

      <View
        style={{
          borderBottomWidth: ms(0.5),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Tax settings & Currency'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <DatePicker
        modal
        mode={'date'}
        open={open}
        date={date}
        onConfirm={date => {
          console.log('date', date);
          //const monthh = String(date.getUTCMonth() + 1).padStart(2, '0');
          const monthh = monthNames[date.getUTCMonth()];
          const dayy = String(date.getUTCDate()).padStart(2, '0');
          console.log('month:', month, 'day:', day);
          setOpen(false);
          setDate(date);
          setMonth(monthh);
          setDay(dayy);
        }}
        onCancel={() => {
          setOpen(false);
        }}
      />

      <ScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(30),
            alignItems: 'center',
          }}>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Location And Currency
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setCountryModal(true)}
            style={{
              marginTop: normalize(20),
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: normalize(10),
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
              height: ms(45),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <Text
              style={{
                fontSize: normalize(12),
                color: COLORS.placeholderColor,
                fontFamily: FONTS.Regular,
              }}>
              {country}
            </Text>
            <Image
              resizeMode="contain"
              style={{height: 5, width: 14, transform: [{rotate: '180deg'}]}}
              source={ICONS.arrow}
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,

              marginTop: normalize(18),
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: normalize(10),
              height: ms(45),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <Text
              style={{
                fontSize: normalize(12),
                color: COLORS.placeholderColor,
                fontFamily: FONTS.Regular,
              }}>
              {currency}
            </Text>
            <Image
              resizeMode="contain"
              style={{height: 5, width: 14, transform: [{rotate: '180deg'}]}}
              source={ICONS.arrow}
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: normalize(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Registration And Certification
            </Text>
          </TouchableOpacity>
          <AnimatedTextInput
            label={'GST IN'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={gstIn}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setGstIn(item);
            }}
          />
          <AnimatedTextInput
            label={'Co. Reg. No'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={regNo}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setRegNo(item);
            }}
          />
          <AnimatedTextInput
            label={'PAN'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={panNo}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setPanNo(item);
            }}
          />
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: normalize(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Tax Year Starts
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setOpen(true)}
            style={{
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,

              marginTop: normalize(20),
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: normalize(10),
              height: ms(45),
              elevation: 2,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <Text
              style={{
                fontSize: normalize(12),
                color: COLORS.placeholderColor,
                fontFamily: FONTS.Regular,
              }}>
              {month}
            </Text>
            <Image
              resizeMode="contain"
              style={{height: 5, width: 14, transform: [{rotate: '180deg'}]}}
              source={ICONS.arrow}
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,

              marginTop: normalize(20),
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: normalize(10),
              height: ms(45),
              elevation: 2,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <Text
              style={{
                fontSize: normalize(12),
                color: COLORS.placeholderColor,
                fontFamily: FONTS.Regular,
              }}>
              {day}
            </Text>
            <Image
              resizeMode="contain"
              style={{height: 5, width: 14, transform: [{rotate: '180deg'}]}}
              source={ICONS.arrow}
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: normalize(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Rates
            </Text>
          </TouchableOpacity>
          <View style={{paddingLeft: ms(5)}}>
            <Text
              style={{
                marginTop: normalize(10),
                fontSize: normalize(12),
                fontFamily: FONTS.Regular,
              }}>
              A tax can have multiple rates associated with it. Edit a tax to
              add additional rates. Default taxes and rates will be applied to
              items
            </Text>
          </View>
          <AnimatedTextInput
            label={'Add GST'}
            //keyboardType={'email-address'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={gst}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setGst(item);
            }}
          />
          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: normalize(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Withholding
            </Text>
          </TouchableOpacity>
          <View
            style={{
              marginTop: normalize(20),
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              width: '100%',
              paddingHorizontal: ms(10),
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(12),
                color: COLORS?.black,
              }}>
              Enable withholding tax
            </Text>
            <TouchableOpacity onPress={() => setEnabled(!enabled)}>
              <Image
                resizeMode="contain"
                style={{height: ms(20), width: ms(32)}}
                source={enabled ? ICONS.switch : ICONS.switchoff}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              // position: 'absolute',
              // bottom: 0,
              marginTop: ms(30),
              backgroundColor: COLORS?.white,
              width: '100%',
            }}>
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                // position: 'absolute',
                // bottom: ms(10),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                checkValidation();
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <Modal
        isVisible={countryModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setCountryModal(false);
        }}
        style={{margin: 0, flex: 1, justifyContent: 'flex-end'}}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height,
            width: '100%',
            height: Dimensions.get('window').height * 0.5,
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setCountryModal(false)}
            style={{position: 'absolute', top: 20, right: 20}}>
            <Image
              resizeMode="contain"
              style={{height: ms(20), width: ms(20)}}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Select Country
            </Text>
          </View>
          <View
            style={{
              height: normalize(46),
              width: '100%',
              borderWidth: ms(0.5),
              borderColor: COLORS.themeColor,
              borderRadius: normalize(10),
              marginBottom: normalize(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: normalize(10),
              elevation: 3,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
            }}>
            <TextInput
              style={{
                height: '100%',
                width: '75%',
              }}
              placeholder="Search"
              placeholderTextColor={COLORS.placeholderColor}
              value={searchedText}
              onChangeText={text => handleSearch(text)}
            />
            <Image
              resizeMode="contain"
              style={{height: normalize(14), width: normalize(14)}}
              source={ICONS.search}
            />
          </View>

          <FlatList
            data={countryList}
            //style={{maxHeight: Dimensions.get('window').height / 3}}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: COLORS?.orange}}>No data found.</Text>
              </View>
            }
            renderItem={({item, index}) => {
              console.log('www', item);

              return (
                <TouchableOpacity
                  style={{
                    borderBottomWidth: normalize(0),
                    borderBottomColor: COLORS.dark_grey,
                    padding: normalize(10),
                    //backgroundColor: '#EBF4F6',
                    marginTop: normalize(5),
                    borderRadius: normalize(5),
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  onPress={() => {
                    console.log('itemaaa', item);
                    setCountry(item?.label);
                    setCurrency(item?.currency);
                    setCountryModal(false);
                    setCountryId(item?.value);
                  }}>
                  <Text
                    style={{
                      color: '#000',
                      fontFamily: FONTS.Fredoka_Regular,
                      textTransform: 'capitalize',
                      marginLeft: normalize(10),
                    }}>
                    {item?.label}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
