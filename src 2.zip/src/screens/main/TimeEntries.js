import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import {navigate} from '../../utils/helpers/RootNaivgation';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import constants from '../../utils/helpers/constants';
import MainHeader from '../../components/MainHeader';
import DepthHeader from '../../components/DepthHeader';
import DeviceInfo, {isTablet} from 'react-native-device-info';

export default function TimeEntries() {
  const [option, setOption] = useState('unpaid');
  const [isTablet, setIsTablet] = useState(false);
  const clientList = [
    {
      name: 'Akash Mishra',
      days: '1 Nov',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '5 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '8 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '10 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '13 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '16 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '17 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '18 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
    {
      name: 'Akash Mishra',
      days: '19 Nov',
      amount: '$125',
      time: '30:00',
      note: 'note',
    },
  ];
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          // borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomWidth: ms(0.3),
          // backgroundColor: 'rgb(232, 243, 255)',
          // borderBottomColor: 'rgb(195, 211, 226)',
          borderBottomColor: 'rgb(255, 255, 255)',
        }}>
        <DepthHeader
          label={'Time Entries'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
        <View
          style={{
            paddingHorizontal: ms(20),
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginVertical: ms(10),
          }}>
          <View
            style={{flexDirection: 'row', alignItems: 'center', gap: ms(10)}}>
            <Text style={{fontFamily: FONTS?.SemiBold, fontSize: ms(14)}}>
              2025 sorted by category
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                tintColor: COLORS?.themeColor,
                transform: [{rotate: '180deg'}],
              }}
              resizeMode="contain"
            />
          </View>
          <Image
            source={ICONS?.sort}
            style={{height: ms(15), width: ms(15)}}
            resizeMode="contain"
          />
        </View>
        <View
          style={{
            marginVertical: ms(10),
            backgroundColor: COLORS?.white,
            flexDirection: 'row',
            width: Dimensions?.get('window')?.width - 60,
            alignSelf: 'center',
            borderRadius: ms(10),
            justifyContent: 'center',
            elevation: 2,
            width: Dimensions?.get('window')?.width,
            marginLeft: -ms(5),
          }}>
          <Text
            style={{
              padding: ms(15),
              width: '45%',
              textAlign: 'center',
              borderBottomWidth: option == 'unpaid' ? ms(1) : ms(0),
              borderBottomColor: COLORS?.themeColor,
              color:
                option == 'unpaid'
                  ? 'rgba(52, 64, 84, 1)'
                  : 'rgba(52, 64, 84, 0.75)',
              fontFamily: FONTS?.Regular,
              fontSize: ms(12),
            }}
            onPress={() => {
              setOption('unpaid');
            }}>
            Unbilled
          </Text>
          <Text
            style={{
              padding: ms(15),
              width: '45%',
              textAlign: 'center',
              borderBottomWidth: option == 'paid' ? ms(1) : ms(0),
              borderBottomColor: COLORS?.themeColor,
              color:
                option == 'paid'
                  ? 'rgba(52, 64, 84, 1)'
                  : 'rgba(52, 64, 84, 0.75)',
              fontFamily: FONTS?.Regular,
              fontSize: ms(12),
            }}
            onPress={() => {
              setOption('paid');
            }}>
            Billed
          </Text>
        </View>
      </View>
      <View
        style={{
          height: Dimensions?.get('window')?.height,
          width: Dimensions?.get('window')?.width,
          alignItems: 'center',
          flex: 1,
        }}>
        <ScrollView
          style={{
            flex: 1,
            width: Dimensions?.get('window')?.width,
          }}>
          <View style={{flex: 1, alignItems: 'center'}}>
            <FlatList
              data={clientList}
              style={{paddingHorizontal: ms(20), marginTop: ms(20)}}
              renderItem={({item, index}) => {
                return (
                  <View
                    style={{
                      padding: ms(10),
                      backgroundColor: COLORS?.white,
                      borderRadius: ms(10),
                      marginBottom: ms(10),
                      borderWidth: ms(0.6),
                      borderColor: COLORS.border,
                      //flexDirection: 'row',
                      //justifyContent: 'space-between',
                      width: isTablet
                        ? Dimensions?.get('window')?.width - 70
                        : Dimensions?.get('window')?.width - 50,
                      elevation: 5,
                      shadowColor: 'rgba(4, 127, 255, 0.2)',
                    }}>
                    <View
                      style={{
                        height: ms(40),
                        borderRadius: ms(5),
                        backgroundColor: 'rgba(4, 127, 255, 0.1)',
                        paddingHorizontal: ms(10),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}>
                      <Text
                        style={{
                          fontSize: ms(14),
                          color: COLORS.themeColor,
                          fontWeight: '600',
                        }}>
                        {item.days}
                      </Text>
                      <View
                        style={{flexDirection: 'row', alignItems: 'center'}}>
                        <Image
                          style={{
                            height: ms(18),
                            width: ms(16),
                            resizeMode: 'contain',
                          }}
                          source={ICONS.alarm}
                        />
                        <Text
                          style={{
                            fontSize: ms(14),
                            color: COLORS.themeColor,
                            fontWeight: '400',
                            marginLeft: ms(5),
                          }}>
                          {item.time}
                        </Text>
                      </View>
                    </View>
                    <View style={{paddingLeft: ms(10)}}>
                      <Text
                        style={{
                          fontFamily: FONTS?.Medium,
                          fontSize: ms(13),
                          color: COLORS?.black,
                          marginTop: ms(10),
                        }}>
                        {item?.name}
                        <Text style={{fontFamily: FONTS?.Light}}>
                          {'\n'}
                          {item?.note}
                        </Text>
                      </Text>
                    </View>
                  </View>
                );
              }}
            />
          </View>
        </ScrollView>
        <TouchableOpacity
          onPress={() => navigate('AddNewTime')}
          style={{
            position: 'absolute',
            bottom: ms(10),
            right: ms(10),
            height: ms(49),
            width: ms(49),
            borderRadius: ms(25),
            backgroundColor: '#047FFF',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            style={{
              height: ms(20),
              width: ms(20),
              resizeMode: 'contain',
              tintColor: COLORS?.white,
            }}
            source={ICONS.plusicn}
          />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
});
