import React, { useEffect, useState, useMemo } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TextInput,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { goBack } from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import { navigate } from '../../utils/helpers/RootNaivgation';
import DeviceInfo, { isTablet } from 'react-native-device-info';
import { useDispatch, useSelector } from 'react-redux';
import {
  addNewExpenseRequest,
  getClientRequest,
  getClientWiseProjectRequest,
  projectListRequest,
  updateExpenseRequest,
} from '../../redux/reducer/ProfileReducer';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import normalize from '../../utils/helpers/normalize';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';
import Toast from '../../utils/helpers/Toast';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
export default function UpdateExpence(props) {
  let prevDetail = props.route.params.item;
  console.log('previous details', JSON.stringify(prevDetail));
  let dispatch = useDispatch();
  const { clientList, clientWiseProject } = useSelector(
    state => state.ProfileReducer,
  );
  const [isTablet, setIsTablet] = useState(false);
  const [merchant, setMerchant] = useState(prevDetail?.merchant || '');
  const [description, setDescription] = useState(prevDetail?.description || '');
  const [rate, setRate] = useState(String(prevDetail?.rate) || '');
  const [tax, setTax] = useState(String(prevDetail?.tax) || '');
  const [tip, setTip] = useState(String(prevDetail?.tip) || '');
  const [camModal, setCamModal] = useState(false);
  const [logoImg, setLogoImg] = useState(prevDetail?.profileImage || '');
  const [logoName, setLogoName] = useState(prevDetail?.image?.substring(0, 30) || '');
  const [selectedDate, setSlectedDate] = useState(
    moment(prevDetail?.date).format('YYYY-MM-DD') || '',
  );
  const [openStart, setOpenStart] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryModal, setCategoryModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(
    prevDetail?.catagory || '',
  );
  const [clientModal, setClientModal] = useState(false);
  const [filteredClient, setFIlterdClient] = useState(clientList);
  const [searchedText, setSearchedText] = useState('');
  const [clientData, setClientData] = useState('');
  const [selectedExpType, setSelectedExpType] = useState(
    prevDetail?.type || '',
  );
  const [expModal, setExpModal] = useState(false);
  const [hsnCode, setHsnCode] = useState(prevDetail?.HSN || '');
  const [sacCode, setSacCode] = useState(prevDetail?.SAC || '');
  const [selectedGstTreatment, setSelectedGstTreatment] = useState('');
  const [projectModal, setProjectModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState('');
  const [dateSend, setDateSend] = useState(moment.utc(prevDetail?.date).format());

  const category = [
    {
      id: 1,
      name: 'Advertising',
    },
    {
      id: 2,
      name: 'Accommodation',
    },
    {
      id: 3,
      name: 'Air fare',
    },
    {
      id: 4,
      name: 'Car Rental',
    },
  ];

  const expType = [
    {
      id: 1,
      type: 'Goods',
    },
    {
      id: 2,
      type: 'Services',
    },
  ];

  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);
  useEffect(() => {
    setFIlterdClient(clientList);
  }, [clientList]);

  useEffect(() => {
    getClient();
  }, [clientList]);

  const getClient = () => {
    let temp = clientList?.filter(item => {
      return item.id == prevDetail.clientId;
    });
    if (temp && temp.length > 0) {
      setClientData(temp[0]);
    }


    let payload = {
      client_id: prevDetail.clientId,
    };
    dispatch(getClientWiseProjectRequest(payload));
  };
  useEffect(() => {
    if (prevDetail.clientId == clientData.id) {
      let temp = clientWiseProject?.filter((item, index) => {
        return item.id == prevDetail.projectId;
      });
      if (temp && temp.length > 0) {
        setSelectedProject(temp[0]);
      }

    }
  }, [clientWiseProject]);
  useEffect(() => {
    let payload = {};
    dispatch(projectListRequest(payload));
    dispatch(getClientRequest(payload));
  }, []);

  const handleSearch = text => {
    setSearchedText(text);
    const filteredData = clientList.filter(contact => {
      return contact.name.toLowerCase().includes(text.toLowerCase());
    });
    setFIlterdClient(filteredData);
  };

  const onPressGallery = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        //includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Image picker cancelled or failed:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          // Create image object with Base64
          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(), // fallback to last part of URI
            type: asset.type, // e.g., 'image/jpeg'
            uri: asset.uri,
            //size: asset.fileSize,
            //base64: `data:${asset.type};base64,${asset.base64}`, // Full data URL
          };

          console.log('Image with Base64:', imageObj);
          setLogoImg(imageObj);
          if (imageObj.name.length > 15) {
            setLogoName(imageObj.name.substring(0, 30));
          } else {
            setLogoName(imageObj.name);
          }

          // Pass to parent component

          setCamModal(false); // Close modal
        }
      },
    );
  };

  const onPressCamera = () => {
    launchCamera(
      {
        mediaType: 'photo',
        quality: 0.5,
        maxWidth: ms(500),
        maxHeight: ms(500),
        //includeBase64: true,
      },
      response => {
        if (response.didCancel || response.errorCode) {
          console.log('Camera cancelled or error:', response);
          return;
        }

        if (response.assets && response.assets.length > 0) {
          const asset = response.assets[0];

          const imageObj = {
            name: asset.fileName || asset.uri.split('/').pop(),
            type: asset.type,
            uri: asset.uri,
            //size: asset.fileSize,
            //base64: `data:${asset.type};base64,${asset.base64}`, // Ready for upload or display
          };

          console.log('Photo with Base64:', imageObj);

          setLogoImg(imageObj);
          if (imageObj.name.length > 15) {
            setLogoName(imageObj.name.substring(0, 30));
          } else {
            setLogoName(imageObj.name);
          }
          setCamModal(false);
        }
      },
    );
  };

  const filteredCategories = useMemo(() => {
    if (!searchQuery.trim()) {
      return category;
    }

    return category.filter(item =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }, [searchQuery, category]);

  const getProject = item => {
    let payload = {
      client_id: item.id,
    };
    dispatch(getClientWiseProjectRequest(payload));
  };

  const checkValidation = () => {
    const formData = new FormData();
    if (clientData) {
      formData.append('clientId', clientData.id);
    } else {
      formData.append('clientId', '');
    }

    if (selectedProject.id) {
      formData.append('projectId', selectedProject.id);
    } else {
      formData.append('projectId', '');
    }

    if (dateSend) {
      formData.append('date', moment.utc(dateSend).format());
    } else {
      formData.append('date', '');
    }
    formData.append('id', prevDetail?.id)
    formData.append('merchant', merchant);
    formData.append('catagory', selectedCategory);
    formData.append('rate', rate);
    formData.append('tax', tax);
    formData.append('tip', tip);
    formData.append('type', selectedExpType);
    formData.append('SAC', sacCode);
    formData.append('HSN', hsnCode);
    formData.append('status', 1);
    formData.append('profileImage', logoImg);
    formData.append('description', description);
    dispatch(updateExpenseRequest(formData))

    // if (merchant == '') {
    //   Toast('Enter merchant');
    // } else if (selectedCategory == '') {
    //   Toast('Select category');
    // } else if (description == '') {
    //   Toast('Enter description');
    // } else if (rate == '') {
    //   Toast('Enter rate');
    // } else if (tax == '') {
    //   Toast('Enter tax');
    // } else if (tip == '') {
    //   Toast('Enter tip');
    // } else if (selectedExpType == '') {
    //   Toast('Select expense type');
    // } else if (clientData == '') {
    //   Toast('Select client');
    // } else if (selectedProject == '') {
    //   Toast('Select project');
    // } else {
    //   if (selectedExpType == 'Goods') {
    //     if (hsnCode == '') {
    //       Toast('Enter HSN code');
    //     } else {
    //       //call api
    //       callAddNewExpense();
    //     }
    //   } else {
    //     if (sacCode == '') {
    //       Toast('Enter SAC code');
    //     } else {
    //       //alert("call api")
    //       callAddNewExpense();
    //     }
    //   }
    // }
  };

  const callAddNewExpense = () => {
    const formData = new FormData();
    //formData.append('name', projectName);
    if (clientData) {
      formData.append('clientId', clientData.id);
    } else {
      formData.append('clientId', '');
    }

    if (selectedProject.id) {
      formData.append('projectId', selectedProject.id);
    } else {
      formData.append('projectId', '');
    }

    if (dateSend) {
      formData.append('date', moment.utc(dateSend).format());
    } else {
      formData.append('date', '');
    }

    formData.append('merchant', merchant);
    formData.append('catagory', selectedCategory);
    formData.append('rate', rate);
    formData.append('tax', tax);
    formData.append('tip', tip);
    formData.append('type', selectedExpType);
    formData.append('SAC', sacCode);
    formData.append('HSN', hsnCode);
    formData.append('status', 1);
    formData.append('profileImage', logoImg);
    formData.append('description', description);

    dispatch(addNewExpenseRequest(formData));
  };

  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Update Expense'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>
      <DatePicker
        modal
        mode={'date'}
        open={openStart}
        date={new Date()}
        onConfirm={date => {
          //setStartDate(date);
          //setSelectedDateNew(date);
          console.log('selected date', date);
          setDateSend(date);
          setSlectedDate(moment(date).format('YYYY-MM-DD'));
          console.log(date);
          setOpenStart(false);
        }}
        onCancel={() => {
          setOpenStart(false);
        }}
      />

      <KeyboardAwareScrollView
        style={{
          flex: 1,
          width: Dimensions?.get('window')?.width,
        }}>
        <View
          style={{
            flex: 1,
            padding: ms(20),
            marginBottom: ms(10),
            alignItems: 'center',
          }}>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Attachment
            </Text>
          </View>
          <View
            onPress={() => setCamModal(true)}
            style={{
              height: ms(45),
              borderWidth: 1,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: ms(20),
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(14),
                }}>
                {logoName ? logoName : 'Upload photo'}
              </Text>
              <TouchableOpacity
                onPress={() => {
                  if (logoName) {
                    setLogoName('');
                    setLogoImg('');
                  } else {
                    setCamModal(true);
                  }
                }}>
                <Image
                  style={{
                    height: ms(17),
                    width: ms(14),
                    resizeMode: 'contain',
                    marginLeft: ms(10),
                  }}
                  source={logoName ? ICONS.crossbtn : ICONS.upload}
                />
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Details
            </Text>
          </View>
          <View
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: COLORS.placeholderColor,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                {selectedDate ? selectedDate : 'Start date'}
              </Text>
              <TouchableOpacity onPress={() => setOpenStart(true)}>
                <Image
                  style={{
                    height: ms(18),
                    width: ms(16.2),
                    resizeMode: 'contain',
                    marginLeft: ms(10),
                  }}
                  source={ICONS.calendar}
                />
              </TouchableOpacity>
            </View>
          </View>

          <AnimatedTextInput
            label={'Merchant'}
            keyboardType={'default'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={merchant}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            onChangeText={item => {
              setMerchant(item);
            }}
          //height={100}
          />
          <TouchableOpacity
            onPress={() => setCategoryModal(true)}
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: COLORS.placeholderColor,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                {selectedCategory ? selectedCategory : 'Select category'}
              </Text>
              <Image
                style={{
                  height: ms(5),
                  width: ms(14),
                  resizeMode: 'contain',
                  tintColor: COLORS.themeColor,
                  transform: [{ rotate: '180deg' }],
                }}
                source={ICONS.arrow}
              />
            </View>
          </TouchableOpacity>

          <AnimatedTextInput
            label={'Description'}
            keyboardType={'default'}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={description}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(85)}
            multiline={true}
            numberOfLines={6}
            onChangeText={item => {
              setDescription(item);
            }}
          //height={100}
          />

          {/* <View
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <TextInput
                placeholder="Rate"
                placeholderTextColor={COLORS.placeholderColor}
                value={rate}
                onChangeText={setRate}
                style={{width: '60%', fontSize: ms(12)}}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '30%',
                }}>
                <View
                  style={{
                    height: 35,
                    width: 0.3,
                    backgroundColor: COLORS.themeColor,
                  }}
                />
                <Text>$</Text>
                <Image
                  style={{
                    height: ms(5),
                    width: ms(14),
                    resizeMode: 'contain',
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '180deg'}],
                  }}
                  source={ICONS.arrow}
                />
              </View>
            </View>
          </View> */}
          <AnimatedTextInput
            label={'Rate'}
            keyboardType={'numeric'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={rate}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            //multiline={true}
            //numberOfLines={10}
            onChangeText={item => {
              setRate(item);
            }}
          />

          {/* <View
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <TextInput
                placeholder="Tax"
                placeholderTextColor={COLORS.placeholderColor}
                value={tax}
                onChangeText={setTax}
                style={{width: '60%', fontSize: ms(12)}}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '30%',
                }}>
                <View
                  style={{
                    height: 35,
                    width: 0.3,
                    backgroundColor: COLORS.themeColor,
                  }}
                />
                <Text>$</Text>
                <Image
                  style={{
                    height: ms(5),
                    width: ms(14),
                    resizeMode: 'contain',
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '180deg'}],
                  }}
                  source={ICONS.arrow}
                />
              </View>
            </View>
          </View> */}

          <AnimatedTextInput
            label={'Tax'}
            keyboardType={'numeric'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={tax}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            //multiline={true}
            //numberOfLines={10}
            onChangeText={item => {
              setTax(item);
            }}
          />

          {/* <View
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <TextInput
                placeholder="Tip"
                placeholderTextColor={COLORS.placeholderColor}
                value={tip}
                onChangeText={setTip}
                style={{width: '60%', fontSize: ms(12)}}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '30%',
                }}>
                <View
                  style={{
                    height: 35,
                    width: 0.3,
                    backgroundColor: COLORS.themeColor,
                  }}
                />
                <Text>$</Text>
                <Image
                  style={{
                    height: ms(5),
                    width: ms(14),
                    resizeMode: 'contain',
                    tintColor: COLORS.themeColor,
                    transform: [{rotate: '180deg'}],
                  }}
                  source={ICONS.arrow}
                />
              </View>
            </View>
          </View> */}
          <AnimatedTextInput
            label={'Tip'}
            keyboardType={'numeric'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            value={tip}
            borderColor={COLORS?.themeColor}
            minimumHeight={ms(45)}
            //multiline={true}
            //numberOfLines={10}
            onChangeText={item => {
              setTip(item);
            }}
          />
          <TouchableOpacity
            onPress={() => setExpModal(true)}
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: COLORS.placeholderColor,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                {selectedExpType ? selectedExpType : 'Select Expense Type'}
              </Text>
              <Image
                style={{
                  height: ms(5),
                  width: ms(14),
                  resizeMode: 'contain',
                  tintColor: COLORS.themeColor,
                  transform: [{ rotate: '180deg' }],
                }}
                source={ICONS.arrow}
              />
            </View>
          </TouchableOpacity>
          {selectedExpType == 'Goods' ? (
            <AnimatedTextInput
              label={'HSN'}
              //keyboardType={'numeric'}
              width={
                isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50
              }
              value={hsnCode}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              //multiline={true}
              //numberOfLines={10}
              onChangeText={item => {
                setHsnCode(item);
              }}
            />
          ) : selectedExpType == 'Services' ? (
            <AnimatedTextInput
              label={'SAC'}
              //keyboardType={'numeric'}
              width={
                isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50
              }
              value={sacCode}
              borderColor={COLORS?.themeColor}
              minimumHeight={ms(45)}
              //multiline={true}
              //numberOfLines={10}

              onChangeText={item => {
                setSacCode(item);
              }}
            />
          ) : null}
          {/* <TouchableOpacity
            
            style={{
              height: ms(45),
              borderWidth: 0.5,
              borderColor: COLORS.themeColor,
              borderRadius: ms(10),
              marginTop: ms(20),
              justifyContent: 'center',
              elevation: 3,
              shadowColor: COLORS.themeColor,
              backgroundColor: COLORS.white,
              width: isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50,
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: ms(10),
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  color: COLORS.placeholderColor,
                  fontFamily: FONTS.Regular,
                  fontSize: ms(12),
                }}>
                {selectedGstTreatment ? selectedGstTreatment : 'GST Treatment'}
              </Text>
              <Image
                style={{
                  height: ms(5),
                  width: ms(14),
                  resizeMode: 'contain',
                  tintColor: COLORS.themeColor,
                  transform: [{rotate: '180deg'}],
                }}
                source={ICONS.arrow}
              />
            </View>
          </TouchableOpacity> */}
          <View
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Medium,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              Project
            </Text>
          </View>

          <TouchableOpacity
            style={{
              padding: ms(10),
              borderWidth: ms(0.6),
              borderRadius: ms(10),
              borderColor: COLORS?.themeColor,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: ms(12),
              width: isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50,
              height: ms(45),
              elevation: 5,
              backgroundColor: 'white',
              shadowColor: COLORS.themeColor,
              marginTop: ms(20),
            }}
            onPress={() => {
              setClientModal(true);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Regular,
                fontSize: ms(13),
                color: COLORS?.themeColor,
              }}>
              {clientData ? clientData?.name : 'Select Client'}
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{ rotate: '180deg' }],
              }}
              resizeMode="contain"
              tintColor={COLORS.themeColor}
            />
          </TouchableOpacity>
          {clientData?.name ? (
            <TouchableOpacity
              style={{
                padding: ms(10),
                borderWidth: ms(0.6),
                borderRadius: ms(10),
                borderColor: COLORS?.themeColor,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                paddingHorizontal: ms(12),
                width: isTablet
                  ? Dimensions.get('window').width - 70
                  : Dimensions.get('window').width - 50,
                height: ms(45),
                elevation: 5,
                backgroundColor: 'white',
                shadowColor: COLORS.themeColor,
                marginTop: ms(20),
              }}
              onPress={() => {
                setProjectModal(true);
              }}>
              <Text
                style={{
                  fontFamily: FONTS?.Regular,
                  fontSize: ms(13),
                  color: COLORS?.themeColor,
                }}>
                {selectedProject
                  ? selectedProject.project_name
                  : 'Select project'}
              </Text>
              <Image
                source={ICONS?.arrow}
                style={{
                  height: ms(5),
                  width: ms(14),
                  transform: [{ rotate: '180deg' }],
                }}
                resizeMode="contain"
                tintColor={COLORS.themeColor}
              />
            </TouchableOpacity>
          ) : null}

          <TouchableOpacity
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(8),
              backgroundColor: COLORS?.themeColor,
              marginVertical: ms(30),

              alignSelf: 'center',
              width: ms(150),
              borderRadius: ms(20),
            }}
            onPress={() => {
              //navigate("Subscription")
              checkValidation();
            }}>
            <Text
              style={{
                color: COLORS?.white,
                textAlign: 'center',
                fontFamily: FONTS?.Medium,
                fontSize: ms(15),
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollView>
      <Modal
        isVisible={camModal}
        backdropOpacity={0.6}
        animationIn={'slideInUp'}
        animationOut={'slideOutDown'}
        animationInTiming={800}
        animationOutTiming={500}
        backdropTransitionOutTiming={0}
        hasBackdrop={true}
        onBackdropPress={() => {
          setCamModal(false);
        }}
        style={{ margin: 0, flex: 1, justifyContent: 'flex-end' }}>
        <View
          style={{
            maxHeight: Dimensions.get('window').height,
            width: '100%',
            //height: Dimensions.get('window').height - normalize(200),
            paddingTop: normalize(10),
            paddingHorizontal: normalize(30),
            backgroundColor: '#FFF',
            borderTopLeftRadius: normalize(20),
            borderTopRightRadius: normalize(20),
            padding: normalize(40),
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
              marginTop: ms(10),
            }}
          />
          <TouchableOpacity
                                onPress={() => setCamModal(false)}
                                style={{position: 'absolute', top: 20, right: 20}}>
                                <Image
                                  resizeMode="contain"
                                  style={{height: ms(20), width: ms(20)}}
                                  source={ICONS.crossbtn}
                                />
                                </TouchableOpacity>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: normalize(18),
                fontFamily: FONTS.Medium,
                paddingVertical: normalize(20),
                //paddingHorizontal: normalize(20),
              }}>
              Open gallery
            </Text>
            <TouchableOpacity
              //onPress={() => (false)}
              style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  fontSize: normalize(16),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Upload
              </Text>
              <Image
                resizeMode="contain"
                style={{
                  height: normalize(17),
                  width: normalize(17),
                  marginLeft: normalize(5),
                }}
                source={ICONS.bluetick}
              />
            </TouchableOpacity>
          </View>

          <Text
            style={{
              fontSize: normalize(14),
              fontFamily: FONTS.Regular,
              //marginTop: normalize(35),
            }}>
            Add image here upload from gallery or click a picture
          </Text>
          <View
            style={{
              flexDirection: 'row',
              width: '100%',
              marginTop: normalize(25),
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() => onPressGallery()}
              style={{
                height: normalize(120),
                width: normalize(140),
                justifyContent: 'center',
                alignItems: 'center',
                borderWidth: 1,
                //borderColor: COLORS.border,
                borderRadius: normalize(20),
                borderStyle: 'dotted',
                borderColor: COLORS.themeColor,
                elevation: 3,
                backgroundColor: COLORS.white,
                shadowColor: COLORS.themeColor,
              }}>
              <Image
                resizeMode="contain"
                style={{ height: normalize(30), width: normalize(40) }}
                source={ICONS.gallery}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: normalize(20),
                }}>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(15), width: ms(15), marginRight: ms(5) }}
                  source={ICONS.plusicn}
                />
                <Text
                  style={{
                    fontSize: normalize(14),
                    color: COLORS.themeColor,
                    fontFamily: FONTS.Regular,
                  }}>
                  Add photo
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => onPressCamera()}
              style={{
                height: normalize(120),
                width: normalize(140),
                borderWidth: 1,
                //borderColor: COLORS.border,
                borderRadius: normalize(20),
                justifyContent: 'center',
                alignItems: 'center',
                borderStyle: 'dotted',
                borderColor: COLORS.themeColor,
                elevation: 3,
                backgroundColor: COLORS.white,
                shadowColor: COLORS.themeColor,
              }}>
              <Image
                resizeMode="contain"
                style={{ height: normalize(30), width: normalize(40) }}
                source={ICONS.cam}
              />
              <Text
                style={{
                  fontSize: normalize(14),
                  marginTop: normalize(20),
                  color: COLORS.themeColor,
                  fontFamily: FONTS.Regular,
                }}>
                Camera
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <Modal
        isVisible={categoryModal}
        onBackdropPress={() => {
          setCategoryModal(false);
        }} // Close modal when tapping outside
        style={{ justifyContent: 'flex-end', margin: 0 }}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(30),
            }}
          />
          <TouchableOpacity
            onPress={() => setCategoryModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Select Category
              </Text>
              <TouchableOpacity
                onPress={() => {
                  //navigate('CreateClient');
                  setCategoryModal(false);
                }}
                style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Add
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(15), width: ms(15), marginLeft: ms(5) }}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>
            <View>
              <View
                style={{
                  height: normalize(46),
                  width: '100%',
                  borderWidth: ms(0.5),
                  borderColor: COLORS.themeColor,
                  borderRadius: normalize(10),
                  marginBottom: normalize(20),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: normalize(10),
                  elevation: 3,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                }}>
                <TextInput
                  style={{
                    height: '100%',
                    width: '75%',
                    fontSize: ms(12),
                    fontFamily: FONTS?.Regular,
                  }}
                  placeholder="Search"
                  placeholderTextColor={COLORS.placeholderColor}
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                />
                <Image
                  resizeMode="contain"
                  style={{ height: normalize(14), width: normalize(14) }}
                  source={ICONS.search}
                />
              </View>
              <FlatList
                data={filteredCategories}
                renderItem={({ item, index }) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: ms(10),
                        marginBottom: mvs(10),
                        borderBottomWidth: ms(0.6),
                        borderBottomColor: 'rgba(229, 231, 235, 1)',
                        paddingBottom: ms(5),
                      }}
                      onPress={() => {
                        //setClientData(item);
                        //dispatch(getAllTimesRequest({id: item?.id}));
                        setSelectedCategory(item.name);
                        setCategoryModal(false);
                      }}>
                      <View>
                        <Text
                          style={{ fontSize: ms(14), fontFamily: FONTS.Regular }}>
                          {item?.name}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                ListEmptyComponent={() => {
                  return (
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={{
                          height: ms(200),
                          width: ms(200),
                          alignSelf: 'center',
                        }}
                        source={ICONS.noclient}
                        resizeMode="contain"
                      />
                      <Text
                        style={{
                          textAlign: 'center',
                          fontSize: ms(12),
                          fontFamily: FONTS.Medium,
                          marginTop: ms(10),
                          color: COLORS.themeColor,
                        }}>
                        No category found
                      </Text>
                    </View>
                  );
                }}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </Modal>

      <Modal
        isVisible={clientModal}
        onBackdropPress={() => {
          setClientModal(false);
        }} // Close modal when tapping outside
        style={{ justifyContent: 'flex-end', margin: 0 }}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(20),
            }}
          />
          <TouchableOpacity
            onPress={() => setClientModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Add Client
              </Text>
              <TouchableOpacity
                onPress={() => {
                  navigate('CreateClient');
                  setClientModal(false);
                }}
                style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Add
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(15), width: ms(15), marginLeft: ms(5) }}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>
            <View>
              <View
                style={{
                  height: normalize(46),
                  width: '100%',
                  borderWidth: ms(0.5),
                  borderColor: COLORS.themeColor,
                  borderRadius: normalize(10),
                  marginBottom: normalize(20),
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingHorizontal: normalize(10),
                  elevation: 3,
                  backgroundColor: 'white',
                  shadowColor: COLORS.themeColor,
                }}>
                <TextInput
                  style={{
                    height: '100%',
                    width: '75%',
                    fontSize: ms(12),
                    fontFamily: FONTS?.Regular,
                  }}
                  placeholder="Search"
                  placeholderTextColor={COLORS.placeholderColor}
                  value={searchedText}
                  onChangeText={text => handleSearch(text)}
                />
                <Image
                  resizeMode="contain"
                  style={{ height: normalize(14), width: normalize(14) }}
                  source={ICONS.search}
                />
              </View>
              <FlatList
                //data={clientList}
                data={filteredClient}
                renderItem={({ item, index }) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: ms(10),
                        marginBottom: mvs(10),
                        borderBottomWidth: ms(0.6),
                        borderBottomColor: 'rgba(229, 231, 235, 1)',
                        paddingBottom: ms(5),
                      }}
                      onPress={() => {
                        getProject(item);
                        setClientData(item);
                        //dispatch(getAllTimesRequest({id: item?.id}));
                        setClientModal(false);
                      }}>
                      {item?.profileImage ? (
                        <Image
                          source={{ uri: item?.profileImage }}
                          style={{
                            height: ms(30),
                            width: ms(30),
                            borderRadius: ms(15),
                          }}
                        //resizeMode="contain"
                        />
                      ) : (
                        <View
                          style={{
                            height: ms(30),
                            width: ms(30),
                            borderRadius: ms(15),
                            backgroundColor: 'rgba(217, 217, 217, 1)',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Text
                            style={{
                              fontSize: ms(14),
                              fontFamily: FONTS.Regular,
                            }}>
                            {item?.name?.[0]}
                          </Text>
                        </View>
                      )}
                      <View>
                        <Text
                          style={{ fontSize: ms(14), fontFamily: FONTS.Regular }}>
                          {item?.name}
                        </Text>
                        <Text
                          style={{ fontSize: ms(14), fontFamily: FONTS.Regular }}>
                          {item?.email}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                ListEmptyComponent={() => {
                  return (
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={{
                          height: ms(200),
                          width: ms(200),
                          alignSelf: 'center',
                        }}
                        source={ICONS.noclient}
                        resizeMode="contain"
                      />
                      <Text
                        style={{
                          textAlign: 'center',
                          fontSize: ms(12),
                          fontFamily: FONTS.Medium,
                          marginTop: ms(10),
                          color: COLORS.themeColor,
                        }}>
                        No client found
                      </Text>
                    </View>
                  );
                }}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </Modal>

      <Modal
        isVisible={expModal}
        onBackdropPress={() => {
          setExpModal(false);
        }} // Close modal when tapping outside
        style={{ justifyContent: 'flex-end', margin: 0 }}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(30),
            }}
          />
          <TouchableOpacity
            onPress={() => setExpModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Select Expense Type
              </Text>
              {/* <TouchableOpacity
                onPress={() => {
                  //navigate('CreateClient');
                  setCategoryModal(false);
                }}
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Add
                </Text>
                <Image
                  resizeMode="contain"
                  style={{height: ms(15), width: ms(15), marginLeft: ms(5)}}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity> */}
            </View>
            <View>
              <FlatList
                data={expType}
                renderItem={({ item, index }) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: ms(10),
                        marginBottom: mvs(10),
                        borderBottomWidth: ms(0.6),
                        borderBottomColor: 'rgba(229, 231, 235, 1)',
                        paddingBottom: ms(5),
                      }}
                      onPress={() => {
                        //setClientData(item);
                        //dispatch(getAllTimesRequest({id: item?.id}));
                        setSelectedExpType(item.type);
                        setExpModal(false);
                      }}>
                      <View>
                        <Text
                          style={{ fontSize: ms(14), fontFamily: FONTS.Regular }}>
                          {item?.type}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                ListEmptyComponent={() => {
                  return (
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={{
                          height: ms(200),
                          width: ms(200),
                          alignSelf: 'center',
                        }}
                        source={ICONS.noclient}
                        resizeMode="contain"
                      />
                      <Text
                        style={{
                          textAlign: 'center',
                          fontSize: ms(12),
                          fontFamily: FONTS.Medium,
                          marginTop: ms(10),
                          color: COLORS.themeColor,
                        }}>
                        No data found
                      </Text>
                    </View>
                  );
                }}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </Modal>

      <Modal
        isVisible={projectModal}
        onBackdropPress={() => {
          setProjectModal(false);
        }} // Close modal when tapping outside
        style={{ justifyContent: 'flex-end', margin: 0 }}>
        <View
          style={{
            backgroundColor: 'white',
            padding: 22,
            //alignItems: 'center',
            borderTopLeftRadius: 15,
            borderTopRightRadius: 15,
            height: Dimensions.get('window').height * 0.6,
          }}>
          <View
            style={{
              width: ms(63),
              height: ms(6),
              borderRadius: ms(8),
              backgroundColor: 'rgba(217, 217, 217, 1)',
              alignSelf: 'center',
              marginBottom: ms(30),
            }}
          />
          <TouchableOpacity
            onPress={() => setProjectModal(false)}
            style={{ position: 'absolute', top: 20, right: 20 }}>
            <Image
              resizeMode="contain"
              style={{ height: ms(20), width: ms(20) }}
              source={ICONS.crossbtn}
            />
          </TouchableOpacity>
          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
            <View
              style={{
                flexDirection: 'row',
                widt: '100%',
                alignItems: 'center',
                marginBottom: 12,
                justifyContent: 'space-between',
                marginTop: ms(20),
              }}>
              <Text
                style={{
                  //textAlign: 'center',
                  fontStyle: FONTS.Medium,
                  fontSize: ms(18),
                }}>
                Select Project
              </Text>
              <TouchableOpacity
                onPress={() => {
                  navigate('CreateProject');
                  setProjectModal(false);
                }}
                style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text
                  style={{
                    fontStyle: FONTS.Medium,
                    fontSize: ms(18),
                    color: COLORS.themeColor,
                  }}>
                  Add
                </Text>
                <Image
                  resizeMode="contain"
                  style={{ height: ms(15), width: ms(15), marginLeft: ms(5) }}
                  source={ICONS.plusicn}
                />
              </TouchableOpacity>
            </View>
            <View>
              <FlatList
                data={clientWiseProject}
                renderItem={({ item, index }) => {
                  return (
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: ms(10),
                        marginBottom: mvs(10),
                        borderBottomWidth: ms(0.6),
                        borderBottomColor: 'rgba(229, 231, 235, 1)',
                        paddingBottom: ms(5),
                      }}
                      onPress={() => {
                        setSelectedProject(item);
                        setProjectModal(false);
                      }}>
                      <View>
                        <Text
                          style={{ fontSize: ms(14), fontFamily: FONTS.Regular }}>
                          {item?.project_name}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                ListEmptyComponent={() => {
                  return (
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={{
                          height: ms(200),
                          width: ms(200),
                          alignSelf: 'center',
                        }}
                        source={ICONS.noclient}
                        resizeMode="contain"
                      />
                      <Text
                        style={{
                          textAlign: 'center',
                          fontSize: ms(12),
                          fontFamily: FONTS.Medium,
                          marginTop: ms(10),
                          color: COLORS.themeColor,
                        }}>
                        No data found
                      </Text>
                    </View>
                  );
                }}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
