import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import { COLORS, FONTS, ICONS, IMAGES } from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import { ms, mvs } from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import AnimatedTextInput from '../../components/AnimatedTextInput';
import { goBack } from '../../utils/helpers/RootNaivgation';
import Modal from 'react-native-modal';
import { navigate } from '../../utils/helpers/RootNaivgation';
import { TextInput } from 'react-native-gesture-handler';
import Toast from '../../utils/helpers/Toast';
import { useDispatch, useSelector } from 'react-redux';
import {
  addItemsRequest,
  invoiceCreateRequest,
  updateItemRequest
} from '../../redux/reducer/ProfileReducer';
import moment from 'moment';
import DeviceInfo, { isTablet } from 'react-native-device-info';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

export default function UpdateItem(props) {
  console.log("from prev", JSON.stringify(props.route.params.item))
  const dispatch = useDispatch();


  const [isModalVisible, setModalVisible] = useState(false);
  const [itemName, setItemName] = useState(props.route.params.item?.item_name);
  const [itemDescription, setItemDescription] = useState(props.route.params.item?.item_Description);

  const [rate, setRate] = useState(String(props.route.params.item?.rate));
  const [quantity, setQuantity] = useState(String(props.route.params.item?.qty));
  const [tax, setTax] = useState(String(props.route.params.item?.tax));
  const [days, setDays] = useState('');

  const [moreDetailOpen, setMoreDetailOpen] = useState(true);
  const [isTablet, setIsTablet] = useState(false);
  const { clientDetails, addedItem } = useSelector(state => state.ProfileReducer);
  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);

  useEffect(() => {
    const checkIsTablet = async () => {
      const tablet = await DeviceInfo.isTablet();
      setIsTablet(tablet);
    };
    checkIsTablet();
  }, []);








  const checkValidation = () => {
    if (itemName == '') {
      Toast('Enter item name');
    } else if (itemDescription == '') {
      Toast('Enter item description');
    } else {
      let payload = {
        id: props.route.params.item.id,
        item_name: itemName,
        item_Description: itemDescription,
        rate: rate,
        qty: quantity,
        unit_code: "",
        tax: tax,
        days: days,
        //listingRequired: false,
        time_units: ""
      };
      dispatch(updateItemRequest(payload));
      setModalVisible(false);
      goBack()
    }
  };

  function isEmpty(item) {
    if (item == null || item == '' || item == undefined) return true;
    return false;
  }
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'Update Item'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
        />
      </View>

      <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
        <View style={{ alignItems: 'center' }}>
          <AnimatedTextInput
            label={'Item Name'}
            //keyboardType={'numeric'}
            value={itemName}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            minimumHeight={ms(45)}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setItemName(item);
            }}
          />
          <AnimatedTextInput
            label={'Item Description'}
            width={
              isTablet
                ? Dimensions.get('window').width - 70
                : Dimensions.get('window').width - 50
            }
            // maxLength={200}
            numberOfLines={10}
            multiline={true}
            minimumHeight={ms(100)}
            value={itemDescription}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setItemDescription(item);
            }}
          />
          <AnimatedTextInput
            label={'Rate'}
            keyboardType={'numeric'}
            minimumHeight={ms(45)}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={rate}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setRate(item);
            }}
          />
          <AnimatedTextInput
            label={'Qty'}
            keyboardType={'numeric'}
            minimumHeight={ms(45)}
            width={
              isTablet
                ? Dimensions?.get('window')?.width - 70
                : Dimensions?.get('window')?.width - 50
            }
            value={quantity}
            borderColor={COLORS?.themeColor}
            onChangeText={item => {
              setQuantity(item);
            }}
          />


          <TouchableOpacity
            style={{
              padding: ms(10),
              backgroundColor: 'rgba(4, 127, 255, 0.1)',
              borderRadius: ms(6),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: ms(20),
              width: '100%',
            }}
            onPress={() => {
              setMoreDetailOpen(!moreDetailOpen);
            }}>
            <Text
              style={{
                fontFamily: FONTS?.Bold,
                fontSize: ms(14),
                color: COLORS?.themeColor,
              }}>
              More Details
            </Text>
            <Image
              source={ICONS?.arrow}
              style={{
                height: ms(5),
                width: ms(14),
                transform: [{ rotate: moreDetailOpen ? '180deg' : '0deg' }],
                tintColor: COLORS?.themeColor,
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {moreDetailOpen ? (
            <View>
              <AnimatedTextInput
                label={'Tax'}
                keyboardType={'numeric'}
                minimumHeight={ms(45)}
                width={
                  isTablet
                    ? Dimensions?.get('window')?.width - 70
                    : Dimensions?.get('window')?.width - 50
                }
                value={tax}
                borderColor={COLORS?.themeColor}
                onChangeText={item => {
                  setTax(item);
                }}
              />

              {/* <View
                style={{
                  height: ms(45),
                  width: isTablet
                    ? Dimensions.get('window').width - 70
                    : Dimensions.get('window').width - 50,
                  borderWidth: 0.5,
                  borderColor: COLORS.themeColor,
                  borderRadius: ms(10),
                  marginTop: ms(20),
                  paddingHorizontal: ms(10),
                  //alignItems:'center'
                  justifyContent: 'center',
                  height: ms(45),
                  elevation: 3,
                  backgroundColor: COLORS.white,
                  shadowColor: COLORS.themeColor,
                }}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <TextInput
                    style={{
                      width: '70%',
                      fontFamily: FONTS?.Regular,
                      fontSize: ms(12),
                      color: '#707070',
                    }}
                    placeholderTextColor={COLORS?.placeholderColor}
                    onChangeText={text => setDays(text)}
                    value={days}
                    placeholder="Time"
                    keyboardType="numeric"
                  />

                  <View
                    style={{
                      width: 1,
                      height: '100%',
                      backgroundColor: COLORS.border,
                    }}
                  />
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text>Days</Text>
                    <Image
                      resizeMode="contain"
                      source={ICONS.arrow}
                      style={{
                        height: ms(5),
                        width: ms(14),
                        marginLeft: ms(10),
                        tintColor: COLORS.themeColor,
                        transform: [{rotate: '180deg'}],
                      }}
                    />
                  </View>
                </View>
              </View> */}
            </View>
          ) : null}
          <View
            style={{
              width: '100%',
              backgroundColor: COLORS.white,
              // paddingTop: ms(10),
              // position: 'absolute',
              // bottom: 0,
              padding: ms(5),
              marginTop: ms(30),
            }}>
            <TouchableOpacity
              style={{
                paddingHorizontal: ms(20),
                paddingVertical: ms(8),
                backgroundColor: COLORS?.themeColor,
                // position: 'absolute',
                // bottom: ms(10),
                alignSelf: 'center',
                width: ms(150),
                borderRadius: ms(20),
              }}
              onPress={() => {
                checkValidation();
                //checkValidationForAddInvoice();
              }}>
              <Text
                style={{
                  color: COLORS?.white,
                  textAlign: 'center',
                  fontFamily: FONTS?.Medium,
                  fontSize: ms(15),
                }}>
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
    paddingHorizontal: ms(20),
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
