import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, ICONS, IMAGES} from '../../themes/Themes';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import {ms, mvs} from '../../utils/helpers/metric';
import FormHeader from '../../components/FormHeader';
import {navigate} from '../../utils/helpers/RootNaivgation';
import {useDispatch, useSelector} from 'react-redux';
import {
  getRoleListRequest,
  roleDeleteRequest,
} from '../../redux/reducer/ProfileReducer';
import Loader from '../../utils/helpers/Loader';
import {useFocusEffect} from '@react-navigation/native';

export default function UserRole() {
  const dispatch = useDispatch();
  const {roleList, loading} = useSelector(state => state.ProfileReducer);

  useFocusEffect(
    useCallback(() => {
      dispatch(getRoleListRequest());
    }, []),
  );
  return (
    <SafeAreaView style={styles.container}>
      <MyStatusBar />
      <Loader visible={loading} />
      <View
        style={{
          borderBottomWidth: ms(0.3),
          backgroundColor: 'rgb(232, 243, 255)',
          borderBottomColor: 'rgb(195, 211, 226)',
        }}>
        <FormHeader
          label={'User Roles & Management'}
          searchOptionPresent={false}
          tickOptionPresent={false}
          addMoreOptionPresent={false}
          isBackPresent={true}
          isSavePresent={false}
        />
      </View>
      <TouchableOpacity
        style={{
          alignItems: 'flex-end',
          marginTop: ms(20),
          width: '100%',
          paddingHorizontal: ms(20),
        }}
        onPress={() => {
          navigate('AddRole');
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Text
            style={{
              fontSize: ms(14),
              fontFamily: FONTS.Regular,
              color: COLORS.themeColor,
            }}>
            Add
          </Text>
          <Image
            resizeMode="contain"
            style={{height: ms(20), width: ms(20), marginLeft: ms(5)}}
            source={ICONS.plusicn}
          />
        </View>
      </TouchableOpacity>
      <FlatList
        data={roleList}
        style={{marginTop: ms(10)}}
        contentContainerStyle={{marginTop:ms(20)}}
        renderItem={({item, index}) => {
          return (
            <TouchableOpacity>
              <View
                style={{
                  width: Dimensions?.get('window')?.width,
                  paddingHorizontal: ms(20),
                  marginTop: ms(0),
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: ms(14),
                    fontFamily: FONTS.Medium,
                    color: '#344054',
                  }}>
                  {item?.roleName}
                </Text>
                
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => {
                        navigate('EditRole', {item: item});
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{
                          height: ms(15),
                          width: ms(15),
                          marginRight: ms(10),
                        }}
                        source={ICONS.editicn}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        dispatch(
                          roleDeleteRequest({
                            uuid: item?.uuid,
                          }),
                        );
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{height: ms(15), width: ms(15)}}
                        source={ICONS.delicn}
                      />
                    </TouchableOpacity>
                  </View>
                
              </View>
              <View
                style={{
                  width: '100%',
                  height: 1,
                  backgroundColor: COLORS.border,
                  marginVertical: ms(10),
                }}
              />
            </TouchableOpacity>
          );
        }}
      />
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    //justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS?.white,
  },

  centerLogo: {
    height: ms(250),
    width: ms(250),
    resizeMode: 'contain',
  },
  centerText: {
    fontSize: ms(18),
    color: COLORS.black,
    fontFamily: FONTS.Inter_SemiBold,
    marginTop: ms(20),
  },
  iconStyle: {
    width: ms(20),
    height: ms(20),
  },
});
