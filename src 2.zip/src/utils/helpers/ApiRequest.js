import axios from 'axios';
import constants from './constants';

export async function postApi(url, body, header) {
  let headerBody = {};
  headerBody.Accept = header.Accept;
  headerBody[`Content-Type`] = header.contenttype;
  header.token != null
    ? (headerBody.Authorization = 'Bearer ' + header.token)
    : null;
  console.log(constants?.BASE_URL + '/' + url);
  const response = await axios({
    method: 'POST',
    baseURL: constants?.BASE_URL,
    url: url,
    data: body,
    headers: headerBody,
  });
  return response;
}

export async function getApi(url, header) {
  let headerBody = {};
  headerBody.Accept = header.Accept;
  headerBody[`Content-Type`] = header.contenttype;
  header.token != null
    ? (headerBody.Authorization = 'Bearer ' + header.token)
    : null;
  console.log(constants?.BASE_URL + '/' + url);
  const response = await axios({
    method: 'GET',
    baseURL: constants?.BASE_URL,
    url: url,
    headers: headerBody,
  });
  console.log(response);
  return response;
}

export async function putApi(url, body, header) {
  let headerBody = {};
  headerBody.Accept = header.Accept;
  headerBody[`Content-Type`] = header.contenttype;
  
  // Check if the token exists and add it to the headers
  if (header.token != null) {
    headerBody.Authorization = 'Bearer ' + header.token;
  }

  console.log(constants?.BASE_URL + '/' + url);

  try {
    const response = await axios({
      method: 'PUT', // Change the method to PUT
      baseURL: constants?.BASE_URL,
      url: url,
      data: body,
      headers: headerBody,
    });
    return response;
  } catch (error) {
    console.error('Error in PUT request:', error);
    throw error; // Rethrow the error for further handling if needed
  }
}
export async function deleteApi(url, header) {
  let headerBody = {};
  
  // Set default headers if provided
  if (header.Accept) headerBody.Accept = header.Accept;
  if (header.contenttype) headerBody['Content-Type'] = header.contenttype;

  // Add authorization token if present
  if (header.token != null) {
    headerBody.Authorization = 'Bearer ' + header.token;
  }

  console.log(constants?.BASE_URL + '/' + url);

  try {
    const response = await axios({
      method: 'DELETE',
      baseURL: constants?.BASE_URL,
      url: url,
      headers: headerBody,
    });

    return response;
  } catch (error) {
    console.error('Error in DELETE request:', error.response || error);
    throw error; // Rethrow to handle it in calling functions
  }
}
