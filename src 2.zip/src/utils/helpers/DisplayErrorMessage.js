import Toast from './Toast';

export default function DisplayErrorMessage(key) {
  switch (key) {
    case 'phone':
      Toast('Enter your mobile number');
      break;
    case 'name':
      Toast('Enter your name');
      break;
    case 'proper phone number':
      Toast('Mobile number must be 10 digit');
      break;
    case 'password':
      Toast('Enter password');
      break;
    case 'confirm password':
      Toast('Password and confirm password must be same');
      break;
    case 'proper email':
      Toast('Please enter valid email id');
      break;
    case 'manager name':
      Toast('Please enter manager name');
      break;
    case 'contact person name':
      Toast('Please enter contact person name');
      break;
    case 'region':
      Toast('Please select region');
      break;
    case 'user type':
      Toast('Please select user type');
      break;
    default:
      Toast('Something went wrong, Please try after some time');
  }
}
