import React from 'react';
import {
  View,
  StyleSheet,
  ActivityIndicator,
  Text,
  Dimensions,
} from 'react-native';
import PropTypes from 'prop-types';
import {COLORS} from '../../themes/Themes';
import {ms} from './metric';

export default function Loader(props) {
  const {visible = true, msg = '', backgroundColor = 'rgba(0,0,0,0.5)'} = props;
  return visible ? (
    <View
      style={[
        styles.container,
        {backgroundColor: backgroundColor, paddingHorizontal: ms(20)},
      ]}>
      <ActivityIndicator color={COLORS.white} size={'large'} />
      {msg ? (
        <Text
          style={{
            color: COLORS?.white,
            textAlign: 'center',
            lineHeight: ms(20),
          }}>
          {msg}
        </Text>
      ) : null}
    </View>
  ) : null;
}

Loader.propTypes = {
  visible: PropTypes.bool,
  msg: PropTypes.string,
  backgroundColor: PropTypes.string,
};

const styles = StyleSheet.create({
  container: {
    // ...StyleSheet.absoluteFillObject,
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 10,
    alignItems: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    // flexDirection: 'row',
    padding: ms(10),
    gap: ms(20),
    position: 'absolute',
    xIndex: 2,
    height: Dimensions?.get('window')?.height,
    width: '100%',
  },
});
