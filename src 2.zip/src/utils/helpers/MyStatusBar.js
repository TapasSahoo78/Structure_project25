import React from 'react';
import {StatusBar, Platform, SafeAreaView} from 'react-native';
import PropTypes from 'prop-types';
import {COLORS} from '../../themes/Themes';

const MyStatusBar = ({
  backgroundColor = COLORS?.white,
  barStyle = 'dark-content',
  translucent,
}) => (
  <SafeAreaView
    style={Platform.OS === 'ios' && [{backgroundColor: backgroundColor}]}>
    <StatusBar
      translucent={translucent}
      backgroundColor={backgroundColor}
      barStyle={barStyle}
      hidden={false}
    />
  </SafeAreaView>
);

export default MyStatusBar;
MyStatusBar.propTypes = {
  backgroundColor: PropTypes.string,
  barStyle: PropTypes.string,
  height: PropTypes.number,
  translucent: PropTypes.bool,
};
