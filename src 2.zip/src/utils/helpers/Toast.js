import Snackbar from 'react-native-snackbar';
import {COLORS, FONTS} from '../../themes/Themes';

export default function Toast(message) {
  Snackbar.show({
    text: message,
    duration: Snackbar.LENGTH_LONG,
    fontFamily: FONTS.Inter_Medium,
    numberOfLines: 5,
  });
  // Toasts.show(message, Toasts.SHORT);
}
