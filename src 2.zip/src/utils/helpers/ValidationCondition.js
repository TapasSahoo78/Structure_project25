import constants from './constants';

export default function ValidationCondition(key, val = '', val2 = '') {
  switch (key) {
    case 'phone':
      if (val == '') {
        return false;
      }
      return true;
    case 'email':
      if (val == '' || val == null || val == undefined) {
        return false;
      }
      return true;
    case 'proper phone number':
      if (String(Number(val)).length != 10) {
        return false;
      }
      return true;
    case 'proper email':
      if (!val.match(constants?.EMAIL_REGEX)) {
        return false;
      }
      return true;
    case 'password':
      if (val == '') {
        return false;
      }
      return true;
    case 'confirm password':
      if (val != val2) {
        return false;
      }
      return true;
    case 'name':
      if (val == '') {
        return false;
      }
      return true;
    case 'manager name':
      if (val == '') {
        return false;
      }
      return true;
    case 'contact person name':
      if (val == '') {
        return false;
      }
      return true;
    case 'region':
      if (val == '') {
        return false;
      }
      return true;
    case 'user type':
      if (val == '') {
        return false;
      }
      return true;
    default:
      return true;
  }
}
