export default {
  ALPHA_NUMERIC: /[^a-zA-Z 0-9]/g,
  NUMERIC: /[^0-9]/g,
  NUMERIC_DECI: /[^0-9.]/g,
  DECIMAL: /^\d{0,9}(\.\d{0,2})?$/,
  ALPHA: /[^a-zA-Z " "]/g,
  EMAIL_REGEX:
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  PHONE_REGEX: /^[6-9]\d{10}$/,
  BASE_URL: 'http://3.108.121.124:4001/api/v1',
  IMAGE_URL: 'http://3.108.121.124:4001/uploads/',
  TOKEN: 'TOKEN',
  gender: ['MALE', 'FEMALE', 'OTHERS'],
  marital_status: ['SINGLE', 'MARRIED'],
  GOOGLE_API_KEY: 'AIzaSyAVZ1qG4_OeMi2QisK6dwZYv7lsjMZF_BE', //'AIzaSyBFB0z2KXPh4T1ARZkdgFlrM7CySCNoo38',
};
