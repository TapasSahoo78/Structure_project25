import {PixelRatio, Dimensions} from 'react-native';

const scale = Dimensions.get('window').width / 375;

export default normalize = size => {
  const newSize = size * scale;

  return Math.round(PixelRatio.roundToNearestPixel(newSize));
};
