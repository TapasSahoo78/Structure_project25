"use client";

import { Box, CircularProgress, Grid } from "@mui/material";
import Sidebar from "@/components/layout/Sidebar";
import Navbar from "@/components/layout/Navbar";
import { useSelector } from "react-redux";
import { RootState } from "@/redux/store";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { isAuthenticated, loading } = useSelector((state: RootState) => state.auth);
    const router = useRouter();
    const [isCheckingAuth, setIsCheckingAuth] = useState(true);

    // useEffect(() => {
    //     // Check authentication status
    //     if (!loading) {
    //         if (!isAuthenticated) {
    //             router.push("/");
    //         } else {
    //             setIsCheckingAuth(false);
    //         }
    //     }
    // }, [isAuthenticated, loading, router]);

    // Show loading spinner while checking authentication
    // if (loading || isCheckingAuth) {
    //     return (
    //         <Box
    //             sx={{
    //                 display: "flex",
    //                 justifyContent: "center",
    //                 alignItems: "center",
    //                 height: "100vh",
    //                 width: "100vw",
    //             }}
    //         >
    //             <CircularProgress />
    //         </Box>
    //     );
    // }

    // Don't render layout if not authenticated
    // if (!isAuthenticated) {
    //     return null;
    // }

    return (
        <Box sx={{ display: "flex" }}>
            <Sidebar />
            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    display: "flex",
                    flexDirection: "column",
                    minHeight: "100vh"
                }}
            >
                <Navbar />
                <Grid container spacing={3}>
                    <Box
                        sx={{
                            p: 3,
                            flexGrow: 1,
                            backgroundColor: "background.default"
                        }}
                    >
                        {/* <DynamicBreadcrumb /> */}
                        {children}
                    </Box>
                </Grid>
            </Box>
        </Box>
    );
}