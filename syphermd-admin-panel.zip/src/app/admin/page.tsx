"use client";

import { Typography, Grid, Card, CardContent, Box, useTheme } from "@mui/material";
import PeopleIcon from "@mui/icons-material/People";
import DashboardIcon from "@mui/icons-material/Dashboard";
import MedicalServicesIcon from "@mui/icons-material/MedicalServices";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";
import PageHeader from "@/components/layout/PageHeader";
import { ReactNode } from "react";

export default function DashboardPage() {
    const theme = useTheme();

    const dashboardData = {
        totalDoctors: 156,
        totalSessions: 1234,
        activeUsers: 892,
        pendingAppointments: 28
    };

    interface StatCardProps {
        icon: ReactNode;
        title: string;
        value: string | number;
        subtitle: string;
        color?:
        | "primary"
        | "secondary"
        | "success"
        | "error"
        | "info"
        | "warning";
    }

    const StatCard = ({ icon, title, value, subtitle, color = "primary" }: StatCardProps) => (
        <Card
            sx={{
                height: '100%',
                background: `linear-gradient(135deg, ${theme.palette.background.paper} 0%, ${theme.palette.action.hover} 100%)`,
                border: `1px solid ${theme.palette.divider}`,
                transition: 'all 0.3s ease',
                '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: theme.shadows[8],
                    borderColor: theme.palette[color].main,
                }
            }}
        >
            <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                        sx={{
                            p: 1.5,
                            borderRadius: 2,
                            backgroundColor: `${theme.palette[color].main}15`,
                            color: theme.palette[color].main,
                            mr: 2,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                    >
                        {icon}
                    </Box>
                    <Box sx={{ flex: 1 }}>
                        <Typography
                            variant="h4"
                            fontWeight="bold"
                            color={theme.palette[color].main}
                        >
                            {value}
                        </Typography>
                        <Typography
                            variant="body2"
                            color="text.secondary"
                            sx={{ mt: 0.5 }}
                        >
                            {title}
                        </Typography>
                    </Box>
                </Box>
                {subtitle && (
                    <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                            display: 'block',
                            fontSize: '0.75rem',
                            opacity: 0.8
                        }}
                    >
                        {subtitle}
                    </Typography>
                )}
            </CardContent>
        </Card>
    );

    return (
        <Box sx={{ mt: 5 }}>
            {/* Header Section */}
            <PageHeader
                title="Dashboard Overview"
                subtitle="Welcome back! Here's what's happening today."
                breadcrumbs={[
                    {
                        label: "",
                        href: "/admin",
                        icon: <PeopleIcon sx={{ mr: 0.5, fontSize: 18 }} />,
                    },
                ]}
            />

            <Grid container spacing={3}>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                    <StatCard
                        icon={<MedicalServicesIcon fontSize="medium" />}
                        title="Total Doctors"
                        value={dashboardData.totalDoctors.toLocaleString()}
                        subtitle=""
                        color="primary"
                    />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                    <StatCard
                        icon={<EventAvailableIcon fontSize="medium" />}
                        title="Completed Sessions"
                        value={dashboardData.totalSessions.toLocaleString()}
                        subtitle=""
                        color="success"
                    />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                    <StatCard
                        icon={<PeopleIcon fontSize="medium" />}
                        title="Active Users"
                        value={dashboardData.activeUsers.toLocaleString()}
                        subtitle=""
                        color="secondary"
                    />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                    <StatCard
                        icon={<DashboardIcon fontSize="medium" />}
                        title="Pending Appointments"
                        value={dashboardData.pendingAppointments.toString()}
                        subtitle=""
                        color="warning"
                    />
                </Grid>
            </Grid>

            <Grid container spacing={3} sx={{ mt: 1 }}>
                <Grid size={{ xs: 12, md: 8 }}>
                    <Card
                        sx={{
                            mt: 3,
                            background: `linear-gradient(135deg, ${theme.palette.background.paper} 0%, ${theme.palette.action.hover} 100%)`,
                            border: `1px solid ${theme.palette.divider}`,
                        }}
                    >
                        <CardContent sx={{ p: 3 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                Recent Activity
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Session analytics and doctor registration trends will appear here.Session analytics and doctor registration trends will appear here.
                            </Typography>
                        </CardContent>
                    </Card>
                </Grid>

                <Grid size={{ xs: 12, md: 4 }}>
                    <Card
                        sx={{
                            mt: 3,
                            background: `linear-gradient(135deg, ${theme.palette.background.paper} 0%, ${theme.palette.action.hover} 100%)`,
                            border: `1px solid ${theme.palette.divider}`,
                        }}
                    >
                        <CardContent sx={{ p: 3 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                Quick Actions
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Manage doctors, view session reports, or generate analytics.
                            </Typography>
                        </CardContent>
                    </Card>
                </Grid>
            </Grid>
        </Box >
    );
}