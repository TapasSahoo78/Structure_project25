"use client";

import {
    Box,
    Typography,
    Breadcrumbs,
    Link as MuiLink,
    useTheme,
    Grid,
} from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import Link from "next/link";

export interface BreadcrumbItem {
    label: string;
    href: string;
    icon?: React.ReactNode;
}

interface PageHeaderProps {
    title: string;
    subtitle?: string;
    breadcrumbs: BreadcrumbItem[];
}

export default function PageHeader({
    title,
    subtitle,
    breadcrumbs,
}: PageHeaderProps) {
    const theme = useTheme();

    return (
        <Box sx={{ mb: 4, position: "relative" }}>
            <Grid container alignItems="flex-end" justifyContent="space-between">
                {/* LEFT: Title + Subtitle */}
                <Grid size={{ xs: 12, md: 6 }}>
                    <Typography
                        variant="h4"
                        fontWeight="bold"
                        gutterBottom
                        sx={{
                            background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            backgroundClip: "text",
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                            mb: 0.5,
                        }}
                    >
                        {title}
                    </Typography>
                    {subtitle && (
                        <Typography variant="body1" color="text.secondary">
                            {subtitle}
                        </Typography>
                    )}
                </Grid>

                {/* RIGHT: Breadcrumb */}
                <Grid size={{ xs: 12, md: 6 }} sx={{
                    display: "flex",
                    justifyContent: { xs: "flex-start", md: "flex-end" },
                    mt: { xs: 2, md: 0 },
                }}>
                    <Breadcrumbs
                        separator={<NavigateNextIcon fontSize="small" />}
                        aria-label="breadcrumb"
                    >
                        {/* Dashboard */}
                        <MuiLink
                            component={Link}
                            href="/admin"
                            underline="hover"
                            color="inherit"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                fontSize: "0.875rem",
                                "&:hover": { color: "primary.main" },
                            }}
                        >
                            <HomeIcon sx={{ mr: 0.5, fontSize: 18 }} />
                            Dashboard
                        </MuiLink>

                        {/* Dynamic Breadcrumbs */}
                        {breadcrumbs.map((item, idx) => {
                            const isLast = idx === breadcrumbs.length - 1;

                            return isLast ? (
                                <Typography
                                    key={item.href}
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "0.875rem",
                                        color: "text.primary",
                                        fontWeight: 500,
                                    }}
                                >
                                    {item.icon}
                                    {item.label}
                                </Typography>
                            ) : (
                                <MuiLink
                                    key={item.href}
                                    component={Link}
                                    href={item.href}
                                    underline="hover"
                                    color="inherit"
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "0.875rem",
                                        "&:hover": { color: "primary.main" },
                                    }}
                                >
                                    {item.icon}
                                    {item.label}
                                </MuiLink>
                            );
                        })}
                    </Breadcrumbs>
                </Grid>
            </Grid>

            {/* MODERN BOTTOM LINE */}
            <Box
                sx={{
                    mt: 3,
                    height: 4,
                    background: `linear-gradient(90deg, 
            transparent 0%, 
            ${theme.palette.primary.main} 30%, 
            ${theme.palette.secondary.main} 70%, 
            transparent 100%)`,
                    borderRadius: 2,
                    position: "relative",
                    overflow: "hidden",
                    "&::before": {
                        content: '""',
                        position: "absolute",
                        top: 0,
                        left: "-100%",
                        width: "100%",
                        height: "100%",
                        background: `linear-gradient(90deg, 
              transparent, 
              ${theme.palette.primary.main}40, 
              ${theme.palette.secondary.main}40, 
              transparent)`,
                        animation: "shimmer 2.5s infinite",
                    },
                    "@keyframes shimmer": {
                        "0%": { left: "-100%" },
                        "100%": { left: "100%" },
                    },
                }}
            />
        </Box >
    );
}