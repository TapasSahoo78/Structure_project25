import { combineReducers } from "@reduxjs/toolkit";
import authSlice from "./slices/authSlice";
import userSlice from "./slices/userSlice";

export default combineReducers({
  auth: authSlice,
  users: userSlice,
});
