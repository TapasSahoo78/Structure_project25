// src/redux/sagas/authSaga.ts
import { call, put, takeLatest } from "redux-saga/effects";
import apiService from "@/services/apiService";
import {
  loginRequest,
  loginSuccess,
  loginFailure,
  getProfileRequest,
  getProfileSuccess,
  getProfileFailure,
  logoutRequest,
  logoutSuccess,
  logoutFailure,
} from "../slices/authSlice";
import { LoginCredentials } from "@/types";
import { LoginResponse, ProfileResponse } from "@/types/api";
import type { SagaIterator } from "redux-saga";

// Helper: Extract response data type
type ApiCall<T> = () => Promise<{ data: T }>;

function* loginSaga(action: ReturnType<typeof loginRequest>): SagaIterator {
  try {
    const { email, password } = action.payload;

    // Explicitly type the API call
    const callLogin = (): Promise<{ data: LoginResponse }> =>
      apiService.post("/auth/login", { email, password });

    const response = yield call(callLogin);
    const { token, ...user } = response.data;

    yield put(loginSuccess({ user, token }));
  } catch (error: any) {
    const message = error.response?.data?.message || "Invalid credentials";
    yield put(loginFailure(message));
  }
}

function* getProfileSaga(): SagaIterator {
  try {
    const callProfile = (): Promise<{ data: ProfileResponse }> =>
      apiService.get("/auth/profile");

    const response = yield call(callProfile);
    yield put(getProfileSuccess(response.data));
  } catch (error: any) {
    const message = error.response?.data?.message || "Session expired";
    yield put(getProfileFailure(message));
  }
}

function* logoutSaga(): SagaIterator {
  try {
    yield call(apiService.post, "/auth/logout");
    yield put(logoutSuccess());
  } catch (error: any) {
    const message = error.response?.data?.message || "Logout failed";
    yield put(logoutFailure(message));
  }
}

// === Watchers ===
const watchFunction = [
  (function* () {
    yield takeLatest(loginRequest.type, loginSaga);
  })(),
  (function* () {
    yield takeLatest(getProfileRequest.type, getProfileSaga);
  })(),
  (function* () {
    yield takeLatest(logoutRequest.type, logoutSaga);
  })(),
];

export default watchFunction;
