// src/redux/sagas/userSaga.ts
import { call, put, takeLatest } from "redux-saga/effects";
import apiService from "@/services/apiService";
import {
  fetchUsersRequest,
  fetchUsersSuccess,
  fetchUsersFailure,
  createUserRequest,
  createUserSuccess,
  createUserFailure,
  updateUserRequest,
  updateUserSuccess,
  updateUserFailure,
  deleteUserRequest,
  deleteUserSuccess,
  deleteUserFailure,
} from "../slices/userSlice";
import { UserResponse, UserListResponse } from "@/types/api";
import type { SagaIterator } from "redux-saga";

// Helper: Extract response data type
type ApiCall<T> = () => Promise<{ data: T }>;

/* ========================================
   FETCH USERS
======================================== */
function* fetchUsersSaga(): SagaIterator {
  try {
    const callFetchUsers = (): Promise<{ data: UserListResponse }> =>
      apiService.get("/users");

    const response = yield call(callFetchUsers);
    yield put(fetchUsersSuccess(response.data.users));
  } catch (error: any) {
    const message = error.response?.data?.message || "Failed to fetch users";
    yield put(fetchUsersFailure(message));
  }
}

/* ========================================
   CREATE USER
======================================== */
function* createUserSaga(
  action: ReturnType<typeof createUserRequest>
): SagaIterator {
  try {
    const userData = action.payload;

    const callCreateUser = (): Promise<{ data: UserResponse }> =>
      apiService.post("/users", userData);

    const response = yield call(callCreateUser);
    yield put(createUserSuccess(response.data));
  } catch (error: any) {
    const message = error.response?.data?.message || "Failed to create user";
    yield put(createUserFailure(message));
  }
}

/* ========================================
   UPDATE USER
======================================== */
function* updateUserSaga(
  action: ReturnType<typeof updateUserRequest>
): SagaIterator {
  try {
    const { id, ...updateData } = action.payload;

    const callUpdateUser = (): Promise<{ data: UserResponse }> =>
      apiService.put(`/users/${id}`, updateData);

    const response = yield call(callUpdateUser);
    yield put(updateUserSuccess(response.data));
  } catch (error: any) {
    const message = error.response?.data?.message || "Failed to update user";
    yield put(updateUserFailure(message));
  }
}

/* ========================================
   DELETE USER
======================================== */
function* deleteUserSaga(
  action: ReturnType<typeof deleteUserRequest>
): SagaIterator {
  try {
    const userId = action.payload;

    const callDeleteUser = (): Promise<{ data: any }> =>
      apiService.delete(`/users/${userId}`);

    yield call(callDeleteUser);
    yield put(deleteUserSuccess(userId));
  } catch (error: any) {
    const message = error.response?.data?.message || "Failed to delete user";
    yield put(deleteUserFailure(message));
  }
}

/* ========================================
   WATCHERS
======================================== */
const watchFunction = [
  (function* () {
    yield takeLatest(fetchUsersRequest.type, fetchUsersSaga);
  })(),
  (function* () {
    yield takeLatest(createUserRequest.type, createUserSaga);
  })(),
  (function* () {
    yield takeLatest(updateUserRequest.type, updateUserSaga);
  })(),
  (function* () {
    yield takeLatest(deleteUserRequest.type, deleteUserSaga);
  })(),
];

export default watchFunction;
