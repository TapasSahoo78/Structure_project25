// src/redux/slices/authSlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { AuthUser, LoginCredentials } from "@/types";

// === Initial State ===
interface AuthState {
  isAuthenticated: boolean;
  user: AuthUser | null;
  token: string | null;
  loading: boolean;
  error: string | null;
  action_status: string | null;
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  token: typeof window !== "undefined" ? localStorage.getItem("token") : null,
  loading: false,
  error: null,
  action_status: null,
};

// === Slice ===
const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    // ── Login ───────────────────────────────────────
    loginRequest(state, _action: PayloadAction<LoginCredentials>) {
      state.action_status = loginRequest.type;
      state.loading = true;
      state.error = null;
    },
    loginSuccess(
      state,
      action: PayloadAction<{ user: AuthUser; token: string }>
    ) {
      state.action_status = loginSuccess.type;
      state.loading = false;
      state.isAuthenticated = true;
      state.user = action.payload.user;
      state.token = action.payload.token;
      localStorage.setItem("token", action.payload.token);
    },
    loginFailure(state, action: PayloadAction<string>) {
      state.action_status = loginFailure.type;
      state.loading = false;
      state.error = action.payload;
    },

    // ── Profile (auto‑load on app start) ─────────────
    getProfileRequest(state) {
      state.action_status = getProfileRequest.type;
      state.loading = true;
      state.error = null;
    },
    getProfileSuccess(state, action: PayloadAction<AuthUser>) {
      state.action_status = getProfileSuccess.type;
      state.loading = false;
      state.isAuthenticated = true;
      state.user = action.payload;
    },
    getProfileFailure(state, action: PayloadAction<string>) {
      state.action_status = getProfileFailure.type;
      state.loading = false;
      state.error = action.payload;
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      localStorage.removeItem("token");
    },

    // ── Logout ───────────────────────────────────────
    logoutRequest(state) {
      state.action_status = logoutRequest.type;
      state.loading = true;
      state.error = null;
    },
    logoutSuccess(state) {
      state.action_status = logoutSuccess.type;
      state.loading = false;
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      localStorage.removeItem("token");
    },
    logoutFailure(state, action: PayloadAction<string>) {
      state.action_status = logoutFailure.type;
      state.loading = false;
      state.error = action.payload;
    },

    // ── Helper ───────────────────────────────────────
    clearAuthError(state) {
      state.error = null;
      state.action_status = null;
    },
  },
});

// === Actions ===
export const {
  loginRequest,
  loginSuccess,
  loginFailure,
  getProfileRequest,
  getProfileSuccess,
  getProfileFailure,
  logoutRequest,
  logoutSuccess,
  logoutFailure,
  clearAuthError,
} = authSlice.actions;

// === Reducer ===
export default authSlice.reducer;
