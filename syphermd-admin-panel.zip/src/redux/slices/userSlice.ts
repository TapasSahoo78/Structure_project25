import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { User } from "@/types";

// === Initial State ===
interface UsersState {
  users: User[];
  loading: boolean;
  error: string | null;
  action_status: string | null;
  total: number;
}

const initialState: UsersState = {
  users: [],
  loading: false,
  error: null,
  action_status: null,
  total: 0,
};

// === Slice ===
const userSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    // === Fetch Users ===
    fetchUsersRequest(state, action: PayloadAction<any>) {
      state.action_status = action.type;
      state.loading = true;
      state.error = null;
    },
    fetchUsersSuccess(state, action: PayloadAction<User[]>) {
      state.action_status = action.type;
      state.loading = false;
      state.users = action.payload;
      state.total = action.payload.length;
    },
    fetchUsersFailure(state, action: PayloadAction<string>) {
      state.action_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    // === Create User ===
    createUserRequest(state, action: PayloadAction<Partial<User>>) {
      state.action_status = action.type;
      state.loading = true;
      state.error = null;
    },
    createUserSuccess(state, action: PayloadAction<User>) {
      state.action_status = action.type;
      state.loading = false;
      state.users.push(action.payload);
      state.total += 1;
    },
    createUserFailure(state, action: PayloadAction<string>) {
      state.action_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    // === Update User ===
    updateUserRequest(
      state,
      action: PayloadAction<Partial<User> & { id: number }>
    ) {
      state.action_status = action.type;
      state.loading = true;
      state.error = null;
    },
    updateUserSuccess(state, action: PayloadAction<User>) {
      state.action_status = action.type;
      state.loading = false;
      const index = state.users.findIndex((u) => u.id === action.payload.id);
      if (index !== -1) {
        state.users[index] = action.payload;
      }
    },
    updateUserFailure(state, action: PayloadAction<string>) {
      state.action_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    // === Delete User ===
    deleteUserRequest(state, action: PayloadAction<number>) {
      state.action_status = action.type;
      state.loading = true;
      state.error = null;
    },
    deleteUserSuccess(state, action: PayloadAction<number>) {
      state.action_status = action.type;
      state.loading = false;
      state.users = state.users.filter((u) => u.id !== action.payload);
      state.total -= 1;
    },
    deleteUserFailure(state, action: PayloadAction<string>) {
      state.action_status = action.type;
      state.loading = false;
      state.error = action.payload;
    },

    // === Clear Error ===
    clearUserError(state) {
      state.error = null;
      state.action_status = null;
    },
  },
});

// === Actions ===
export const {
  fetchUsersRequest,
  fetchUsersSuccess,
  fetchUsersFailure,
  createUserRequest,
  createUserSuccess,
  createUserFailure,
  updateUserRequest,
  updateUserSuccess,
  updateUserFailure,
  deleteUserRequest,
  deleteUserSuccess,
  deleteUserFailure,
  clearUserError,
} = userSlice.actions;

// === Reducer ===
export default userSlice.reducer;
