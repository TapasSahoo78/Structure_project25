export interface LoginResponse {
  token: string;
  id: number;
  name: string;
  email: string;
  role: string;
}

export interface ProfileResponse {
  id: number;
  name: string;
  email: string;
  role: string;
}

/* ─────── USER API ─────── */
export interface UserResponse {
  id: number;
  name: string;
  email: string;
  role?: string;
  status?: "active" | "inactive";
  createdAt?: string;
}

export interface UserListResponse {
  users: UserResponse[];
  total: number;
}

export interface ApiError {
  message: string;
}
