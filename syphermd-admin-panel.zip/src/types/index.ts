// === User Types ===
export interface User {
  id: number;
  name: string;
  email: string;
  role?: string;
  status?: "active" | "inactive";
  createdAt?: string;
}

// === Auth Types ===
export interface AuthUser {
  id: number;
  name: string;
  email: string;
  token: string;
  role: string;
}
// === Login Types ===
export interface LoginCredentials {
  email: string;
  password: string;
}
// === Register Types ===
export interface RegisterData {
  name: string;
  email: string;
  password: string;
}
