// src/interfaces/Role.ts
import { ObjectId, Types } from "mongoose";
import { ICreated } from "./general.interface"; // Assuming this is where ICreated is defined

export interface IFaqSchema extends ICreated {
    _id: ObjectId;
    faqCategoryId: ObjectId;
    categoryName: string;
    question: string;
    answer: string;
    is_active: boolean;
    is_user: boolean;
}

export interface IFaq extends IFaqSchema { }
