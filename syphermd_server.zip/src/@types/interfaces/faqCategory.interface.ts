import { ObjectId, Types } from "mongoose";
import { ICreated } from "./general.interface";

export interface IfaqCategoryShema extends ICreated {
    _id: Types.ObjectId;
    name: string;
    description: string;
}

export interface ICategory extends IfaqCategoryShema { }
