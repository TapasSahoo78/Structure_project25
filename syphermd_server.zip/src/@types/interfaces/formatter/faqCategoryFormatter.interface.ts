import { ObjectId, SchemaDefinitionProperty } from "mongoose";
export interface IFaqCategoryResponse {
        _id: string | ObjectId;
        name: string;
        description: string | null;
}