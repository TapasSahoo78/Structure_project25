import { ObjectId, SchemaDefinitionProperty } from "mongoose";
export interface IMenuResponse {
        _id: string | ObjectId;
        parentIdId: ObjectId;
        name: string;
        menu_order: string,
        link_type: string;
        pageId: ObjectId;
        menu_group: string;
        menu_link: string,
        is_active: boolean;
}