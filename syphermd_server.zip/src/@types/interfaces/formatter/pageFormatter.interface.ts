import { ObjectId, SchemaDefinitionProperty } from "mongoose";
import { IBlock } from "../formatter/blockFormatter.interface";
export interface IPageResponse {
        _id: string | ObjectId;
        title: string;
        blocks: IBlock[];
        meta_title: string;
        meta_description: string;
        meta_keywords: string;
}