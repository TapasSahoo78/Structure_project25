// src/interfaces/Role.ts
import { ICreated } from "./general.interface"; // Assuming this is where ICreated is defined
import { Permission } from '../types/permission/permission.types'; // Importing the Permission enum
import { IObjectId } from "./objectId.interface";

export interface IRoleSchema extends ICreated {
    name: string; // The name of the role
    permissions: Permission[]; // Array of permissions associated with the role
}

export interface IRole extends IRoleSchema, IObjectId { }
