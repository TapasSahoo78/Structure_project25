import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface ISettingSchema extends ICreated {
	name: string | null,
	slug: string | null,
	value: string | null,
	description: string | null,
}

export interface ISetting extends ISettingSchema, IObjectId { }
