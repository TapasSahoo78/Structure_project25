import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../../constants/message";
import service from "../../../../../services";
import { convertCaseInsensitiveForQuery } from "../../../../../services/auth/auth.service";
import { addMemberActivityLog } from "../../../../../services/activityLog/employeeLog.service";
import {
	employeeActivity,
	employeeActivityLogDescription,
	employeeActivityLogStatus
} from "../../../../../constants/activityLog/activityLog";
import userModel from "../../../../../model/user.model";
import { formatUserResponse } from "../../../../../utils/formatter/userResponseFormatter";
import roleModel from "../../../../../model/role.model";

export const login = async (req: Request, res: Response): Promise<any> => {
	try {
		const { user_id, roleName, password, devices_token } = req.body;

		// Input validation
		if (!user_id || !password) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("User ID and password are required")
			});
		}

		// Build query based on user_id type
		const isEmail = user_id.includes("@");
		const query = isEmail ? { email: convertCaseInsensitiveForQuery(user_id) } : { user_name: user_id };

		// Find role and user in parallel
		const [role, user] = await Promise.all([
			roleModel.findOne({ name: roleName ?? "Customer" }),
			userModel.findOne(query)
		]);

		// Find user with correct role
		const qualifiedUser = role
			? await userModel.findOne({
					$and: [query, { roleId: role._id }]
				})
			: user;

		if (!qualifiedUser) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed!")
			});
		}

		// Check if password exists
		if (!qualifiedUser.password) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed! Password is missing.")
			});
		}

		// Verify password
		const isPasswordValid = await service.auth.comparePassword(password, qualifiedUser.password);

		if (!isPasswordValid) {
			await logMemberActivity({
				roleId: qualifiedUser.roleId,
				email: qualifiedUser.email,
				first_name: qualifiedUser.first_name,
				last_name: qualifiedUser.last_name,
				user_name: qualifiedUser.user_name,
				activity: employeeActivity.login,
				status: employeeActivityLogStatus.fail,
				description: employeeActivityLogDescription.password_incorrect,
				activity_initiated_by: user_id
			});

			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed!")
			});
		}

		// Prepare user updates
		const userUpdates = {
			last_login_date: Date.now(),
			devices_token: devices_token || null
		};

		// JWT payload and token generation
		const jwtPayload = {
			email: qualifiedUser.email,
			roleId: qualifiedUser.roleId,
			first_name: qualifiedUser.first_name,
			last_name: qualifiedUser.last_name,
			user_name: qualifiedUser.user_name
		};

		const [token, updatedUser] = await Promise.all([
			service.auth.generateJWT(jwtPayload),
			userModel.findByIdAndUpdate(qualifiedUser._id, userUpdates, { new: true })
		]);

		if (!updatedUser) {
			await logMemberActivity({
				roleId: qualifiedUser.roleId,
				email: qualifiedUser.email,
				first_name: qualifiedUser.first_name,
				last_name: qualifiedUser.last_name,
				user_name: qualifiedUser.user_name,
				activity: employeeActivity.login,
				status: employeeActivityLogStatus.fail,
				description: employeeActivityLogDescription.login_unsuccessful,
				activity_initiated_by: user_id
			});

			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.none
			});
		}

		// Log successful login
		await logMemberActivity({
			roleId: qualifiedUser.roleId,
			email: qualifiedUser.email,
			first_name: qualifiedUser.first_name,
			last_name: qualifiedUser.last_name,
			user_name: qualifiedUser.user_name,
			activity: employeeActivity.login,
			status: employeeActivityLogStatus.pass,
			description: employeeActivityLogDescription.login_successful,
			activity_initiated_by: user_id
		});

		const userResponse = await formatUserResponse(updatedUser);

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.post.succAuth,
			result: {
				userResponse,
				token
			}
		});
	} catch (error) {
		console.error("Login error:", error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error: process.env.NODE_ENV === "development" ? error : {}
		});
	}
};

// Helper function to reduce code duplication
const logMemberActivity = async (payload: any) => {
	await addMemberActivityLog(payload);
};

export const customerLogin = async (req: Request, res: Response): Promise<any> => {
	try {
		const { user_id, password, devices_token } = req.body; // Expecting roleId from the request body

		// Checking if user_id is email or user_name
		const query = user_id.includes("@")
			? { email: convertCaseInsensitiveForQuery(user_id) }
			: { user_name: user_id };
		let role = await roleModel.findOne({
			name: "Customer"
		});
		if (!role) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Role not Exist")
			});
		}
		// Find the user with the provided roleId
		let user = await userModel.findOne({
			$and: [query, { roleId: role._id }] // Querying by roleId
		});
		console.log(user);

		if (!user) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed!")
			});
		}

		if (user.password === null) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed! Password is missing.")
			});
		}

		// Comparing given Password with Actual Password
		const passwordCompare: boolean = await service.auth.comparePassword(password, user.password);

		if (!passwordCompare) {
			// Member Password Incorrect Log
			const memberLoginActivityPayload = {
				roleId: user.roleId,
				email: user.email,
				first_name: user.first_name,
				last_name: user.last_name,
				user_name: user.user_name,
				activity: employeeActivity.login,
				status: employeeActivityLogStatus.fail,
				description: employeeActivityLogDescription.password_incorrect
			};
			await addMemberActivityLog(memberLoginActivityPayload);

			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Authentication Failed!")
			});
		}

		// Updating Last login date with current system date
		user.last_login_date = Date.now();
		user.devices_token = devices_token ?? null;

		// Creating JWT payload for login
		let jwtPayload = {
			email: user.email,
			roleId: user.roleId,
			first_name: user.first_name,
			last_name: user.last_name,
			user_name: user.user_name
		};

		// Generating JWT
		const token: string = await service.auth.generateJWT(jwtPayload);

		// Updating the database
		const loginInstance = await userModel.findByIdAndUpdate(user._id, user);

		if (!loginInstance) {
			// Member Unsuccessful Login Log
			const memberLoginActivityPayload = {
				roleId: user.roleId,
				email: user.email,
				first_name: user.first_name,
				last_name: user.last_name,
				user_name: user.user_name,
				activity: employeeActivity.login,
				status: employeeActivityLogStatus.fail,
				description: employeeActivityLogDescription.login_unsuccessful,
				activity_initiated_by: user_id
			};
			await addMemberActivityLog(memberLoginActivityPayload);

			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.none
			});
		}

		// Member Successful Login Log
		const memberLoginActivityPayload = {
			roleId: user.roleId,
			email: user.email,
			first_name: user.first_name,
			last_name: user.last_name,
			user_name: user.user_name,
			activity: employeeActivity.login,
			status: employeeActivityLogStatus.pass,
			description: employeeActivityLogDescription.login_successful,
			activity_initiated_by: user_id
		};
		await addMemberActivityLog(memberLoginActivityPayload);
		const userResponse = await formatUserResponse(loginInstance);
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.post.succAuth,
			result: {
				userResponse,
				token
			}
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};

export const getProfile = async (req: Request, res: Response): Promise<any> => {
	try {
		const userDetails = await userModel.findOne({
			email: req.user.email
		});

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			result: {
				userDetails
			}
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Login Unsuccessful!"),
			error
		});
	}
};
