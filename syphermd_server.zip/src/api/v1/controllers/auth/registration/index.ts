import { userRegistration } from "../registration/userRegistration/userRegistration.controller";

const registration = {
	userRegistration,
};
export default registration;
