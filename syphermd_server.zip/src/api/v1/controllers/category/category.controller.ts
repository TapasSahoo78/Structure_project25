// controllers/category.controller.ts
import { Request, Response } from "express";
import { MESSAGE } from "../../../../constants/message";
import categoryModel from "../../../../model/category.model";
import { StatusCodes } from "http-status-codes";
import { ICategory } from "../../../../@types/interfaces/category.interface";
import { formatCategoryResponse } from "../../../../utils/formatter/categoryResponseFormatter";
import { formatCategoriesResponse } from "../../../../utils/formatter/categoryResponseFormatter";

// Add a new category
export const addCategory = async (req: Request, res: Response): Promise<any> => {
	try {
		const category: ICategory = req.body;
		const newCategory = new categoryModel(category);
		await newCategory.save();
		res.status(StatusCodes.CREATED).json({
			message: "Category created successfully",
			category: newCategory
		});
	} catch (error: unknown) {
		// Type guard to check if error is an instance of Error
		if (error instanceof Error) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Invalid Token!"),
				error: error.message // Provide only the error message for security
			});
		}

		// Fallback for unexpected error types
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("An unexpected error occurred")
		});
	}
};

// Edit an existing category
export const editCategory = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	try {
		const updatedCategory = await categoryModel.findByIdAndUpdate(id, req.body, { new: true });
		if (!updatedCategory) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Category not found"
			});
		}
		res.status(StatusCodes.OK).json({
			message: "Category updated successfully",
			category: updatedCategory
		});
	} catch (error: unknown) {
		// Type guard to check if error is an instance of Error
		if (error instanceof Error) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Invalid Token!"),
				error: error.message // Provide only the error message for security
			});
		}

		// Fallback for unexpected error types
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("An unexpected error occurred")
		});
	}
};

// Delete a category
export const deleteCategory = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	try {
		const deletedCategory = await categoryModel.findByIdAndDelete(id);
		if (!deletedCategory) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Category not found"
			});
		}
		res.status(StatusCodes.OK).json({
			message: "Category deleted successfully"
		});
	} catch (error: unknown) {
		// Type guard to check if error is an instance of Error
		if (error instanceof Error) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Invalid Token!"),
				error: error.message // Provide only the error message for security
			});
		}

		// Fallback for unexpected error types
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("An unexpected error occurred")
		});
	}
};

// Get a category by ID
export const getCategory = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	try {
		const category = await categoryModel.findById(id);
		if (!category) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Category not found"
			});
		}
		const categoryResponse = await formatCategoryResponse(category);
		res.status(StatusCodes.OK).json(categoryResponse);
	} catch (error: unknown) {
		// Type guard to check if error is an instance of Error
		if (error instanceof Error) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Invalid Token!"),
				error: error.message // Provide only the error message for security
			});
		}

		// Fallback for unexpected error types
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("An unexpected error occurred")
		});
	}
};

// Get all categories
export const getAllCategories = async (req: Request, res: Response): Promise<any> => {
	try {
		const categories = await categoryModel.find();
		const categoryResponse = await formatCategoriesResponse(categories);
		res.status(StatusCodes.OK).json(categoryResponse);
	} catch (error: unknown) {
		// Type guard to check if error is an instance of Error
		if (error instanceof Error) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Invalid Token!"),
				error: error.message // Provide only the error message for security
			});
		}

		// Fallback for unexpected error types
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("An unexpected error occurred")
		});
	}
};
