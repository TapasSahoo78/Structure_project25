// controllers/faq.controller.ts
import { Request, Response } from "express";
import { MESSAGE } from "../../../../constants/message";
import faqModel from "../../../../model/faq.model";
import { StatusCodes } from "http-status-codes";
import { IFaq } from "../../../../@types/interfaces/faq.interface";
import { formatFaqResponse, formatFaqsResponse } from "../../../../utils/formatter/faqResponseFormatter";

// Add a new block
export const addBlock = async (req: Request, res: Response): Promise<any> => {
    try {
        const faq: IFaq = req.body;
        const newFaq = new faqModel(faq);
        await newFaq.save();
        res.status(StatusCodes.CREATED).json({
            message: "Faq created successfully",
            block: newFaq,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing block
export const editBlock = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const updatedFaq = await faqModel.findByIdAndUpdate(id, req.body, { new: true });
        if (!updatedFaq) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Faq not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Faq updated successfully",
            block: updatedFaq,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a block
export const deleteBlock = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const deletedFaq = await faqModel.findByIdAndDelete(id);
        if (!deletedFaq) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Faq not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Faq deleted successfully",
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a block by ID
export const getBlock = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const faq = await faqModel.findById(id);
        if (!faq) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Faq not found",
            });
        }
        const faqResponse = await formatFaqResponse(faq)
        res.status(StatusCodes.OK).json(faqResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all categories
export const getAllBlocks = async (req: Request, res: Response): Promise<any> => {
    try {
        const faqs = await faqModel.find();
        const faqResponse = await formatFaqsResponse(faqs)
        res.status(StatusCodes.OK).json(faqResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};
