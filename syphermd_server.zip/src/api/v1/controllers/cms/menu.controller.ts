// controllers/menu.controller.ts
import { Request, Response } from "express";
import { MESSAGE } from "../../../../constants/message";
import menuModel from "../../../../model/menu.model";
import { StatusCodes } from "http-status-codes";
import { IMenu } from "../../../../@types/interfaces/menu.interface";
import { formatMenuResponse, formatMenusResponse } from "../../../../utils/formatter/menuResponseFormatter";

// Add a new category
export const addMenu = async (req: Request, res: Response): Promise<any> => {
    try {
        const menu: IMenu = req.body;
        const newMenu = new menuModel(menu);
        await newMenu.save();
        res.status(StatusCodes.CREATED).json({
            message: "Menu created successfully",
            category: newMenu,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing category
export const editMenu = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const updatedMenu = await menuModel.findByIdAndUpdate(id, req.body, { new: true });
        if (!updatedMenu) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Menu not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Menu updated successfully",
            category: updatedMenu,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a category
export const deleteMenu = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const deletedMenu = await menuModel.findByIdAndDelete(id);
        if (!deletedMenu) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Menu not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Menu deleted successfully",
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a category by ID
export const getMenu = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const menu = await menuModel.findById(id);
        if (!menu) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Menu not found",
            });
        }
        const menuResponse = await formatMenuResponse(menu)
        res.status(StatusCodes.OK).json(menuResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all categories
export const getAllMenus = async (req: Request, res: Response): Promise<any> => {
    try {
        const menus = await menuModel.find();
        const menuResponse = await formatMenusResponse(menus)
        res.status(StatusCodes.OK).json(menuResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};
