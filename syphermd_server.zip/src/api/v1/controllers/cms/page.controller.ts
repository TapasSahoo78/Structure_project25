// controllers/page.controller.ts
import { Request, Response } from "express";
import { MESSAGE } from "../../../../constants/message";
import pageModel from "../../../../model/page.model";
import { StatusCodes } from "http-status-codes";
import { IPage } from "../../../../@types/interfaces/page.interface";
import {
    formatPageResponse,
    formatPagesResponse
} from "../../../../utils/formatter/pageResponseFormatter";

// Add a new page
export const addPage = async (req: Request, res: Response): Promise<any> => {
    try {
        const page: IPage = req.body;
        const newPage = new pageModel(page);
        await newPage.save();
        res.status(StatusCodes.CREATED).json({
            message: "Page created successfully",
            page: newPage,
        });
    } catch (error: unknown) {
        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Edit an existing page
export const editPage = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        let updatedPage;
        if (req.params.block_id) {
            if (Array.isArray(req.body.blocks) && req.params.block_id) {
                const updateFields = Object.fromEntries(
                    Object.entries(req.body.blocks[0]).map(([key, value]) => ([`blocks.$.${key}`, value]))
                );

                updatedPage = await pageModel.findOneAndUpdate(
                    { _id: id, "blocks._id": req.params.block_id },
                    {
                        $set: updateFields
                    },
                    { new: true }
                );
                console.log(updatedPage);
            }
        } else if (!req.params.block_id && id && Array.isArray(req.body.blocks)) {
            const newBlocks = req.body.blocks.map((block: any) => ({
                sectionType: block.sectionType,
                title: block.title,
                subtitle: block.subtitle,
                content: block.content,
                order_number: block.order_number
            }));
            updatedPage = await pageModel.findOneAndUpdate(
                { _id: id },
                {
                    $push: { blocks: { $each: newBlocks } }
                },
                { new: true }
            );
        }
        else {
            updatedPage = await pageModel.findByIdAndUpdate(id, req.body, { new: true });
        }

        if (!updatedPage) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Page not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Updated successfully",
            page: updatedPage,
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Delete a page
export const deletePage = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        let deletedPage;
        if (req.params.block_id) {
            deletedPage = await pageModel.findByIdAndUpdate(id, { $pull: { blocks: req.params.block_id } });
        } else {
            deletedPage = await pageModel.findByIdAndDelete(id);
        }

        if (!deletedPage) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Page not found",
            });
        }
        res.status(StatusCodes.OK).json({
            message: "Page deleted successfully",
        });
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get a page by ID
export const getPage = async (req: Request, res: Response): Promise<any> => {
    const { id } = req.params;
    try {
        const page = await pageModel.findById(id);
        if (!page) {
            return res.status(StatusCodes.NOT_FOUND).json({
                message: "Page not found",
            });
        }
        const pageResponse = await formatPageResponse(page, req?.params?.block_id)
        res.status(StatusCodes.OK).json(pageResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

// Get all pages
export const getAllPages = async (req: Request, res: Response): Promise<any> => {
    try {
        const pages = await pageModel.find();
        const pageResponse = await formatPagesResponse(pages)
        res.status(StatusCodes.OK).json(pageResponse);
    } catch (error: unknown) {

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};