import { Request, Response } from "express";
import { Model } from "mongoose";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import service from "../../../../services";
import slugify from "slugify";
import { log } from "node:console";
// import settingModel from "../../../../model/setting.model";

export const updateSetting = async (req: Request, res: Response): Promise<any> => {
	const { name, value, description } = req.body;
	try {
		// Generate the slug from the name
		let slug = slugify(name);

		// Check if a setting with the same slug already exists
		// let existingSetting = await settingModel.findOne({ slug });

		// if (existingSetting) {
		// 	existingSetting.value = value;
		// 	existingSetting.description = description;
		// 	await existingSetting.save(); // Save the updated setting
		// } else {
		// 	// Create a new setting or use the updated slug
		// 	existingSetting = await settingModel.create({
		// 		name,
		// 		slug,
		// 		value,
		// 		description
		// 	});
		// }
		return res.status(200).json({
			message: "Setting created successfully!",
			// data: existingSetting
		});

	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Dog updated unsuccessful!"),
			error
		});
	}

}

export const listSetting = async (req: Request, res: Response): Promise<any> => {
	try {
		// const setting = await settingModel.find();
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Setting fetch successfully!"),
			// setting
		});
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Setting fetch unsuccessful!"),
			error
		});
	}
};

export const editSetting = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	try {
		// const setting = await settingModel.findById(id);
		// if (!setting) {
		// 	return res.status(StatusCodes.NOT_FOUND).json({
		// 		message: MESSAGE.custom("Setting not found!"),
		// 	});
		// }
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.custom("Setting updated successfully!"),
			// data: setting
		});
	} catch (error) {
		console.log(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Setting updated unsuccessful!"),
			error
		});
	}
}