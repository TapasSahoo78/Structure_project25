// routes/category.routes.ts
import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import {
	addCategory,
	editCategory,
	deleteCategory,
	getCategory,
	getAllCategories
} from "../../controllers/category/category.controller";

const router = express.Router();

// Category Management Routes
router.route("/categories").post(validator(validators.categoryValidator, null), addCategory); // Add a new category
router.route("/categories/:id").put(validator(validators.categoryValidator, null), editCategory); // Edit an existing category
router.route("/categories/:id").delete(deleteCategory); // Delete a category
router.route("/categories/:id").get(getCategory); // Get a category by ID
router.route("/categories").get(getAllCategories); // Get all categories

module.exports = router;
