import express from "express";

const app = express();

app.use(express.json());

// Route definitions
app.use("/", require("./auth/user.routes"));
app.use("/", require("./auth/role.routes"));
app.use("/", require("./category/category.routes"));
app.use("/", require("./tool/tool.routes"));
app.use("/", require("./faq/category.routes"));

app.use("/", require("./cms/cms.routes"));

module.exports = app;
