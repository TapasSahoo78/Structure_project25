import express from "express";
import { addTool, getAllTools, getTool, updateTool, deleteTool } from "../../controllers/tool/tool.controller";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";

const router = express.Router();

router.route("/tools").post(validator(validators.toolValidator, null), addTool);
router.route("/tools/:id").put(validator(validators.toolValidator, null), updateTool);
router.route("/tools/:id").delete(deleteTool);
router.route("/tools/:id").get(getTool);
router.route("/tools").get(getAllTools);

module.exports = router;
