// src/validators/category.validator.ts
import Joi from "joi";

export const faqCategoryValidator = Joi.object({
    _id: Joi.optional(),
    name: Joi.string()
        .trim()
        .max(100)
        .required()
        .messages({
            'string.base': 'Category name must be a string.',
            'string.empty': 'Category name is required.',
            'string.max': 'Category name cannot be more than 100 characters.',
            'any.required': 'Category name is required.'
        }),
    description: Joi.string()
        .max(500)
        .required()
        .messages({
            'string.base': 'Description must be a string.',
            'string.empty': 'Description is required.',
            'string.max': 'Description cannot be more than 500 characters.',
            'any.required': 'Description is required.'
        })
});
