// src/validators/tool.validator.ts
import Joi, { optional } from "joi";

export const toolValidator = Joi.object({
    _id: Joi.optional(),
    categoryId: Joi.string()
        .required()
        .messages({
            'string.base': 'Category ID must be a string.',
            'string.empty': 'Category ID is required.',
            'any.required': 'Category ID is required.'
        }),

    name: Joi.string()
        .trim()
        .required()
        .messages({
            'string.base': 'Tool name must be a string.',
            'string.empty': 'Tool name is required.',
            'any.required': 'Tool name is required.'
        }),

    overview: Joi.string()
        .trim()
        .required()
        .messages({
            'string.base': 'Overview must be a string.',
            'string.empty': 'Overview is required.',
            'any.required': 'Overview is required.'
        }),

    updates: Joi.string()
        .trim()
        .required()
        .messages({
            'string.base': 'Updates must be a string.',
            'string.empty': 'Updates are required.',
            'any.required': 'Updates are required.'
        }),

    pros: Joi.array()
        .items(Joi.string().trim())
        .required()
        .messages({
            'array.base': 'Pros must be an array of strings.',
            'any.required': 'Pros are required.'
        }),

    cons: Joi.array()
        .items(Joi.string().trim())
        .required()
        .messages({
            'array.base': 'Cons must be an array of strings.',
            'any.required': 'Cons are required.'
        }),

    pricing: Joi.alternatives()
        .try(
            Joi.number().required().messages({
                'number.base': 'Pricing must be a number.',
                'any.required': 'Pricing is required.'
            }),
            Joi.string().pattern(/^\d+(\.\d+)?$/).required().messages({
                'string.base': 'Pricing must be a string.',
                'string.pattern.base': 'Pricing must be a valid number format.',
                'any.required': 'Pricing is required.'
            })
        ),
    gallery: Joi.array()
        .items(Joi.string().uri().messages({
            'string.base': 'Gallery item must be a string.',
            'string.empty': 'Gallery item cannot be an empty string.',
            'string.uri': 'Gallery item must be a valid URL.'
        }))
        .optional()
        .messages({
            'array.base': 'Gallery must be an array of strings.',
            'any.required': 'Gallery is required.'
        }),

    faq: Joi.array()
        .items(
            Joi.object({
                question: Joi.string()
                    .required()
                    .messages({
                        'string.base': 'Question must be a string.',
                        'string.empty': 'Question is required.',
                        'any.required': 'Question is required.'
                    }),
                answer: Joi.string()
                    .required()
                    .messages({
                        'string.base': 'Answer must be a string.',
                        'string.empty': 'Answer is required.',
                        'any.required': 'Answer is required.'
                    }),
                _id: Joi.optional(),
                id: Joi.optional()
            })
        )
        .required()
        .messages({
            'array.base': 'FAQ must be an array of objects.',
            'any.required': 'FAQ is required.'
        }),

    category: Joi.optional(),
    categoryDetails: Joi.optional(),
});
