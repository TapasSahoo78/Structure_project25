import Joi from "joi";
import { GENDER } from "../../../../../constants/gender/gender";
import { CONTACT_LABEL } from "../../../../../constants/contactLabel/contactLabel";

export const registrationValidator = Joi.object({
	roleId: Joi.string().required(),
	first_name: Joi.string().min(1).max(30).required(),
	middle_name: Joi.string().allow('').max(30),
	last_name: Joi.string().min(1).max(30).required(),
	user_name: Joi.string().alphanum().min(3).max(30).required(),
	password: Joi.string().min(6).max(100).required(),
	email: Joi.string().email().required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).optional(),
	address_line_1: Joi.string().max(100).optional(),
	address_line_2: Joi.string().allow('').max(100),
	city: Joi.string().max(50).optional(),
	state: Joi.string().max(50).optional(),
	country: Joi.string().max(50).optional(),
	ZIP: Joi.string().length(6).pattern(/^[0-9]+$/).optional(),
	contact_label: Joi.string().valid(CONTACT_LABEL.home, CONTACT_LABEL.business, CONTACT_LABEL.mail, CONTACT_LABEL.mobile, CONTACT_LABEL.other).optional(),
	phone_number: Joi.alternatives().try(
			Joi.string().pattern(/^[0-9]+$/).required(),
			Joi.number().integer().required()
	),
	phone_extension: Joi.alternatives().try(
		Joi.string().allow('').required(),
		Joi.number().allow('').required()
	),
});
export const emailVerificationValidator = Joi.object({
	roleId: Joi.string().allow(''),
	type: Joi.string().valid('email', 'otp', 'password', 'veryemail').required(),
	email: Joi.string().email().when('type', {
		is: 'otp', // When type is 'otp'
		then: Joi.optional(), // Email is optional when type is 'otp'
		otherwise: Joi.required() // Email is required when type is 'email'
	}),
	otp: Joi.string().allow('').when('type', {
		is: 'otp', // When type is 'otp'
		then: Joi.required(), // OTP is required
		otherwise: Joi.forbidden() // OTP should not be present when type is 'email'
	}),
	password: Joi.string().allow('').when('type', {
		is: 'password', // When type is 'password'
		then: Joi.required(), // Password is required
		otherwise: Joi.forbidden() // Password should not be present when type is 'email or otp'
	}),
	confirmPassword: Joi.string().allow('').when('type', {
		is: 'password', // When type is 'password'
		then: Joi.required(), // Confirm Password is required
		otherwise: Joi.forbidden() // Confirm Password should not be present when type is 'email or otp'
	})
});

export const changePasswordValidator = Joi.object({
	email: Joi.string().email().required(),
	old_password: Joi.string().min(6).max(100).required(),
	new_password: Joi.string().min(6).max(100).required(),
	confirm_password: Joi.string().min(6).max(100).required()
});




