import { loginValidator } from "./auth/login/login.validator";
import {
	registrationValidator,
	emailVerificationValidator,
	changePasswordValidator
} from "./auth/registration/registration.validator";
import { userValidator, adminUserValidator, customerValidator } from "./user/user.validator";
import { categoryValidator } from "./Tool/category.validator";
import { faqCategoryValidator } from "./Tool/faqcat.validator";
import { faqValidator } from "./Tool/faqs.validator";
import { toolValidator } from "./Tool/tool.validator";

import { pageValidator } from "./cms/page.validator";
import { menuValidator } from "./cms/menu.validator";

export const validators = {
	loginValidator,
	registrationValidator,
	emailVerificationValidator,
	changePasswordValidator,
	userValidator,
	adminUserValidator,
	customerValidator,
	categoryValidator,
	faqCategoryValidator,
	faqValidator,
	toolValidator,

	pageValidator,
	menuValidator
};
