import { S3Client } from "@aws-sdk/client-s3";

const credential = {
	accessKeyId: "AKIA2A7LWBD7I57MGLLHlkjhgfds",
	secretAccessKey: "eOf+rM/OjTw7t1RmgEYq4gGcItJJAz+i8+M7fmuJuytrd",
};

export const s3Client = new S3Client({ region: "eu-north-1", credentials: credential });
export const s3Url = "https://soumadipagoliuytrew.s3.eu-north-1.amazonawsjhgfd.com"

export const bucketName = "soumadipagolqwe";
