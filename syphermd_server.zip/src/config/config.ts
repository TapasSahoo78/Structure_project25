export const NODE_ENV: "PROD" | "DEV" | "LOCAL" | "LOCAL_ATLAS" = "LOCAL";

export const MONGO_URI = {
	LOCAL: "mongodb://127.0.0.1:27017/syphermd_db",
	LOCAL_ATLAS: "",
	DEV: "mongodb://mgpsuser:MgPS%403245%40gh@3.111.66.206:27017/?authSource=mgpsDB",
	PROD: ""
};

// Local, Devlopment and Production SypherMD_Management Portal URL
export const localSypherMD_ManagementUrl = "http://localhost:3131";
export const testSypherMD_ManagementUrl = "";
export const devSypherMD_ManagementUrl = "";
export const prodSypherMD_ManagementUrl = "";

export const emailLoginUrl =
	String(NODE_ENV) == "PROD"
		? `${prodSypherMD_ManagementUrl}/`
		: String(NODE_ENV) == "DEV"
			? `${devSypherMD_ManagementUrl}/`
			: String(NODE_ENV) == "LOCAL"
				? `${localSypherMD_ManagementUrl}/`
				: ""; //Has to change in Production and Test Production

export const SYPHERMD_AI_LINK = emailLoginUrl;

export const mongoDump = {
	host: String(NODE_ENV) == "PROD" ? "127.0.0.1" : "localhost",
	port: String(NODE_ENV) == "PROD" ? 27017 : 27017,
	database: "syphermd_db",
	outputDir: String(NODE_ENV) == "PROD" ? "" : __dirname + "../../../database_backup"
};

export const STRIPE_SECRET_KEY =
	"sk_test_51NdpkRBuHqQNZg72VM5ngF17FUi5lff7whLJdPy4IlFn6ZoymSeIvnOWVqB5NfaTHat6yHTCpJIPMCYHcp0HmxUm00I84mXZRh";
