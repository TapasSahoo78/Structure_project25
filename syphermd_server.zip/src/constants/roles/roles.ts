export const roles = {
	super_admin: "Super Admin",
	admin: "Admin",
	member: "Customer"
};

export const ROLES = roles;
