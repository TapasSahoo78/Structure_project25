import { Request, Response, NextFunction } from "express";
import { StatusCodes } from "http-status-codes";
import jwt from "jsonwebtoken";
import { MESSAGE } from "../../constants/message";
import { ROLES } from "../../constants/roles/roles"; // Assuming this contains role IDs
import userModel from "../../model/user.model";
import roleModel from "../../model/role.model";

interface DecodedToken {
    _id: string;
    roleId: string; // Changed to roleId
}

export const adminAuth = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Access denied. No token provided"),
            });
        }

        const token = authHeader.replace("Bearer ", "");

        if (!token) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Access denied. No token provided"),
            });
        }

        if (!process.env.JWT_KEY) {
            return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
                message: MESSAGE.custom("JWT secret key not found"),
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_KEY) as DecodedToken;

        req.user = decoded; // Attach decoded token to the request object
        const userData = await userModel.findOne({
            email: req.user.email
        })

        if (!userData) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("User not found"),
            });
        }
        const existingRole = await roleModel.findById(userData.roleId);
        console.log(existingRole)
		if (!existingRole) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom(`Role with ID '${userData.roleId}' does not exist.`)
			});
		}

        // Check if the user roleId is allowed
        if (![ROLES.super_admin, ROLES.admin].includes(existingRole.name)) {
            return res.status(StatusCodes.FORBIDDEN).json({
                message: MESSAGE.custom("Access denied. You do not have permission to perform this action"),
            });
        }

        req.user.info = userData; // Attach user data to the request object

        next();
    }catch (error: unknown) {
        console.error("Authentication error:", error);

        // Type guard to check if error is an instance of Error
        if (error instanceof Error) {
            return res.status(StatusCodes.UNAUTHORIZED).json({
                message: MESSAGE.custom("Invalid Token!"),
                error: error.message, // Provide only the error message for security
            });
        }

        // Fallback for unexpected error types
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.custom("An unexpected error occurred"),
        });
    }
};

export default adminAuth;
