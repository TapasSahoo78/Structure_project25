import { model } from "mongoose";
import { ICategory } from "../@types/interfaces/category.interface";
import categorySchema from "./schemaDefiniton/category.schema";

const categoryModel = model<ICategory>("categories", categorySchema);

export default categoryModel;
