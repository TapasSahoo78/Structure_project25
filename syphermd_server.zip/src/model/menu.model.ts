import { model } from "mongoose";
import { IMenuSchema } from "../@types/interfaces/menu.interface";
import menuSchema from "./schemaDefiniton/menu.schema";

const menuModel = model<IMenuSchema>("menus", menuSchema);

export default menuModel;
