import { model } from "mongoose";
import { IPage } from "../@types/interfaces/page.interface";
import pageSchema from "./schemaDefiniton/page.schema";

const pageModel = model<IPage>("pages", pageSchema);

export default pageModel;
