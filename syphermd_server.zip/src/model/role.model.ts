import { model } from "mongoose";
import { IRole } from "../@types/interfaces/role.interface";
import roleSchema from "./schemaDefiniton/role.schema";

const roleModel = model<IRole>("roles", roleSchema);

export default roleModel;
