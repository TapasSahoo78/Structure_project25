import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IFaqSchema } from "../../@types/interfaces/faq.interface";

const faqSchema: Schema<IFaqSchema> = new Schema<IFaqSchema>(
	{
		faqCategoryId: {
			type: Schema.Types.ObjectId,
			ref: 'FaqCategory',  // Reference to the FaqCategory model
			required: true
		},
		question: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [5000, "Question cannot be more than 50 characters"]
		},
		answer: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [5000, "Answer cannot be more than 50 characters"]
		},
		is_active: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		is_user: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
		created_date: { ...SCHEMA_DEFINITION_PROPERTY.requiredDate, default: Date.now }
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default faqSchema;
