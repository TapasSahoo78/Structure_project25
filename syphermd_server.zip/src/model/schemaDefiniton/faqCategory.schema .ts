// src/models/Category.ts
import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IfaqCategoryShema } from "../../@types/interfaces/faqCategory.interface"; // Assuming this is where your IfaqCategoryShema interface is defined

const faqCategorySchema: Schema<IfaqCategoryShema> = new Schema<IfaqCategoryShema>(
    {
        name: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            trim: true,
            maxlength: [100, "Category name cannot be more than 100 characters"],
        },
        description: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            maxlength: [500, "Description cannot be more than 500 characters"],
        },
        created_date: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredDate,
            default: Date.now,
        },
        created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
    },
    {
        ...GENERAL_SCHEMA_OPTIONS,
        toJSON: { virtuals: true },
        toObject: { virtuals: true },
    }
);


export default faqCategorySchema;
