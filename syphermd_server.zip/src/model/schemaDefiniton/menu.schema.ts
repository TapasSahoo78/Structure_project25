import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IMenuSchema } from "../../@types/interfaces/menu.interface";

const menuSchema: Schema<IMenuSchema> = new Schema<IMenuSchema>(
	{
		parentIdId: {
			type: Schema.Types.ObjectId,
			ref: 'Menu',
			required: false
		},
		name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Name cannot be more than 100 characters"]
		},
		menu_order: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Menu order cannot be more than 100 characters"]
		},
		link_type: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Link type cannot be more than 100 characters"],
			comment: "	1 => header, 2 => footer"
		},
		pageId: {
			type: Schema.Types.ObjectId,
			ref: 'Page',
			required: false
		},
		menu_group: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Menu group cannot be more than 100 characters"],
			required: false
		},
		menu_link: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Menu link cannot be more than 100 characters"],
			required: false
		},
		is_active: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
		created_date: { ...SCHEMA_DEFINITION_PROPERTY.requiredDate, default: Date.now }
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default menuSchema;
