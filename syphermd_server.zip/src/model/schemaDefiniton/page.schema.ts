// src/models/Role.ts
import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IPage } from "../../@types/interfaces/page.interface"; // Assuming this is where your IPage interface is defined

const pageSchema: Schema<IPage> = new Schema<IPage>(
    {
        title: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            trim: true,
            maxlength: [100, "Role title cannot be more than 100 characters"]
        },
        blocks: [
            {
                title: { ...SCHEMA_DEFINITION_PROPERTY.requiredString },
                subtitle: { ...SCHEMA_DEFINITION_PROPERTY.optionalNullString },
                content: { ...SCHEMA_DEFINITION_PROPERTY.optionalNullString },
                order_number: { ...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber },
                status: { ...SCHEMA_DEFINITION_PROPERTY.requiredBoolean }
            }
        ],
        meta_title: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            trim: true,
            maxlength: [500, "Role title cannot be more than 500 characters"]
        },
        meta_description: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            trim: true,
            maxlength: [1000, "Role title cannot be more than 1000 characters"]
        },
        meta_keywords: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredString,
            trim: true,
            maxlength: [1000, "Role title cannot be more than 1000 characters"]
        },
        created_date: {
            ...SCHEMA_DEFINITION_PROPERTY.requiredDate,
            default: Date.now
        },
        created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
    },
    {
        ...GENERAL_SCHEMA_OPTIONS,
        toJSON: { virtuals: true },
        toObject: { virtuals: true }
    }
);

export default pageSchema;
