// src/models/Role.ts
import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IRole } from "../../@types/interfaces/role.interface"; // Assuming this is where your IRole interface is defined
import { Permission } from "../../@types/types/permission/permission.types"; // Importing the Permission enum

const roleSchema: Schema<IRole> = new Schema<IRole>(
	{
		name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [50, "Role name cannot be more than 50 characters"]
		},
		permissions: {
			type: [String],
			enum: Object.values(Permission), // Assuming permissions are defined in an enum
			required: true
		},
		created_date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
			default: Date.now
		},
		created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default roleSchema;
