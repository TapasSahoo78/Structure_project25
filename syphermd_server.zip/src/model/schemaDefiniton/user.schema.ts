import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { IUser } from "../../@types/interfaces/user.interface";
import { GENDER } from "../../constants/gender/gender";

const userSchema: Schema<IUser> = new Schema<IUser>(
	{
		first_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [50, "First Name cannot be more than 50 characters"]
		},
		middle_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		last_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [50, "Last Name cannot be more than 50 characters"]
		},
		user_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		email: SCHEMA_DEFINITION_PROPERTY.requiredString,
		phone_number: SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		password: SCHEMA_DEFINITION_PROPERTY.requiredString,
		is_disabled: SCHEMA_DEFINITION_PROPERTY.optionalBoolean,
		roleId: {
			type: Schema.Types.ObjectId,
			ref: "Role", // Reference to the Role model
			required: true
		}, // Added roleId to reference the user's role
		gender: { ...SCHEMA_DEFINITION_PROPERTY.optionalNullString, enum: [GENDER.male, GENDER.female, GENDER.others] },
		address_line_1: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		address_line_2: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		city: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		state: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		country: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		ZIP: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		contact_label: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		phone_extension: { ...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber, default: 1 },
		is_registered: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		is_active: SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		last_login_date: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		created_by: SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
		created_date: { ...SCHEMA_DEFINITION_PROPERTY.requiredDate, default: Date.now },
		devices_token: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		otp: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		expiresAt: SCHEMA_DEFINITION_PROPERTY.optionalNullDate
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default userSchema;
