import memberLogModel from "../../model/memberLog.model";
import { getCurrentMongoDBFormattedDate } from "../date/date.service";

export const addMemberActivityLog = async (memberActivityLogPayload: any) => {
	try {
		const employeeActivityLog = {
			roleId: memberActivityLogPayload.roleId,
			email: memberActivityLogPayload.email,
			first_name: memberActivityLogPayload.first_name,
			last_name: memberActivityLogPayload.last_name,
			user_name: memberActivityLogPayload.user_name,
			activity: memberActivityLogPayload.activity,
			status: memberActivityLogPayload.status,
			description: memberActivityLogPayload.description,
			activity_initiated_by: memberActivityLogPayload.activity_initiated_by,
			date: getCurrentMongoDBFormattedDate()
		};

		await new memberLogModel(employeeActivityLog).save();
	} catch (error: any) {
		console.log("Member Activity Log Error", error);
		throw error;
	}
};
