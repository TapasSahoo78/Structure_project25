import prefixCharecterAddition from "./prefixCharecterAddition";

// DATE FORMAT : MM-DD-YYYY
export const dateConverterToUSFormat = (date: string): string => {
	const parsedDate: number = Date.parse(date);
	const _date: Date = new Date(parsedDate);

	const formattedDate =
		prefixCharecterAddition(_date.getMonth() + 1) +
		"-" +
		prefixCharecterAddition(_date.getDate()) +
		"-" +
		_date.getFullYear();

	return formattedDate;
};
