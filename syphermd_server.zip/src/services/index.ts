import {
	isDuplicateGroupOwnerEmailService,
	isDuplicateValueCheckService,
	isRegisteredEmailService,
	isDuplicateUserNameService,
	isRegisteredUsernameService,
	hashPassword,
	comparePassword,
	generateJWT,
	convertCaseInsensitiveForQuery
} from "./auth/auth.service";
import { isValidEmailService, generateId, generateOtp } from "./common/validEmail.service";
import { sendEmail } from "./common/sendEmail.service";
import { isValidUserNameService } from "./common/validUserName.service";
import { initCapitalize } from "./common/initCapitalize";
import {
	addMinutesToDate,
	calculateAge,
	calculateAgeGroup,
	compareDate,
	dateDifference,
	dateTimeZoneConverter,
	formatDate,
	formatDateAsPayload,
	formateMongoDateNotificationService,
	formateMongoDateService,
	getAgeInDays,
	getCurrentMongoDBFormattedDate,
	getFormattedMongoDBDateEmailService,
	isTermDateMoreThanNintyDays
} from "./date/date.service";
import { createMessage } from "./sms/sms.services";

const service = {
	auth: {
		isDuplicateGroupOwnerEmailService,
		isDuplicateValueCheckService,
		isRegisteredEmailService,
		isDuplicateUserNameService,
		isRegisteredUsernameService,
		hashPassword,
		comparePassword,
		generateJWT,
		convertCaseInsensitiveForQuery
	},
	common: {
		isValidEmailService,
		isValidUserNameService,
		initCapitalize,
		generateId,
		generateOtp,
		sendEmail
	},
	date: {
		formateMongoDateService,
		formateMongoDateNotificationService,
		addMinutesToDate,
		compareDate,
		formatDate,
		isTermDateMoreThanNintyDays,
		dateDifference,
		formatDateAsPayload,
		getCurrentMongoDBFormattedDate,
		calculateAge,
		getAgeInDays,
		calculateAgeGroup,
		getFormattedMongoDBDateEmailService,
		dateTimeZoneConverter
	},
	sms: {
		createMessage
	},
};

export default service;
