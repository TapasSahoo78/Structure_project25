// import { promises } from 'dns';
// import admin from 'firebase-admin'; // Import Firebase Admin SDK
// import path from 'path';
// import { sendNotification } from './sendPushNotifaction.services'; // Adjust path as needed

// // Initialize Firebase Admin SDK
// // const serviceAccount = require(path.join(__dirname, 'firebase-adminsdk.json'));

// admin.initializeApp({
// 	credential: admin.credential.cert(serviceAccount),
// });
// // Function to send push notification
// export const sendPushNotification = async (token: string, message: any): Promise<void> => {
// 	const payload = {
// 		notification: {
// 			title: message.title,
// 			body: message.body,
// 		},
// 		token: token, // The device token you want to send the notification to
// 	};

// 	try {
// 		const response = await admin.messaging().send(payload);
// 		console.log('Successfully sent message:', response);
// 	} catch (error) {
// 		console.error('Error sending message:', error);
// 	}
// };

// // Example usage
// const deviceToken = 'YOUR_DEVICE_TOKEN'; // Replace with your device's FCM token
// const message = {
// 	title: 'Hello!',
// 	body: 'This is a test notification.',
// };

