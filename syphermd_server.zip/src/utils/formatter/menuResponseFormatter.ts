// src/utils/responseFormatter.ts
import { IMenuResponse } from '../../@types/interfaces/formatter/menuFormatter.interface';
import { IMenu } from '../../@types/interfaces/menu.interface'; // Assuming you have a category interface
import menuModel from '../../model/menu.model'; // Import the role model

export const formatMenuResponse = async (menu: IMenu): Promise<IMenuResponse> => {
    // Fetch the role name based on roleId
    // const ParentCategory = await categoryModel.findById(category.parent_id);
    // const parent = ParentCategory ? ParentCategory.name : 'None'; // Default if not found
    // const subcategories = await categoryModel.find({
    //     parent_id: category._id
    // }) as ICategory[];

    return {
        _id: menu._id.toString(),
        parentIdId: menu.parentIdId,
        name: menu.name,
        menu_order: menu.menu_order,
        link_type: menu.link_type,
        pageId: menu.pageId,
        menu_group: menu.menu_group,
        menu_link: menu.menu_link,
        is_active: menu.is_active
    };
};

export const formatMenusResponse = async (menus: IMenu[]): Promise<IMenuResponse[]> => {
    // Use Promise.all to fetch roles for all categorys concurrently
    const categoryResponses = await Promise.all(menus.map(async (menu) => {
        // Fetch the role name based on roleId
        // const ParentCategory = await categoryModel.findById(category.parent_id);
        // const parent = ParentCategory ? ParentCategory.name : 'None'; // Default if not found
        // const subcategories = await categoryModel.find({
        //     parent_id: category._id
        // }) as ICategory[];

        return {
            _id: menu._id.toString(),
            parentIdId: menu.parentIdId,
            name: menu.name,
            menu_order: menu.menu_order,
            link_type: menu.link_type,
            pageId: menu.pageId,
            menu_group: menu.menu_group,
            menu_link: menu.menu_link,
            is_active: menu.is_active
        };
    }));

    return categoryResponses; // Return the array of category responses
};
