// src/utils/responseFormatter.ts
import { IPageResponse } from '../../@types/interfaces/formatter/pageFormatter.interface';
import { IPage } from '../../@types/interfaces/page.interface'; // Assuming you have a page interface
import pageModel from '../../model/page.model'; // Import the page model

export const formatPageResponse = async (page: IPage, block_id: string = ''): Promise<IPageResponse> => {
    const filteredBlocks = block_id
        ? (page.blocks || []).filter(block =>
            block.id?.toLowerCase() === block_id.toLowerCase()
        )
        : page.blocks || [];

    return {
        _id: page._id.toString(),
        title: page.title,
        blocks: filteredBlocks,
        meta_title: page.meta_title,
        meta_description: page.meta_description,
        meta_keywords: page.meta_keywords
    };
};

export const formatPagesResponse = async (pages: IPage[]): Promise<IPageResponse[]> => {
    // Use Promise.all to fetch roles for all pages concurrently
    const pageResponses = await Promise.all(pages.map(async (page) => {
        // Fetch the role name based on roleId
        // const ParentCategory = await categoryModel.findById(category.parent_id);
        // const parent = ParentCategory ? ParentCategory.name : 'None'; // Default if not found
        // const subcategories = await categoryModel.find({
        //     parent_id: category._id
        // }) as ICategory[];

        return {
            _id: page._id.toString(),
            title: page.title,
            blocks: page.blocks,
            meta_title: page.meta_title,
            meta_description: page.meta_description,
            meta_keywords: page.meta_keywords
        };
    }));

    return pageResponses; // Return the array of category responses
};
