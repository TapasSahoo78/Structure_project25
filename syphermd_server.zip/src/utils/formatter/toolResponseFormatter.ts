// src/utils/responseFormatter.ts
import { IToolResponse } from '../../@types/interfaces/formatter/toolFormatter.interface';
import { ITool } from '../../@types/interfaces/tool.interface'; // Assuming you have a category interface
import categoryModel from '../../model/category.model'; // Import the role model
import { formatCategoryResponse } from './categoryResponseFormatter';

export const formatToolResponse = async (tool: ITool): Promise<IToolResponse> => {
    const category = await categoryModel.findById(tool.categoryId);
    const categoryName = category ? category.name : null; // Default if not found

    return {
        _id: tool._id.toString(),
        name: tool.name,
        overview: tool.overview,
        updates: tool.updates,
        pros: tool.pros,
        cons: tool.cons,
        pricing: tool.pricing,
        gallery: tool.gallery,
        faq: tool.faq,
        categoryId: tool.categoryId.toString(),
        category: categoryName,
        categoryDetails: (category) ? await formatCategoryResponse(category) : null
    };
};

export const formatToolsResponse = async (tools: ITool[]): Promise<IToolResponse[]> => {
    // Use Promise.all to fetch categories for all tools concurrently
    const toolResponses = await Promise.all(tools.map(async (tool) => {
        // Fetch the category name based on categoryId
        const category = await categoryModel.findById(tool.categoryId);
        const categoryName = category ? category.name : null; // Default if not found

        return {
            _id: tool._id.toString(),
            name: tool.name,
            overview: tool.overview,
            updates: tool.updates,
            pros: tool.pros,
            cons: tool.cons,
            pricing: tool.pricing,
            gallery: tool.gallery,
            faq: tool.faq,
            categoryId: tool.categoryId.toString(),
            category: categoryName,
            categoryDetails: (category) ? await formatCategoryResponse(category) : null
        };
    }));

    return toolResponses; // Return the array of tool responses
};