// src/utils/responseFormatter.ts
import { IUserResponse } from '../../@types/interfaces/formatter/userFormatter.interface';
import { IUser } from '../../@types/interfaces/user.interface'; // Assuming you have a user interface
import roleModel from '../../model/role.model'; // Import the role model

export const formatUserResponse = async (user: IUser): Promise<IUserResponse> => {
    // Fetch the role name based on roleId
    const role = await roleModel.findById(user.roleId);
    const roleName = role ? role.name : 'Unknown Role'; // Default if not found

    return {
        first_name: user.first_name,
        middle_name: user.middle_name,
        last_name: user.last_name,
        user_name: user.user_name,
        password: user.password,
        email: user.email,
        gender: user.gender,
        address_line_1: user.address_line_1,
        address_line_2: user.address_line_2,
        city: user.city,
        state: user.state,
        country: user.country,
        ZIP: user.ZIP,
        contact_label: user.contact_label,
        phone_number: user.phone_number,
        phone_extension: user.phone_extension,
        is_registered: user.is_registered,
        is_active: user.is_active,
        is_disabled: user.is_disabled,
        devices_token: user.devices_token,
        otp: user.otp,
        expiresAt: user.expiresAt,
        last_login_date: user.last_login_date,
        _id: user._id.toString(),
        roleId: user.roleId,
        roleName: roleName, // Include role name in the response
    };
};

export const formatUsersResponse = async (users: IUser[]): Promise<IUserResponse[]> => {
    // Use Promise.all to fetch roles for all users concurrently
    const userResponses = await Promise.all(users.map(async (user) => {
        // Fetch the role name based on roleId
        const role = await roleModel.findById(user.roleId);
        const roleName = role ? role.name : 'Unknown Role'; // Default if not found

        return {
            first_name: user.first_name,
            middle_name: user.middle_name,
            last_name: user.last_name,
            user_name: user.user_name,
            password: user.password,
            email: user.email,
            gender: user.gender,
            address_line_1: user.address_line_1,
            address_line_2: user.address_line_2,
            city: user.city,
            state: user.state,
            country: user.country,
            ZIP: user.ZIP,
            contact_label: user.contact_label,
            phone_number: user.phone_number,
            phone_extension: user.phone_extension,
            is_registered: user.is_registered,
            is_active: user.is_active,
            is_disabled: user.is_disabled,
            devices_token: user.devices_token,
            otp: user.otp,
            expiresAt: user.expiresAt,
            last_login_date: user.last_login_date,
            _id: user._id.toString(),
            roleId: user.roleId,
            roleName: roleName,
        };
    }));

    return userResponses; // Return the array of user responses
};
